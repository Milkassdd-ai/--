<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Fence;
use pocketmine\block\FenceGate;
use pocketmine\block\Stair;
use pocketmine\block\Thin;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\Wall;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\player\Player;
use pocketmine\world\World;

class BlockProcessor {

	private Main $plugin;
	private array $disconnectedBlocks = [];

	public function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}

	public function isConnectableBlock(Block $block): bool {
		return $block instanceof Fence || $block instanceof Wall || $block instanceof Thin;
	}

	public function isRotatableBlock(Block $block): bool {
		if ($block instanceof Stair) return true;
		if ($block instanceof FenceGate) return true;
		return method_exists($block, 'setFacing') && method_exists($block, 'getFacing');
	}

	public function processOneBlock(Block $block, Player $player): string {
		$world = $player->getWorld();
		$pos = $block->getPosition();
		$session = $this->plugin->getSession($player);
		$oldBlock = clone $world->getBlock($pos);

		if ($this->isConnectableBlock($block)) {
			$this->forceDisconnectBlock($world, $pos, $player);
			$session->addSingleUndo($pos, $oldBlock);
			return "disconnected";
		}

		if ($this->isRotatableBlock($block)) {
			$this->forceRotateBlock($world, $pos, $block);
			$session->addSingleUndo($pos, $oldBlock);
			return "rotated";
		}

		return "none";
	}

	public function processPalkeSelection(Player $player): array {
		$session = $this->plugin->getSession($player);
		$bounds = $session->getPalkeSelectionBounds();
		if ($bounds === null) {
			return ['rotated' => 0, 'disconnected' => 0];
		}

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $player->getWorld();
		$rotated = 0;
		$disconnected = 0;
		$undoData = [];

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$block = $world->getBlock($pos);

					if ($block->getTypeId() === BlockTypeIds::AIR) continue;

					$isConnectable = $this->isConnectableBlock($block);
					$isRotatable = $this->isRotatableBlock($block);

					if (!$isConnectable && !$isRotatable) continue;

					$oldBlock = clone $world->getBlock($pos);
					$undoData[] = ['vec' => $pos, 'block' => $oldBlock];

					if ($isConnectable) {
						$this->forceDisconnectBlock($world, $pos, $player);
						$disconnected++;
					} elseif ($isRotatable) {
						$this->forceRotateBlock($world, $pos, $block);
						$rotated++;
					}
				}
			}
		}

		if (!empty($undoData)) {
			$session->saveUndoPublic($undoData);
		}

		return ['rotated' => $rotated, 'disconnected' => $disconnected];
	}

	private function getCleanBlock(Block $block): Block {
		$cleanBlock = clone $block;

		if ($cleanBlock instanceof Thin) {
			try {
				$ref = new \ReflectionClass($cleanBlock);
				$prop = $ref->getProperty('connections');
				$prop->setAccessible(true);
				$prop->setValue($cleanBlock, []);
			} catch (\Throwable $e) {}
		}

		if ($cleanBlock instanceof Fence) {
			try {
				$ref = new \ReflectionClass($cleanBlock);
				$prop = $ref->getProperty('connections');
				$prop->setAccessible(true);
				$prop->setValue($cleanBlock, []);
			} catch (\Throwable $e) {}
		}

		if ($cleanBlock instanceof Wall) {
			try {
				$ref = new \ReflectionClass($cleanBlock);
				$prop = $ref->getProperty('connections');
				$prop->setAccessible(true);
				$prop->setValue($cleanBlock, []);
				if ($ref->hasProperty('post')) {
					$postProp = $ref->getProperty('post');
					$postProp->setAccessible(true);
					$postProp->setValue($cleanBlock, true);
				}
			} catch (\Throwable $e) {}
		}

		return $cleanBlock;
	}

	public function forceDisconnectBlock(World $world, Vector3 $pos, Player $player): void {
		$block = $world->getBlock($pos);
		$cleanBlock = $this->getCleanBlock($block);
		$cleanStateId = $cleanBlock->getStateId();

		$x = (int)$pos->x;
		$y = (int)$pos->y;
		$z = (int)$pos->z;

		$chunkX = $x >> 4;
		$chunkZ = $z >> 4;
		$chunk = $world->getChunk($chunkX, $chunkZ);
		if ($chunk === null) return;

		$subChunkY = $y >> 4;
		$subChunk = $chunk->getSubChunk($subChunkY);
		$localX = $x & 0x0f;
		$localY = $y & 0x0f;
		$localZ = $z & 0x0f;

		$subChunk->setBlockStateId($localX, $localY, $localZ, $cleanStateId);
		$world->setChunk($chunkX, $chunkZ, $chunk);
		$this->sendBlockPacketToAll($world, $pos, $cleanStateId);
		$this->disconnectedBlocks[$this->posKey($world, $pos)] = $cleanStateId;
		$this->resendNeighbors($world, $pos);
	}

	private function resendNeighbors(World $world, Vector3 $pos): void {
		$sides = [$pos->north(), $pos->south(), $pos->east(), $pos->west()];

		foreach ($sides as $nPos) {
			$nBlock = $world->getBlock($nPos);
			if ($nBlock->getTypeId() === BlockTypeIds::AIR) continue;
			if (!$this->isConnectableBlock($nBlock)) continue;

			$key = $this->posKey($world, $nPos);

			if (isset($this->disconnectedBlocks[$key])) {
				$this->sendBlockPacketToAll($world, $nPos, $this->disconnectedBlocks[$key]);
				continue;
			}

			$nX = (int)$nPos->x;
			$nY = (int)$nPos->y;
			$nZ = (int)$nPos->z;
			$ourX = (int)$pos->x;
			$ourY = (int)$pos->y;
			$ourZ = (int)$pos->z;

			$ourChunkX = $ourX >> 4;
			$ourChunkZ = $ourZ >> 4;
			$ourChunk = $world->getChunk($ourChunkX, $ourChunkZ);
			if ($ourChunk === null) continue;

			$ourSubChunk = $ourChunk->getSubChunk($ourY >> 4);
			$ourLocalX = $ourX & 0x0f;
			$ourLocalY = $ourY & 0x0f;
			$ourLocalZ = $ourZ & 0x0f;

			$savedState = $ourSubChunk->getBlockStateId($ourLocalX, $ourLocalY, $ourLocalZ);
			$airStateId = VanillaBlocks::AIR()->getStateId();
			$ourSubChunk->setBlockStateId($ourLocalX, $ourLocalY, $ourLocalZ, $airStateId);

			$world->setBlockAt($nX, $nY, $nZ, VanillaBlocks::AIR(), false);
			$world->setBlockAt($nX, $nY, $nZ, $nBlock, false);

			$updatedNeighborStateId = $world->getBlock($nPos)->getStateId();
			$ourSubChunk->setBlockStateId($ourLocalX, $ourLocalY, $ourLocalZ, $savedState);
			$this->sendBlockPacketToAll($world, $nPos, $updatedNeighborStateId);
		}
	}

	public function sendBlockPacketToAll(World $world, Vector3 $pos, int $stateId): void {
		$blockPos = BlockPosition::fromVector3($pos);
		foreach ($world->getPlayers() as $p) {
			try {
				$networkId = $p->getNetworkSession()->getTypeConverter()->getBlockTranslator()->internalIdToNetworkId($stateId);
				$p->getNetworkSession()->sendDataPacket(UpdateBlockPacket::create(
					$blockPos,
					$networkId,
					UpdateBlockPacket::FLAG_NETWORK,
					UpdateBlockPacket::DATA_LAYER_NORMAL
				));
			} catch (\Throwable $e) {}
		}
	}

	public function forceRotateBlock(World $world, Vector3 $pos, Block $block): void {
		if (!method_exists($block, 'setFacing') || !method_exists($block, 'getFacing')) return;

		try {
			$currentFacing = $block->getFacing();
			$order = [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST];
			$verticalOrder = [Facing::UP, Facing::DOWN];

			$idx = array_search($currentFacing, $order, true);
			if ($idx !== false) {
				$nextIdx = ($idx + 1) % count($order);
				$block->setFacing($order[$nextIdx]);
				$this->safeSetBlockAt($world, (int)$pos->x, (int)$pos->y, (int)$pos->z, $block);
				$this->sendBlockPacketToAll($world, $pos, $block->getStateId());
				return;
			}

			$idx = array_search($currentFacing, $verticalOrder, true);
			if ($idx !== false) {
				$nextIdx = ($idx + 1) % count($verticalOrder);
				$block->setFacing($verticalOrder[$nextIdx]);
				$this->safeSetBlockAt($world, (int)$pos->x, (int)$pos->y, (int)$pos->z, $block);
				$this->sendBlockPacketToAll($world, $pos, $block->getStateId());
			}
		} catch (\Throwable $e) {}
	}

	private function safeSetBlockAt(World $world, int $x, int $y, int $z, Block $block): void {
		$stateId = $block->getStateId();
		try {
			$world->setBlockAt($x, $y, $z, $block, false);
			return;
		} catch (\Throwable $e) {}

		$chunkX = $x >> 4;
		$chunkZ = $z >> 4;
		$chunk = $world->getChunk($chunkX, $chunkZ);
		if ($chunk === null) return;

		$subChunk = $chunk->getSubChunk($y >> 4);
		$subChunk->setBlockStateId($x & 0x0f, $y & 0x0f, $z & 0x0f, $stateId);
		$world->setChunk($chunkX, $chunkZ, $chunk);
	}

	public function posKey(World $world, Vector3 $pos): string {
		return $world->getFolderName() . ":" . (int)$pos->x . ":" . (int)$pos->y . ":" . (int)$pos->z;
	}
}
