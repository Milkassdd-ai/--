<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class EventListener implements Listener {

	private Main $plugin;
	private BlockProcessor $processor;

	public function __construct(Main $plugin, BlockProcessor $processor) {
		$this->plugin = $plugin;
		$this->processor = $processor;
	}

	public function onQuit(PlayerQuitEvent $event): void {
		$this->plugin->removeSession($event->getPlayer()->getName());
	}

	public function onInteract(PlayerInteractEvent $event): void {
		$player = $event->getPlayer();
		$item = $event->getItem();
		$block = $event->getBlock();
		$action = $event->getAction();

		if (!$player->hasPermission("rcedit.use")) return;

		$session = $this->plugin->getSession($player);

		if ($session->isIdMode()) {
			if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK || $action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
				$event->cancel();
				$pos = $block->getPosition();
				$player->sendMessage(Message::PREFIX . "Блок: " . TF::YELLOW . $block->getName());
				$player->sendMessage(Message::PREFIX . "TypeID: " . TF::WHITE . $block->getTypeId() . TF::GRAY . " | StateID: " . TF::WHITE . $block->getStateId());
				$player->sendMessage(Message::PREFIX . "Позиция: " . TF::WHITE . Helpers::vecStr($pos));
			}
			return;
		}

		if ($item->getNamedTag()->getTag("RcPalke") !== null) {
			if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
				$event->cancel();
				$session->setPalkePos1($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Палка Точка 1: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendPalkeInfo($player, $session);
				return;
			}

			if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
				$event->cancel();

				if (!$session->hasPalkePos1()) {
					$result = $this->processor->processOneBlock($block, $player);
					if ($result === "rotated") {
						$player->sendMessage(Message::SUCCESS . "Блок повёрнут: " . TF::WHITE . $block->getName());
					} elseif ($result === "disconnected") {
						$player->sendMessage(Message::SUCCESS . "Блок отсоединён: " . TF::WHITE . $block->getName());
					} else {
						$player->sendMessage(Message::ERR . "Этот блок нельзя повернуть/отсоединить.");
					}
					return;
				}

				$session->setPalkePos2($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Палка Точка 2: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendPalkeInfo($player, $session);
				return;
			}
			return;
		}

		if ($item->getTypeId() === VanillaItems::GOLDEN_AXE()->getTypeId()) {
			if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
				$event->cancel();
				$session->setPos1($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Точка 1: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendSelectionInfo($player, $session);
			} elseif ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
				$event->cancel();
				$session->setPos2($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Точка 2: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendSelectionInfo($player, $session);
			}
		}
	}

	public function onBreak(BlockBreakEvent $event): void {
		$player = $event->getPlayer();
		$item = $event->getItem();

		if (!$player->hasPermission("rcedit.use")) return;

		$session = $this->plugin->getSession($player);

		if ($session->isIdMode()) {
			$event->cancel();
			return;
		}
		if ($item->getNamedTag()->getTag("RcPalke") !== null) {
			$event->cancel();
			return;
		}
		if ($item->getTypeId() === VanillaItems::GOLDEN_AXE()->getTypeId()) {
			$event->cancel();
		}
	}

	private function sendSelectionInfo(Player $player, Session $session): void {
		if (!$session->hasSelection()) return;
		$bounds = $session->getSelectionBounds();
		$min = $bounds['min'];
		$max = $bounds['max'];
		$sx = (int)($max->x - $min->x + 1);
		$sy = (int)($max->y - $min->y + 1);
		$sz = (int)($max->z - $min->z + 1);
		$player->sendMessage(Message::PREFIX . "Размер: " . TF::WHITE . "{$sx}x{$sy}x{$sz}" . TF::GRAY . " (" . ($sx * $sy * $sz) . " блоков)");
	}

	private function sendPalkeInfo(Player $player, Session $session): void {
		if (!$session->hasPalkeSelection()) return;
		$bounds = $session->getPalkeSelectionBounds();
		$min = $bounds['min'];
		$max = $bounds['max'];
		$sx = (int)($max->x - $min->x + 1);
		$sy = (int)($max->y - $min->y + 1);
		$sz = (int)($max->z - $min->z + 1);
		$player->sendMessage(Message::PREFIX . "Палка выделение: " . TF::WHITE . "{$sx}x{$sy}x{$sz}" . TF::GRAY . " (" . ($sx * $sy * $sz) . " блоков)");
		$player->sendMessage(Message::PREFIX . "Используйте /rcsetp для обработки.");
	}
}
