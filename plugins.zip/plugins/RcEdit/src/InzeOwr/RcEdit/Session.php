<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\World;

class Session {

	private Player $player;
	private Main $plugin;

	private ?Vector3 $pos1 = null;
	private ?Vector3 $pos2 = null;
	private ?Vector3 $palkePos1 = null;
	private ?Vector3 $palkePos2 = null;

	private array $clipboard = [];
	private ?array $clipboardSize = null;
	private array $undoStack = [];
	private array $redoStack = [];
	private bool $idMode = false;

	private const MAX_UNDO = 50;

	public function __construct(Player $player, Main $plugin) {
		$this->player = $player;
		$this->plugin = $plugin;
	}

	private function safeSetBlock(World $world, Vector3 $pos, Block $block): void {
		$stateId = $block->getStateId();
		$x = (int)$pos->x;
		$y = (int)$pos->y;
		$z = (int)$pos->z;

		try {
			$world->setBlock($pos, $block, false);
			return;
		} catch (\Throwable $e) {}

		$chunkX = $x >> 4;
		$chunkZ = $z >> 4;
		$chunk = $world->getChunk($chunkX, $chunkZ);
		if ($chunk === null) return;

		$subChunk = $chunk->getSubChunk($y >> 4);
		$subChunk->setBlockStateId($x & 0x0f, $y & 0x0f, $z & 0x0f, $stateId);
		$world->setChunk($chunkX, $chunkZ, $chunk);
	}

	public function setPos1(Vector3 $pos): void { $this->pos1 = $pos->floor(); }
	public function setPos2(Vector3 $pos): void { $this->pos2 = $pos->floor(); }
	public function getPos1(): ?Vector3 { return $this->pos1; }
	public function getPos2(): ?Vector3 { return $this->pos2; }

	public function hasSelection(): bool {
		return $this->pos1 !== null && $this->pos2 !== null;
	}

	public function getSelectionBounds(): ?array {
		if (!$this->hasSelection()) return null;
		return [
			'min' => new Vector3(
				min($this->pos1->x, $this->pos2->x),
				min($this->pos1->y, $this->pos2->y),
				min($this->pos1->z, $this->pos2->z)
			),
			'max' => new Vector3(
				max($this->pos1->x, $this->pos2->x),
				max($this->pos1->y, $this->pos2->y),
				max($this->pos1->z, $this->pos2->z)
			)
		];
	}

	public function setPalkePos1(Vector3 $pos): void { $this->palkePos1 = $pos->floor(); }
	public function setPalkePos2(Vector3 $pos): void { $this->palkePos2 = $pos->floor(); }
	public function hasPalkePos1(): bool { return $this->palkePos1 !== null; }

	public function hasPalkeSelection(): bool {
		return $this->palkePos1 !== null && $this->palkePos2 !== null;
	}

	public function getPalkeSelectionBounds(): ?array {
		if (!$this->hasPalkeSelection()) return null;
		return [
			'min' => new Vector3(
				min($this->palkePos1->x, $this->palkePos2->x),
				min($this->palkePos1->y, $this->palkePos2->y),
				min($this->palkePos1->z, $this->palkePos2->z)
			),
			'max' => new Vector3(
				max($this->palkePos1->x, $this->palkePos2->x),
				max($this->palkePos1->y, $this->palkePos2->y),
				max($this->palkePos1->z, $this->palkePos2->z)
			)
		];
	}

	public function clearPalkeSelection(): void {
		$this->palkePos1 = null;
		$this->palkePos2 = null;
	}

	public function hasClipboard(): bool { return !empty($this->clipboard); }

	public function isIdMode(): bool { return $this->idMode; }

	public function toggleIdMode(): bool {
		$this->idMode = !$this->idMode;
		return $this->idMode;
	}

	private function saveUndo(array $blocks): void {
		if (empty($blocks)) return;
		$this->undoStack[] = $blocks;
		$this->redoStack = [];
		while (count($this->undoStack) > self::MAX_UNDO) {
			array_shift($this->undoStack);
		}
	}

	public function saveUndoPublic(array $blocks): void { $this->saveUndo($blocks); }

	public function addSingleUndo(Vector3 $pos, Block $oldBlock): void {
		$this->saveUndo([['vec' => $pos, 'block' => $oldBlock]]);
	}

	public function undo(): bool {
		if (empty($this->undoStack)) return false;
		$lastAction = array_pop($this->undoStack);
		$redoAction = [];
		$world = $this->player->getWorld();

		foreach ($lastAction as $data) {
			$pos = $data['vec'];
			$redoAction[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
			$this->safeSetBlock($world, $pos, $data['block']);
		}
		$this->redoStack[] = $redoAction;
		return true;
	}

	public function redo(): bool {
		if (empty($this->redoStack)) return false;
		$lastUndo = array_pop($this->redoStack);
		$undoAction = [];
		$world = $this->player->getWorld();

		foreach ($lastUndo as $data) {
			$pos = $data['vec'];
			$undoAction[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
			$this->safeSetBlock($world, $pos, $data['block']);
		}
		$this->undoStack[] = $undoAction;
		return true;
	}

	public function fillSelection(Block $block): int {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();
		$undoData = [];
		$count = 0;

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$oldBlock = $world->getBlock($pos);
					if ($oldBlock->isSameState($block)) continue;
					$undoData[] = ['vec' => $pos, 'block' => $oldBlock];
					$this->safeSetBlock($world, $pos, $block);
					$count++;
				}
			}
		}
		$this->saveUndo($undoData);
		return $count;
	}

	public function copy(): int {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();
		$this->clipboard = [];

		$this->clipboardSize = [
			'sizeX' => (int)($max->x - $min->x + 1),
			'sizeY' => (int)($max->y - $min->y + 1),
			'sizeZ' => (int)($max->z - $min->z + 1)
		];

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$this->clipboard[] = [
						'vec' => new Vector3($x - (int)$min->x, $y - (int)$min->y, $z - (int)$min->z),
						'block' => clone $world->getBlock($pos)
					];
				}
			}
		}
		return count($this->clipboard);
	}

	public function pasteToSelection(): int {
		if (empty($this->clipboard)) return 0;
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$pasteMin = $bounds['min'];
		$world = $this->player->getWorld();
		$undoData = [];
		$count = 0;

		foreach ($this->clipboard as $entry) {
			$pastePos = new Vector3(
				(int)$pasteMin->x + (int)$entry['vec']->x,
				(int)$pasteMin->y + (int)$entry['vec']->y,
				(int)$pasteMin->z + (int)$entry['vec']->z
			);
			$oldBlock = $world->getBlock($pastePos);
			if ($oldBlock->isSameState($entry['block'])) continue;
			$undoData[] = ['vec' => $pastePos, 'block' => $oldBlock];
			$this->safeSetBlock($world, $pastePos, $entry['block']);
			$count++;
		}
		$this->saveUndo($undoData);
		return $count;
	}

	public function pasteAtPlayer(): int {
		if (empty($this->clipboard)) return 0;

		$playerPos = $this->player->getPosition()->floor();
		$world = $this->player->getWorld();
		$undoData = [];
		$count = 0;

		foreach ($this->clipboard as $entry) {
			$pastePos = new Vector3(
				(int)$playerPos->x + (int)$entry['vec']->x,
				(int)$playerPos->y + (int)$entry['vec']->y,
				(int)$playerPos->z + (int)$entry['vec']->z
			);
			$oldBlock = $world->getBlock($pastePos);
			if ($oldBlock->isSameState($entry['block'])) continue;
			$undoData[] = ['vec' => $pastePos, 'block' => $oldBlock];
			$this->safeSetBlock($world, $pastePos, $entry['block']);
			$count++;
		}
		$this->saveUndo($undoData);
		return $count;
	}

	public function saveSchematic(string $name): bool {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return false;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();
		$data = [
			'sizeX' => (int)($max->x - $min->x + 1),
			'sizeY' => (int)($max->y - $min->y + 1),
			'sizeZ' => (int)($max->z - $min->z + 1),
			'blocks' => []
		];

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$block = $world->getBlock($pos);
					$data['blocks'][] = [
						'rx' => $x - (int)$min->x,
						'ry' => $y - (int)$min->y,
						'rz' => $z - (int)$min->z,
						'sid' => $block->getStateId()
					];
				}
			}
		}

		$path = $this->plugin->getSchematicsPath() . $name . ".json";
		$json = json_encode($data, JSON_UNESCAPED_UNICODE);
		return $json !== false && file_put_contents($path, $json) !== false;
	}

	public function loadSchematic(string $name): bool {
		$path = $this->plugin->getSchematicsPath() . $name . ".json";
		if (!file_exists($path)) return false;

		$content = file_get_contents($path);
		if ($content === false) return false;

		$data = json_decode($content, true);
		if ($data === null || !isset($data['blocks'], $data['sizeX'])) return false;

		$this->clipboard = [];
		$this->clipboardSize = [
			'sizeX' => (int)$data['sizeX'],
			'sizeY' => (int)$data['sizeY'],
			'sizeZ' => (int)$data['sizeZ']
		];

		$registry = RuntimeBlockStateRegistry::getInstance();
		foreach ($data['blocks'] as $entry) {
			$stateId = (int)$entry['sid'];
			try {
				$block = $registry->fromStateId($stateId);
			} catch (\Throwable $e) {
				$block = VanillaBlocks::AIR();
			}
			$this->clipboard[] = [
				'vec' => new Vector3((int)$entry['rx'], (int)$entry['ry'], (int)$entry['rz']),
				'block' => $block
			];
		}
		return !empty($this->clipboard);
	}

	public function rotateClipboard(int $direction): void {
		if (empty($this->clipboard) || $this->clipboardSize === null) return;

		$maxX = $this->clipboardSize['sizeX'] - 1;
		$maxZ = $this->clipboardSize['sizeZ'] - 1;
		$newClipboard = [];

		foreach ($this->clipboard as $entry) {
			$x = (int)$entry['vec']->x;
			$y = (int)$entry['vec']->y;
			$z = (int)$entry['vec']->z;
			$block = clone $entry['block'];

			$newX = $x;
			$newZ = $z;
			if ($direction === 1) { $newX = $maxZ - $z; $newZ = $x; }
			elseif ($direction === 2) { $newX = $z; $newZ = $maxX - $x; }
			elseif ($direction === 3) { $newX = $maxX - $x; $newZ = $maxZ - $z; }

			$this->rotateBlockFacing($block, $direction);
			$newClipboard[] = ['vec' => new Vector3($newX, $y, $newZ), 'block' => $block];
		}

		$this->clipboard = $newClipboard;
		if ($direction === 1 || $direction === 2) {
			$old = $this->clipboardSize['sizeX'];
			$this->clipboardSize['sizeX'] = $this->clipboardSize['sizeZ'];
			$this->clipboardSize['sizeZ'] = $old;
		}
	}

	private function rotateBlockFacing(Block $block, int $direction): void {
		if (!method_exists($block, 'setFacing') || !method_exists($block, 'getFacing')) return;
		try {
			$f = $block->getFacing();
			$hor = [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST];
			if (!in_array($f, $hor, true)) return;

			$cw  = [Facing::NORTH => Facing::EAST, Facing::EAST => Facing::SOUTH, Facing::SOUTH => Facing::WEST, Facing::WEST => Facing::NORTH];
			$ccw = [Facing::NORTH => Facing::WEST, Facing::WEST => Facing::SOUTH, Facing::SOUTH => Facing::EAST, Facing::EAST => Facing::NORTH];
			$fl  = [Facing::NORTH => Facing::SOUTH, Facing::SOUTH => Facing::NORTH, Facing::EAST => Facing::WEST, Facing::WEST => Facing::EAST];

			if ($direction === 1 && isset($cw[$f]))  $block->setFacing($cw[$f]);
			elseif ($direction === 2 && isset($ccw[$f])) $block->setFacing($ccw[$f]);
			elseif ($direction === 3 && isset($fl[$f]))  $block->setFacing($fl[$f]);
		} catch (\Throwable $e) {}
	}

	public function connectPattern(array $pattern, int $mode): int {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();
		$undoData = [];
		$count = 0;

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$isWall = ($x == (int)$min->x || $x == (int)$max->x || $z == (int)$min->z || $z == (int)$max->z);
					$isFloorCeil = ($y == (int)$min->y || $y == (int)$max->y);

					$place = ($mode === 3) || ($mode === 2 && $isFloorCeil) || ($mode === 1 && $isWall);
					if (!$place) continue;

					$sel = $this->pickRandomBlock($pattern);
					$this->randomizeFacing($sel);

					$pos = new Vector3($x, $y, $z);
					$undoData[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
					$this->safeSetBlock($world, $pos, $sel);
					$count++;
				}
			}
		}
		$this->saveUndo($undoData);
		return $count;
	}

	private function pickRandomBlock(array $pattern): Block {
		$total = 0;
		foreach ($pattern as $item) $total += $item['chance'];
		$rand = mt_rand(1, max(1, (int)$total));
		$cur = 0;
		foreach ($pattern as $item) {
			$cur += $item['chance'];
			if ($rand <= $cur) return clone $item['block'];
		}
		return clone $pattern[0]['block'];
	}

	private function randomizeFacing(Block $block): void {
		$f = [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST];
		if (method_exists($block, 'setFacing')) {
			try { $block->setFacing($f[array_rand($f)]); } catch (\Throwable $e) {}
		}
	}
}
