<?php

namespace InzeOwr\RcMarry;

use pocketmine\entity\Entity;
use pocketmine\entity\Human;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\event\entity\EntityDamageEvent;

class MarryNpcEntity extends Human {

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setNameTagAlwaysVisible(true);
        $this->setScale(1.0);
    }

    public function getSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.8, 0.6, 1.62);
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
    }

    public function canBeCollidedWith(): bool {
        return false;
    }

    public function canCollideWith(Entity $entity): bool {
        return false;
    }

    public function canBeMovedByCurrents(): bool {
        return false;
    }

    public function canSaveWithChunk(): bool {
        return true;
    }

    public function onUpdate(int $currentTick): bool {
        return parent::onUpdate($currentTick);
    }
}