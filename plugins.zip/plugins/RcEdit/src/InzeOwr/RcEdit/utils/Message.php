<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit\utils;

use pocketmine\utils\TextFormat as TF;

/**
 * Константы префиксов для сообщений.
 */
final class Message {

	public const PREFIX = TF::BOLD . TF::AQUA . "RcEdit" . TF::DARK_GRAY . " » " . TF::RESET . TF::GRAY;
	public const SUCCESS = TF::BOLD . TF::GREEN . "RcEdit" . TF::DARK_GRAY . " » " . TF::RESET . TF::GREEN;
	public const ERR = TF::BOLD . TF::RED . "RcEdit" . TF::DARK_GRAY . " » " . TF::RESET . TF::RED;

	private function __construct() {
		// NOOP
	}
}
