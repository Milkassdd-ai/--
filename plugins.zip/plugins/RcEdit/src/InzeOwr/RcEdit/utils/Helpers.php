<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit\utils;

use pocketmine\math\Vector3;

/**
 * Общие вспомогательные методы.
 */
final class Helpers {

	private function __construct() {
		// NOOP
	}

	public static function vecStr(Vector3 $v): string {
		return (int)$v->x . ", " . (int)$v->y . ", " . (int)$v->z;
	}
}
