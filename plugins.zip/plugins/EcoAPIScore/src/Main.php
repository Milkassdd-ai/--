<?php

declare(strict_types=1);

namespace Ifera\EcoAPIScore;

use Ifera\EcoAPIScore\listeners\EventListener;
use Ifera\EcoAPIScore\listeners\TagResolveListener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

class Main extends PluginBase implements Listener { // implements Listener добавлен

    public function onEnable(): void { // void добавлен
        $pluginManager = $this->getServer()->getPluginManager(); // Получаем PluginManager

        $pluginManager->registerEvents(new EventListener($this), $this); // Регистрация EventListener
        $pluginManager->registerEvents(new TagResolveListener($this), $this); // Регистрация TagResolveListener
    }
}