<?php

declare(strict_types=1);

namespace InzeOwr\RcInv;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;
use pocketmine\item\Item;

class Main extends PluginBase implements Listener
{
    private Config $limitsConfig;

    /** @var array */
    private array $staffGroups = [];

    /** @var array */
    private array $limitedGroups = [];

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->validateConfig();

        @mkdir($this->getDataFolder() . "data/", 0777, true);

        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);

        $this->staffGroups = $this->getConfig()->get("staff_groups", []);
        $this->limitedGroups = $this->getConfig()->get("limited_groups", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
    }

    private function validateConfig(): void
    {
        $config = $this->getConfig();
        $changed = false;

        $defaults = [
            "log_actions" => true,
            "broadcast_clear" => true,
            "self_clear_protection" => true,
            "staff_groups" => [
                "CREATOR", "OWNER", "GLADMIN", "CURATOR",
                "SADMIN", "ADMIN", "MANAGER", "SMODER", "MODER"
            ],
            "limited_groups" => [
                "MIRAGE" => [
                    "max_clears" => 5,
                    "cooldown_hours" => 24,
                    "can_see" => true
                ],
                "SPARK" => [
                    "max_clears" => 10,
                    "cooldown_hours" => 24,
                    "can_see" => true
                ]
            ]
        ];

        foreach ($defaults as $key => $value) {
            if (!$config->exists($key)) {
                $config->set($key, $value);
                $changed = true;
                $this->getLogger()->warning("Ключ '$key' отсутствовал в конфиге — добавлен со значением по умолчанию.");
            }
        }

        if ($changed) {
            $config->save();
            $this->getLogger()->info(TF::GREEN . "Конфиг обновлён с недостающими ключами.");
        }
    }

    protected function onDisable(): void
    {
        $this->limitsConfig->save();
    }

    // ==================== УТИЛИТЫ ====================

    private function getTimeRemaining(int $expireTimestamp): string
    {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return "истёк";
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $minutes = floor(($diff % 3600) / 60);
        $seconds = $diff % 60;
        $parts = [];
        if ($days > 0) $parts[] = $days . " дн.";
        if ($hours > 0) $parts[] = $hours . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0) $parts[] = $seconds . " сек.";
        return implode(" ", $parts);
    }

    private function findPlayer(string $name): ?Player
    {
        $name = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }
        return $found;
    }

    private function getAdminName(CommandSender $sender): string
    {
        return $sender instanceof Player ? $sender->getName() : "Console";
    }

    private function broadcast(string $message): void
    {
        if ($this->getConfig()->get("broadcast_clear", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function logAction(string $message): void
    {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(TF::clean($message));
        }
    }

    // ==================== RcGroup ИНТЕГРАЦИЯ ====================

    private function getRcGroup(): ?\InzeOwr\RcGroup\Main
    {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    private function getPlayerGroup(string $nickname): string
    {
        $rcGroup = $this->getRcGroup();
        if ($rcGroup === null) return "";
        return $rcGroup->getGroup($nickname);
    }

    private function isStaff(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return false;
        return in_array($group, $this->staffGroups, true);
    }

    private function getLimitedConfig(string $nickname): ?array
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        if (isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group])) {
            return $this->limitedGroups[$group];
        }
        return null;
    }

    private function isLimited(string $nickname): bool
    {
        return $this->getLimitedConfig($nickname) !== null;
    }

    // ==================== ПРОВЕРКИ ====================

    private function checkStaffProtection(CommandSender $sender, string $targetName): bool
    {
        if (!($sender instanceof Player)) return true;

        if ($this->isStaff($targetName)) {
            $sender->sendMessage("§c[RcInv] Вы не можете выполнить это действие с сотрудником проекта!");
            return false;
        }

        return true;
    }

    private function checkSelfClear(CommandSender $sender, string $targetName): bool
    {
        if ($this->getConfig()->get("self_clear_protection", true)) {
            if ($sender instanceof Player && strtolower($sender->getName()) === strtolower($targetName)) {
                $sender->sendMessage("§c[RcInv] Вы не можете очистить свой инвентарь этой командой!");
                return false;
            }
        }
        return true;
    }

    private function checkBypass(CommandSender $sender, string $targetName): bool
    {
        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer !== null && $targetPlayer->hasPermission("rcinv.bypass")) {
            $sender->sendMessage("§c[RcInv] Этот игрок защищён от очистки инвентаря!");
            return false;
        }
        return true;
    }

    private function canClearTarget(CommandSender $sender, string $targetName): bool
    {
        if (!$this->checkSelfClear($sender, $targetName)) return false;
        if (!$this->checkBypass($sender, $targetName)) return false;
        if (!$this->checkStaffProtection($sender, $targetName)) return false;
        return true;
    }

    private function canSeeInventory(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();

        if ($this->isStaff($senderName)) return true;

        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg !== null) {
            return (bool)($limitCfg["can_see"] ?? false);
        }

        return false;
    }

    private function checkAndUseClearLimit(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();

        if ($this->isStaff($senderName)) return true;

        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxClears = (int)($limitCfg["max_clears"] ?? 0);
        $cooldownHours = (int)($limitCfg["cooldown_hours"] ?? 24);
        if ($maxClears <= 0) return true;

        $senderKey = strtolower($senderName);
        $limitsData = $this->limitsConfig->get($senderKey, null);

        if ($limitsData === null || !is_array($limitsData)) {
            $limitsData = [
                "clears_used" => 0,
                "period_start" => time()
            ];
        }

        $periodStart = (int)($limitsData["period_start"] ?? time());
        $clearsUsed = (int)($limitsData["clears_used"] ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $clearsUsed = 0;
            $periodStart = time();
        }

        if ($clearsUsed >= $maxClears) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->getTimeRemaining($resetTime);
            $sender->sendMessage("§c[RcInv] Вы исчерпали лимит очисток (§e" . $maxClears . "§c)! Сброс через: §e" . $remaining);
            return false;
        }

        $clearsUsed++;
        $this->limitsConfig->set($senderKey, [
            "clears_used" => $clearsUsed,
            "period_start" => $periodStart
        ]);
        $this->limitsConfig->save();

        $left = $maxClears - $clearsUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->getTimeRemaining($resetTime);
        $sender->sendMessage("§e[RcInv] Использовано очисток: §c" . $clearsUsed . "/" . $maxClears . "§e. Осталось: §c" . $left . "§e. Сброс через: §c" . $remaining);

        return true;
    }

    // ==================== ФОРМЫ ====================

    private function getItemDisplayName(Item $item): string
    {
        if ($item->isNull()) return "";

        $name = $item->getName();
        $count = $item->getCount();

        $result = "§f" . $name;
        if ($count > 1) {
            $result .= " §7x" . $count;
        }

        if ($item->hasEnchantments()) {
            $enchNames = [];
            foreach ($item->getEnchantments() as $enchInstance) {
                $enchNames[] = $enchInstance->getType()->getName() . " " . $enchInstance->getLevel();
            }
            $result .= "\n§d" . implode(", ", $enchNames);
        }

        if ($item->hasCustomName()) {
            $result = "§e" . $item->getCustomName() . " §7(" . $name . ")";
            if ($count > 1) {
                $result .= " §7x" . $count;
            }
        }

        return $result;
    }

    private function sendInventoryForm(Player $viewer, Player $target): void
    {
        $targetName = $target->getName();
        $inventory = $target->getInventory();
        $armorInventory = $target->getArmorInventory();

        $content = "";

        // Броня
        $content .= "§l§6═══ Броня ═══§r\n";
        $armorSlotNames = ["Шлем", "Нагрудник", "Поножи", "Ботинки"];
        $armorItems = $armorInventory->getContents();
        $hasArmor = false;

        for ($i = 0; $i < 4; $i++) {
            if (isset($armorItems[$i]) && !$armorItems[$i]->isNull()) {
                $content .= "§e" . $armorSlotNames[$i] . ": " . $this->getItemDisplayName($armorItems[$i]) . "\n";
                $hasArmor = true;
            }
        }

        if (!$hasArmor) {
            $content .= "§7Пусто\n";
        }

        // В руке
        $content .= "\n§l§6═══ В руке ═══§r\n";
        $handItem = $inventory->getItemInHand();
        if (!$handItem->isNull()) {
            $content .= $this->getItemDisplayName($handItem) . "\n";
        } else {
            $content .= "§7Пусто\n";
        }

        // Вторая рука
        $offhand = $target->getOffHandInventory()->getItem(0);
        if (!$offhand->isNull()) {
            $content .= "\n§l§6═══ Вторая рука ═══§r\n";
            $content .= $this->getItemDisplayName($offhand) . "\n";
        }

        // Инвентарь
        $content .= "\n§l§6═══ Инвентарь ═══§r\n";
        $invItems = $inventory->getContents();
        $hasItems = false;

        foreach ($invItems as $slot => $item) {
            if (!$item->isNull()) {
                $content .= "§7[" . ($slot + 1) . "] " . $this->getItemDisplayName($item) . "\n";
                $hasItems = true;
            }
        }

        if (!$hasItems) {
            $content .= "§7Пусто\n";
        }

        // Подсчёт
        $totalItems = 0;
        $totalCount = 0;
        foreach ($invItems as $item) {
            if (!$item->isNull()) {
                $totalItems++;
                $totalCount += $item->getCount();
            }
        }
        foreach ($armorItems as $item) {
            if (!$item->isNull()) {
                $totalItems++;
                $totalCount += $item->getCount();
            }
        }
        if (!$offhand->isNull()) {
            $totalItems++;
            $totalCount += $offhand->getCount();
        }

        $content .= "\n§eВсего: §c" . $totalItems . " §eпредметов (§c" . $totalCount . " §eшт.)";

        $group = $this->getPlayerGroup($targetName);
        $groupStr = $group !== "" ? " §7[" . $group . "]" : "";

        $formData = [
            "type" => "form",
            "title" => "§l§eИнвентарь игрока §c" . $targetName . $groupStr,
            "content" => $content,
            "buttons" => [
                ["text" => "§cЗакрыть"]
            ]
        ];

        $form = new class($formData) implements \pocketmine\form\Form {
            private array $data;

            public function __construct(array $data)
            {
                $this->data = $data;
            }

            public function jsonSerialize(): mixed
            {
                return $this->data;
            }

            public function handleResponse(Player $player, $data): void
            {
                // Закрытие формы
            }
        };

        $viewer->sendForm($form);
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch (strtolower($command->getName())) {
            case "rcinvsee": return $this->handleInvSee($sender, $args);
            case "rccrinv": return $this->handleClearInv($sender, $args);
        }
        return false;
    }

    // ===== /rcinvsee =====
    private function handleInvSee(CommandSender $sender, array $args): bool
    {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§c[RcInv] Команда доступна только игрокам!");
            return true;
        }

        if (count($args) < 1) {
            $sender->sendMessage("§c[RcInv] Использование: /rcinvsee <ник>");
            return true;
        }

        if (!$this->canSeeInventory($sender)) {
            $sender->sendMessage("§c[RcInv] У вас нет доступа к просмотру инвентаря!");
            return true;
        }

        $targetInput = $args[0];

        $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer === null) {
            $sender->sendMessage("§c[RcInv] Игрок " . $targetInput . " не найден на сервере!");
            return true;
        }

        $targetName = $targetPlayer->getName();

        $this->sendInventoryForm($sender, $targetPlayer);

        $this->logAction("[RcInv] " . $sender->getName() . " просмотрел инвентарь " . $targetName);

        return true;
    }

    // ===== /rccrinv =====
    private function handleClearInv(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§c[RcInv] Использование: /rccrinv <ник> <причина>");
            return true;
        }

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);
        $adminName = $this->getAdminName($sender);

        if (empty(trim($reason))) {
            $sender->sendMessage("§c[RcInv] Укажите причину очистки инвентаря!");
            return true;
        }

        $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer === null) {
            $sender->sendMessage("§c[RcInv] Игрок " . $targetInput . " не найден на сервере!");
            return true;
        }

        $targetName = $targetPlayer->getName();

        if (!$this->canClearTarget($sender, $targetName)) return true;

        if (!$this->checkAndUseClearLimit($sender)) return true;

        $totalItems = 0;
        $totalCount = 0;
        foreach ($targetPlayer->getInventory()->getContents() as $item) {
            if (!$item->isNull()) {
                $totalItems++;
                $totalCount += $item->getCount();
            }
        }
        foreach ($targetPlayer->getArmorInventory()->getContents() as $item) {
            if (!$item->isNull()) {
                $totalItems++;
                $totalCount += $item->getCount();
            }
        }
        $offhand = $targetPlayer->getOffHandInventory()->getItem(0);
        if (!$offhand->isNull()) {
            $totalItems++;
            $totalCount += $offhand->getCount();
        }

        $targetPlayer->getInventory()->clearAll();
        $targetPlayer->getArmorInventory()->clearAll();
        $targetPlayer->getOffHandInventory()->clearAll();
        $targetPlayer->getCursorInventory()->clearAll();

        $targetPlayer->sendMessage("§eВаш инвентарь был очищен игроком §c" . $adminName . " §eпо причине: §c" . $reason);

        $this->broadcast("§eИгрок §c" . $adminName . " §eочистил инвентарь игроку §c" . $targetName . " §eпричина: §c" . $reason . " §e(§c" . $totalItems . " §eпредметов, §c" . $totalCount . " §eшт.)");

        $this->logAction("[RcInv] " . $adminName . " очистил инвентарь " . $targetName . " (" . $totalItems . " предметов, " . $totalCount . " шт.). Причина: " . $reason);

        return true;
    }
}
