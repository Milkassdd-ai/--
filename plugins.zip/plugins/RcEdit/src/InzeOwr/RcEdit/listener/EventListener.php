<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit\listener;

use InzeOwr\RcEdit\Main;
use InzeOwr\RcEdit\processor\BlockProcessor;
use InzeOwr\RcEdit\utils\Helpers;
use InzeOwr\RcEdit\utils\Message;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\utils\TextFormat as TF;

/**
 * Обработчик событий: взаимодействие, ломание, выход.
 */
class EventListener implements Listener {

	private Main $plugin;
	private BlockProcessor $processor;

	public function __construct(Main $plugin, BlockProcessor $processor) {
		$this->plugin = $plugin;
		$this->processor = $processor;
	}

	// ================================================================
	// Выход игрока
	// ================================================================

	public function onQuit(PlayerQuitEvent $event): void {
		$this->plugin->removeSession($event->getPlayer()->getName());
	}

	// ================================================================
	// Взаимодействие с блоком
	// ================================================================

	public function onInteract(PlayerInteractEvent $event): void {
		$player = $event->getPlayer();
		$item = $event->getItem();
		$block = $event->getBlock();
		$action = $event->getAction();

		if (!$player->hasPermission("rcedit.use")) {
			return;
		}

		$session = $this->plugin->getSession($player);

		// --- 1. Режим ID инспектора ---
		if ($session->isIdMode()) {
			if ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK || $action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
				$event->cancel();
				$blockName = $block->getName();
				$stateId = $block->getStateId();
				$typeId = $block->getTypeId();
				$pos = $block->getPosition();
				$player->sendMessage(Message::PREFIX . "Блок: " . TF::YELLOW . $blockName);
				$player->sendMessage(Message::PREFIX . "TypeID: " . TF::WHITE . $typeId . TF::GRAY . " | StateID: " . TF::WHITE . $stateId);
				$player->sendMessage(Message::PREFIX . "Позиция: " . TF::WHITE . Helpers::vecStr($pos));
			}
			return;
		}

		// --- 2. Палка поворота/отсоединения ---
		if ($item->getNamedTag()->getTag("RcPalke") !== null) {
			if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
				$event->cancel();
				$session->setPalkePos1($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Палка Точка 1: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendPalkeSelectionInfo($player, $session);
				return;
			} elseif ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
				$event->cancel();

				if (!$session->hasPalkePos1()) {
					$result = $this->processor->processOneBlock($block, $player);
					if ($result === "rotated") {
						$player->sendMessage(Message::SUCCESS . "Блок повёрнут: " . TF::WHITE . $block->getName());
					} elseif ($result === "disconnected") {
						$player->sendMessage(Message::SUCCESS . "Блок отсоединён: " . TF::WHITE . $block->getName());
					} else {
						$player->sendMessage(Message::ERR . "Этот блок нельзя повернуть/отсоединить.");
					}
					return;
				}

				$session->setPalkePos2($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Палка Точка 2: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendPalkeSelectionInfo($player, $session);
				return;
			}
			return;
		}

		// --- 3. Выделение топориком ---
		if ($item->getTypeId() === VanillaItems::GOLDEN_AXE()->getTypeId()) {
			if ($action === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
				$event->cancel();
				$session->setPos1($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Точка 1: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendSelectionInfo($player, $session);
			} elseif ($action === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
				$event->cancel();
				$session->setPos2($block->getPosition());
				$player->sendMessage(Message::SUCCESS . "Точка 2: " . TF::WHITE . Helpers::vecStr($block->getPosition()));
				$this->sendSelectionInfo($player, $session);
			}
		}
	}

	// ================================================================
	// Ломание блока
	// ================================================================

	public function onBreak(BlockBreakEvent $event): void {
		$player = $event->getPlayer();
		$item = $event->getItem();

		if (!$player->hasPermission("rcedit.use")) {
			return;
		}

		$session = $this->plugin->getSession($player);

		if ($session->isIdMode()) {
			$event->cancel();
			return;
		}

		if ($item->getNamedTag()->getTag("RcPalke") !== null) {
			$event->cancel();
			return;
		}

		if ($item->getTypeId() === VanillaItems::GOLDEN_AXE()->getTypeId()) {
			$event->cancel();
		}
	}

	// ================================================================
	// Информационные сообщения
	// ================================================================

	private function sendSelectionInfo(\pocketmine\player\Player $player, \InzeOwr\RcEdit\session\Session $session): void {
		if ($session->hasSelection()) {
			$bounds = $session->getSelectionBounds();
			$min = $bounds['min'];
			$max = $bounds['max'];
			$sizeX = (int)($max->x - $min->x + 1);
			$sizeY = (int)($max->y - $min->y + 1);
			$sizeZ = (int)($max->z - $min->z + 1);
			$total = $sizeX * $sizeY * $sizeZ;
			$player->sendMessage(Message::PREFIX . "Размер: " . TF::WHITE . "{$sizeX}x{$sizeY}x{$sizeZ}" . TF::GRAY . " ({$total} блоков)");
		}
	}

	private function sendPalkeSelectionInfo(\pocketmine\player\Player $player, \InzeOwr\RcEdit\session\Session $session): void {
		if ($session->hasPalkeSelection()) {
			$bounds = $session->getPalkeSelectionBounds();
			$min = $bounds['min'];
			$max = $bounds['max'];
			$sizeX = (int)($max->x - $min->x + 1);
			$sizeY = (int)($max->y - $min->y + 1);
			$sizeZ = (int)($max->z - $min->z + 1);
			$total = $sizeX * $sizeY * $sizeZ;
			$player->sendMessage(Message::PREFIX . "Палка выделение: " . TF::WHITE . "{$sizeX}x{$sizeY}x{$sizeZ}" . TF::GRAY . " ({$total} блоков)");
			$player->sendMessage(Message::PREFIX . "Используйте /rcsetp для обработки.");
		}
	}
}
