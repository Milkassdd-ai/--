<?php

namespace InzeOwr\RcOrg\entities;

use pocketmine\entity\Human;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\world\World;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\systems\CourtSystem;

class LawsuitNPC extends Human {
    public function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setNoClientPredictions();
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTag("§l§5Подача искового заявления\n§r§l§fНажмите для взаимодействия");
    }

    public function saveNBT(): CompoundTag {
        return parent::saveNBT();
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
    }

    public function onInteract(Player $player, Vector3 $clickPos): bool {
        Main::getInstance()->handleLawsuitNpcTouch($player);
        return true;
    }
}
