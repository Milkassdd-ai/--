<?php

declare(strict_types=1);

namespace LuiDuo\RcRust;

use pocketmine\block\Farmland;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\FarmlandHydrationChangeEvent;
use pocketmine\event\entity\EntityTrampleFarmlandEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;
use pocketmine\block\VanillaBlocks;

class Main extends PluginBase implements Listener{

	/** @var array<string, TaskHandler> playerName => TaskHandler */
	private array $messageTasks = [];

	/** @var array<string, string> playerName => original nametag */
	private array $originalNametags = [];

	private const MESSAGE_DURATION_TICKS = 300;
	private const MAX_LENGTH = 35;

	public function onEnable() : void{
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§aRcRust §7by §bLuiDuo §7enabled!");
	}

	public function onDisable() : void{
		foreach($this->messageTasks as $handler){
			$handler->cancel();
		}
		$this->messageTasks = [];
		$this->originalNametags = [];
	}

	/* ================================================================
	 *  Сообщение над ником
	 * ================================================================ */

	public function onChat(PlayerChatEvent $event) : void{
		$player = $event->getPlayer();
		$message = $event->getMessage();
		$name = $player->getName();

		if(!isset($this->originalNametags[$name])){
			$this->originalNametags[$name] = $player->getNameTag();
		}

		if(mb_strlen($message, 'UTF-8') > self::MAX_LENGTH){
			$message = mb_substr($message, 0, self::MAX_LENGTH - 3, 'UTF-8') . "...";
		}

		$player->setNameTag("§l" . $message . "\n§r" . $this->originalNametags[$name]);

		if(isset($this->messageTasks[$name])){
			$this->messageTasks[$name]->cancel();
		}

		$handler = $this->getScheduler()->scheduleDelayedTask(
			new ClosureTask(function() use ($player, $name) : void{
				if($player->isOnline()){
					$player->setNameTag($this->originalNametags[$name] ?? $player->getName());
				}
				unset($this->messageTasks[$name], $this->originalNametags[$name]);
			}),
			self::MESSAGE_DURATION_TICKS
		);

		$this->messageTasks[$name] = $handler;
	}

	public function onQuit(PlayerQuitEvent $event) : void{
		$name = $event->getPlayer()->getName();
		if(isset($this->messageTasks[$name])){
			$this->messageTasks[$name]->cancel();
			unset($this->messageTasks[$name], $this->originalNametags[$name]);
		}
	}

	/* ================================================================
	 *  Защита грядок — никогда не превращаются обратно в грязь
	 * ================================================================ */

	/**
	 * Блокируем высыхание грядки (случайные тики).
	 */
	public function onFarmlandHydrationChange(FarmlandHydrationChangeEvent $event) : void{
		$event->cancel();
	}

	/**
	 * Блокируем топтание грядки игроками и мобами.
	 */
	public function onEntityTrampleFarmland(EntityTrampleFarmlandEvent $event) : void{
		$event->cancel();
	}

	/**
	 * Защита от превращения грядки в грязь при установке твёрдого блока сверху.
	 *
	 * getTransaction()->getBlocks() возвращает Generator,
	 * который yields: [int $x, int $y, int $z, Block $block]
	 *
	 * Farmland::onNearbyBlockChange() превращает грядку в грязь БЕЗ событий,
	 * поэтому восстанавливаем через 1 тик после размещения.
	 */
	public function onBlockPlace(BlockPlaceEvent $event) : void{
		$world = $event->getPlayer()->getWorld();
		$toRestore = [];

		foreach($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]){
			// Проверяем блок под поставленным — грядка ли это
			$belowY = $y - 1;
			$below = $world->getBlockAt($x, $belowY, $z);

			if($below instanceof Farmland && $block->isSolid()){
				$toRestore[] = [
					'x' => $x,
					'y' => $belowY,
					'z' => $z,
					'wetness' => $below->getWetness()
				];
			}
		}

		if(count($toRestore) > 0){
			$this->getScheduler()->scheduleDelayedTask(
				new ClosureTask(function() use ($world, $toRestore) : void{
					foreach($toRestore as $pos){
						$current = $world->getBlockAt($pos['x'], $pos['y'], $pos['z']);
						if(!($current instanceof Farmland)){
							$world->setBlockAt(
								$pos['x'],
								$pos['y'],
								$pos['z'],
								VanillaBlocks::FARMLAND()->setWetness($pos['wetness'])
							);
						}
					}
				}),
				1
			);
		}
	}
}
