<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit\session;

use InzeOwr\RcEdit\Main;
use pocketmine\block\Block;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\World;

/**
 * Сессия игрока: позиции, буфер обмена, undo/redo, схематики.
 */
class Session {

	private Player $player;
	private Main $plugin;

	private ?Vector3 $pos1 = null;
	private ?Vector3 $pos2 = null;

	private ?Vector3 $palkePos1 = null;
	private ?Vector3 $palkePos2 = null;

	/** @var array{vec: Vector3, block: Block}[] */
	private array $clipboard = [];

	/** @var array{sizeX: int, sizeY: int, sizeZ: int}|null */
	private ?array $clipboardSize = null;

	/** @var array[] */
	private array $undoStack = [];
	/** @var array[] */
	private array $redoStack = [];

	private bool $idMode = false;

	private const MAX_UNDO = 50;

	public function __construct(Player $player, Main $plugin) {
		$this->player = $player;
		$this->plugin = $plugin;
	}

	// ================================================================
	// Основные позиции
	// ================================================================

	public function setPos1(Vector3 $pos): void {
		$this->pos1 = $pos->floor();
	}

	public function setPos2(Vector3 $pos): void {
		$this->pos2 = $pos->floor();
	}

	public function getPos1(): ?Vector3 {
		return $this->pos1;
	}

	public function getPos2(): ?Vector3 {
		return $this->pos2;
	}

	public function hasSelection(): bool {
		return $this->pos1 !== null && $this->pos2 !== null;
	}

	public function getSelectionBounds(): ?array {
		if (!$this->hasSelection()) return null;
		return [
			'min' => new Vector3(
				min($this->pos1->x, $this->pos2->x),
				min($this->pos1->y, $this->pos2->y),
				min($this->pos1->z, $this->pos2->z)
			),
			'max' => new Vector3(
				max($this->pos1->x, $this->pos2->x),
				max($this->pos1->y, $this->pos2->y),
				max($this->pos1->z, $this->pos2->z)
			)
		];
	}

	// ================================================================
	// Позиции палки
	// ================================================================

	public function setPalkePos1(Vector3 $pos): void {
		$this->palkePos1 = $pos->floor();
	}

	public function setPalkePos2(Vector3 $pos): void {
		$this->palkePos2 = $pos->floor();
	}

	public function hasPalkePos1(): bool {
		return $this->palkePos1 !== null;
	}

	public function hasPalkeSelection(): bool {
		return $this->palkePos1 !== null && $this->palkePos2 !== null;
	}

	public function getPalkeSelectionBounds(): ?array {
		if (!$this->hasPalkeSelection()) return null;
		return [
			'min' => new Vector3(
				min($this->palkePos1->x, $this->palkePos2->x),
				min($this->palkePos1->y, $this->palkePos2->y),
				min($this->palkePos1->z, $this->palkePos2->z)
			),
			'max' => new Vector3(
				max($this->palkePos1->x, $this->palkePos2->x),
				max($this->palkePos1->y, $this->palkePos2->y),
				max($this->palkePos1->z, $this->palkePos2->z)
			)
		];
	}

	public function clearPalkeSelection(): void {
		$this->palkePos1 = null;
		$this->palkePos2 = null;
	}

	// ================================================================
	// Clipboard
	// ================================================================

	public function getClipboard(): array {
		return $this->clipboard;
	}

	public function hasClipboard(): bool {
		return !empty($this->clipboard);
	}

	// ================================================================
	// ID Mode
	// ================================================================

	public function isIdMode(): bool {
		return $this->idMode;
	}

	public function toggleIdMode(): bool {
		$this->idMode = !$this->idMode;
		return $this->idMode;
	}

	// ================================================================
	// Undo / Redo
	// ================================================================

	private function saveUndo(array $blocks): void {
		if (empty($blocks)) return;
		$this->undoStack[] = $blocks;
		$this->redoStack = [];
		while (count($this->undoStack) > self::MAX_UNDO) {
			array_shift($this->undoStack);
		}
	}

	public function saveUndoPublic(array $blocks): void {
		$this->saveUndo($blocks);
	}

	public function addSingleUndo(Vector3 $pos, Block $oldBlock): void {
		$this->saveUndo([['vec' => $pos, 'block' => $oldBlock]]);
	}

	public function undo(): bool {
		if (empty($this->undoStack)) return false;
		$lastAction = array_pop($this->undoStack);

		$redoAction = [];
		$world = $this->player->getWorld();

		foreach ($lastAction as $data) {
			$pos = $data['vec'];
			$prevBlock = $data['block'];

			$redoAction[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
			$world->setBlock($pos, $prevBlock, false);
		}

		$this->redoStack[] = $redoAction;
		return true;
	}

	public function redo(): bool {
		if (empty($this->redoStack)) return false;
		$lastUndo = array_pop($this->redoStack);

		$undoAction = [];
		$world = $this->player->getWorld();

		foreach ($lastUndo as $data) {
			$pos = $data['vec'];
			$block = $data['block'];

			$undoAction[] = ['vec' => $pos, 'block' => $world->getBlock($pos)];
			$world->setBlock($pos, $block, false);
		}

		$this->undoStack[] = $undoAction;
		return true;
	}

	// ================================================================
	// Fill
	// ================================================================

	public function fillSelection(Block $block): int {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();

		$undoData = [];
		$count = 0;

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$oldBlock = $world->getBlock($pos);

					if ($oldBlock->isSameState($block)) continue;

					$undoData[] = ['vec' => $pos, 'block' => $oldBlock];
					$world->setBlock($pos, $block, false);
					$count++;
				}
			}
		}
		$this->saveUndo($undoData);
		return $count;
	}

	// ================================================================
	// Copy
	// ================================================================

	public function copy(): int {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();

		$this->clipboard = [];

		$sizeX = (int)($max->x - $min->x + 1);
		$sizeY = (int)($max->y - $min->y + 1);
		$sizeZ = (int)($max->z - $min->z + 1);

		$this->clipboardSize = [
			'sizeX' => $sizeX,
			'sizeY' => $sizeY,
			'sizeZ' => $sizeZ
		];

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$block = $world->getBlock($pos);

					$relative = new Vector3(
						$x - (int)$min->x,
						$y - (int)$min->y,
						$z - (int)$min->z
					);
					$this->clipboard[] = ['vec' => $relative, 'block' => $block];
				}
			}
		}

		return count($this->clipboard);
	}

	// ================================================================
	// Paste (по выделению)
	// ================================================================

	public function pasteToSelection(): int {
		if (empty($this->clipboard)) return 0;

		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$pasteMin = $bounds['min'];
		$world = $this->player->getWorld();

		$undoData = [];
		$count = 0;

		foreach ($this->clipboard as $entry) {
			$rel = $entry['vec'];
			$block = $entry['block'];

			$pastePos = new Vector3(
				(int)$pasteMin->x + (int)$rel->x,
				(int)$pasteMin->y + (int)$rel->y,
				(int)$pasteMin->z + (int)$rel->z
			);

			$oldBlock = $world->getBlock($pastePos);

			if ($oldBlock->isSameState($block)) continue;

			$undoData[] = ['vec' => $pastePos, 'block' => $oldBlock];
			$world->setBlock($pastePos, $block, false);
			$count++;
		}

		$this->saveUndo($undoData);
		return $count;
	}

	// ================================================================
	// Paste на позиции игрока (для rcpastex)
	// ================================================================

	public function pasteAtPlayer(): int {
		if (empty($this->clipboard)) return 0;

		$playerPos = $this->player->getPosition()->floor();
		$world = $this->player->getWorld();

		$undoData = [];
		$count = 0;

		foreach ($this->clipboard as $entry) {
			$rel = $entry['vec'];
			$block = $entry['block'];

			$pastePos = new Vector3(
				(int)$playerPos->x + (int)$rel->x,
				(int)$playerPos->y + (int)$rel->y,
				(int)$playerPos->z + (int)$rel->z
			);

			$oldBlock = $world->getBlock($pastePos);

			if ($oldBlock->isSameState($block)) continue;

			$undoData[] = ['vec' => $pastePos, 'block' => $oldBlock];
			$world->setBlock($pastePos, $block, false);
			$count++;
		}

		$this->saveUndo($undoData);
		return $count;
	}

	// ================================================================
	// Сохранение / Загрузка схематик
	// ================================================================

	public function saveSchematic(string $name): bool {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return false;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();

		$data = [];
		$data['sizeX'] = (int)($max->x - $min->x + 1);
		$data['sizeY'] = (int)($max->y - $min->y + 1);
		$data['sizeZ'] = (int)($max->z - $min->z + 1);
		$data['blocks'] = [];

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {
					$pos = new Vector3($x, $y, $z);
					$block = $world->getBlock($pos);

					$data['blocks'][] = [
						'rx' => $x - (int)$min->x,
						'ry' => $y - (int)$min->y,
						'rz' => $z - (int)$min->z,
						'sid' => $block->getStateId()
					];
				}
			}
		}

		$path = $this->plugin->getSchematicsPath() . $name . ".json";
		$json = json_encode($data, JSON_UNESCAPED_UNICODE);

		if ($json === false) return false;

		return file_put_contents($path, $json) !== false;
	}

	public function loadSchematic(string $name): bool {
		$path = $this->plugin->getSchematicsPath() . $name . ".json";

		if (!file_exists($path)) return false;

		$content = file_get_contents($path);
		if ($content === false) return false;

		$data = json_decode($content, true);
		if ($data === null) return false;

		if (!isset($data['blocks']) || !isset($data['sizeX'])) return false;

		$this->clipboard = [];
		$this->clipboardSize = [
			'sizeX' => (int)$data['sizeX'],
			'sizeY' => (int)$data['sizeY'],
			'sizeZ' => (int)$data['sizeZ']
		];

		$blockStateRegistry = RuntimeBlockStateRegistry::getInstance();

		foreach ($data['blocks'] as $entry) {
			$rx = (int)$entry['rx'];
			$ry = (int)$entry['ry'];
			$rz = (int)$entry['rz'];
			$stateId = (int)$entry['sid'];

			try {
				$block = $blockStateRegistry->fromStateId($stateId);
			} catch (\Throwable $e) {
				$block = VanillaBlocks::AIR();
			}

			$this->clipboard[] = [
				'vec' => new Vector3($rx, $ry, $rz),
				'block' => $block
			];
		}

		return !empty($this->clipboard);
	}

	// ================================================================
	// Rotate
	// ================================================================

	public function rotateClipboard(int $direction): void {
		if (empty($this->clipboard)) return;
		if ($this->clipboardSize === null) return;

		$maxX = $this->clipboardSize['sizeX'] - 1;
		$maxZ = $this->clipboardSize['sizeZ'] - 1;

		$newClipboard = [];
		foreach ($this->clipboard as $entry) {
			$vec = $entry['vec'];
			$block = clone $entry['block'];

			$x = (int)$vec->x;
			$y = (int)$vec->y;
			$z = (int)$vec->z;

			$newX = $x;
			$newZ = $z;

			if ($direction === 1) {
				$newX = $maxZ - $z;
				$newZ = $x;
			} elseif ($direction === 2) {
				$newX = $z;
				$newZ = $maxX - $x;
			} elseif ($direction === 3) {
				$newX = $maxX - $x;
				$newZ = $maxZ - $z;
			}

			$newVec = new Vector3($newX, $y, $newZ);

			$this->rotateBlockFacing($block, $direction);

			$newClipboard[] = ['vec' => $newVec, 'block' => $block];
		}
		$this->clipboard = $newClipboard;

		if ($direction === 1 || $direction === 2) {
			$oldSizeX = $this->clipboardSize['sizeX'];
			$oldSizeZ = $this->clipboardSize['sizeZ'];
			$this->clipboardSize['sizeX'] = $oldSizeZ;
			$this->clipboardSize['sizeZ'] = $oldSizeX;
		}
	}

	private function rotateBlockFacing(Block $block, int $direction): void {
		if (!method_exists($block, 'setFacing') || !method_exists($block, 'getFacing')) {
			return;
		}

		try {
			$currentFacing = $block->getFacing();

			if (!in_array($currentFacing, [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST], true)) {
				return;
			}

			$clockwise = [
				Facing::NORTH => Facing::EAST,
				Facing::EAST  => Facing::SOUTH,
				Facing::SOUTH => Facing::WEST,
				Facing::WEST  => Facing::NORTH,
			];

			$counterClockwise = [
				Facing::NORTH => Facing::WEST,
				Facing::WEST  => Facing::SOUTH,
				Facing::SOUTH => Facing::EAST,
				Facing::EAST  => Facing::NORTH,
			];

			$flip = [
				Facing::NORTH => Facing::SOUTH,
				Facing::SOUTH => Facing::NORTH,
				Facing::EAST  => Facing::WEST,
				Facing::WEST  => Facing::EAST,
			];

			if ($direction === 1 && isset($clockwise[$currentFacing])) {
				$block->setFacing($clockwise[$currentFacing]);
			} elseif ($direction === 2 && isset($counterClockwise[$currentFacing])) {
				$block->setFacing($counterClockwise[$currentFacing]);
			} elseif ($direction === 3 && isset($flip[$currentFacing])) {
				$block->setFacing($flip[$currentFacing]);
			}
		} catch (\Throwable $e) {}
	}

	// ================================================================
	// Connect Pattern
	// ================================================================

	public function connectPattern(array $pattern, int $mode): int {
		$bounds = $this->getSelectionBounds();
		if ($bounds === null) return 0;

		$min = $bounds['min'];
		$max = $bounds['max'];
		$world = $this->player->getWorld();
		$undoData = [];
		$count = 0;

		for ($x = (int)$min->x; $x <= (int)$max->x; $x++) {
			for ($y = (int)$min->y; $y <= (int)$max->y; $y++) {
				for ($z = (int)$min->z; $z <= (int)$max->z; $z++) {

					$isWall = ($x == (int)$min->x || $x == (int)$max->x || $z == (int)$min->z || $z == (int)$max->z);
					$isFloorCeil = ($y == (int)$min->y || $y == (int)$max->y);

					$place = false;
					if ($mode === 3) $place = true;
					if ($mode === 2 && $isFloorCeil) $place = true;
					if ($mode === 1 && $isWall) $place = true;

					if (!$place) continue;

					$selectedBlock = $this->pickRandomBlock($pattern);
					$this->randomizeFacing($selectedBlock);

					$pos = new Vector3($x, $y, $z);
					$oldBlock = $world->getBlock($pos);
					$undoData[] = ['vec' => $pos, 'block' => $oldBlock];
					$world->setBlock($pos, $selectedBlock, false);
					$count++;
				}
			}
		}
		$this->saveUndo($undoData);
		return $count;
	}

	private function pickRandomBlock(array $pattern): Block {
		$totalChance = 0;
		foreach ($pattern as $item) {
			$totalChance += $item['chance'];
		}

		$rand = mt_rand(1, max(1, (int)$totalChance));
		$current = 0;
		foreach ($pattern as $item) {
			$current += $item['chance'];
			if ($rand <= $current) {
				return clone $item['block'];
			}
		}
		return clone $pattern[0]['block'];
	}

	private function randomizeFacing(Block $block): void {
		$facings = [Facing::NORTH, Facing::EAST, Facing::SOUTH, Facing::WEST];
		if (method_exists($block, 'setFacing')) {
			try {
				$block->setFacing($facings[array_rand($facings)]);
			} catch (\Throwable $e) {}
		}
	}
}
