<?php

declare(strict_types=1);

namespace InzeOwr\RcMuzic;

use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\StopSoundPacket;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;
use jojoe77777\FormAPI\SimpleForm;

class Main extends PluginBase implements Listener {

    /** @var array<string, string> soundName => displayName */
    private array $tracks = [];

    /** @var array<string, int> soundName => seconds */
    private array $durations = [];

    /** @var array<string, array{track: string, handler: TaskHandler|null, startTime: int, mode: int, position: array}> */
    private array $activeSpeakers = [];

    /** @var array<string, bool> */
    private array $mutedPlayers = [];

    private float $radius = 150.0;
    private float $volume = 10.0;

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->radius = (float) $this->getConfig()->get("radius", 150);
        $this->volume = (float) $this->getConfig()->get("volume", 10.0);

        $this->loadTracks();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    /**
     * Парсит формат минуты.секунды в секунды
     * 3.30 = 3 мин 30 сек = 210 сек
     * 4.01 = 4 мин 1 сек = 241 сек
     */
    private function parseDuration(mixed $value): int {
        $str = (string) $value;

        if (strpos($str, ".") !== false) {
            $parts = explode(".", $str);
            $minutes = (int) $parts[0];
            $seconds = (int) str_pad($parts[1] ?? "0", 2, "0", STR_PAD_RIGHT);

            // Защита: если секунды > 59, обрезаем
            if ($seconds > 59) {
                $seconds = 59;
            }

            return ($minutes * 60) + $seconds;
        }

        // Если нет точки — считаем что это просто секунды
        return (int) $value;
    }

    private function loadTracks(): void {
        $tracksData = $this->getConfig()->get("tracks", []);
        if (!is_array($tracksData)) return;

        foreach ($tracksData as $soundName => $data) {
            if (!is_array($data)) continue;

            $name = (string) ($data["name"] ?? "§f♪ " . $soundName);
            $duration = $this->parseDuration($data["duration"] ?? "3.00");

            $this->tracks[$soundName] = $name;
            $this->durations[$soundName] = $duration;

            $mins = intdiv($duration, 60);
            $secs = $duration % 60;
        }
    }

    public function onDisable(): void {
        foreach ($this->activeSpeakers as $data) {
            if (isset($data["handler"]) && $data["handler"] instanceof TaskHandler) {
                $data["handler"]->cancel();
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();

        if (isset($this->activeSpeakers[$name])) {
            $track = $this->activeSpeakers[$name]["track"];
            $mode = $this->activeSpeakers[$name]["mode"];
            $handler = $this->activeSpeakers[$name]["handler"] ?? null;

            if ($mode === 1) {
                $this->stopSoundForAllInRadius($player, $track);
            }

            if ($handler instanceof TaskHandler) {
                $handler->cancel();
            }
            unset($this->activeSpeakers[$name]);
        }

        unset($this->mutedPlayers[$name]);
    }

    // =====================
    //  COMMAND
    // =====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cOnly in-game!");
            return true;
        }
        if ($command->getName() !== "rcmuzic") return false;

        if (!isset($args[0])) {
            $sender->sendMessage("§e§l♪ RcMuzic §r§7Использование:");
            $sender->sendMessage("§f/rcmuzic 1 §7— музыка для всех");
            $sender->sendMessage("§f/rcmuzic 2 §7— музыка только себе");
            $sender->sendMessage("§f/rcmuzic 3 §7— выключить музыку для себя");
            $sender->sendMessage("§f/rcmuzic stop §7— остановить свою музыку");
            return true;
        }

        $arg = strtolower($args[0]);

        if ($arg === "stop") {
            $this->stopMusic($sender);
            $sender->sendMessage("§c§l♪ §r§7Музыка остановлена");
            return true;
        }

        if ($arg === "1") {
            $this->openMainMenu($sender, 1);
            return true;
        }

        if ($arg === "2") {
            $this->openMainMenu($sender, 2);
            return true;
        }

        if ($arg === "3") {
            $this->toggleMuteForSelf($sender);
            return true;
        }

        $sender->sendMessage("§c§l♪ §r§7Используй: /rcmuzic 1, 2, 3 или stop");
        return true;
    }

    // =====================
    //  MUTE TOGGLE
    // =====================

    private function toggleMuteForSelf(Player $player): void {
        $name = $player->getName();

        if (isset($this->mutedPlayers[$name])) {
            unset($this->mutedPlayers[$name]);
            $player->sendMessage("§a§l♪ §r§fМузыка снова включена для вас");
        } else {
            $this->mutedPlayers[$name] = true;
            $player->sendMessage("§c§l♪ §r§7Музыка выключена для вас");
            $this->stopAllSoundsForPlayer($player);
        }
    }

    private function stopAllSoundsForPlayer(Player $player): void {
        foreach ($this->tracks as $soundName => $displayName) {
            $pk = new StopSoundPacket();
            $pk->soundName = $soundName;
            $pk->stopAll = false;
            $pk->stopLegacyMusic = false;
            $player->getNetworkSession()->sendDataPacket($pk);
        }
    }

    // =====================
    //  FORMAT HELPERS
    // =====================

    private function formatTime(int $totalSeconds): string {
        $mins = intdiv($totalSeconds, 60);
        $secs = $totalSeconds % 60;
        return sprintf("%d:%02d", $mins, $secs);
    }

    // =====================
    //  FORMS
    // =====================

    private function openMainMenu(Player $player, int $mode): void {
        $isPlaying = isset($this->activeSpeakers[$player->getName()]);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($mode): void {
            if ($data === null) return;

            $isPlaying = isset($this->activeSpeakers[$player->getName()]);

            if ($data === 0) {
                $this->openTrackList($player, $mode);
                return;
            }

            if ($isPlaying) {
                if ($data === 1) {
                    $this->stopMusic($player);
                    $player->sendMessage("§c§l♪ §r§7Музыка остановлена");
                } elseif ($data === 2) {
                    $this->playNextTrack($player, $mode);
                } elseif ($data === 3) {
                    $this->playRandomTrack($player, $mode);
                }
            }
        });

        $modeText = $mode === 1 ? "§aВсем" : "§bТолько себе";
        $form->setTitle("§l§6♪ RcMuzic ♪");

        $status = "§7Режим: " . $modeText . "\n§7Статус: ";
        if ($isPlaying) {
            $track = $this->activeSpeakers[$player->getName()]["track"];
            $name = $this->tracks[$track] ?? $track;
            $dur = $this->durations[$track] ?? 0;
            $elapsed = time() - ($this->activeSpeakers[$player->getName()]["startTime"] ?? time());
            $remaining = max(0, $dur - $elapsed);
            $currentMode = $this->activeSpeakers[$player->getName()]["mode"];
            $currentModeText = $currentMode === 1 ? "§aвсем" : "§bсебе";
            $status .= "§a▶ " . $name . "\n" .
                       "§7Длительность: §e" . $this->formatTime($dur) . "\n" .
                       "§7Осталось: §e" . $this->formatTime($remaining) . "\n" .
                       "§7Играет: " . $currentModeText;
        } else {
            $status .= "§cНе играет";
        }

        $isMuted = isset($this->mutedPlayers[$player->getName()]);
        $muteStatus = $isMuted ? "\n§c⚠ Вы отключили чужую музыку (/rcmuzic 3)" : "";

        $form->setContent(
            $status . "\n\n" .
            "§fРадиус: §e" . (int)$this->radius . " блоков\n" .
            "§fТреков: §e" . count($this->tracks) . "\n" .
            "§fГромкость: §e" . $this->volume .
            $muteStatus
        );

        $form->addButton("§l§2♪ Выбрать трек\n§r§8Список музыки");

        if ($isPlaying) {
            $form->addButton("§l§4■ Стоп\n§r§8Остановить музыку");
            $form->addButton("§l§9▶▶ Следующий\n§r§8Переключить");
            $form->addButton("§l§5? Рандом\n§r§8Случайный трек");
        }

        $player->sendForm($form);
    }

    private function openTrackList(Player $player, int $mode): void {
        if (count($this->tracks) === 0) {
            $player->sendMessage("§c§l♪ §r§7Нет доступных треков!");
            return;
        }

        $trackKeys = array_keys($this->tracks);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($trackKeys, $mode): void {
            if ($data === null) {
                $this->openMainMenu($player, $mode);
                return;
            }

            if (!isset($trackKeys[$data])) return;

            $selected = $trackKeys[$data];
            $this->startMusic($player, $selected, $mode);
        });

        $modeText = $mode === 1 ? "§aвсем в радиусе" : "§bтолько вам";
        $form->setTitle("§l§e♪ Выбор трека ♪");
        $form->setContent("§7Нажми на трек чтобы включить\n§7Играет: " . $modeText . "\n§7Радиус: " . (int)$this->radius . " блоков");

        foreach ($this->tracks as $soundName => $displayName) {
            $dur = $this->durations[$soundName] ?? 0;

            $prefix = "";
            if (isset($this->activeSpeakers[$player->getName()]) &&
                $this->activeSpeakers[$player->getName()]["track"] === $soundName) {
                $prefix = "§a▶ ";
            }

            $form->addButton($prefix . $displayName . "\n§r§7⏱ " . $this->formatTime($dur));
        }

        $player->sendForm($form);
    }

    // =====================
    //  MUSIC CONTROL
    // =====================

    private function startMusic(Player $player, string $trackName, int $mode): void {
        $this->stopMusic($player);

        if (!isset($this->tracks[$trackName])) {
            $player->sendMessage("§cТрек не найден!");
            return;
        }

        $duration = $this->durations[$trackName] ?? 180;
        $displayName = $this->tracks[$trackName] ?? $trackName;

        $pos = $player->getPosition();

        if ($mode === 1) {
            $this->broadcastPlaySound($player, $trackName);
        } else {
            $this->playSoundForPlayer($player, $trackName, $pos->getX(), $pos->getY(), $pos->getZ());
        }

        $modeText = $mode === 1 ? "§aвсем" : "§bтолько вам";
        $player->sendMessage("§a§l♪ §r§fСейчас играет: " . $displayName);
        $player->sendMessage("§7Длительность: " . $this->formatTime($duration) . " | Режим: " . $modeText);

        $playerName = $player->getName();
        $handler = $this->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function () use ($playerName, $trackName, $mode): void {
                $player = $this->getServer()->getPlayerExact($playerName);
                if ($player === null) {
                    unset($this->activeSpeakers[$playerName]);
                    return;
                }
                if (!isset($this->activeSpeakers[$playerName])) return;

                $nextTrack = $this->getNextTrack($trackName);
                $nextName = $this->tracks[$nextTrack] ?? $nextTrack;
                $player->sendMessage("§6§l♪ §r§7Авто: " . $nextName);
                $this->startMusic($player, $nextTrack, $mode);
            }),
            $duration * 20
        );

        $this->activeSpeakers[$playerName] = [
            "track" => $trackName,
            "handler" => $handler,
            "startTime" => time(),
            "mode" => $mode,
            "position" => [
                "x" => $pos->getX(),
                "y" => $pos->getY(),
                "z" => $pos->getZ(),
                "world" => $pos->getWorld()->getFolderName(),
            ],
        ];
    }

    private function stopMusic(Player $player): void {
        $name = $player->getName();
        if (!isset($this->activeSpeakers[$name])) return;

        $track = $this->activeSpeakers[$name]["track"];
        $mode = $this->activeSpeakers[$name]["mode"];
        $handler = $this->activeSpeakers[$name]["handler"] ?? null;

        if ($mode === 1) {
            $this->stopSoundForAllInRadius($player, $track);
        } else {
            $this->stopSoundForPlayer($player, $track);
        }

        if ($handler instanceof TaskHandler) {
            $handler->cancel();
        }

        unset($this->activeSpeakers[$name]);
    }

    private function playNextTrack(Player $player, int $mode): void {
        $current = $this->activeSpeakers[$player->getName()]["track"] ?? "";
        $currentMode = $this->activeSpeakers[$player->getName()]["mode"] ?? $mode;
        $next = $this->getNextTrack($current);
        $this->startMusic($player, $next, $currentMode);
    }

    private function playRandomTrack(Player $player, int $mode): void {
        $keys = array_keys($this->tracks);
        if (count($keys) === 0) return;
        $currentMode = $this->activeSpeakers[$player->getName()]["mode"] ?? $mode;
        $random = $keys[array_rand($keys)];
        $this->startMusic($player, $random, $currentMode);
    }

    // =====================
    //  SOUND PACKETS
    // =====================

    private function broadcastPlaySound(Player $source, string $soundName): void {
        $pos = $source->getPosition();

        foreach ($source->getWorld()->getPlayers() as $p) {
            if (isset($this->mutedPlayers[$p->getName()])) continue;

            if ($p->getPosition()->distance($pos) <= $this->radius) {
                $this->playSoundForPlayer($p, $soundName, $pos->getX(), $pos->getY(), $pos->getZ());
            }
        }
    }

    private function playSoundForPlayer(Player $player, string $soundName, float $x, float $y, float $z): void {
        $pk = new PlaySoundPacket();
        $pk->soundName = $soundName;
        $pk->x = $x;
        $pk->y = $y;
        $pk->z = $z;
        $pk->volume = $this->volume;
        $pk->pitch = 1.0;
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    private function stopSoundForAllInRadius(Player $source, string $soundName): void {
        foreach ($source->getWorld()->getPlayers() as $p) {
            if ($p->getPosition()->distance($source->getPosition()) <= $this->radius + 50) {
                $this->stopSoundForPlayer($p, $soundName);
            }
        }
    }

    private function stopSoundForPlayer(Player $player, string $soundName): void {
        $pk = new StopSoundPacket();
        $pk->soundName = $soundName;
        $pk->stopAll = false;
        $pk->stopLegacyMusic = false;
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    // =====================
    //  HELPERS
    // =====================

    private function getNextTrack(string $current): string {
        $keys = array_keys($this->tracks);
        if (count($keys) === 0) return $current;

        $idx = array_search($current, $keys);
        if ($idx === false) return $keys[0];

        $nextIdx = ($idx + 1) % count($keys);
        return $keys[$nextIdx];
    }
}
