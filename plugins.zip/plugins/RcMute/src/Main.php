<?php

declare(strict_types=1);

namespace InzeOwr\RcMute;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase implements Listener
{
    private Config $mutesConfig;
    private Config $limitsConfig;
    private string $timezone;
    private string $datetimeFormat;
    private array  $staffGroups   = [];
    private array  $limitedGroups = [];

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->validateConfig();

        @mkdir($this->getDataFolder() . "data/", 0777, true);

        $this->mutesConfig  = new Config($this->getDataFolder() . "data/mutes.json",  Config::JSON);
        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);

        $this->timezone       = $this->getConfig()->get("timezone",       "Europe/Moscow");
        $this->datetimeFormat = $this->getConfig()->get("datetime_format", "d.m.y - H:i:s");

        date_default_timezone_set($this->timezone);

        $this->staffGroups   = $this->getConfig()->get("staff_groups",   []);
        $this->limitedGroups = $this->getConfig()->get("limited_groups", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
    }

    private function validateConfig(): void
    {
        $config  = $this->getConfig();
        $changed = false;

        $defaults = [
            "timezone"              => "Europe/Moscow",
            "datetime_format"       => "d.m.y - H:i:s",
            "max_mute_time"         => 0,
            "log_actions"           => true,
            "broadcast_mutes"       => true,
            "broadcast_unmutes"     => true,
            "self_mute_protection"  => true,
            "staff_groups"          => [
                "CREATOR", "OWNER", "GLADMIN", "CURATOR",
                "SADMIN", "ADMIN", "MANAGER", "SMODER", "MODER",
            ],
            "limited_groups" => [
                "MIRAGE" => [
                    "max_mutes"        => 6,
                    "max_time_minutes" => 180,
                    "cooldown_hours"   => 24,
                    "can_unmute_staff" => false,
                ],
                "SPARK" => [
                    "max_mutes"        => 12,
                    "max_time_minutes" => 360,
                    "cooldown_hours"   => 24,
                    "can_unmute_staff" => false,
                ],
            ],
        ];

        foreach ($defaults as $key => $value) {
            if (!$config->exists($key)) {
                $config->set($key, $value);
                $changed = true;
                $this->getLogger()->warning("Ключ «{$key}» отсутствовал в конфиге — добавлен со значением по умолчанию.");
            }
        }

        if ($changed) {
            $config->save();
            $this->getLogger()->info(TF::GREEN . "Конфиг обновлён.");
        }
    }

    protected function onDisable(): void
    {
        $this->mutesConfig->save();
        $this->limitsConfig->save();
    }

    // ==================== УТИЛИТЫ ====================

    private function formatTimestamp(int $timestamp): string
    {
        $dt = new \DateTime("@{$timestamp}");
        $dt->setTimezone(new \DateTimeZone($this->timezone));
        return $dt->format($this->datetimeFormat);
    }

    private function getTimeRemaining(int $expireTimestamp): string
    {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return "истёк";

        $days    = (int) floor($diff / 86400);
        $hours   = (int) floor(($diff % 86400) / 3600);
        $minutes = (int) floor(($diff % 3600) / 60);
        $seconds = (int) ($diff % 60);

        $parts = [];
        if ($days > 0)                   $parts[] = $days . " дн.";
        if ($hours > 0)                  $parts[] = $hours . " ч.";
        if ($minutes > 0)                $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0) $parts[] = $seconds . " сек.";

        return implode(" ", $parts);
    }

    /**
     * Парсит строку времени вида: 10m, 2h, 1d, 3ms, 1g или 90 (минуты).
     * Нормализует по правилам: >60m → h, >24h → d, >30d → ms, >12ms → g.
     * Ограничение: не более 365 лет.
     * Возвращает количество минут или null при ошибке.
     */
    private function parseTime(string $input): ?int
    {
        $input = strtolower(trim($input));

        // Составное время: 1g1h, 2d3h30m и т.п.
        $totalMinutes = 0;
        $pattern      = '/(\d+)(g|ms|d|h|m)/';
        $matches      = [];

        if (preg_match_all($pattern, $input, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $val  = (int) $match[1];
                $unit = $match[2];
                $totalMinutes += $this->toMinutes($val, $unit);
            }
            // Если ничего не разобрано — fallback на чистое число
            if ($totalMinutes === 0) return null;
        } elseif (is_numeric($input)) {
            $val = (int) $input;
            if ($val <= 0) return null;
            $totalMinutes = $val; // считаем минуты
        } else {
            return null;
        }

        if ($totalMinutes <= 0) return null;

        // Максимум: 365 лет в минутах
        $maxMinutes = 365 * 525960;
        if ($totalMinutes > $maxMinutes) return null;

        // Проверка глобального ограничения конфига
        $maxTime = (int) $this->getConfig()->get("max_mute_time", 0);
        if ($maxTime > 0 && $totalMinutes > $maxTime) return null;

        return $totalMinutes;
    }

    private function toMinutes(int $val, string $unit): int
    {
        return match ($unit) {
            "m"  => $val,
            "h"  => $val * 60,
            "d"  => $val * 1440,
            "ms" => $val * 43200,   // ~30 дней
            "g"  => $val * 525960,  // ~365 дней
            default => 0,
        };
    }

    /**
     * Нормализует минуты в наилучшую читаемую единицу.
     * >60m → h, >24h → d, >30d → ms, >12ms → g (с остатками).
     */
    private function normalizeTime(int $totalMinutes): string
    {
        $years   = (int) floor($totalMinutes / 525960);
        $rest    = $totalMinutes % 525960;
        $months  = (int) floor($rest / 43200);
        $rest    = $rest % 43200;
        $days    = (int) floor($rest / 1440);
        $rest    = $rest % 1440;
        $hours   = (int) floor($rest / 60);
        $minutes = $rest % 60;

        $parts = [];
        if ($years   > 0) $parts[] = $years   . " " . $this->pluralYear($years);
        if ($months  > 0) $parts[] = $months  . " " . $this->pluralMonth($months);
        if ($days    > 0) $parts[] = $days    . " " . $this->pluralDay($days);
        if ($hours   > 0) $parts[] = $hours   . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";

        return implode(" ", $parts);
    }

    private function pluralYear(int $n): string
    {
        $n = abs($n) % 100;
        $n1 = $n % 10;
        if ($n >= 11 && $n <= 19)  return "лет";
        if ($n1 === 1)              return "год";
        if ($n1 >= 2 && $n1 <= 4)  return "года";
        return "лет";
    }

    private function pluralMonth(int $n): string
    {
        $n = abs($n) % 100;
        $n1 = $n % 10;
        if ($n >= 11 && $n <= 19)  return "месяцев";
        if ($n1 === 1)              return "месяц";
        if ($n1 >= 2 && $n1 <= 4)  return "месяца";
        return "месяцев";
    }

    private function pluralDay(int $n): string
    {
        $n = abs($n) % 100;
        $n1 = $n % 10;
        if ($n >= 11 && $n <= 19)  return "дней";
        if ($n1 === 1)              return "день";
        if ($n1 >= 2 && $n1 <= 4)  return "дня";
        return "дней";
    }

    private function findPlayer(string $name): ?Player
    {
        $name  = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;

        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }

        return $found;
    }

    private function resolveTargetName(string $input): string
    {
        $player = $this->findPlayer($input);
        return $player !== null ? $player->getName() : $input;
    }

    private function getAdminName(CommandSender $sender): string
    {
        return $sender instanceof Player ? $sender->getName() : "Console";
    }

    private function broadcast(string $message): void
    {
        if ($this->getConfig()->get("broadcast_mutes", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function broadcastUnmute(string $message): void
    {
        if ($this->getConfig()->get("broadcast_unmutes", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function notifyStaff(string $message): void
    {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if ($this->isStaff($player->getName())) {
                $player->sendMessage("§l§7[А] §r§7" . $message);
            }
        }
    }

    private function logAction(string $message): void
    {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(TF::clean($message));
        }
    }

    private function cleanExpiredMutes(): void
    {
        $now     = time();
        $cleaned = 0;

        foreach ($this->mutesConfig->getAll() as $name => $data) {
            if (isset($data["expire"]) && $data["expire"] <= $now) {
                $this->mutesConfig->remove($name);
                $cleaned++;
            }
        }

        if ($cleaned > 0) $this->mutesConfig->save();
    }

    // ==================== RcGroup ====================

    private function getRcGroup(): ?\InzeOwr\RcGroup\Main
    {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    private function getPlayerGroup(string $nickname): string
    {
        $rcGroup = $this->getRcGroup();
        return $rcGroup !== null ? $rcGroup->getGroup($nickname) : "";
    }

    private function isStaff(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        return $group !== "" && in_array($group, $this->staffGroups, true);
    }

    private function getLimitedConfig(string $nickname): ?array
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        return isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group])
            ? $this->limitedGroups[$group]
            : null;
    }

    // ==================== ПРОВЕРКИ ====================

    private function checkStaffProtection(CommandSender $sender, string $targetName): bool
    {
        if (!($sender instanceof Player)) return true;
        if ($this->isStaff($targetName)) {
            $sender->sendMessage("§l§cВы не можете выдать наказание сотруднику проекта.");
            return false;
        }
        return true;
    }

    private function checkSelfMute(CommandSender $sender, string $targetName): bool
    {
        if ($this->getConfig()->get("self_mute_protection", true)) {
            if ($sender instanceof Player && strtolower($sender->getName()) === strtolower($targetName)) {
                $sender->sendMessage("§l§cВы не можете заблокировать чат самому себе.");
                return false;
            }
        }
        return true;
    }

    private function checkBypass(CommandSender $sender, string $targetName): bool
    {
        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer !== null && $targetPlayer->hasPermission("rcmute.bypass")) {
            $sender->sendMessage("§l§cЭтот игрок защищён от блокировок чата.");
            return false;
        }
        return true;
    }

    private function canMuteTarget(CommandSender $sender, string $targetName): bool
    {
        if (!$this->checkSelfMute($sender, $targetName))        return false;
        if (!$this->checkBypass($sender, $targetName))          return false;
        if (!$this->checkStaffProtection($sender, $targetName)) return false;
        return true;
    }

    private function checkLimitedTime(CommandSender $sender, int $minutes): bool
    {
        if (!($sender instanceof Player)) return true;

        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;

        $maxTime = (int) ($limitCfg["max_time_minutes"] ?? 0);
        if ($maxTime <= 0) return true;

        if ($minutes > $maxTime) {
            $allowed = $this->normalizeTime($maxTime);
            $sender->sendMessage("§l§cМаксимальное время блокировки для вашей привилегии: §r§c" . $allowed . ". Вы указали: §l§c" . $this->normalizeTime($minutes) . "§r§c.");
            return false;
        }

        return true;
    }

    /**
     * Проверяет лимит и списывает одно использование.
     * Вызывается ПОСЛЕДНЕЙ, непосредственно перед выполнением действия.
     */
    private function checkAndUseMuteLimit(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();
        $limitCfg   = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxMutes      = (int) ($limitCfg["max_mutes"]      ?? 0);
        $cooldownHours = (int) ($limitCfg["cooldown_hours"] ?? 24);
        if ($maxMutes <= 0) return true;

        $senderKey  = strtolower($senderName);
        $limitsData = $this->limitsConfig->get($senderKey, null);

        if (!is_array($limitsData)) {
            $limitsData = ["mutes_used" => 0, "period_start" => time()];
        }

        $periodStart     = (int) ($limitsData["period_start"] ?? time());
        $mutesUsed       = (int) ($limitsData["mutes_used"]   ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $mutesUsed   = 0;
            $periodStart = time();
        }

        if ($mutesUsed >= $maxMutes) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->getTimeRemaining($resetTime);
            $sender->sendMessage("§l§cВы исчерпали лимит блокировок §r§c(§l" . $maxMutes . "§r§c). Сброс через: §l" . $remaining . "§r§c.");
            return false;
        }

        $mutesUsed++;
        $this->limitsConfig->set($senderKey, ["mutes_used" => $mutesUsed, "period_start" => $periodStart]);
        $this->limitsConfig->save();

        $left      = $maxMutes - $mutesUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->getTimeRemaining($resetTime);
        $sender->sendMessage("§l§cИспользовано блокировок: §r§c" . $mutesUsed . "/" . $maxMutes . ". Осталось: §l" . $left . "§r§c. Сброс через: §l" . $remaining . "§r§c.");

        return true;
    }

    private function checkLimitedUnmute(CommandSender $sender, array $muteData): bool
    {
        if (!($sender instanceof Player)) return true;

        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;

        $canUnmuteStaff = (bool) ($limitCfg["can_unmute_staff"] ?? false);
        if ($canUnmuteStaff) return true;

        $muteAdmin = $muteData["admin"] ?? "";
        if ($this->isStaff($muteAdmin)) {
            $sender->sendMessage("§l§cВы не можете снять наказание, выданное сотрудником проекта.");
            return false;
        }

        return true;
    }

    // ==================== СОБЫТИЯ ====================

    public function onChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();
        $name   = strtolower($player->getName());

        if (!$this->mutesConfig->exists($name)) return;

        $data = $this->mutesConfig->get($name);

        if (isset($data["expire"]) && time() >= $data["expire"]) {
            $this->mutesConfig->remove($name);
            $this->mutesConfig->save();
            return;
        }

        $event->cancel();

        $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
        $remaining = isset($data["expire"]) ? $this->getTimeRemaining($data["expire"]) : "Никогда";
        $duration  = isset($data["duration_str"]) ? " (" . $data["duration_str"] . ")" : "";

        $player->sendMessage("§l§cВам выдана блокировка чата.");
        $player->sendMessage("§l§cСотрудник: §r§c"    . $data["admin"]);
        $player->sendMessage("§l§cПричина: §r§c"       . $data["reason"]);
        $player->sendMessage("§l§cРазблокировка: §r§c" . $expireStr . $duration);
        $player->sendMessage("§l§cОсталось: §r§c"      . $remaining);
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        $name   = strtolower($player->getName());

        if (!$this->mutesConfig->exists($name)) return;

        $data = $this->mutesConfig->get($name);

        if (isset($data["expire"]) && time() >= $data["expire"]) {
            $this->mutesConfig->remove($name);
            $this->mutesConfig->save();
            return;
        }

        $expireStr = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
        $remaining = isset($data["expire"]) ? $this->getTimeRemaining($data["expire"]) : "Никогда";
        $duration  = isset($data["duration_str"]) ? " (" . $data["duration_str"] . ")" : "";

        $player->sendMessage("§l§cАктивная блокировка чата.");
        $player->sendMessage("§l§cСотрудник: §r§c"    . $data["admin"]);
        $player->sendMessage("§l§cПричина: §r§c"       . $data["reason"]);
        $player->sendMessage("§l§cРазблокировка: §r§c" . $expireStr . $duration);
        $player->sendMessage("§l§cОсталось: §r§c"      . $remaining);
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch (strtolower($command->getName())) {
            case "rcmute":     return $this->handleMute($sender, $args);
            case "rcunmute":   return $this->handleUnmute($sender, $args);
            case "rcmuteinfo": return $this->handleMuteInfo($sender, $args);
            case "rcmutelist": return $this->handleMuteList($sender, $args);
        }
        return false;
    }

    // ===== /rcmute =====
    private function handleMute(CommandSender $sender, array $args): bool
    {
        if (count($args) < 3) {
            $sender->sendMessage("§l§cИспользование: §r§c/rcmute <ник> <время> [-s] <причина>");
            $sender->sendMessage("§l§cПримеры времени: §r§c10m, 2h, 1d, 1ms, 1g, 1g2d3h.");
            return true;
        }

        $targetInput = array_shift($args);
        $timeStr     = array_shift($args);

        // Тихий мут
        $silent = false;
        if (isset($args[0]) && strtolower($args[0]) === "-s") {
            if (!$this->isStaff($this->getAdminName($sender)) && $sender instanceof Player) {
                $sender->sendMessage("§l§cФлаг -s доступен только сотрудникам проекта.");
                return true;
            }
            $silent = true;
            array_shift($args);
        }

        $reason    = implode(" ", $args);
        $adminName = $this->getAdminName($sender);
        $targetName = $this->resolveTargetName($targetInput);
        $targetKey  = strtolower($targetName);

        if (empty(trim($reason))) {
            $sender->sendMessage("§l§cУкажите причину блокировки.");
            return true;
        }

        // Все проверки ДО списания лимита
        if (!$this->canMuteTarget($sender, $targetName)) return true;

        $minutes = $this->parseTime($timeStr);
        if ($minutes === null) {
            $sender->sendMessage("§l§cУкажите корректное время. Примеры: §r§c10m, 2h, 1d, 1ms, 1g, 1g2h.");
            return true;
        }

        if (!$this->checkLimitedTime($sender, $minutes)) return true;

        if ($this->mutesConfig->exists($targetKey)) {
            $existing = $this->mutesConfig->get($targetKey);
            if (isset($existing["expire"]) && $existing["expire"] > time()) {
                $sender->sendMessage("§l§cИгрок §r§c" . $targetName . " §l§cуже заблокирован до §r§c" . $this->formatTimestamp($existing["expire"]) . "§l§c. Блокировка будет перезаписана.");
            }
        }

        // Лимит — последняя проверка
        if (!$this->checkAndUseMuteLimit($sender)) return true;

        $expireTime   = time() + ($minutes * 60);
        $expireStr    = $this->formatTimestamp($expireTime);
        $durationStr  = $this->normalizeTime($minutes);

        $muteData = [
            "admin"        => $adminName,
            "reason"       => $reason,
            "time"         => time(),
            "expire"       => $expireTime,
            "date"         => $this->formatTimestamp(time()),
            "duration_str" => $durationStr,
        ];

        $this->mutesConfig->set($targetKey, $muteData);
        $this->mutesConfig->save();

        $targetPlayer = $this->getServer()->getPlayerExact($targetName) ?? $this->findPlayer($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->sendMessage("§l§cВам выдана блокировка чата.");
            $targetPlayer->sendMessage("§l§cСотрудник: §r§c"    . $adminName);
            $targetPlayer->sendMessage("§l§cПричина: §r§c"       . $reason);
            $targetPlayer->sendMessage("§l§cРазблокировка: §r§c" . $expireStr . " (" . $durationStr . ")");
        }

        $publicMsg = "§l§c" . $adminName . " §r§cвыдал блокировку чата §l§c" . $targetName . "§r§c. Причина: §l§c" . $reason . "§r§c. До разблокировки: §l§c" . $expireStr . " §r§c(" . $durationStr . ")§r§c.";

        if ($silent) {
            $this->notifyStaff($adminName . " тихо заблокировал чат " . $targetName . ". Причина: " . $reason . ". До: " . $expireStr . " (" . $durationStr . ").");
        } else {
            $this->broadcast($publicMsg);
        }

        $this->logAction("[RcMute] " . $adminName . " выдал мут " . $targetName . " на " . $durationStr . ". Причина: " . $reason . ($silent ? " [тихо]" : ""));

        return true;
    }

    // ===== /rcunmute =====
    private function handleUnmute(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§l§cИспользование: §r§c/rcunmute <ник> <причина>");
            return true;
        }

        $targetInput = array_shift($args);
        $reason      = implode(" ", $args);
        $targetKey   = strtolower($targetInput);
        $adminName   = $this->getAdminName($sender);

        if (empty(trim($reason))) {
            $sender->sendMessage("§l§cУкажите причину разблокировки.");
            return true;
        }

        if (!$this->mutesConfig->exists($targetKey)) {
            $sender->sendMessage("§l§cИгрок §r§c" . $targetInput . " §l§cне заблокирован.");
            return true;
        }

        $muteData = $this->mutesConfig->get($targetKey);

        if (!$this->checkLimitedUnmute($sender, $muteData)) return true;

        $previousAdmin = $muteData["admin"];

        $this->mutesConfig->remove($targetKey);
        $this->mutesConfig->save();

        $targetPlayer = $this->getServer()->getPlayerExact($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->sendMessage("§l§cБлокировка чата снята.");
            $targetPlayer->sendMessage("§l§cСнял: §r§c"    . $adminName);
            $targetPlayer->sendMessage("§l§cПричина: §r§c" . $reason);
        }

        $this->broadcastUnmute("§l§c" . $adminName . " §r§cснял блокировку чата §l§c" . $targetInput . "§r§c. Причина: §l§c" . $reason . "§r§c.");
        $this->getServer()->broadcastMessage("§l§c — §r§cРанее выдано сотрудником §l§c" . $previousAdmin . "§r§c.");
        $this->logAction("[RcMute] " . $adminName . " снял мут " . $targetInput . ". Причина: " . $reason);

        return true;
    }

    // ===== /rcmuteinfo =====
    private function handleMuteInfo(CommandSender $sender, array $args): bool
    {
        if (count($args) < 1) {
            $sender->sendMessage("§l§cИспользование: §r§c/rcmuteinfo <ник>");
            return true;
        }

        $targetKey = strtolower($args[0]);

        $group = $this->getPlayerGroup($args[0]);
        if ($group !== "") {
            $sender->sendMessage("§l§cГруппа игрока §r§c" . $args[0] . "§l§c: §r§c" . $group . "§l§c.");
        }

        if (!$this->mutesConfig->exists($targetKey)) {
            $sender->sendMessage("§l§cБлокировок чата не найдено для §r§c" . $args[0] . "§l§c.");
            return true;
        }

        $data = $this->mutesConfig->get($targetKey);

        if (isset($data["expire"]) && time() >= $data["expire"]) {
            $sender->sendMessage("§l§7Блокировка чата истекла.");
            $this->mutesConfig->remove($targetKey);
            $this->mutesConfig->save();
            return true;
        }

        $expireStr   = isset($data["expire"]) ? $this->formatTimestamp($data["expire"]) : "Никогда";
        $remaining   = isset($data["expire"]) ? $this->getTimeRemaining($data["expire"]) : "Никогда";
        $durationStr = $data["duration_str"] ?? "—";

        $sender->sendMessage("§l§c— Блокировка чата —");
        $sender->sendMessage("§l§cСотрудник: §r§c"      . $data["admin"]);
        $sender->sendMessage("§l§cПричина: §r§c"         . $data["reason"]);
        $sender->sendMessage("§l§cВыдано: §r§c"          . ($data["date"] ?? "—"));
        $sender->sendMessage("§l§cНа срок: §r§c"         . $durationStr);
        $sender->sendMessage("§l§cРазблокировка: §r§c"   . $expireStr);
        $sender->sendMessage("§l§cОсталось: §r§c"        . $remaining);

        return true;
    }

    // ===== /rcmutelist =====
    private function handleMuteList(CommandSender $sender, array $args): bool
    {
        $page    = isset($args[0]) && is_numeric($args[0]) ? max(1, (int) $args[0]) : 1;
        $perPage = 8;
        $allMutes = [];

        foreach ($this->mutesConfig->getAll() as $name => $data) {
            $expired    = isset($data["expire"]) && time() >= $data["expire"];
            $type       = $expired ? "§7ИСТЁК" : "§lАКТИВ";
            $allMutes[] = "§l§c" . $type . " §r§c" . $name . " §7| §r§c" . ($data["admin"] ?? "—") . " §7| §r§c" . ($data["reason"] ?? "—");
        }

        $total   = count($allMutes);
        $maxPage = max(1, (int) ceil($total / $perPage));
        $page    = min($page, $maxPage);

        $sender->sendMessage("§l§cСписок блокировок чата §r§c(стр. {$page}/{$maxPage}, всего: {$total})§l§c.");

        if ($total === 0) {
            $sender->sendMessage("§l§cСписок пуст.");
        } else {
            $offset = ($page - 1) * $perPage;
            $slice  = array_slice($allMutes, $offset, $perPage);
            $i      = $offset + 1;
            foreach ($slice as $line) {
                $sender->sendMessage("§l§c" . $i . ". §r§c" . $line);
                $i++;
            }
        }

        return true;
    }
}
