<?php

namespace InzeOwr\RcMarry;

use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\ModalForm;
use jojoe77777\FormAPI\CustomForm;

class Forms {

    /**
     * Главное меню свадебного регистратора
     */
    public static function openMainMenu(Player $player, Main $plugin): void {
        $passport = $plugin->getPassportData($player->getName());
        $hasPassport = $passport !== null;
        $isMarried = false;
        $partnerName = "";
        $partnerFio = "";
        $marryTime = 0;

        if($hasPassport && !empty($passport['partner'])) {
            $isMarried = true;
            $partnerName = $passport['partner'];
            $partnerFio = $passport['partnerFio'] ?? $partnerName;
            $marryTime = $passport['marryTime'] ?? 0;
        }

        $stats = $plugin->getMarryManager()->getStats();

        $form = new SimpleForm(function(Player $player, $data) use ($plugin, $hasPassport, $isMarried, $partnerName, $partnerFio, $marryTime) {
            if($data === null) return;

            $btnId = (int) $data;

            if(!$hasPassport) {
                $player->sendMessage("§cУ вас нет паспорта! Получите его в паспортном столе.");
                return;
            }

            if(!$isMarried) {
                if($btnId === 0) {
                    self::startProposal($player, $plugin);
                } elseif($btnId === 1) {
                    self::openInfoForm($player, $plugin);
                }
            } else {
                if($btnId === 0) {
                    self::openDivorceConfirm($player, $plugin, $partnerName, $partnerFio, $marryTime);
                } elseif($btnId === 1) {
                    self::openMarriageInfo($player, $plugin, $partnerName, $partnerFio, $marryTime);
                } elseif($btnId === 2) {
                    self::openInfoForm($player, $plugin);
                }
            }
        });

        $form->setTitle("§l§dСвадебный регистратор");

        $content = "§7Добро пожаловать в ЗАГС!\n\n";

        $playerFio = $hasPassport ? ($passport['fio'] ?? $player->getName()) : $player->getName();

        if(!$hasPassport) {
            $content .= "§cУ вас нет паспорта!\n§7Обратитесь в паспортный стол.\n\n";
        } elseif(!$isMarried) {
            $content .= "§eВаше ФИО: §f{$playerFio}\n";
            $content .= "§7Вы не состоите в браке.\n\n";
            $content .= "§a§lСвадьба: §r§f4000$\n";
            $content .= "§c§lРазвод: §r§f5000$\n\n";
            $content .= "§7Для свадьбы необходим паспорт у обоих.\n";
            $content .= "§7Предложение делается в радиусе §e5 блоков §7от NPC.\n";
        } else {
            $duration = $plugin->getMarryManager()->getMarriageDuration($player->getName());
            $content .= "§eВаше ФИО: §f{$playerFio}\n";
            $content .= "§aВы в браке с: §f{$partnerFio} (§e{$partnerName}§f)\n";
            $content .= "§7Вместе уже: §b{$duration}\n\n";
            $content .= "§c§lРазвод: §r§f5000$\n";
            $content .= "§7Развод происходит без участия партнера.\n";
        }

        $content .= "\n§8§lСтатистика ЗАГСа:\n";
        $content .= "§8Браков заключено: §f{$stats['total_marriages']}\n";
        $content .= "§8Разводов: §f{$stats['total_divorces']}\n";

        $form->setContent($content);

        if(!$hasPassport) {
            $form->addButton("§l§7[Заблокировано] §8Нет паспорта", -1, "", -1);
            $form->addButton("§l§eИнформация");
        } elseif(!$isMarried) {
            $form->addButton("§l§aПожениться\n§r§7(4000$)", -1, "", 0);
            $form->addButton("§l§eИнформация\n§r§7О системе", -1, "", 1);
        } else {
            $form->addButton("§l§cРасторгнуть брак\n§r§7(5000$)", -1, "", 0);
            $form->addButton("§l§aИнформация о браке\n§r§7Сколько вместе", -1, "", 1);
            $form->addButton("§l§eО системе", -1, "", 2);
        }

        $player->sendForm($form);
    }

    /**
     * Начать процесс предложения
     */
    private static function startProposal(Player $player, Main $plugin): void {
        $passport = $plugin->getPassportData($player->getName());
        if($passport === null) {
            $player->sendMessage("§cУ вас нет паспорта!");
            return;
        }

        $money = $plugin->getEconomy()->myMoney($player);
        if($money < 4000) {
            $player->sendMessage("§cУ вас недостаточно денег! Свадьба стоит 4000$.");
            $player->sendMessage("§7Ваш баланс: §e{$money}$");
            return;
        }

        $npcPos = $plugin->getMarryNpcPosition();
        if($npcPos === null) {
            $player->sendMessage("§cНе удалось найти свадебный NPC. Обратитесь к администрации.");
            return;
        }

        $dist = $player->getPosition()->distance($npcPos);
        if($dist > 5) {
            $player->sendMessage("§cВы должны находиться в радиусе 5 блоков от свадебного NPC!");
            return;
        }

        if($plugin->getMarryManager()->isMarried($player->getName())) {
            $player->sendMessage("§cВы уже состоите в браке!");
            return;
        }

        $plugin->setProposalSession($player->getName(), [
            'target' => null,
            'npcPos' => $npcPos,
            'step' => 'choose_player',
            'timeout' => time() + 60
        ]);

        $player->sendMessage("§a§lВы выбрали пожениться!");
        $player->sendMessage("§7Ударьте игрока, которому хотите сделать предложение.");
        $player->sendMessage("§7Игрок должен находиться в радиусе §e5 блоков §7от NPC.");
        $player->sendMessage("§cПредложение автоматически отменится через 60 секунд или если вы выйдете из радиуса.");
    }

    /**
     * Форма предложения для цели
     */
    public static function openProposalForm(Player $target, Player $proposer, Main $plugin): void {
        $proposerPass = $plugin->getPassportData($proposer->getName());
        $proposerFio = $proposerPass['fio'] ?? $proposer->getName();

        $form = new ModalForm(function(Player $target, $data) use ($plugin, $proposer) {
            if($data === null) {
                $plugin->declineProposal($proposer, $target);
                return;
            }

            if($data) {
                $plugin->acceptProposal($proposer, $target);
            } else {
                $plugin->declineProposal($proposer, $target);
            }
        });

        $form->setTitle("§l§dПредложение руки и сердца");
        $form->setContent(
            "§e{$proposerFio} (§f{$proposer->getName()}§e)\n" .
            "§7делает вам предложение!\n\n" .
            "§7Вы согласны вступить в брак?\n\n" .
            "§7Свадьбу оплачивает приглашающая сторона.\n" .
            "§7В случае согласия в паспорте появится запись о партнере."
        );
        $form->setButton1("§l§aСогласиться");
        $form->setButton2("§l§cОтказать");

        $target->sendForm($form);
    }

    /**
     * Подтверждение развода
     */
    private static function openDivorceConfirm(Player $player, Main $plugin, string $partnerName, string $partnerFio, int $marryTime): void {
        $duration = $plugin->getMarryManager()->getMarriageDuration($player->getName());
        $money = $plugin->getEconomy()->myMoney($player);

        $form = new ModalForm(function(Player $player, $data) use ($plugin) {
            if($data === null) return;

            if($data) {
                $money = $plugin->getEconomy()->myMoney($player);
                if($money < 5000) {
                    $player->sendMessage("§cНедостаточно средств! Развод стоит 5000$. Ваш баланс: {$money}$");
                    return;
                }
                $plugin->divorce($player);
            } else {
                $player->sendMessage("§eВы отменили развод.");
            }
        });

        $form->setTitle("§l§cРасторжение брака");
        $form->setContent(
            "§eВы уверены, что хотите развестись?\n\n" .
            "§fПартнер: §e{$partnerFio} (§f{$partnerName}§e)\n" .
            "§fВ браке: §b{$duration}\n\n" .
            "§cСтоимость развода: 5000$\n" .
            "§7Ваш баланс: §e{$money}$\n\n" .
            "§7Развод происходит §lбез участия §r§7второй половинки.\n" .
            "§7Запись о браке исчезнет из паспорта у обоих."
        );
        $form->setButton1("§l§cРазвестись (5000$)");
        $form->setButton2("§l§aОстаться в браке");

        $player->sendForm($form);
    }

    /**
     * Информация о текущем браке
     */
    private static function openMarriageInfo(Player $player, Main $plugin, string $partnerName, string $partnerFio, int $marryTime): void {
        $duration = $plugin->getMarryManager()->getMarriageDuration($player->getName());
        $passport = $plugin->getPassportData($player->getName());
        $playerFio = $passport['fio'] ?? $player->getName();

        $partnerPassport = $plugin->getPassportData($partnerName);
        $partnerFioDisplay = $partnerFio;
        if($partnerPassport !== null) {
            $partnerFioDisplay = $partnerPassport['fio'] ?? $partnerName;
        }

        $marriedDate = $marryTime > 0 ? date("d.m.Y H:i", $marryTime) : "§7Неизвестно";

        $form = new SimpleForm(function(Player $player, $data) {
            // Просто закрываем
        });

        $form->setTitle("§l§dИнформация о браке");

        $content =
            "§l§e=== Данные о браке ===\n\n" .
            "§fВы: §e{$playerFio} (§f{$player->getName()}§e)\n" .
            "§fПартнер: §e{$partnerFioDisplay} (§f{$partnerName}§e)\n" .
            "§fДата брака: §b{$marriedDate}\n" .
            "§fВместе уже: §b{$duration}\n\n" .
            "§l§e=== Условия ===\n\n" .
            "§fСвадьба: §a4000$\n" .
            "§fРазвод: §c5000$\n" .
            "§fПлатит: §eПриглашающая сторона\n\n" .
            "§l§e=== Требования ===\n\n" .
            "§7• Наличие паспорта у обоих\n" .
            "§7• Нахождение в радиусе 5 блоков от NPC\n" .
            "§7• Согласие второй половинки\n" .
            "§7• Достаточно средств на счету\n\n" .
            "§l§e=== Статистика ЗАГСа ===\n\n";

        $stats = $plugin->getMarryManager()->getStats();
        $content .=
            "§fВсего браков: §b{$stats['total_marriages']}\n" .
            "§fРазводов: §c{$stats['total_divorces']}\n" .
            "§fЗаработано средств: §e{$stats['money_earned']}$\n";

        $form->setContent($content);
        $form->addButton("§l§eЗакрыть");

        $player->sendForm($form);
    }

    /**
     * Информация о системе
     */
    private static function openInfoForm(Player $player, Main $plugin): void {
        $stats = $plugin->getMarryManager()->getStats();

        $form = new SimpleForm(function(Player $player, $data) {
            // Закрываем
        });

        $form->setTitle("§l§dО системе бракосочетания");

        $content =
            "§l§e=== Система браков RcMarry ===\n\n" .
            "§7Плагин позволяет игрокам заключать браки\n" .
            "§7прямо на сервере с полной документацией.\n\n" .
            "§l§e=== Как пожениться? ===\n\n" .
            "§71. Имейте паспорт (получить у паспортиста)\n" .
            "§72. Подойдите к свадебному NPC\n" .
            "§73. Нажмите на NPC и выберите §a'Пожениться'§7\n" .
            "§74. Ударьте игрока, которому делаете предложение\n" .
            "§75. Игрок должен быть в §e5 блоках §7от NPC\n" .
            "§76. Игрок получит предложение и может согласиться\n\n" .
            "§l§e=== Как развестись? ===\n\n" .
            "§71. Нажмите на свадебного NPC\n" .
            "§72. Выберите §c'Расторгнуть брак'§7\n" .
            "§73. Подтвердите развод (5000$)\n" .
            "§74. Развод происходит без участия партнера\n\n" .
            "§l§e=== Требования ===\n\n" .
            "§7• Паспорт у обоих участников\n" .
            "§7• 4000$ для свадьбы\n" .
            "§7• 5000$ для развода\n" .
            "§7• Наличие свадебного NPC на карте\n\n" .
            "§l§e=== Статистика ===\n\n" .
            "§fСыграно свадеб: §b{$stats['total_marriages']}\n" .
            "§fРазводов: §c{$stats['total_divorces']}\n" .
            "§fВыручка ЗАГСа: §e{$stats['money_earned']}$\n\n" .
            "§7Автор: §fInzeOwr\n" .
            "§7Версия: §f1.0.0";

        $form->setContent($content);
        $form->addButton("§l§eЗакрыть");

        $player->sendForm($form);
    }
}