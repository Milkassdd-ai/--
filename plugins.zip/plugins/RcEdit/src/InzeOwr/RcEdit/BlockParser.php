<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\block\UnknownBlock;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\StringToItemParser;

final class BlockParser {

	private function __construct() {}

	public static function parse(string $input): ?Block {
		$input = strtolower(trim($input));

		if ($input === "0" || $input === "air") {
			return VanillaBlocks::AIR();
		}

		if (preg_match('/^-?\d+$/', $input)) {
			$num = (int)$input;
			$block = self::tryFromNumber($num);
			if ($block !== null) return $block;
		}

		try {
			$item = StringToItemParser::getInstance()->parse($input);
			if ($item !== null) {
				$block = $item->getBlock();
				if ($block->getTypeId() !== BlockTypeIds::AIR || $input === "air") {
					return $block;
				}
			}
		} catch (\Throwable $e) {}

		return null;
	}

	private static function tryFromNumber(int $num): ?Block {
		$registry = RuntimeBlockStateRegistry::getInstance();

		try {
			$block = $registry->fromStateId($num);
			if ($block !== null && !($block instanceof UnknownBlock)) {
				return $block;
			}
		} catch (\Throwable $e) {}

		$shift = Block::INTERNAL_STATE_DATA_BITS;
		$mask = ~(~0 << $shift);

		for ($data = 0; $data <= $mask; $data++) {
			try {
				$block = $registry->fromStateId(($num << $shift) | $data);
				if ($block !== null && !($block instanceof UnknownBlock)) {
					return $block;
				}
			} catch (\Throwable $e) {
				break;
			}
		}

		return null;
	}
}
