<?php

namespace InzeOwr\RcOrg\systems;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\Server;
use InzeOwr\RcOrg\Main;

class FNSSystem {

    private Main $plugin;
    private Config $fnsData;

    public const FNS_RANKS = [
        1 => "Инспектор ФНС",
        2 => "Старший инспектор ФНС",
        3 => "Ведущий инспектор ФНС",
        4 => "Секретарь ФНС",
        5 => "Зам. руководителя ФНС",
        6 => "Руководитель ФНС"
    ];

    public const FNS_SALARY = [
        1 => 8000,
        2 => 12000,
        3 => 18000,
        4 => 25000,
        5 => 40000,
        6 => 70000
    ];

    public const MIN_PV_RANK = 5;
    public const FNS_COLOR = "e";

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->fnsData = new Config($plugin->getDataFolder() . "fns_data.json", Config::JSON);
    }

    public function getPlugin(): Main {
        return $this->plugin;
    }

    public function getFNSRank(string $playerName): int {
        return (int)$this->fnsData->getNested(strtolower($playerName) . ".rank", 0);
    }

    public function isInFNS(string $playerName): bool {
        return $this->getFNSRank($playerName) > 0;
    }

    public function getFNSRankName(int $rank): string {
        return self::FNS_RANKS[$rank] ?? "Неизвестно";
    }

    public function getFNSSalary(int $rank): int {
        return self::FNS_SALARY[$rank] ?? 5000;
    }

    public function getSavedPVRank(string $playerName): int {
        return (int)$this->fnsData->getNested(strtolower($playerName) . ".saved_pv_rank", 0);
    }

    
    public function getFNSJoinDate(string $playerName): string {
        return (string)$this->fnsData->getNested(strtolower($playerName) . ".join_date", "Нет данных");
    }

    
    public function getLastFNSSalary(string $playerName): int {
        return (int)$this->fnsData->getNested(strtolower($playerName) . ".last_salary", 0);
    }

    
    public function setLastFNSSalary(string $playerName, int $time): void {
        $this->fnsData->setNested(strtolower($playerName) . ".last_salary", $time);
        $this->fnsData->save();
    }

    private function syncRankToMain(string $playerName, int $rank): void {
        $key = strtolower($playerName);
        $this->plugin->data->setNested("$key.rank", $rank);
        $this->plugin->data->save();
        $this->plugin->updateExternalTag($playerName, "PV");
    }

    public function canJoinFNS(string $playerName): array {
        $org = $this->plugin->getPlayerOrg($playerName);
        if ($org !== "PV") {
            return ['success' => false, 'error' => "Только сотрудники Правительства могут состоять в ФНС."];
        }

        $pvRank = $this->plugin->getPlayerRank($playerName);
        if ($pvRank < self::MIN_PV_RANK && $pvRank < 100) {
            return ['success' => false, 'error' => "Требуется минимум " . self::MIN_PV_RANK . " ранг."];
        }

        if ($this->isInFNS($playerName)) {
            return ['success' => false, 'error' => "Сотрудник уже состоит в ФНС."];
        }

        return ['success' => true];
    }

    
    public function canManageFNS(Player $admin): bool {
        $org = $this->plugin->getPlayerOrg($admin->getName());
        $rank = $this->plugin->getPlayerRank($admin->getName());

        if ($org === "PV" && $rank >= 16) return true;

        $fnsRank = $this->getFNSRank($admin->getName());
        if ($fnsRank >= 5) return true;

        return false;
    }

    
    public function canInviteToFNS(Player $admin): bool {
        return $this->canManageFNS($admin);
    }

    
    public function setFNSRank(Player $admin, string $targetName, int $newRank): bool {
        if ($newRank < 1 || $newRank > 6) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§fРанг должен быть от 1 до 6.");
            return false;
        }

        $org = $this->plugin->getPlayerOrg($admin->getName());
        $pvRank = $this->plugin->getPlayerRank($admin->getName());
        if (!($org === "PV" && $pvRank >= 16)) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§fУ вас нет полномочий для спец. назначения.");
            return false;
        }

        if (!$this->isInFNS($targetName)) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§fСотрудник не состоит в ФНС.");
            return false;
        }

        $oldRank = $this->getFNSRank($targetName);
        $this->fnsData->setNested(strtolower($targetName) . ".rank", $newRank);
        $this->fnsData->save();

        $this->syncRankToMain($targetName, 100 + $newRank);

        $oldRankName = $this->getFNSRankName($oldRank);
        $newRankName = $this->getFNSRankName($newRank);

        $admin->sendMessage("§a§l[§eФНС§a§l] §r§l§fСотрудник §e{$targetName} §fназначен на должность §e{$newRankName} ({$newRank})§f.\n§7Предыдущая: {$oldRankName} ({$oldRank})");

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target) {
            $target->sendMessage("§a§l[§eФНС§a§l] §r§l§fВам присвоена должность: §e{$newRankName} ({$newRank})");
        }

        return true;
    }

    public function addToFNS(Player $admin, string $targetName): bool {
        if (!$this->canManageFNS($admin)) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§fУ вас нет полномочий.");
            return false;
        }

        $check = $this->canJoinFNS($targetName);
        if (!$check['success']) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§f" . $check['error']);
            return false;
        }

        $currentPVRank = $this->plugin->getPlayerRank($targetName);

        if ($currentPVRank > 100) $currentPVRank = self::MIN_PV_RANK;

        $key = strtolower($targetName);
        $this->fnsData->set($key, [
            'rank' => 1,
            'real_name' => $targetName,
            'join_date' => date("d.m.Y H:i"),
            'saved_pv_rank' => $currentPVRank,
            'last_salary' => 0
        ]);
        $this->fnsData->save();

        $this->syncRankToMain($targetName, 101);

        $admin->sendMessage("§a§l[§eФНС§a§l] §r§l§fСотрудник §e{$targetName} §fпринят в ФНС.");
        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target) $target->sendMessage("§a§l[§eФНС§a§l] §r§l§fВы приняты в Федеральную Налоговую Службу!");

        return true;
    }

    public function promoteFNS(Player $admin, string $targetName): bool {
        if (!$this->canManageFNS($admin)) return false;
        if (!$this->isInFNS($targetName)) return false;

        $currentRank = $this->getFNSRank($targetName);
        if ($currentRank >= 6) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§fМаксимальный ранг.");
            return false;
        }

        $newRank = $currentRank + 1;
        $this->fnsData->setNested(strtolower($targetName) . ".rank", $newRank);
        $this->fnsData->save();

        $this->syncRankToMain($targetName, 100 + $newRank);

        $admin->sendMessage("§a§l[§eФНС§a§l] §r§l§fСотрудник повышен до §e" . $this->getFNSRankName($newRank) . " ({$newRank})§f.");

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target) $target->sendMessage("§a§l[§eФНС§a§l] §r§l§fВы повышены до §e" . $this->getFNSRankName($newRank) . " ({$newRank})§f!");

        return true;
    }

    public function demoteFNS(Player $admin, string $targetName): bool {
        if (!$this->canManageFNS($admin)) return false;
        if (!$this->isInFNS($targetName)) return false;

        $currentRank = $this->getFNSRank($targetName);
        if ($currentRank <= 1) {
            $admin->sendMessage("§c§l[§eФНС§c§l] §r§l§fМинимальный ранг.");
            return false;
        }

        $newRank = $currentRank - 1;
        $this->fnsData->setNested(strtolower($targetName) . ".rank", $newRank);
        $this->fnsData->save();

        $this->syncRankToMain($targetName, 100 + $newRank);

        $admin->sendMessage("§a§l[§eФНС§a§l] §r§l§fСотрудник понижен до §e" . $this->getFNSRankName($newRank) . " ({$newRank})§f.");

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target) $target->sendMessage("§c§l[§eФНС§c§l] §r§l§fВы понижены до §e" . $this->getFNSRankName($newRank) . " ({$newRank})§f.");

        return true;
    }

    public function removeFromFNS(Player $admin, string $targetName, string $reason = ""): bool {
        if (!$this->canManageFNS($admin)) return false;
        if (!$this->isInFNS($targetName)) return false;

        $rankName = $this->getFNSRankName($this->getFNSRank($targetName));
        $this->restoreAndRemove($targetName, $reason, $admin->getName());

        $reasonStr = !empty($reason) ? " Причина: §e{$reason}" : "";
        $admin->sendMessage("§a§l[§eФНС§a§l] §r§l§fСотрудник §e{$targetName} §f(§e{$rankName}§f) уволен из ФНС.{$reasonStr}");

        return true;
    }

    public function selfLeave(Player $player): bool {
        if (!$this->isInFNS($player->getName())) return false;
        $this->restoreAndRemove($player->getName(), "С/Ж", null);
        $player->sendMessage("§a§l[§eФНС§a§l] §r§l§fВы уволились из ФНС. Ваш ранг в Правительстве восстановлен.");
        return true;
    }

    private function restoreAndRemove(string $targetName, string $reason, ?string $adminName): void {
        $savedPVRank = $this->getSavedPVRank($targetName);

        if ($savedPVRank < self::MIN_PV_RANK) $savedPVRank = self::MIN_PV_RANK;

        $this->fnsData->remove(strtolower($targetName));
        $this->fnsData->save();

        $this->syncRankToMain($targetName, $savedPVRank);

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target && $adminName !== null) {
            $reasonStr = !empty($reason) ? " Причина: §e{$reason}" : "";
            $target->sendMessage("§c§l[§eФНС§c§l] §r§l§fВы уволены из ФНС. Ваш ранг в Правительстве восстановлен.{$reasonStr}");
        }
    }

    public function collectFNSSalary(Player $player): void {
        $name = $player->getName();
        if (!$this->isInFNS($name)) return;

        $lastTime = $this->getLastFNSSalary($name);
        $time = time();

        if (($time - $lastTime) < 1200) {
            $rem = 1200 - ($time - $lastTime);
            $min = floor($rem / 60);
            $sec = $rem % 60;
            $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fЖалование доступно через: §e{$min} мин. {$sec} сек.");
            return;
        }

        $amount = $this->getFNSSalary($this->getFNSRank($name));
        \onebone\economyapi\EconomyAPI::getInstance()->addMoney($player, $amount);
        $this->setLastFNSSalary($name, $time);

        $player->sendMessage("§a§l[§eФНС§a§l] §r§l§fЗарплата получена: §e" . number_format($amount) . "\$");
    }

    public function clearData(string $playerName): void {
        if ($this->isInFNS($playerName)) {
            $this->fnsData->remove(strtolower($playerName));
            $this->fnsData->save();
        }
    }

    public function getFNSMemberCount(): int {
        return count($this->fnsData->getAll());
    }

    public function getFNSLeader(): ?array {
        foreach ($this->fnsData->getAll() as $name => $data) {
            if (isset($data['rank']) && $data['rank'] === 6) {
                return [
                    'nick' => $data['real_name'] ?? $name,
                    'fio' => $this->plugin->getFio($data['real_name'] ?? $name),
                    'date' => $data['join_date'] ?? "Неизвестно"
                ];
            }
        }
        return null;
    }

    public function getAllFNSMembers(): array {
        $m = [];
        foreach ($this->fnsData->getAll() as $name => $d) {
            $m[] = ['name' => $d['real_name'] ?? $name, 'rank' => $d['rank']];
        }
        usort($m, fn($a, $b) => $b['rank'] <=> $a['rank']);
        return $m;
    }
}