<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase {

	private BlockProcessor $processor;
	private CommandHandler $commandHandler;
	private EventListener $eventListener;

	/** @var array<string, Session> */
	private array $sessions = [];

	public function onEnable(): void {
		$this->processor = new BlockProcessor($this);
		$this->commandHandler = new CommandHandler($this, $this->processor);
		$this->eventListener = new EventListener($this, $this->processor);

		$this->getServer()->getPluginManager()->registerEvents($this->eventListener, $this);
		@mkdir($this->getDataFolder() . "schematics", 0777, true);
	}

	public function onDisable(): void {
		$this->sessions = [];
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
		return $this->commandHandler->handle($sender, $command, $args);
	}

	public function getSession(Player $player): Session {
		$name = $player->getName();
		if (!isset($this->sessions[$name])) {
			$this->sessions[$name] = new Session($player, $this);
		}
		return $this->sessions[$name];
	}

	public function removeSession(string $name): void {
		unset($this->sessions[$name]);
	}

	public function getBlockProcessor(): BlockProcessor {
		return $this->processor;
	}

	public function getSchematicsPath(): string {
		return $this->getDataFolder() . "schematics/";
	}
}
