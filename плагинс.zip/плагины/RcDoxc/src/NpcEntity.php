<?php

namespace InzeOwr\RcDoxc;

use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;

class NpcEntity extends Human {

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        // Делаем ник всегда видимым
        $this->setNameTagAlwaysVisible(true);
        // Отключаем сохранение гравитации, чтобы не падал сквозь блоки при лагах
        $this->setHasGravity(false);
    }

    // Полностью отключаем передвижение по физике
    protected function move(float $dx, float $dy, float $dz): void {
        // Оставляем пустым, чтобы сущность не двигалась
    }

    // Запрещаем толкать NPC
    public function canBePushed(): bool {
        return false;
    }

    // Обработка получения урона
    public function attack(EntityDamageEvent $source): void {
        // Отменяем любой урон
        $source->cancel();
        
        // ВАЖНО: Мы не открываем форму здесь, так как Entity не должен зависеть от Main напрямую.
        // Логику открытия формы оставим в EventListener (Main.php), который поймает это событие даже если оно отменено.
    }
    
    // Чтобы NPC поворачивал голову за игроком (опционально, убрал чтобы стоял смирно)
    // Если нужно чтобы крутился - раскомментируй onUpdate и добавь логику lookAt
    public function onUpdate(int $currentTick): bool {
        return parent::onUpdate($currentTick);
    }
}