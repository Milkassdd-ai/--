<?php

namespace InzeOwr\RcOrg\systems;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\CustomForm;
use InzeOwr\RcOrg\Main;

class WantedSystem {

    private Main $plugin;
    private Config $wanted;
    private array $tracking = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->wanted = new Config($plugin->getDataFolder() . "wanted.json", Config::JSON);
    }

    public function addStars(string $targetName, int $amount, string $reason, ?Player $officer = null): void {
        $name = strtolower($targetName);
        $current = $this->wanted->get($name, 0);
        if (!is_array($current)) {
            $current = 0;
        } else {
            $current = $current['stars'] ?? 0;
        }
        $new = $current + $amount;
        if ($new > 7) $new = 7;

        $officerName = $officer ? $officer->getName() : "Система";

        $this->wanted->set($name, [
            "stars" => $new,
            "reason" => $reason,
            "by" => $officerName,
            "date" => date("d.m.Y H:i")
        ]);
        $this->wanted->save();

        $officerInfo = "";
        $color = "f";

        if ($officer) {
            $org = $this->plugin->getPlayerOrg($officer->getName());
            $rank = $this->plugin->getPlayerRank($officer->getName());
            $rankName = $this->plugin->getRankName($org, $rank);
            $color = $this->plugin->getOrgColor($org);
            $coloredOrg = $this->plugin->getColoredOrgName($org);
            $officerInfo = "{$rankName} {$officerName} ({$coloredOrg}§l§{$color})";
        } else {
            $officerInfo = "§c[СИСТЕМА]";
            $color = "c";
        }

        $msg = "§l§{$color}{$officerInfo} §r§l§fобъявил в розыск гражданина §e{$targetName} §f(§c{$new}★§f). Причина: §7{$reason}";

        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $pOrg = $this->plugin->getPlayerOrg($p->getName());
            if ($pOrg !== null && $pOrg !== "MF") $p->sendMessage($msg);
        }

        $t = Server::getInstance()->getPlayerExact($targetName);
        if ($t) {
            $t->sendMessage("§c§l[РОЗЫСК] §r§l§fВам выдано §e{$amount} §fуровень розыска! Текущий: §c{$new}★§f.");
            $t->sendMessage("§l§fПричина: §7{$reason}");
            if ($officer) {
                $org = $this->plugin->getPlayerOrg($officer->getName());
                $rankName = $this->plugin->getRankName($org, $this->plugin->getPlayerRank($officer->getName()));
                $coloredOrg = $this->plugin->getColoredOrgName($org);
                $t->sendMessage("§l§fСотрудник: §e{$rankName} {$officer->getName()} §7({$coloredOrg}§7)");
            }
        }

        if ($officer) {
            $officer->sendMessage("§a§l[Розыск] §r§l§fГражданин §e{$targetName} §fобъявлен в розыск (§c{$new}★§f). Причина: §7{$reason}");
            $org = $this->plugin->getPlayerOrg($officer->getName());
            if ($org) {
                $this->plugin->addLog($org, "Сотрудник {$officer->getName()} объявил {$targetName} в розыск ({$new}★). Причина: {$reason}");
            }
        }
    }

    public function getStars(string $name): int {
        $data = $this->wanted->get(strtolower($name), 0);
        if (is_array($data)) return (int)($data['stars'] ?? 0);
        return (int)$data;
    }

    public function clearStars(string $name): void {
        $key = strtolower($name);
        $this->wanted->remove($key);
        $this->wanted->save();
        foreach ($this->tracking as $officer => $target) {
            if (strtolower($target) === $key) {
                unset($this->tracking[$officer]);
            }
        }
    }

    public function hasStars(string $name): bool {
        return $this->getStars($name) > 0;
    }

    public function getWantedInfo(string $name): array {
        $data = $this->wanted->get(strtolower($name), []);
        if (is_array($data)) {
            return [
                "stars"  => (int)($data['stars'] ?? 0),
                "reason" => $data['reason'] ?? "Не указана",
                "by"     => $data['by'] ?? "Система",
                "date"   => $data['date'] ?? "Неизвестно"
            ];
        }
        return [
            "stars"  => (int)$data,
            "reason" => "Не указана",
            "by"     => "Система",
            "date"   => "Неизвестно"
        ];
    }

    public function startTracking(string $officerName, string $targetName): void {
        $this->tracking[strtolower($officerName)] = $targetName;
    }

    public function stopTracking(string $officerName): void {
        unset($this->tracking[strtolower($officerName)]);
    }

    public function isTracking(string $officerName): bool {
        return isset($this->tracking[strtolower($officerName)]);
    }

    public function getTrackedTarget(string $officerName): ?string {
        return $this->tracking[strtolower($officerName)] ?? null;
    }

    public function tickTracking(): void {
        foreach ($this->tracking as $officerKey => $targetName) {
            $officer = Server::getInstance()->getPlayerExact($officerKey);
            if ($officer === null || !$officer->isOnline()) {
                unset($this->tracking[$officerKey]);
                continue;
            }

            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target === null || !$target->isOnline()) {
                $officer->sendTip(
                    "§e§l[Отслеживание]\n" .
                    "§fГражданин §e{$targetName} §fпокинул сервер.\n" .
                    "§7Отслеживание прервано."
                );
                unset($this->tracking[$officerKey]);
                continue;
            }

            if (!$this->hasStars($targetName)) {
                $officer->sendTip(
                    "§a§l[Отслеживание]\n" .
                    "§fГражданин §e{$targetName} §fбольше не в розыске.\n" .
                    "§7Отслеживание завершено."
                );
                unset($this->tracking[$officerKey]);
                continue;
            }

            $distance = round($officer->getPosition()->distance($target->getPosition()), 1);
            $stars = $this->getStars($targetName);
            $starsStr = str_repeat("★", $stars);

            if ($distance <= 5) {
                $proximity = "§aВплотную";
            } elseif ($distance <= 15) {
                $proximity = "§eОчень близко";
            } elseif ($distance <= 30) {
                $proximity = "§6Близко";
            } elseif ($distance <= 60) {
                $proximity = "§cДалеко";
            } else {
                $proximity = "§4Очень далеко";
            }

            $officer->sendTip(
                "§c§l[Розыск] §e{$targetName} §c{$starsStr}\n" .
                "§fРасстояние: §e{$distance} м. §7— {$proximity}\n" .
                "§7Перезайдите для отмены отслеживания."
            );
        }
    }

    public function openWantedMenu(Player $officer): void {
        $online = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($p->getName() !== $officer->getName()) {
                $online[] = $p->getName();
            }
        }

        if (empty($online)) {
            $officer->sendMessage("§c§l[Розыск] §r§l§fНа сервере нет других игроков.");
            return;
        }

        $form = new CustomForm(function (Player $player, $data) use ($online) {
            if ($data === null) return;

            $action = (int)($data[0] ?? 0);
            $targetIndex = (int)($data[1] ?? 0);

            if (!isset($online[$targetIndex])) return;
            $targetName = $online[$targetIndex];

            if ($action === 0) {
                $stars = (int)($data[2] ?? 1);
                $reason = trim($data[3] ?? "");

                if (empty($reason)) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину розыска.");
                    return;
                }

                if (Main::getInstance()->getImmunitySystem()->hasImmunity($targetName)) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fУ гражданина §e{$targetName} §fдействует статус неприкосновенности!");
                    return;
                }

                $tOrg = Main::getInstance()->getPlayerOrg($targetName);
                $tRank = Main::getInstance()->getPlayerRank($targetName);
                if ($tOrg !== null && $tOrg !== "MF" && $tRank >= 15) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fЗапрещено объявлять в розыск руководство гос. структур.");
                    return;
                }

                $this->addStars($targetName, $stars, $reason, $player);

            } elseif ($action === 1) {
                if (!$this->hasStars($targetName)) {
                    $player->sendMessage("§c§l[Розыск] §r§l§fУ гражданина нет звёзд розыска.");
                    return;
                }

                $this->clearStars($targetName);
                $player->sendMessage("§a§l[Розыск] §r§l§fРозыск с гражданина §e{$targetName} §fснят.");

                $target = Server::getInstance()->getPlayerExact($targetName);
                if ($target) {
                    $target->sendMessage("§a§l[Розыск] §r§l§fС вас снят розыск сотрудником правоохранительных органов.");
                }

                $org = Main::getInstance()->getPlayerOrg($player->getName());
                if ($org) {
                    Main::getInstance()->addLog($org, "§c§l{$player->getName()} §6§lснял розыск с §b§l{$targetName}");
                }
            }
        });

        $form->setTitle("§l§9УПРАВЛЕНИЕ РОЗЫСКОМ");
        $form->addDropdown("§l§fДействие:", ["Выдать розыск", "Снять розыск"]);
        $form->addDropdown("§l§fВыберите гражданина:", $online);
        $form->addSlider("§l§fКоличество звезд:", 1, 7, 1, 1);
        $form->addInput("§l§fПричина:", "Убийство, нападение на сотрудника...");
        $officer->sendForm($form);
    }
}