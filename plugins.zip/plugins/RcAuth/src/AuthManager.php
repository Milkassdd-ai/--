<?php

declare(strict_types=1);

namespace InzeOwr\RcAuth;

use pocketmine\player\Player;
use pocketmine\scheduler\Task;

class AuthManager {

    private Main $plugin;
    private array $authenticated = [];
    private array $loginAttempts = [];
    private array $authHandlers = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function isAuthenticated(Player $player): bool {
        return isset($this->authenticated[strtolower($player->getName())]);
    }

    public function setAuthenticated(Player $player, bool $value): void {
        $nick = strtolower($player->getName());
        if ($value) {
            $this->authenticated[$nick] = true;
        } else {
            unset($this->authenticated[$nick]);
        }
    }

    public function getLoginAttempts(string $nick): int {
        return $this->loginAttempts[strtolower($nick)] ?? 0;
    }

    public function setLoginAttempts(string $nick, int $attempts): void {
        $this->loginAttempts[strtolower($nick)] = $attempts;
    }

    public function decreaseLoginAttempts(string $nick): int {
        $nick = strtolower($nick);
        if (!isset($this->loginAttempts[$nick])) {
            $this->loginAttempts[$nick] = 0;
        }
        $this->loginAttempts[$nick]--;
        return $this->loginAttempts[$nick];
    }

    public function startAuthTimer(Player $player): void {
        $nick = strtolower($player->getName());
        $playerName = $player->getName();
        $task = new class($this->plugin, $playerName) extends Task {
            private Main $plugin;
            private string $playerName;
            public function __construct(Main $plugin, string $playerName) {
                $this->plugin = $plugin;
                $this->playerName = $playerName;
            }
            public function onRun(): void {
                $p = $this->plugin->getServer()->getPlayerExact($this->playerName);
                if ($p === null) {
                    return;
                }
                if (!$this->plugin->getAuthManager()->isAuthenticated($p)) {
                    $p->kick("§l§c | Время на авторизацию истекло");
                }
            }
        };
        $handler = $this->plugin->getScheduler()->scheduleDelayedTask($task, 20 * 60);
        $this->authHandlers[$nick] = $handler;
    }

    public function cancelAuthTimer(string $nick): void {
        $nick = strtolower($nick);
        if (isset($this->authHandlers[$nick])) {
            $this->authHandlers[$nick]->cancel();
            unset($this->authHandlers[$nick]);
        }
    }

    public function cleanupPlayer(Player $player): void {
        $nick = strtolower($player->getName());
        unset($this->authenticated[$nick]);
        unset($this->loginAttempts[$nick]);
        $this->cancelAuthTimer($nick);
    }

    public function isIpAuthEnabled(Player $player): bool {
        $nick = strtolower($player->getName());
        $settings = $this->plugin->getPlayerSettings();
        return (bool) $settings->getNested($nick . ".ip_auth", false);
    }

    public function setIpAuthEnabled(string $nick, bool $enabled): void {
        $nick = strtolower($nick);
        $this->plugin->getPlayerSettings()->setNested($nick . ".ip_auth", $enabled);
        $this->plugin->getPlayerSettings()->save();
    }
}
