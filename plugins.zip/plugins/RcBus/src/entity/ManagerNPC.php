<?php

declare(strict_types=1);

namespace InzeOwr\RcBus\entity;

use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;

class ManagerNPC extends Human
{
    private string $businessTech = "";

    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null)
    {
        parent::__construct($location, $skin, $nbt);
        if ($nbt !== null) {
            $this->businessTech = $nbt->getString("BusinessTech", "");
        }
    }

    public function getBusinessTech(): string
    {
        return $this->businessTech;
    }

    public function saveNBT(): CompoundTag
    {
        $nbt = parent::saveNBT();
        $nbt->setString("BusinessTech", $this->businessTech);
        $nbt->setString("NPCType", "manager");
        return $nbt;
    }

    protected function entityBaseTick(int $tickDiff = 1): bool
    {
        $this->motion = new Vector3(0, 0, 0);
        return parent::entityBaseTick($tickDiff);
    }

    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);
        $this->setNoClientPredictions(true);
        $this->setNameTagAlwaysVisible(true);
        $this->gravity = 0.0;
        $this->gravityEnabled = false;
        $this->businessTech = $nbt->getString("BusinessTech", "");
    }
}