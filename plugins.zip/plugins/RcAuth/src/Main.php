<?php

declare(strict_types=1);

namespace InzeOwr\RcAuth;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class Main extends PluginBase {

    private Config $db;
    private Config $logs;
    private Config $bans;
    private Config $settings;
    private AuthManager $authManager;
    private FormFactory $formFactory;

    protected function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->db = new Config($this->getDataFolder() . "database.yml", Config::YAML);
        $this->logs = new Config($this->getDataFolder() . "logs.yml", Config::YAML);
        $this->bans = new Config($this->getDataFolder() . "temp_bans.yml", Config::YAML);
        $this->settings = new Config($this->getDataFolder() . "settings.yml", Config::YAML);
        $this->authManager = new AuthManager($this);
        $this->formFactory = new FormFactory($this);
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
    }


    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch (strtolower($command->getName())) {
            case "rcauth":
                $this->handleRcAuth($sender, $args);
                return true;
            case "rcauthlog":
                $this->handleRcAuthLog($sender, $args);
                return true;
            case "rcpauth":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§l§c | Только для игроков");
                    return true;
                }
                $this->handleRcPAuth($sender);
                return true;
        }
        return false;
    }

    public function getDb(): Config {
        return $this->db;
    }

    public function getLogs(): Config {
        return $this->logs;
    }

    public function getBans(): Config {
        return $this->bans;
    }

    public function getPlayerSettings(): Config {
        return $this->settings;
    }

    public function getAuthManager(): AuthManager {
        return $this->authManager;
    }

    public function getFormFactory(): FormFactory {
        return $this->formFactory;
    }

    public function getMskTime(): string {
        $date = new \DateTime("now", new \DateTimeZone("Europe/Moscow"));
        return $date->format("d.m.y H:i:s");
    }

    public function addLog(string $nick, string $action, string $ip): void {
        $nick = strtolower($nick);
        $currentLogs = $this->logs->get($nick, []);
        $currentLogs[] = "§l§7 | " . $this->getMskTime() . " §f" . $action . " §7(IP: " . $ip . ")";
        $this->logs->set($nick, $currentLogs);
        $this->logs->save();
    }


    public function handleRcAuth(CommandSender $sender, array $args): void {
        if (!$sender->hasPermission("rcauth.admin")) {
            $sender->sendMessage("§l§c | У вас нет прав");
            return;
        }
        if (count($args) < 2) {
            $sender->sendMessage("§l§e | Использование: /rcauth <ник> <новый_пароль>");
            return;
        }
        $targetNick = strtolower($args[0]);
        $newPass = $args[1];

        if (strlen($newPass) < 4) {
            $sender->sendMessage("§l§c | Слишком короткий пароль");
            return;
        }

        if (!$this->getDb()->exists($targetNick)) {
            $sender->sendMessage("§l§c | Игрок не найден");
            return;
        }

        $hashAlgo = defined("PASSWORD_ARGON2ID") ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        $data = $this->getDb()->get($targetNick);
        $data["password"] = password_hash($newPass, $hashAlgo);
        $data["ip"] = "reset_" . time();
        $this->getDb()->set($targetNick, $data);
        $this->getDb()->save();

        $this->addLog($targetNick, "Пароль изменен админом " . $sender->getName(), "SYSTEM");
        $sender->sendMessage("§l§a | Пароль для §e" . $targetNick . " §aизменен. IP сброшен");

        $targetP = $this->getServer()->getPlayerExact($targetNick);
        if ($targetP !== null) {
            $this->getAuthManager()->setAuthenticated($targetP, false);
            $targetP->sendMessage("§l§e | Администратор изменил ваш пароль. Войдите снова");
            $this->getFormFactory()->sendLoginForm($targetP);
        }
    }

    public function handleRcAuthLog(CommandSender $sender, array $args): void {
        if (!$sender->hasPermission("rcauth.admin")) {
            $sender->sendMessage("§l§c | У вас нет прав");
            return;
        }
        if (!isset($args[0])) {
            $sender->sendMessage("§l§e | Использование: /rcauthlog <ник>");
            return;
        }
        $target = strtolower($args[0]);
        if (!$this->getLogs()->exists($target)) {
            $sender->sendMessage("§l§c | Логов для игрока §e" . $target . " §cне найдено");
            return;
        }
        $sender->sendMessage("§l§b | История входов §e" . $target);
        foreach (array_reverse($this->getLogs()->get($target)) as $line) {
            $sender->sendMessage($line);
        }
    }

    public function handleRcPAuth(Player $player): void {
        $this->getFormFactory()->sendSettingsForm($player);
    }
}
