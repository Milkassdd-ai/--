<?php

namespace InzeOwr\RcMarry;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\VanillaItems;
use pocketmine\world\World;
use pocketmine\utils\TextFormat;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityPreExplodeEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\entity\EntityMotionEvent;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\scheduler\ClosureTask;
use onebone\economyapi\EconomyAPI;
use InzeOwr\RcDoxc\Main as RcDoxcMain;

class Main extends PluginBase implements Listener {

    private MarryManager $marryManager;
    private ?EconomyAPI $economy = null;
    private ?RcDoxcMain $rcDoxc = null;

    /** @var array<string, array> Сессии предложений */
    private array $proposalSessions = [];

    /** @var array<string, bool> Игроки в режиме удаления NPC */
    private array $deleteMode = [];

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->marryManager = new MarryManager($this);
        $this->economy = EconomyAPI::getInstance();

        $rcDoxcPlugin = $this->getServer()->getPluginManager()->getPlugin("RcDoxc");
        if($rcDoxcPlugin instanceof RcDoxcMain && $rcDoxcPlugin->isEnabled()){
            $this->rcDoxc = $rcDoxcPlugin;
        } else {
            $this->getLogger()->warning("RcDoxc не найден или выключен! Плагин паспортов не работает.");
        }

        EntityFactory::getInstance()->register(MarryNpcEntity::class, function(World $world, CompoundTag $nbt): MarryNpcEntity {
            $skin = Human::parseSkinNbt($nbt);
            return new MarryNpcEntity(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);
        }, ['RcMarryNpcEntity']);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->checkProposalTimeouts();
        }), 20);
    }

    public function getMarryManager(): MarryManager {
        return $this->marryManager;
    }

    public function getEconomy(): ?EconomyAPI {
        return $this->economy;
    }

    public function getRcDoxc(): ?RcDoxcMain {
        return $this->rcDoxc;
    }

    public function getPassportData(string $playerName): ?array {
        if($this->rcDoxc === null) return null;
        return $this->rcDoxc->getDataManager()->getData($playerName, 'passport');
    }

    public function savePassportData(string $playerName, array $data): void {
        if($this->rcDoxc === null) return;
        $this->rcDoxc->getDataManager()->saveData($playerName, 'passport', $data);
    }

    public function getProposalSession(string $playerName): ?array {
        return $this->proposalSessions[strtolower($playerName)] ?? null;
    }

    public function setProposalSession(string $playerName, ?array $session): void {
        $key = strtolower($playerName);
        if($session === null) {
            unset($this->proposalSessions[$key]);
        } else {
            $this->proposalSessions[$key] = $session;
        }
    }

    public function getProposalSessions(): array {
        return $this->proposalSessions;
    }

    /**
     * Каждый тик проверяем не протухли ли сессии
     */
    private function checkProposalTimeouts(): void {
        $now = time();
        foreach($this->proposalSessions as $name => $session) {
            if(isset($session['timeout']) && $now > $session['timeout']) {
                $player = $this->getServer()->getPlayerByPrefix($name);
                if($player !== null) {
                    $player->sendMessage("§cВремя предложения истекло. Начните заново.");
                }
                unset($this->proposalSessions[$name]);
                continue;
            }
            if($session['step'] === 'choose_player') {
                $player = $this->getServer()->getPlayerByPrefix($name);
                if($player !== null) {
                    $dist = $player->getPosition()->distance($session['npcPos']);
                    if($dist > 5) {
                        $player->sendMessage("§cВы вышли за радиус 5 блоков от свадебного NPC. Предложение отменено.");
                        unset($this->proposalSessions[$name]);
                    }
                }
            }
        }
    }

    /**
     * Ищем свадебного NPC на всех мирах
     */
    public function getMarryNpcPosition(): ?\pocketmine\world\Position {
        foreach($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach($world->getEntities() as $entity) {
                if($entity instanceof MarryNpcEntity) {
                    return $entity->getPosition();
                }
            }
        }
        return null;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if(!$sender instanceof Player) return false;

        if($command->getName() === "rcmarry") {
            if(!isset($args[0])) {
                if(!$sender->hasPermission("rcmarry.admin")) {
                    $sender->sendMessage("§cУ вас нет прав на установку свадебного NPC.");
                    return true;
                }
                $this->spawnMarryNpc($sender);
                $sender->sendMessage("§aСвадебный NPC успешно установлен!");
                return true;
            }

            if($args[0] === "del" || $args[0] === "delete") {
                if(!$sender->hasPermission("rcmarry.admin")) {
                    $sender->sendMessage("§cУ вас нет прав.");
                    return true;
                }
                $this->deleteMode[strtolower($sender->getName())] = true;
                $sender->sendMessage("§aРежим удаления NPC активирован! Нажмите на NPC левой кнопкой мыши.");
                $sender->sendMessage("§7Напишите §c/rcmarry cancel §7чтобы отменить.");
                return true;
            }

            if($args[0] === "cancel") {
                if(isset($this->deleteMode[strtolower($sender->getName())])) {
                    unset($this->deleteMode[strtolower($sender->getName())]);
                    $sender->sendMessage("§cРежим удаления NPC отменен.");
                } else {
                    $sender->sendMessage("§cВы не в режиме удаления.");
                }
                return true;
            }
        }
        return false;
    }

    private function spawnMarryNpc(Player $player): void {
        $location = $player->getLocation();
        $nbt = CompoundTag::create()
            ->setString("RcMarryNpc", "true")
            ->setString("RcDoxcNpcType", "rc_marry_npc");
        $entity = new MarryNpcEntity($location, $player->getSkin(), $nbt);
        $entity->setNameTag("§l§dСвадебный регистратор\n§r§7Нажмите чтобы открыть");
        $entity->spawnToAll();
    }

    /**
     * Правый клик по NPC (через пакет)
     */
    public function onDataPacketReceive(DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();
        if($player === null) return;

        if($packet instanceof InventoryTransactionPacket) {
            $trData = $packet->trData;
            if($trData instanceof UseItemOnEntityTransactionData) {
                if($trData->getActionType() === UseItemOnEntityTransactionData::ACTION_INTERACT) {
                    $entityId = $trData->getActorRuntimeId();
                    $entity = $player->getWorld()->getEntity($entityId);
                    if($entity instanceof MarryNpcEntity) {
                        $event->cancel();
                        $this->handleNpcClick($player);
                    }
                }
            }
        }
    }

    /**
     * Левый клик или любой урон по NPC
     */
    public function onNpcDamage(EntityDamageByEntityEvent $event): void {
        $entity = $event->getEntity();
        $damager = $event->getDamager();

        if($entity instanceof MarryNpcEntity) {
            $event->cancel();

            if($damager instanceof Player) {
                $name = strtolower($damager->getName());
                if(isset($this->deleteMode[$name])) {
                    $entity->flagForDespawn();
                    $entity->close();
                    $damager->sendMessage("§aСвадебный NPC успешно удален!");
                    unset($this->deleteMode[$name]);
                    return;
                }
                $this->handleNpcClick($damager);
            }
        }
    }

    /**
     * Защита NPC от взрывов
     */
    public function onNpcExplode(EntityPreExplodeEvent $event): void {
        $entity = $event->getEntity();
        if($entity instanceof MarryNpcEntity) {
            $event->cancel();
        }
    }

    /**
     * Защита NPC от пихания
     */
    public function onNpcMotion(EntityMotionEvent $event): void {
        $entity = $event->getEntity();
        if($entity instanceof MarryNpcEntity) {
            $event->cancel();
        }
    }

    private function handleNpcClick(Player $player): void {
        $session = $this->getProposalSession($player->getName());
        if($session !== null && $session['step'] === 'choose_player') {
            $player->sendMessage("§cВы уже выбрали пожениться! Нажмите на игрока в радиусе 5 блоков от NPC.");
            return;
        }

        Forms::openMainMenu($player, $this);
    }

    /**
     * Обработка удара по игроку (предложение руки и сердца)
     */
    public function onPlayerHit(EntityDamageByEntityEvent $event): void {
        if($event->isCancelled()) return;

        $damager = $event->getDamager();
        $victim = $event->getEntity();

        if(!$damager instanceof Player || !$victim instanceof Player) return;

        $session = $this->getProposalSession($damager->getName());
        if($session === null || $session['step'] !== 'choose_player') return;

        $event->cancel();

        // Проверка радиуса от NPC
        $dist = $victim->getPosition()->distance($session['npcPos']);
        if($dist > 5) {
            $damager->sendMessage("§cИгрок вышел за радиус 5 блоков от NPC. Предложение отменено.");
            $this->setProposalSession($damager->getName(), null);
            return;
        }

        // Проверка на самого себя
        if(strtolower($victim->getName()) === strtolower($damager->getName())) {
            $damager->sendMessage("§cНельзя жениться на самом себе!");
            return;
        }

        // Проверка паспорта у цели
        $targetPassport = $this->getPassportData($victim->getName());
        if($targetPassport === null) {
            $damager->sendMessage("§cУ этого игрока нет паспорта!");
            $this->setProposalSession($damager->getName(), null);
            return;
        }

        // Проверка что цель не в браке
        if(!empty($targetPassport['partner'])) {
            $damager->sendMessage("§cЭтот игрок уже состоит в браке!");
            $this->setProposalSession($damager->getName(), null);
            return;
        }

        // Проверка паспорта у дамагера
        $myPassport = $this->getPassportData($damager->getName());
        if($myPassport === null) {
            $damager->sendMessage("§cУ вас нет паспорта!");
            $this->setProposalSession($damager->getName(), null);
            return;
        }

        // Проверка что дамагер не в браке
        if(!empty($myPassport['partner'])) {
            $damager->sendMessage("§cВы уже состоите в браке!");
            $this->setProposalSession($damager->getName(), null);
            return;
        }

        // Проверка денег
        $myMoney = $this->economy->myMoney($damager);
        if($myMoney < 4000) {
            $damager->sendMessage("§cУ вас недостаточно денег для свадьбы. Нужно 4000$.");
            $damager->sendMessage("§7Ваш баланс: §e{$myMoney}$");
            $this->setProposalSession($damager->getName(), null);
            return;
        }

        // Обновляем сессию
        $session['target'] = $victim->getName();
        $session['step'] = 'waiting_accept';
        $this->setProposalSession($damager->getName(), $session);

        // Открываем форму цели
        Forms::openProposalForm($victim, $damager, $this);
    }

    /**
     * Принятие предложения
     */
    public function acceptProposal(Player $proposer, Player $target): void {
        // Повторная проверка денег
        $myMoney = $this->economy->myMoney($proposer);
        if($myMoney < 4000) {
            $proposer->sendMessage("§cНедостаточно средств для свадьбы! Нужно 4000$.");
            $this->setProposalSession($proposer->getName(), null);
            return;
        }

        // Повторная проверка партнера у цели
        $targetPass = $this->getPassportData($target->getName());
        if($targetPass === null) {
            $proposer->sendMessage("§cУ цели больше нет паспорта!");
            $this->setProposalSession($proposer->getName(), null);
            return;
        }
        if(!empty($targetPass['partner'])) {
            $proposer->sendMessage("§cИгрок уже в браке с кем-то другим!");
            $target->sendMessage("§cВы не можете принять предложение, так как уже состоите в браке.");
            $this->setProposalSession($proposer->getName(), null);
            return;
        }

        // Повторная проверка proposer
        $proposerPass = $this->getPassportData($proposer->getName());
        if($proposerPass === null) {
            $proposer->sendMessage("§cУ вас больше нет паспорта!");
            $this->setProposalSession($proposer->getName(), null);
            return;
        }
        if(!empty($proposerPass['partner'])) {
            $proposer->sendMessage("§cВы уже состоите в браке!");
            $this->setProposalSession($proposer->getName(), null);
            return;
        }

        // Все проверки пройдены - проводим свадьбу
        $this->economy->reduceMoney($proposer, 4000);

        $proposerFio = $proposerPass['fio'] ?? $proposer->getName();
        $targetFio = $targetPass['fio'] ?? $target->getName();
        $proposerName = $proposer->getName();
        $targetName = $target->getName();
        $now = time();

        // Сохраняем в паспорт proposer
        $proposerPass['partner'] = $targetName;
        $proposerPass['partnerFio'] = $targetFio;
        $proposerPass['marryTime'] = $now;
        $this->savePassportData($proposerName, $proposerPass);

        // Сохраняем в паспорт target
        $targetPass['partner'] = $proposerName;
        $targetPass['partnerFio'] = $proposerFio;
        $targetPass['marryTime'] = $now;
        $this->savePassportData($targetName, $targetPass);

        // Сохраняем в менеджер браков
        $this->marryManager->marry($proposerName, $targetName, $now);

        // Очищаем сессию
        $this->setProposalSession($proposer->getName(), null);

        // Бродкаст
        $this->getServer()->broadcastMessage("§l§dГраждане §e{$proposerFio} (§f{$proposerName}§e) §dи §e{$targetFio} (§f{$targetName}§e) §dсоединили себя узами брака.");
        $this->getServer()->broadcastMessage("");
        $this->getServer()->broadcastMessage("§r§l§7- Пожелаем им удачи!");

        $proposer->sendMessage("§a§lПоздравляем с бракосочетанием!");
        $target->sendMessage("§a§lПоздравляем с бракосочетанием!");
    }

    /**
     * Отклонение предложения
     */
    public function declineProposal(Player $proposer, Player $target): void {
        $proposer->sendMessage("§cИгрок §e{$target->getName()} §cотклонил ваше предложение.");
        $target->sendMessage("§cВы отклонили предложение.");
        $this->setProposalSession($proposer->getName(), null);
    }

    /**
     * Развод
     */
    public function divorce(Player $player): void {
        $passport = $this->getPassportData($player->getName());
        if($passport === null || empty($passport['partner'])) {
            $player->sendMessage("§cВы не состоите в браке!");
            return;
        }

        // Проверка денег
        $myMoney = $this->economy->myMoney($player);
        if($myMoney < 5000) {
            $player->sendMessage("§cНедостаточно средств! Развод стоит 5000$. Ваш баланс: {$myMoney}$");
            return;
        }

        $partnerName = $passport['partner'];

        // Снимаем деньги
        $this->economy->reduceMoney($player, 5000);

        // Очищаем паспорт игрока
        unset($passport['partner']);
        unset($passport['partnerFio']);
        unset($passport['marryTime']);
        $this->savePassportData($player->getName(), $passport);

        // Очищаем паспорт партнера
        $partnerPassport = $this->getPassportData($partnerName);
        if($partnerPassport !== null) {
            unset($partnerPassport['partner']);
            unset($partnerPassport['partnerFio']);
            unset($partnerPassport['marryTime']);
            $this->savePassportData($partnerName, $partnerPassport);
        }

        // Удаляем из менеджера
        $this->marryManager->divorce($player->getName(), $partnerName);

        $player->sendMessage("§c§lВы развелись. Ваш брак расторгнут.");

        $partner = $this->getServer()->getPlayerByPrefix($partnerName);
        if($partner !== null) {
            $partner->sendMessage("§c§lВаш партнер §e{$player->getName()} §cрасторгнул брак. Вы разведены.");
        }

        $this->getServer()->broadcastMessage("§7[§c§lРАЗВОД§7] §f{$partnerName} §7и §f{$player->getName()} §7больше не вместе...");
    }
}