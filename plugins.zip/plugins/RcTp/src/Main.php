<?php

declare(strict_types=1);

namespace InzeOwr\RcTp;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;
use pocketmine\world\particle\HugeExplodeSeedParticle;
use pocketmine\world\sound\ExplodeSound;

class Main extends PluginBase implements Listener
{
    private Config $limitsConfig;
    private Config $locksConfig;

    /** @var array */
    private array $staffGroups = [];

    /** @var array */
    private array $limitedGroups = [];

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->validateConfig();

        @mkdir($this->getDataFolder() . "data/", 0777, true);

        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);
        $this->locksConfig = new Config($this->getDataFolder() . "data/locks.json", Config::JSON);

        $this->staffGroups = $this->getConfig()->get("staff_groups", []);
        $this->limitedGroups = $this->getConfig()->get("limited_groups", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function validateConfig(): void
    {
        $config = $this->getConfig();
        $changed = false;

        $defaults = [
            "log_actions" => true,
            "self_tp_protection" => true,
            "staff_groups" => [
                "CREATOR", "OWNER", "GLADMIN", "CURATOR",
                "SADMIN", "ADMIN", "MANAGER", "SMODER", "MODER"
            ],
            "limited_groups" => [
                "MIRAGE" => [
                    "max_tp" => 15,
                    "cooldown_hours" => 24
                ],
                "SPARK" => [
                    "max_tp" => 25,
                    "cooldown_hours" => 24
                ]
            ],
            "effects" => [
                "sound_enabled" => true,
                "sound_volume" => 0.5,
                "sound_pitch" => 1.5,
                "particles_enabled" => true,
                "particle_count" => 30
            ]
        ];

        foreach ($defaults as $key => $value) {
            if (!$config->exists($key)) {
                $config->set($key, $value);
                $changed = true;
                $this->getLogger()->warning("Ключ '$key' отсутствовал в конфиге — добавлен со значением по умолчанию.");
            }
        }

        if ($changed) {
            $config->save();
            $this->getLogger()->info(TF::GREEN . "Конфиг обновлён с недостающими ключами.");
        }
    }

    protected function onDisable(): void
    {
        $this->limitsConfig->save();
        $this->locksConfig->save();
    }

    // ==================== УТИЛИТЫ ====================

    private function getTimeRemaining(int $expireTimestamp): string
    {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return "истёк";
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $minutes = floor(($diff % 3600) / 60);
        $seconds = $diff % 60;
        $parts = [];
        if ($days > 0) $parts[] = $days . " дн.";
        if ($hours > 0) $parts[] = $hours . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0) $parts[] = $seconds . " сек.";
        return implode(" ", $parts);
    }

    private function findPlayer(string $name): ?Player
    {
        $name = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }
        return $found;
    }

    private function logAction(string $message): void
    {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(TF::clean($message));
        }
    }

    // ==================== RcGroup ИНТЕГРАЦИЯ ====================

    private function getRcGroup(): ?\InzeOwr\RcGroup\Main
    {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    private function getPlayerGroup(string $nickname): string
    {
        $rcGroup = $this->getRcGroup();
        if ($rcGroup === null) return "";
        return $rcGroup->getGroup($nickname);
    }

    private function isStaff(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return false;
        return in_array($group, $this->staffGroups, true);
    }

    private function isLimited(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return false;
        return isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group]);
    }

    private function getLimitedConfig(string $nickname): ?array
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        if (isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group])) {
            return $this->limitedGroups[$group];
        }
        return null;
    }

    /**
     * Может ли игрок использовать /rctp
     * Только сотрудники и лимитированные группы
     */
    private function canUseTp(string $nickname): bool
    {
        if ($this->isStaff($nickname)) return true;
        if ($this->isLimited($nickname)) return true;
        return false;
    }

    // ==================== БЛОКИРОВКА ТП ====================

    private function isTpLocked(string $nickname): bool
    {
        $key = strtolower($nickname);
        return (bool)$this->locksConfig->get($key, false);
    }

    private function setTpLock(string $nickname, bool $locked): void
    {
        $key = strtolower($nickname);
        if ($locked) {
            $this->locksConfig->set($key, true);
        } else {
            $this->locksConfig->remove($key);
        }
        $this->locksConfig->save();
    }

    // ==================== ЭФФЕКТЫ ====================

    private function playTeleportEffects(Player $player): void
    {
        $effects = $this->getConfig()->get("effects", []);
        $pos = $player->getPosition();
        $world = $player->getWorld();

        if ((bool)($effects["sound_enabled"] ?? true)) {
            $world->addSound($pos, new ExplodeSound(), $world->getPlayers());
        }

        if ((bool)($effects["particles_enabled"] ?? true)) {
            $count = (int)($effects["particle_count"] ?? 30);

            for ($i = 0; $i < $count; $i++) {
                $offsetX = (mt_rand(-100, 100) / 100) * 1.5;
                $offsetY = (mt_rand(50, 300) / 100);
                $offsetZ = (mt_rand(-100, 100) / 100) * 1.5;

                $particlePos = $pos->add($offsetX, $offsetY, $offsetZ);
                $world->addParticle($particlePos, new HugeExplodeSeedParticle());
            }
        }
    }

    // ==================== ЛИМИТЫ ====================

    private function checkAndUseTpLimit(Player $sender): bool
    {
        $senderName = $sender->getName();

        // Сотрудники — без лимита
        if ($this->isStaff($senderName)) return true;

        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxTp = (int)($limitCfg["max_tp"] ?? 0);
        $cooldownHours = (int)($limitCfg["cooldown_hours"] ?? 24);
        if ($maxTp <= 0) return true;

        $senderKey = strtolower($senderName);
        $limitsData = $this->limitsConfig->get($senderKey, null);

        if ($limitsData === null || !is_array($limitsData)) {
            $limitsData = [
                "tp_used" => 0,
                "period_start" => time()
            ];
        }

        $periodStart = (int)($limitsData["period_start"] ?? time());
        $tpUsed = (int)($limitsData["tp_used"] ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $tpUsed = 0;
            $periodStart = time();
        }

        if ($tpUsed >= $maxTp) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->getTimeRemaining($resetTime);
            $sender->sendMessage("§c[RcTp] Вы исчерпали лимит телепортаций (§e" . $maxTp . "§c)! Сброс через: §e" . $remaining);
            return false;
        }

        $tpUsed++;
        $this->limitsConfig->set($senderKey, [
            "tp_used" => $tpUsed,
            "period_start" => $periodStart
        ]);
        $this->limitsConfig->save();

        $left = $maxTp - $tpUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->getTimeRemaining($resetTime);
        $sender->sendMessage("§e[RcTp] Использовано телепортаций: §c" . $tpUsed . "/" . $maxTp . "§e. Осталось: §c" . $left . "§e. Сброс через: §c" . $remaining);

        return true;
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch (strtolower($command->getName())) {
            case "rctp": return $this->handleTp($sender, $args);
            case "rctph": return $this->handleTpHere($sender, $args);
            case "rctplk": return $this->handleTpLock($sender, $args);
        }
        return false;
    }

    // ===== /rctp =====
    private function handleTp(CommandSender $sender, array $args): bool
    {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§c[RcTp] Команда доступна только игрокам!");
            return true;
        }

        if (count($args) < 1) {
            $sender->sendMessage("§c[RcTp] Использование: /rctp <ник>");
            return true;
        }

        $senderName = $sender->getName();
        $senderIsStaff = $this->isStaff($senderName);

        // Проверка доступа к команде
        if (!$this->canUseTp($senderName)) {
            $sender->sendMessage("§c[RcTp] У вас нет доступа к этой команде!");
            return true;
        }

        $targetInput = $args[0];

        // Поиск игрока
        $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer === null) {
            $sender->sendMessage("§c[RcTp] Игрок " . $targetInput . " не найден на сервере!");
            return true;
        }

        $targetName = $targetPlayer->getName();

        // Тп к самому себе
        if ($this->getConfig()->get("self_tp_protection", true)) {
            if (strtolower($senderName) === strtolower($targetName)) {
                $sender->sendMessage("§c[RcTp] Вы не можете телепортироваться к самому себе!");
                return true;
            }
        }

        $targetIsStaff = $this->isStaff($targetName);

        // Не-сотрудники не могут тп к сотрудникам
        if (!$senderIsStaff && $targetIsStaff) {
            $sender->sendMessage("§c[RcTp] Вы не можете телепортироваться к сотруднику проекта!");
            return true;
        }

        // Блокировка тп — сотрудники игнорируют
        if ($this->isTpLocked($targetName)) {
            if (!$senderIsStaff) {
                $sender->sendMessage("§c[RcTp] Игрок " . $targetName . " запретил телепортацию к себе!");
                return true;
            }
        }

        // Лимит
        if (!$this->checkAndUseTpLimit($sender)) return true;

        // Эффекты на старой позиции
        $this->playTeleportEffects($sender);

        // Телепортация
        $sender->teleport($targetPlayer->getPosition());

        // Эффекты на новой позиции
        $this->playTeleportEffects($sender);

        // Роль для сообщения
        $roleLabel = $senderIsStaff ? "Администратор" : "Игрок";

        $sender->sendMessage("§a[RcTp] Вы телепортировались к игроку §e" . $targetName);
        $targetPlayer->sendMessage("§e" . $roleLabel . " §c" . $senderName . " §eтелепортировался к вам");

        $this->logAction("[RcTp] " . $senderName . " телепортировался к " . $targetName);

        return true;
    }

    // ===== /rctph =====
    private function handleTpHere(CommandSender $sender, array $args): bool
    {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§c[RcTp] Команда доступна только игрокам!");
            return true;
        }

        if (count($args) < 1) {
            $sender->sendMessage("§c[RcTp] Использование: /rctph <ник>");
            return true;
        }

        $senderName = $sender->getName();

        // Только для сотрудников
        if (!$this->isStaff($senderName)) {
            $sender->sendMessage("§c[RcTp] Эта команда доступна только сотрудникам проекта!");
            return true;
        }

        $targetInput = $args[0];

        // Поиск игрока
        $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer === null) {
            $sender->sendMessage("§c[RcTp] Игрок " . $targetInput . " не найден на сервере!");
            return true;
        }

        $targetName = $targetPlayer->getName();

        // Тп самого себя к себе
        if ($this->getConfig()->get("self_tp_protection", true)) {
            if (strtolower($senderName) === strtolower($targetName)) {
                $sender->sendMessage("§c[RcTp] Вы не можете телепортировать самого себя к себе!");
                return true;
            }
        }

        // Эффекты на старой позиции цели
        $this->playTeleportEffects($targetPlayer);

        // Телепортация цели к отправителю
        $targetPlayer->teleport($sender->getPosition());

        // Эффекты на новой позиции цели
        $this->playTeleportEffects($targetPlayer);

        $sender->sendMessage("§a[RcTp] Вы телепортировали игрока §e" . $targetName . " §aк себе");
        $targetPlayer->sendMessage("§eАдминистратор §c" . $senderName . " §eтелепортировал вас к себе");

        $this->logAction("[RcTp] " . $senderName . " телепортировал " . $targetName . " к себе");

        return true;
    }

    // ===== /rctplk =====
    private function handleTpLock(CommandSender $sender, array $args): bool
    {
        if (!($sender instanceof Player)) {
            $sender->sendMessage("§c[RcTp] Команда доступна только игрокам!");
            return true;
        }

        $senderName = $sender->getName();
        $currentLock = $this->isTpLocked($senderName);

        if ($currentLock) {
            $this->setTpLock($senderName, false);
            $sender->sendMessage("§a[RcTp] Вы разрешили телепортацию к себе");
            $sender->sendMessage("§7[RcTp] Примечание: сотрудники проекта могут телепортироваться к вам независимо от этой настройки");
        } else {
            $this->setTpLock($senderName, true);
            $sender->sendMessage("§c[RcTp] Вы запретили телепортацию к себе");
            $sender->sendMessage("§7[RcTp] Примечание: запрет действует только на игроков, сотрудники проекта могут телепортироваться к вам");
        }

        $this->logAction("[RcTp] " . $senderName . " " . ($currentLock ? "разрешил" : "запретил") . " телепортацию к себе");

        return true;
    }
}
