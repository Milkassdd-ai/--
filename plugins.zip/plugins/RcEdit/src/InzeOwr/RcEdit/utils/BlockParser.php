<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit\utils;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\StringToItemParser;

/**
 * Утилита для парсинга строк в блоки.
 * Поддерживает названия блоков и числовые StateId.
 */
final class BlockParser {

	private function __construct() {
		// NOOP
	}

	/**
	 * Парсит строку в объект Block.
	 *
	 * Форматы:
	 *  - "air" или "0" → воздух
	 *  - Число (положительное или отрицательное) → блок по StateId
	 *  - Название (stone, oak_planks и т.д.) → блок через StringToItemParser
	 */
	public static function parse(string $input): ?Block {
		$input = strtolower(trim($input));

		// --- Воздух ---
		if ($input === "0" || $input === "air") {
			return VanillaBlocks::AIR();
		}

		// --- StateId (число, может быть отрицательным в PM5) ---
		if (preg_match('/^-?\d+$/', $input)) {
			try {
				$block = RuntimeBlockStateRegistry::getInstance()->fromStateId((int)$input);
				if ($block !== null) {
					return $block;
				}
			} catch (\Throwable $e) {
				return null;
			}
		}

		// --- Название блока ---
		try {
			$item = StringToItemParser::getInstance()->parse($input);
			if ($item !== null) {
				$block = $item->getBlock();
				if ($block->getTypeId() !== BlockTypeIds::AIR || $input === "air") {
					return $block;
				}
			}
		} catch (\Throwable $e) {}

		return null;
	}
}
