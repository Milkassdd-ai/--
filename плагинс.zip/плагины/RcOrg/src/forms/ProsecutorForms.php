<?php

namespace InzeOwr\RcOrg\forms;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use InzeOwr\RcDoxc\Main as RcDoxc;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\systems\ProsecutorSystem;
use InzeOwr\RcOrg\systems\CourtSystem;

class ProsecutorForms {

    public static function openDossierMenu(Player $player, string $targetName): void {
        $api = Main::getInstance();
        $targetOrg = $api->getPlayerOrg($targetName);
        $targetRank = $api->getPlayerRank($targetName);
        
        $orgName = $targetOrg ? $api->getOrgName($targetOrg) : "Безработный";
        $rankName = $targetOrg ? $api->getRankName($targetOrg, $targetRank) : "Гражданский";
        
        $fio = $api->getFio($targetName);
        
        $dob = "Неизвестно";
        $doxc = $api->getServer()->getPluginManager()->getPlugin("RcDoxc");
        if ($doxc instanceof RcDoxc && $doxc->isEnabled()) {
            $passport = $doxc->getDataManager()->getData($targetName, 'passport');
            if ($passport && isset($passport['birth_date'])) {
                $dob = $passport['birth_date'];
            }
        }
        
        $records = $api->getCourtSystem()->getCriminalRecords($targetName);
        $countConvictions = count($records);
        
        $content = "§l§eПРОКУРОРСКОЕ ДОСЬЕ\n\n";
        $content .= "§l§fФИО: §b{$fio}\n";
        $content .= "§l§fДата рождения: §7{$dob}\n";
        $content .= "§l§fМесто работы: §a{$orgName}\n";
        $content .= "§l§fДолжность: §a{$rankName} ({$targetRank})\n";
        $content .= "§l§fСудимостей: §c{$countConvictions}\n\n";

        $form = new SimpleForm(function (Player $player, $data) use ($targetName, $api, $targetOrg) {
            if ($data === null) return;
            if ($data === 0) {
                $api->getCourtSystem()->openCriminalRecordView($player, $targetName, $api->getCourtSystem()->getCriminalRecords($targetName));
            }
            if ($data === 1 && $targetOrg && $targetOrg !== "MF") {
                Forms::openLogs($player, $targetOrg);
            }
        });

        $form->setTitle("§l§6Досье: {$targetName}");
        $form->setContent($content);
        $form->addButton("§l§cАРХИВ СУДИМОСТЕЙ");
        
        if ($targetOrg && $targetOrg !== "MF") {
            $form->addButton("§l§9ДЕЙСТВИЯ ВО ФРАКЦИИ");
        }
        
        $form->addButton("§l§7Закрыть");
        $player->sendForm($form);
    }

    public static function openInspectionMenu(Player $player, string $orgKey): void {
        if ($orgKey === "GP") {
            $player->sendMessage("§c§l[Ошибка] §r§l§fПрокуратура не может проводить проверку сама у себя.");
            return;
        }

        $api = Main::getInstance();
        $sys = $api->getProsecutorSystem();
        $isFrozen = $sys->isFrozen($orgKey);
        $strikes = $sys->getStrikes($orgKey);
        $coloredOrg = $api->getColoredOrgName($orgKey);

        $form = new SimpleForm(function (Player $player, $data) use ($sys, $orgKey, $isFrozen) {
            if ($data === null) return;
            
            if ($data === 0) {
                if (!$isFrozen) {
                    if ($sys->startInspection($orgKey, $player->getName())) {
                        $coloredOrg = Main::getInstance()->getColoredOrgName($orgKey);
                        $player->sendMessage("§a§l[Городская Прокуратура] §r§l§fПроверка организации {$coloredOrg} §fначалась. Деятельность заморожена.");
                    } else {
                        $player->sendMessage("§c§l[Городская Прокуратура] §r§l§fНевозможно начать проверку (Лидер отсутствует или не в сети).");
                    }
                } else {
                    self::openRatingForm($player, $orgKey);
                }
            }
        });

        $form->setTitle("§l§2ПРОВЕРКА: {$orgKey}");
        $status = $isFrozen ? "§cИДЕТ ПРОВЕРКА" : "§aОЖИДАНИЕ";
        $form->setContent(
            "§l§fОрганизация: {$coloredOrg}\n" .
            "§l§fСтатус: {$status}\n" .
            "§l§fВыговоров: §c{$strikes}/3\n"
        );

        if (!$isFrozen) {
            $form->addButton("§l§aНАЧАТЬ ПРОВЕРКУ\n§r§l§7Заморозить фракцию");
        } else {
            $form->addButton("§l§cЗАКОНЧИТЬ ПРОВЕРКУ\n§r§l§7Выставить оценку");
        }
        
        $player->sendForm($form);
    }

    public static function openRatingForm(Player $player, string $orgKey): void {
        $form = new CustomForm(function (Player $player, $data) use ($orgKey) {
            if ($data === null) return;
            
            $rating = (int)$data[1];
            $reason = trim($data[2] ?? "");
            
            if ($rating < 5 && empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fПри оценке ниже 5 баллов необходимо указать причину выговора!");
                self::openRatingForm($player, $orgKey);
                return;
            }
            
            $api = Main::getInstance();
            $sys = $api->getProsecutorSystem();
            $sys->stopInspection($orgKey);
            
            $coloredOrg = $api->getColoredOrgName($orgKey);
            $prosecutorFio = $api->getFio($player->getName());
            
            $msg = "§a§l[Городская Прокуратура] §r§l§fПроверка организации {$coloredOrg} §fзавершена.\n";
            $msg .= "§l§fПрокурор: §e{$player->getName()}\n";
            $msg .= "§l§fОценка: §b{$rating}/10";
            
            if ($rating < 5) {
                $currentStrikes = $sys->getStrikes($orgKey);
                $isThirdStrike = ($currentStrikes >= 2);
                
                $strikeData = [
                    'prosecutor' => $player->getName(),
                    'prosecutor_fio' => $prosecutorFio,
                    'prosecutor_rank' => $api->getRealRankName($player->getName()),
                    'reason' => $reason,
                    'rating' => $rating,
                    'date' => date("d.m.Y H:i:s")
                ];
                
                $id = $sys->createPendingStrike($orgKey, $strikeData);
                $sys->notifyAdmins($id, $isThirdStrike);
                
                $msg .= "\n§e§lВЫГОВОР ОЖИДАЕТ ПОДТВЕРЖДЕНИЯ АДМИНИСТРАТОРА";
            }
            
            $api->getServer()->broadcastMessage($msg);
        });

        $form->setTitle("§l§2ИТОГИ ПРОВЕРКИ");
        $form->addLabel("§l§fОцените работу организации по 10-балльной шкале.\n§7Оценка ниже 5 влечет за собой выговор.\n§c§lПри оценке ниже 5 — укажите причину!");
        $form->addSlider("§l§fОценка:", 0, 10, 1, 5);
        $form->addInput("§l§fПричина выговора (если оценка < 5):", "Нарушение устава, коррупция...");
        $player->sendForm($form);
    }

    public static function openRemoveStrikeMenu(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $sys = $api->getProsecutorSystem();
        $strikes = $sys->getStrikesData($orgKey);
        $coloredOrg = $api->getColoredOrgName($orgKey);
        
        if (empty($strikes)) {
            $player->sendMessage("§a§l[Система] §r§l§fУ организации {$coloredOrg} §fнет выговоров.");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($strikes, $orgKey) {
            if ($data === null) return;
            
            if (isset($strikes[$data])) {
                self::openStrikeDetailForm($player, $orgKey, $data, $strikes[$data]);
            }
        });

        $form->setTitle("§l§cСнятие выговора");
        $form->setContent("§l§fОрганизация: {$coloredOrg}\n§l§fВыговоров: §c" . count($strikes) . "/3\n\n§l§7Выберите выговор для просмотра:");

        foreach ($strikes as $index => $strike) {
            $date = $strike['date'] ?? "Неизвестно";
            $reason = mb_substr($strike['reason'] ?? "Без причины", 0, 20) . "...";
            $form->addButton("§l§cВыговор #" . ($index + 1) . "\n§r§l§7{$date}");
        }
        
        $form->addButton("§l§7Отмена");
        $player->sendForm($form);
    }

    public static function openStrikeDetailForm(Player $player, string $orgKey, int $index, array $strike): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        
        $prosecutor = $strike['prosecutor'] ?? "Неизвестен";
        $prosecutorFio = $strike['prosecutor_fio'] ?? "Неизвестно";
        $prosecutorRank = $strike['prosecutor_rank'] ?? "Неизвестно";
        $reason = $strike['reason'] ?? "Не указана";
        $rating = $strike['rating'] ?? "?";
        $date = $strike['date'] ?? "Неизвестно";
        $confirmedBy = $strike['confirmed_by'] ?? "Неизвестно";
        
        $content = "§l§cИНФОРМАЦИЯ О ВЫГОВОРЕ\n\n";
        $content .= "§l§fОрганизация: {$coloredOrg}\n";
        $content .= "§l§fВыговор #" . ($index + 1) . "\n\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fПрокурор: §e{$prosecutorFio}\n";
        $content .= "§l§fНик: §7{$prosecutor}\n";
        $content .= "§l§fДолжность: §7{$prosecutorRank}\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fОценка: §e{$rating}/10\n";
        $content .= "§l§fПричина: §c{$reason}\n";
        $content .= "§l§fДата: §7{$date}\n";
        $content .= "§l§fПодтвердил: §7{$confirmedBy}\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

        $form = new SimpleForm(function (Player $player, $data) use ($orgKey, $index) {
            if ($data === null) return;
            
            if ($data === 0) {
                self::confirmRemoveStrike($player, $orgKey, $index);
            } elseif ($data === 1) {
                self::openRemoveStrikeMenu($player, $orgKey);
            }
        });

        $form->setTitle("§l§cВыговор #" . ($index + 1));
        $form->setContent($content);
        $form->addButton("§l§4СНЯТЬ ВЫГОВОР\n§r§l§7Удалить из базы");
        $form->addButton("§l§7Назад");
        $player->sendForm($form);
    }

    public static function confirmRemoveStrike(Player $player, string $orgKey, int $index): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        
        $form = new ModalForm(function (Player $player, ?bool $data) use ($orgKey, $index) {
            if ($data === true) {
                $api = Main::getInstance();
                $coloredOrg = $api->getColoredOrgName($orgKey);
                $sys = $api->getProsecutorSystem();
                
                if ($sys->removeStrike($orgKey, $index)) {
                    $player->sendMessage("§a§l[Система] §r§l§fВыговор #" . ($index + 1) . " организации {$coloredOrg} §fуспешно снят.");
                    $api->addLog($orgKey, "§c§l{$player->getName()} §6§l(§4§l17 РАНГ§6§l) снял §e§lВЫГОВОР #" . ($index + 1));
                    
                    Server::getInstance()->broadcastMessage("§a§l[Городская Прокуратура] §r§l§fС организации {$coloredOrg} §fснят выговор.");
                    Server::getInstance()->broadcastMessage("§l§7Администратор: {$player->getName()}");
                } else {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНе удалось снять выговор.");
                }
            } else {
                $api = Main::getInstance();
                $strikes = $api->getProsecutorSystem()->getStrikesData($orgKey);
                if (isset($strikes[$index])) {
                    self::openStrikeDetailForm($player, $orgKey, $index, $strikes[$index]);
                }
            }
        });

        $form->setTitle("§l§4Подтверждение");
        $form->setContent("§l§fВы уверены, что хотите снять выговор #" . ($index + 1) . " с организации {$coloredOrg}§f?\n\n§l§7Это действие будет записано в логи.");
        $form->setButton1("§l§4ДА, СНЯТЬ");
        $form->setButton2("§l§aОТМЕНА");
        $player->sendForm($form);
    }

    public static function openPendingStrikesMenu(Player $player): void {
        $sys = Main::getInstance()->getProsecutorSystem();
        $pending = $sys->getAllPendingStrikes();
        
        if (empty($pending)) {
            $player->sendMessage("§a§l[Система] §r§l§fНет ожидающих подтверждения выговоров.");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($pending) {
            if ($data === null) return;
            
            $keys = array_keys($pending);
            if (isset($keys[$data])) {
                $id = $keys[$data];
                self::openPendingStrikeDetail($player, $id);
            }
        });

        $form->setTitle("§l§eОжидающие выговоры");
        $form->setContent("§l§fВыберите выговор для рассмотрения:");

        foreach ($pending as $id => $strike) {
            $orgKey = $strike['org'] ?? "?";
            $coloredOrg = Main::getInstance()->getColoredOrgName($orgKey);
            $prosecutor = $strike['prosecutor'] ?? "?";
            $form->addButton("§l{$coloredOrg}\n§r§l§7От: {$prosecutor}");
        }
        
        $player->sendForm($form);
    }

    public static function openPendingStrikeDetail(Player $player, string $id): void {
        $api = Main::getInstance();
        $sys = $api->getProsecutorSystem();
        $strike = $sys->getPendingStrike($id);
        
        if ($strike === null) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fВыговор не найден или уже обработан.");
            return;
        }

        $orgKey = $strike['org'] ?? "?";
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $currentStrikes = $sys->getStrikes($orgKey);
        $isThirdStrike = ($currentStrikes >= 2);
        
        $prosecutor = $strike['prosecutor'] ?? "Неизвестен";
        $prosecutorFio = $strike['prosecutor_fio'] ?? "Неизвестно";
        $prosecutorRank = $strike['prosecutor_rank'] ?? "Неизвестно";
        $reason = $strike['reason'] ?? "Не указана";
        $rating = $strike['rating'] ?? "?";
        $date = $strike['created_at'] ?? "Неизвестно";
        
        $content = "§l§eЗАПРОС НА ВЫГОВОР\n\n";
        $content .= "§l§fОрганизация: {$coloredOrg}\n";
        $content .= "§l§fБудет выговор: §c" . ($currentStrikes + 1) . "/3";
        if ($isThirdStrike) {
            $content .= " §4[СНЯТИЕ ЛИДЕРА!]";
        }
        $content .= "\n\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fПрокурор: §e{$prosecutorFio}\n";
        $content .= "§l§fНик: §7{$prosecutor}\n";
        $content .= "§l§fДолжность: §7{$prosecutorRank}\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fОценка: §e{$rating}/10\n";
        $content .= "§l§fПричина: §c{$reason}\n";
        $content .= "§l§fДата: §7{$date}\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

        $form = new SimpleForm(function (Player $player, $data) use ($id, $isThirdStrike, $sys) {
            if ($data === null) return;
            
            if ($data === 0) {
                if ($isThirdStrike && !$sys->canConfirmThirdStrike($player)) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fТретий выговор (снятие лидера) может подтвердить только CURATOR, GLADMIN, MANAGER, OWNER или CREATOR.");
                    return;
                }
                
                $sys->confirmPendingStrike($id, $player->getName());
                $player->sendMessage("§a§l[Система] §r§l§fВыговор подтверждён.");
            } elseif ($data === 1) {
                self::openDenyReasonForm($player, $id);
            }
        });

        $form->setTitle("§l§eЗапрос на выговор");
        $form->setContent($content);
        $form->addButton("§l§aПОДТВЕРДИТЬ\n§r§l§7Выдать выговор");
        $form->addButton("§l§cОТКЛОНИТЬ\n§r§l§7Указать причину");
        $form->addButton("§l§7Закрыть");
        $player->sendForm($form);
    }

    public static function openDenyReasonForm(Player $player, string $id): void {
        $form = new CustomForm(function (Player $player, $data) use ($id) {
            if ($data === null) return;
            
            $reason = trim($data[0] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину отклонения.");
                self::openDenyReasonForm($player, $id);
                return;
            }
            
            $sys = Main::getInstance()->getProsecutorSystem();
            $sys->denyPendingStrike($id, $player->getName(), $reason);
            $player->sendMessage("§a§l[Система] §r§l§fВыговор отклонён.");
        });

        $form->setTitle("§l§cПричина отклонения");
        $form->addInput("§l§fУкажите причину отклонения выговора:", "Недостаточно оснований...");
        $player->sendForm($form);
    }
}