<?php

declare(strict_types=1);

namespace InzeOwr\RcBan;

use pocketmine\player\Player;
use jojoe77777\FormAPI\SimpleForm;

class FormFactory {
    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function sendBanForm(Player $player, array $data, string $durationStr): void {
        $expireStr = isset($data["expire"]) && $data["expire"] > 0
            ? $this->plugin->getBanManager()->formatTimestamp($data["expire"]) . " (" . $durationStr . ")"
            : $this->plugin->msg("ban_form_never");

        $title = $this->plugin->msg("ban_form_title");
        $content =
            $this->plugin->msg("ban_form_admin", ["issuer" => $this->plugin->getIssuerFromData($data)]) . "\n" .
            $this->plugin->msg("ban_form_nick", ["nick" => $player->getName()]) . "\n" .
            $this->plugin->msg("ban_form_reason", ["reason" => $data["reason"] ?? "—"]) . "\n" .
            $this->plugin->msg("ban_form_expire", ["expire" => $expireStr]) . "\n\n" .
            $this->plugin->msg("ban_form_extra");

        $form = new SimpleForm(function (Player $player, ?int $data) {
            if (!$player->isOnline()) return;
            $player->kick($this->plugin->msg("kick_banned"));
        });
        $form->setTitle($title);
        $form->setContent($content);
        $form->addButton($this->plugin->msg("ban_form_button"));
        $player->sendForm($form);
    }
}