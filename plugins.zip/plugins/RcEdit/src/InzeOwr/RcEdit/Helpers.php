<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\math\Vector3;

final class Helpers {

	private function __construct() {}

	public static function vecStr(Vector3 $v): string {
		return (int)$v->x . ", " . (int)$v->y . ", " . (int)$v->z;
	}
}
