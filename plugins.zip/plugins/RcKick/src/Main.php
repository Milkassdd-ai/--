<?php

declare(strict_types=1);

namespace InzeOwr\RcKick;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase implements Listener
{
    private Config $limitsConfig;
    private array $staffGroups = [];
    private array $limitedGroups = [];

    protected function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->validateConfig();

        @mkdir($this->getDataFolder() . "data/", 0777, true);

        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);
        $this->staffGroups  = $this->getConfig()->get("staff_groups", []);
        $this->limitedGroups = $this->getConfig()->get("limited_groups", []);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
    }

    private function validateConfig(): void
    {
        $config  = $this->getConfig();
        $changed = false;

        $defaults = [
            "log_actions"          => true,
            "broadcast_kicks"      => true,
            "self_kick_protection" => true,
            "staff_groups"         => [
                "CREATOR", "OWNER", "GLADMIN", "CURATOR",
                "SADMIN", "ADMIN", "MANAGER", "SMODER", "MODER",
            ],
            "limited_groups" => [
                "MIRAGE" => ["max_kicks" => 10, "cooldown_hours" => 24],
                "SPARK"  => ["max_kicks" => 20, "cooldown_hours" => 24],
            ],
        ];

        foreach ($defaults as $key => $value) {
            if (!$config->exists($key)) {
                $config->set($key, $value);
                $changed = true;
                $this->getLogger()->warning("Ключ «{$key}» отсутствовал в конфиге — добавлен со значением по умолчанию.");
            }
        }

        if ($changed) {
            $config->save();
            $this->getLogger()->info(TF::GREEN . "Конфиг обновлён.");
        }
    }

    protected function onDisable(): void
    {
        $this->limitsConfig->save();
    }

    // ==================== УТИЛИТЫ ====================

    private function getTimeRemaining(int $expireTimestamp): string
    {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return "истёк";

        $days    = (int) floor($diff / 86400);
        $hours   = (int) floor(($diff % 86400) / 3600);
        $minutes = (int) floor(($diff % 3600) / 60);
        $seconds = (int) ($diff % 60);

        $parts = [];
        if ($days > 0)                      $parts[] = $days . " дн.";
        if ($hours > 0)                     $parts[] = $hours . " ч.";
        if ($minutes > 0)                   $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0)    $parts[] = $seconds . " сек.";

        return implode(" ", $parts);
    }

    private function findPlayer(string $name): ?Player
    {
        $name  = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;

        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }

        return $found;
    }

    private function getAdminName(CommandSender $sender): string
    {
        return $sender instanceof Player ? $sender->getName() : "Console";
    }

    private function broadcast(string $message): void
    {
        if ($this->getConfig()->get("broadcast_kicks", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    private function notifyStaff(string $message): void
    {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if ($this->isStaff($player->getName())) {
                $player->sendMessage("§l§7[А] §r§7" . $message);
            }
        }
    }

    private function logAction(string $message): void
    {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(TF::clean($message));
        }
    }

    // ==================== RcGroup ====================

    private function getRcGroup(): ?\InzeOwr\RcGroup\Main
    {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($plugin !== null && $plugin->isEnabled() && $plugin instanceof \InzeOwr\RcGroup\Main) {
            return $plugin;
        }
        return null;
    }

    private function getPlayerGroup(string $nickname): string
    {
        $rcGroup = $this->getRcGroup();
        return $rcGroup !== null ? $rcGroup->getGroup($nickname) : "";
    }

    private function isStaff(string $nickname): bool
    {
        $group = $this->getPlayerGroup($nickname);
        return $group !== "" && in_array($group, $this->staffGroups, true);
    }

    private function getLimitedConfig(string $nickname): ?array
    {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        return isset($this->limitedGroups[$group]) && is_array($this->limitedGroups[$group])
            ? $this->limitedGroups[$group]
            : null;
    }

    // ==================== ПРОВЕРКИ ====================

    private function checkStaffProtection(CommandSender $sender, string $targetName): bool
    {
        if (!($sender instanceof Player)) return true;
        if ($this->isStaff($targetName)) {
            $sender->sendMessage("§l§cВы не можете кикнуть сотрудника проекта.");
            return false;
        }
        return true;
    }

    private function checkSelfKick(CommandSender $sender, string $targetName): bool
    {
        if ($this->getConfig()->get("self_kick_protection", true)) {
            if ($sender instanceof Player && strtolower($sender->getName()) === strtolower($targetName)) {
                $sender->sendMessage("§l§cВы не можете кикнуть самого себя.");
                return false;
            }
        }
        return true;
    }

    private function checkBypass(CommandSender $sender, string $targetName): bool
    {
        $targetPlayer = $this->getServer()->getPlayerExact($targetName);
        if ($targetPlayer !== null && $targetPlayer->hasPermission("rckick.bypass")) {
            $sender->sendMessage("§l§cЭтот игрок защищён от кика.");
            return false;
        }
        return true;
    }

    private function canKickTarget(CommandSender $sender, string $targetName): bool
    {
        if (!$this->checkSelfKick($sender, $targetName))       return false;
        if (!$this->checkBypass($sender, $targetName))         return false;
        if (!$this->checkStaffProtection($sender, $targetName)) return false;
        return true;
    }

    /**
     * Проверяет лимит и списывает одно использование.
     * Вызывается ПОСЛЕДНЕЙ, непосредственно перед выполнением действия.
     */
    private function checkAndUseKickLimit(CommandSender $sender): bool
    {
        if (!($sender instanceof Player)) return true;

        $senderName = $sender->getName();
        $limitCfg   = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;

        $maxKicks      = (int) ($limitCfg["max_kicks"]      ?? 0);
        $cooldownHours = (int) ($limitCfg["cooldown_hours"] ?? 24);
        if ($maxKicks <= 0) return true;

        $senderKey   = strtolower($senderName);
        $limitsData  = $this->limitsConfig->get($senderKey, null);

        if (!is_array($limitsData)) {
            $limitsData = ["kicks_used" => 0, "period_start" => time()];
        }

        $periodStart     = (int) ($limitsData["period_start"] ?? time());
        $kicksUsed       = (int) ($limitsData["kicks_used"]   ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $kicksUsed   = 0;
            $periodStart = time();
        }

        if ($kicksUsed >= $maxKicks) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->getTimeRemaining($resetTime);
            $sender->sendMessage("§l§cВы исчерпали лимит киков §r§c(§l" . $maxKicks . "§r§c). Сброс через: §l" . $remaining . "§r§c.");
            return false;
        }

        $kicksUsed++;
        $this->limitsConfig->set($senderKey, ["kicks_used" => $kicksUsed, "period_start" => $periodStart]);
        $this->limitsConfig->save();

        $left      = $maxKicks - $kicksUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->getTimeRemaining($resetTime);
        $sender->sendMessage("§l§cИспользовано киков: §r§c" . $kicksUsed . "/" . $maxKicks . ". Осталось: §l" . $left . "§r§c. Сброс через: §l" . $remaining . "§r§c.");

        return true;
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        if (strtolower($command->getName()) === "rckick") {
            return $this->handleKick($sender, $args);
        }
        return false;
    }

    private function handleKick(CommandSender $sender, array $args): bool
    {
        if (count($args) < 2) {
            $sender->sendMessage("§l§cИспользование: §r§c/rckick <ник> [-s] <причина>");
            return true;
        }

        $targetInput = array_shift($args);

        // Флаг тихого кика
        $silent = false;
        if (isset($args[0]) && strtolower($args[0]) === "-s") {
            if (!$this->isStaff($this->getAdminName($sender)) && !($sender instanceof Player === false)) {
                $sender->sendMessage("§l§cФлаг -s доступен только сотрудникам проекта.");
                return true;
            }
            $silent = true;
            array_shift($args);
        }

        $reason    = implode(" ", $args);
        $adminName = $this->getAdminName($sender);

        if (empty(trim($reason))) {
            $sender->sendMessage("§l§cУкажите причину кика.");
            return true;
        }

        $targetPlayer = $this->findPlayer($targetInput);
        if ($targetPlayer === null) {
            $sender->sendMessage("§l§cИгрок §r§c" . $targetInput . " §l§cне найден на сервере.");
            return true;
        }

        $targetName = $targetPlayer->getName();

        // Все проверки ДО списания лимита
        if (!$this->canKickTarget($sender, $targetName)) return true;
        if (!$this->checkAndUseKickLimit($sender))       return true;

        $targetPlayer->kick("§l§cВас кикнул §r§c" . $adminName . "§l§c. Причина: §r§c" . $reason . "§l§c.");

        if ($silent) {
            $this->notifyStaff($adminName . " тихо кикнул " . $targetName . ". Причина: " . $reason);
        } else {
            $this->broadcast("§l§c" . $adminName . " §r§cкикнул §l§c" . $targetName . "§r§c. Причина: §l§c" . $reason . "§r§c.");
        }

        $this->logAction("[RcKick] " . $adminName . " кикнул " . $targetName . ". Причина: " . $reason . ($silent ? " [тихо]" : ""));

        return true;
    }
}
