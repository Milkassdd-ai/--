<?php

namespace InzeOwr\RcMarry;

use pocketmine\utils\Config;

class MarryManager {

    private Main $plugin;
    private Config $marriages;
    private Config $stats;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        @mkdir($plugin->getDataFolder() . "data/", 0777, true);
        $this->marriages = new Config($plugin->getDataFolder() . "data/marriages.json", Config::JSON, []);
        $this->stats = new Config($plugin->getDataFolder() . "data/stats.json", Config::JSON, [
            'total_marriages' => 0,
            'total_divorces' => 0,
            'money_earned' => 0
        ]);
    }

    /**
     * Зарегистрировать брак
     */
    public function marry(string $player1, string $player2, int $time): void {
        $marriages = $this->marriages->getAll();
        $marriages[strtolower($player1)] = [
            'partner' => $player2,
            'time' => $time
        ];
        $marriages[strtolower($player2)] = [
            'partner' => $player1,
            'time' => $time
        ];
        $this->marriages->setAll($marriages);
        $this->marriages->save();

        $stats = $this->stats->getAll();
        $stats['total_marriages']++;
        $stats['money_earned'] += 4000;
        $this->stats->setAll($stats);
        $this->stats->save();
    }

    /**
     * Расторгнуть брак
     */
    public function divorce(string $player1, string $player2): void {
        $marriages = $this->marriages->getAll();
        unset($marriages[strtolower($player1)]);
        unset($marriages[strtolower($player2)]);
        $this->marriages->setAll($marriages);
        $this->marriages->save();

        $stats = $this->stats->getAll();
        $stats['total_divorces']++;
        $stats['money_earned'] += 5000;
        $this->stats->setAll($stats);
        $this->stats->save();
    }

    /**
     * Получить данные брака игрока
     */
    public function getMarriage(string $playerName): ?array {
        $marriages = $this->marriages->getAll();
        return $marriages[strtolower($playerName)] ?? null;
    }

    /**
     * Получить имя партнера
     */
    public function getPartner(string $playerName): ?string {
        $data = $this->getMarriage($playerName);
        return $data['partner'] ?? null;
    }

    /**
     * Получить время брака
     */
    public function getMarryTime(string $playerName): ?int {
        $data = $this->getMarriage($playerName);
        return $data['time'] ?? null;
    }

    /**
     * Проверить, состоит ли игрок в браке
     */
    public function isMarried(string $playerName): bool {
        return $this->getMarriage($playerName) !== null;
    }

    /**
     * Получить время в браке (форматированное)
     */
    public function getMarriageDuration(string $playerName): string {
        $time = $this->getMarryTime($playerName);
        if($time === null) return "§7Нет данных";

        $diff = time() - $time;
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $minutes = floor(($diff % 3600) / 60);

        $result = "";
        if($days > 0) $result .= "{$days} дн. ";
        if($hours > 0) $result .= "{$hours} ч. ";
        $result .= "{$minutes} мин.";

        return $result;
    }

    /**
     * Получить статистику
     */
    public function getStats(): array {
        return $this->stats->getAll();
    }
}