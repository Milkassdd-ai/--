<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit;

use pocketmine\block\VanillaBlocks;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class CommandHandler {

	private Main $plugin;
	private BlockProcessor $processor;

	public function __construct(Main $plugin, BlockProcessor $processor) {
		$this->plugin = $plugin;
		$this->processor = $processor;
	}

	public function handle(CommandSender $sender, Command $command, array $args): bool {
		if (!$sender instanceof Player) {
			$sender->sendMessage(Message::ERR . "Только для игроков.");
			return true;
		}
		if (!$sender->hasPermission("rcedit.use")) {
			$sender->sendMessage(Message::ERR . "Нет прав.");
			return true;
		}

		$session = $this->plugin->getSession($sender);

		return match ($command->getName()) {
			"rcwand"    => $this->cmdWand($sender),
			"rcpalke"   => $this->cmdPalke($sender, $session),
			"rcsetp"    => $this->cmdSetP($sender, $session),
			"rcid"      => $this->cmdId($sender, $session),
			"rce"       => $this->cmdE($sender, $session, $args),
			"rcset"     => $this->cmdSet($sender, $session, $args),
			"rccopy"    => $this->cmdCopy($sender, $session),
			"rcpaste"   => $this->cmdPaste($sender, $session),
			"rccopyx"   => $this->cmdCopyX($sender, $session, $args),
			"rccopyu"   => $this->cmdCopyU($sender, $args),
			"rcpastex"  => $this->cmdPasteX($sender, $session, $args),
			"rcrotate"  => $this->cmdRotate($sender, $session, $args),
			"rcundo"    => $this->cmdUndo($sender, $session),
			"rcreturn"  => $this->cmdReturn($sender, $session),
			"rcconnect" => $this->cmdConnect($sender, $session, $args),
			default     => false,
		};
	}

	private function cmdWand(Player $p): bool {
		$wand = VanillaItems::GOLDEN_AXE();
		$wand->setCustomName(TF::RESET . TF::GOLD . TF::BOLD . "✦ " . TF::RESET . TF::GOLD . "RcEdit Топорик");
		$wand->setLore([TF::GRAY . "ЛКМ: " . TF::WHITE . "Точка 1", TF::GRAY . "ПКМ: " . TF::WHITE . "Точка 2"]);
		$p->getInventory()->addItem($wand);
		$p->sendMessage(Message::SUCCESS . "Топорик выделения выдан.");
		return true;
	}

	private function cmdPalke(Player $p, Session $s): bool {
		$s->clearPalkeSelection();
		$stick = VanillaItems::STICK();
		$stick->setCustomName(TF::RESET . TF::LIGHT_PURPLE . TF::BOLD . "⚙ " . TF::RESET . TF::LIGHT_PURPLE . "RcEdit Палка");
		$stick->setLore([
			TF::GRAY . "ПКМ: " . TF::WHITE . "Повернуть/Отсоединить",
			TF::GRAY . "ЛКМ: " . TF::WHITE . "Точка 1",
			TF::GRAY . "ПКМ (с P1): " . TF::WHITE . "Точка 2",
			TF::GRAY . "Затем: " . TF::YELLOW . "/rcsetp",
		]);
		$stick->getNamedTag()->setString("RcPalke", "true");
		$p->getInventory()->addItem($stick);
		$p->sendMessage(Message::SUCCESS . "Палка поворота/отсоединения выдана.");
		$p->sendMessage(Message::PREFIX . "ПКМ по блоку — повернуть/отсоединить.");
		$p->sendMessage(Message::PREFIX . "ЛКМ=P1, ПКМ=P2, затем /rcsetp.");
		return true;
	}

	private function cmdSetP(Player $p, Session $s): bool {
		if (!$s->hasPalkeSelection()) {
			$p->sendMessage(Message::ERR . "Нет выделения палкой.");
			$p->sendMessage(Message::PREFIX . "Возьмите палку (/rcpalke), ЛКМ=P1, ПКМ=P2.");
			return true;
		}
		$r = $this->processor->processPalkeSelection($p);
		$p->sendMessage(Message::SUCCESS . "Повёрнуто: " . TF::WHITE . $r['rotated'] . TF::GREEN . ", отсоединено: " . TF::WHITE . $r['disconnected'] . TF::GREEN . ".");
		$p->sendMessage(Message::PREFIX . "Введите /rcsetp ещё раз для повторного поворота.");
		return true;
	}

	private function cmdId(Player $p, Session $s): bool {
		$state = $s->toggleIdMode();
		$p->sendMessage($state
			? Message::SUCCESS . "Режим ID " . TF::GREEN . "ВКЛЮЧЕН" . TF::GRAY . ". Тапните по блоку."
			: Message::PREFIX . "Режим ID " . TF::RED . "ВЫКЛЮЧЕН.");
		return true;
	}

	private function cmdE(Player $p, Session $s, array $args): bool {
		if (!isset($args[0]) || !in_array($args[0], ["1", "2"])) {
			$p->sendMessage(Message::ERR . "Использование: /rce <1|2>");
			return true;
		}
		$pos = $p->getPosition()->floor();
		if ($args[0] === "1") {
			$s->setPos1($pos);
			$p->sendMessage(Message::SUCCESS . "Точка 1 (ноги): " . TF::WHITE . Helpers::vecStr($pos));
		} else {
			$s->setPos2($pos);
			$p->sendMessage(Message::SUCCESS . "Точка 2 (ноги): " . TF::WHITE . Helpers::vecStr($pos));
		}
		$this->sendSelInfo($p, $s);
		return true;
	}

	private function cmdSet(Player $p, Session $s, array $args): bool {
		if (!$s->hasSelection()) {
			$p->sendMessage(Message::ERR . "Сначала выделите область (/rcwand).");
			return true;
		}
		if (!isset($args[0])) {
			$p->sendMessage(Message::ERR . "Использование: /rcset <название_блока|StateId>");
			return true;
		}

		$block = BlockParser::parse($args[0]);
		if ($block === null) {
			$p->sendMessage(Message::ERR . "Блок \"" . $args[0] . "\" не найден.");
			$p->sendMessage(Message::PREFIX . "Укажите название (stone) или StateId (число).");
			return true;
		}

		$count = $s->fillSelection($block);
		$p->sendMessage(Message::SUCCESS . "Установлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
		return true;
	}

	private function cmdCopy(Player $p, Session $s): bool {
		if (!$s->hasSelection()) {
			$p->sendMessage(Message::ERR . "Сначала выделите область.");
			return true;
		}
		$count = $s->copy();
		if ($count === 0) { $p->sendMessage(Message::ERR . "Область пуста."); return true; }
		$p->sendMessage(Message::SUCCESS . "Скопировано " . TF::WHITE . $count . TF::GREEN . " блоков.");
		$p->sendMessage(Message::PREFIX . "Выделите новую область и /rcpaste");
		$p->sendMessage(Message::PREFIX . "Или /rcrotate <1|2|3> для поворота.");
		return true;
	}

	private function cmdPaste(Player $p, Session $s): bool {
		if (!$s->hasClipboard()) { $p->sendMessage(Message::ERR . "Буфер пуст. Сначала /rccopy."); return true; }
		if (!$s->hasSelection()) { $p->sendMessage(Message::ERR . "Выделите область (точка 1 = начало)."); return true; }
		$count = $s->pasteToSelection();
		$p->sendMessage($count > 0
			? Message::SUCCESS . "Вставлено " . TF::WHITE . $count . TF::GREEN . " блоков."
			: Message::ERR . "Нечего вставлять.");
		return true;
	}

	private function cmdCopyX(Player $p, Session $s, array $args): bool {
		if (!$s->hasSelection()) { $p->sendMessage(Message::ERR . "Сначала выделите область."); return true; }
		if (!isset($args[0])) { $p->sendMessage(Message::ERR . "Использование: /rccopyx <название>"); return true; }

		$name = strtolower(trim($args[0]));
		if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $name)) {
			$p->sendMessage(Message::ERR . "Название: только буквы, цифры, _ и -");
			return true;
		}

		if (!$s->saveSchematic($name)) { $p->sendMessage(Message::ERR . "Ошибка сохранения."); return true; }

		$p->sendMessage(Message::SUCCESS . "Сохранено как: " . TF::WHITE . $name);
		$p->sendMessage(Message::PREFIX . "Вставить: /rcpastex " . $name);
		$p->sendMessage(Message::PREFIX . "Удалить: /rccopyu " . $name);
		return true;
	}

	private function cmdCopyU(Player $p, array $args): bool {
		$list = $this->listSchematics();

		if (!isset($args[0])) {
			$p->sendMessage(Message::ERR . "Использование: /rccopyu <название>");
			$p->sendMessage($list !== ""
				? Message::PREFIX . "Сохранённые: " . TF::YELLOW . $list
				: Message::PREFIX . "Нет сохранённых построек.");
			return true;
		}

		$name = strtolower(trim($args[0]));
		$path = $this->plugin->getSchematicsPath() . $name . ".json";

		if (!file_exists($path)) {
			$p->sendMessage(Message::ERR . "\"" . $name . "\" не найдено.");
			if ($list !== "") $p->sendMessage(Message::PREFIX . "Доступные: " . TF::YELLOW . $list);
			return true;
		}

		unlink($path);
		$p->sendMessage(Message::SUCCESS . "\"" . TF::WHITE . $name . TF::GREEN . "\" удалена.");
		return true;
	}

	private function cmdPasteX(Player $p, Session $s, array $args): bool {
		$list = $this->listSchematics();

		if (!isset($args[0])) {
			$p->sendMessage(Message::ERR . "Использование: /rcpastex <название>");
			$p->sendMessage($list !== ""
				? Message::PREFIX . "Сохранённые: " . TF::YELLOW . $list
				: Message::PREFIX . "Нет сохранённых построек.");
			return true;
		}

		$name = strtolower(trim($args[0]));
		if (!$s->loadSchematic($name)) {
			$p->sendMessage(Message::ERR . "\"" . $name . "\" не найдено.");
			if ($list !== "") $p->sendMessage(Message::PREFIX . "Доступные: " . TF::YELLOW . $list);
			return true;
		}

		$count = $s->pasteAtPlayer();
		$p->sendMessage($count > 0
			? Message::SUCCESS . "Вставлено \"" . TF::WHITE . $name . TF::GREEN . "\": " . TF::WHITE . $count . TF::GREEN . " блоков."
			: Message::ERR . "Нечего вставлять.");
		return true;
	}

	private function cmdRotate(Player $p, Session $s, array $args): bool {
		if (!$s->hasClipboard()) { $p->sendMessage(Message::ERR . "Буфер пуст. Сначала /rccopy."); return true; }
		if (!isset($args[0]) || !in_array($args[0], ["1", "2", "3"])) {
			$p->sendMessage(Message::ERR . "Использование: /rcrotate <1|2|3>");
			$p->sendMessage(Message::PREFIX . "1=90° вправо, 2=90° влево, 3=180°");
			return true;
		}
		$dir = (int)$args[0];
		$s->rotateClipboard($dir);
		$msg = match($dir) { 1 => "90° вправо", 2 => "90° влево", 3 => "180°", default => "?" };
		$p->sendMessage(Message::SUCCESS . "Буфер повёрнут на " . TF::WHITE . $msg . TF::GREEN . ".");
		return true;
	}

	private function cmdUndo(Player $p, Session $s): bool {
		$p->sendMessage($s->undo() ? Message::SUCCESS . "Действие отменено." : Message::ERR . "Нечего отменять.");
		return true;
	}

	private function cmdReturn(Player $p, Session $s): bool {
		$p->sendMessage($s->redo() ? Message::SUCCESS . "Действие возвращено." : Message::ERR . "Нечего возвращать.");
		return true;
	}

	private function cmdConnect(Player $p, Session $s, array $args): bool {
		if (count($args) < 2) {
			$p->sendMessage(Message::ERR . "Использование: /rcconnect <блоки> <режим>");
			$p->sendMessage(Message::PREFIX . "Блоки: stone%50,dirt%50 (или StateId)");
			$p->sendMessage(Message::PREFIX . "Режим: 1=стены, 2=пол/потолок, 3=все");
			return true;
		}
		if (!$s->hasSelection()) { $p->sendMessage(Message::ERR . "Нет выделения."); return true; }

		$mode = (int)$args[1];
		if ($mode < 1 || $mode > 3) { $p->sendMessage(Message::ERR . "Режим: 1, 2 или 3."); return true; }

		$pattern = [];
		foreach (explode(",", $args[0]) as $part) {
			$d = explode("%", $part);
			$bName = $d[0];
			$chance = isset($d[1]) ? (float)$d[1] : 100.0;
			if ($chance <= 0) continue;
			$blk = BlockParser::parse($bName);
			if ($blk !== null) {
				$pattern[] = ['block' => $blk, 'chance' => $chance];
			} else {
				$p->sendMessage(Message::ERR . "Блок \"" . $bName . "\" не найден, пропущен.");
			}
		}

		if (empty($pattern)) { $p->sendMessage(Message::ERR . "Ни один блок не распознан."); return true; }

		$count = $s->connectPattern($pattern, $mode);
		$p->sendMessage(Message::SUCCESS . "Установлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
		return true;
	}

	private function sendSelInfo(Player $p, Session $s): void {
		if (!$s->hasSelection()) return;
		$b = $s->getSelectionBounds();
		$sx = (int)($b['max']->x - $b['min']->x + 1);
		$sy = (int)($b['max']->y - $b['min']->y + 1);
		$sz = (int)($b['max']->z - $b['min']->z + 1);
		$p->sendMessage(Message::PREFIX . "Размер: " . TF::WHITE . "{$sx}x{$sy}x{$sz}" . TF::GRAY . " (" . ($sx * $sy * $sz) . " блоков)");
	}

	private function listSchematics(): string {
		$files = glob($this->plugin->getSchematicsPath() . "*.json");
		if (empty($files)) return "";
		$names = [];
		foreach ($files as $f) $names[] = basename($f, ".json");
		return implode(", ", $names);
	}
}
