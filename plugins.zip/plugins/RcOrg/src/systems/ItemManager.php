<?php

namespace InzeOwr\RcOrg\systems;

use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use InzeOwr\RcOrg\Main;

class ItemManager {

    private Main $plugin;

    public const HANDCUFFS_TAG = "rc_handcuffs";
    public const MEDKIT_TAG = "rc_medkit";
    public const LEADER_CUFFS_TAG = "rc_leader_cuffs";
    public const COURT_TAG = "rc_court_item";
    public const GP_TABLET_TAG = "rc_gp_tablet";
    public const GP_DOCS_TAG = "rc_gp_docs";
    public const CONFISCATE_TAG = "rc_confiscate";
    public const LAWSUIT_TABLET_TAG = "rc_lawsuit_tablet";
    public const FINE_TABLET_TAG = "rc_fine_tablet";
    public const WANTED_ITEM_TAG = "rc_wanted_item";
    public const IMMUNITY_TABLET_TAG = "rc_immunity_tablet";
    public const FNS_TABLET_TAG = "rc_fns_tablet";
    public const MAFIA_ROPE_TAG = "rc_mafia_rope";
    public const DOC_IDENTIFIER_TAG = "rc_doc_identifier";

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function createHandcuffs(): Item {
        $item = VanillaItems::RAW_GOLD();
        $item->setCount(1);
        $item->setCustomName("��l§6Наручники");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::HANDCUFFS_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createMedkit(): Item {
        $item = VanillaItems::SLIMEBALL();
        $item->setCount(1);
        $item->setCustomName("§l§aАптечка первой помощи");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::MEDKIT_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createLeaderCuffs(): Item {
        $item = VanillaItems::RAW_IRON();
        $item->setCount(1);
        $item->setCustomName("§l§cНаручники для руководства");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::LEADER_CUFFS_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createCourtItem(): Item {
        $item = VanillaItems::RAW_COPPER();
        $item->setCount(1);
        $item->setCustomName("§l§5Судебные действия");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::COURT_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createProsecutorTablet(): Item {
        $item = VanillaItems::CLOCK();
        $item->setCount(1);
        $item->setCustomName("§l§eПланшет Прокуратуры");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::GP_TABLET_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createProsecutorDocuments(): Item {
        $item = VanillaItems::BRICK();
        $item->setCount(1);
        $item->setCustomName("§l§2Планшет проверки");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::GP_DOCS_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createConfiscationTool(): Item {
        $item = VanillaItems::GOLD_INGOT();
        $item->setCount(1);
        $item->setCustomName("§l§cИзъятие документов");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::CONFISCATE_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createLawsuitTablet(): Item {
        $item = VanillaItems::BRICK();
        $item->setCount(1);
        $item->setCustomName("§l§5Планшет Исков");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::LAWSUIT_TABLET_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createFineTablet(): Item {
        $item = VanillaItems::COMPASS();
        $item->setCount(1);
        $item->setCustomName("§l§bПланшет организации");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::FINE_TABLET_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createWantedItem(): Item {
        $item = VanillaItems::IRON_SWORD();
        $item->setCount(1);
        $item->setCustomName("§l§9Полицейская дубинка");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::WANTED_ITEM_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createImmunityTablet(): Item {
        $item = VanillaItems::GOLDEN_HOE();
        $item->setCount(1);
        $item->setCustomName("§l§6Реестр неприкосновенности");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::IMMUNITY_TABLET_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createFNSTablet(): Item {
        $item = VanillaItems::BRICK();
        $item->setCount(1);
        $item->setCustomName("§l§eПланшет ФНС\n§r§7Финансовый мониторинг");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::FNS_TABLET_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createMafiaRope(): Item {
        $item = VanillaItems::COPPER_INGOT();
        $item->setCount(1);
        $item->setCustomName("§l§5Инструменты ОПГ\n§r§7Связывание и мешки");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::MAFIA_ROPE_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function createDocumentIdentifier(): Item {
        $item = VanillaItems::BOOK();
        $item->setCount(1);
        $item->setCustomName("§l§bИндификатор документов\n§r§7Просмотр документов гражданина");
        $nbt = $item->getNamedTag();
        $nbt->setString(self::DOC_IDENTIFIER_TAG, "true");
        $item->setNamedTag($nbt);
        return $item;
    }

    public function isHandcuffs(Item $item): bool { return $item->getNamedTag()->getString(self::HANDCUFFS_TAG, "") === "true"; }
    public function isMedkit(Item $item): bool { return $item->getNamedTag()->getString(self::MEDKIT_TAG, "") === "true"; }
    public function isLeaderCuffs(Item $item): bool { return $item->getNamedTag()->getString(self::LEADER_CUFFS_TAG, "") === "true"; }
    public function isCourtItem(Item $item): bool { return $item->getNamedTag()->getString(self::COURT_TAG, "") === "true"; }
    public function isProsecutorTablet(Item $item): bool { return $item->getNamedTag()->getString(self::GP_TABLET_TAG, "") === "true"; }
    public function isProsecutorDocuments(Item $item): bool { return $item->getNamedTag()->getString(self::GP_DOCS_TAG, "") === "true"; }
    public function isConfiscationTool(Item $item): bool { return $item->getNamedTag()->getString(self::CONFISCATE_TAG, "") === "true"; }
    public function isLawsuitTablet(Item $item): bool { return $item->getNamedTag()->getString(self::LAWSUIT_TABLET_TAG, "") === "true"; }
    public function isFineTablet(Item $item): bool { return $item->getNamedTag()->getString(self::FINE_TABLET_TAG, "") === "true"; }
    public function isWantedItem(Item $item): bool { return $item->getNamedTag()->getString(self::WANTED_ITEM_TAG, "") === "true"; }
    public function isImmunityTablet(Item $item): bool { return $item->getNamedTag()->getString(self::IMMUNITY_TABLET_TAG, "") === "true"; }
    public function isFNSTablet(Item $item): bool { return $item->getNamedTag()->getString(self::FNS_TABLET_TAG, "") === "true"; }
    public function isMafiaRope(Item $item): bool {
        return $item->getNamedTag()->getString(self::MAFIA_ROPE_TAG, "") === "true";
    }
    public function isDocumentIdentifier(Item $item): bool { return $item->getNamedTag()->getString(self::DOC_IDENTIFIER_TAG, "") === "true"; }

    public function isSpecialItem(Item $item): bool {
        return $this->isHandcuffs($item) || $this->isMedkit($item) || $this->isLeaderCuffs($item)
            || $this->isCourtItem($item) || $this->isProsecutorTablet($item) || $this->isProsecutorDocuments($item)
            || $this->isConfiscationTool($item) || $this->isLawsuitTablet($item) || $this->isFineTablet($item)
            || $this->isWantedItem($item) || $this->isImmunityTablet($item) || $this->isFNSTablet($item) || $this->isMafiaRope($item)
            || $this->isDocumentIdentifier($item);
    }

    public function canUseHandcuffs(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "GP" && $rank >= 10) return true;
        if ($org === "FSB" && $rank >= 4) return true;
        if ($org === "MVD" && $rank >= 4) return true;
        return false;
    }

    public function canUseMedkit(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "GB" && $rank >= 3) return true;
        return false;
    }

    public function canUseLeaderCuffs(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "GP" && $rank >= 13) return true;
        if (($org === "FSB" || $org === "MVD") && $rank >= 13) return true;
        return false;
    }

    public function canUseProsecutorTablet(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "GP" && $rank >= 5) return true;
        return false;
    }

    public function canUseProsecutorDocuments(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        return (in_array($org, ["FSB", "GP", "GS"], true) && $rank >= 15 && $rank <= 100);
    }

    public function canUseDocumentIdentifier(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        return (in_array($org, ["MVD", "FSB", "GP", "GS"], true) && $rank >= 6 && $rank <= 100);
    }

    public function canUseConfiscationTool(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($rank < 14 && $rank <= 100) return false;
        if ($org === "FSB" || $org === "MVD" || $org === "GP" || $org === "GS") return true;
        if ($org === "GB") return true;
        return false;
    }

    public function canUseLawsuitTablet(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "GS" && $rank >= 14) return true;
        return false;
    }

    public function canUseFineTablet(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if (($org === "MVD" || $org === "FSB") && $rank >= 12) return true;
        return false;
    }

    public function canUseWantedItem(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if (($org === "MVD" || $org === "FSB" || $org === "GP") && $rank >= 4) return true;
        return false;
    }

    public function canUseImmunityTablet(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "GS" && $rank >= 15) return true;
        return false;
    }

    public function canUseFNSTablet(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($org === "PV" && $rank >= 16 && $rank <= 100) return true;
        if ($org === "PV" && $rank > 100) return true;
        return false;
    }

    public function canUseMafiaRope(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        return ($org === "MF" && $rank >= 6);
    }

    public function ensureHandcuffs(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isHandcuffs($i)) return;
        $player->getInventory()->addItem($this->createHandcuffs());
        $player->sendMessage("§e§l[Снаряжение] §r§l§fВам выданы табельные наручники.");
    }

    public function ensureMedkit(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isMedkit($i)) return;
        $player->getInventory()->addItem($this->createMedkit());
        $player->sendMessage("§a§l[" . $this->plugin->getColoredOrgName("GB") . "§a§l] §r§l§fВам выдана аптечка.");
    }

    public function ensureLeaderCuffs(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isLeaderCuffs($i)) return;
        $player->getInventory()->addItem($this->createLeaderCuffs());
        $player->sendMessage("§c§l[Снаряжение] §r§l§fВам выданы спецнаручники.");
    }

    public function ensureCourtItem(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isCourtItem($i)) return;
        $player->getInventory()->addItem($this->createCourtItem());
        $player->sendMessage("§5§l[" . $this->plugin->getColoredOrgName("GS") . "§5§l] §r§l§fВам выданы судебные полномочия.");
    }

    public function ensureProsecutorTablet(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isProsecutorTablet($i)) return;
        $player->getInventory()->addItem($this->createProsecutorTablet());
        $player->sendMessage("§e§l[" . $this->plugin->getColoredOrgName("GP") . "§e§l] §r§l§fВам выдан служебный планшет.");
    }

    public function ensureProsecutorDocuments(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isProsecutorDocuments($i)) return;
        $player->getInventory()->addItem($this->createProsecutorDocuments());
        $player->sendMessage("§2§l[Проверка] §r§l§fВам выдан планшет проверки документов.");
    }

    public function ensureConfiscationTool(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isConfiscationTool($i)) return;
        $player->getInventory()->addItem($this->createConfiscationTool());
        $player->sendMessage("§c§l[Снаряжение] §r§l§fВам выдано средство для изъятия документов.");
    }

    public function ensureLawsuitTablet(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isLawsuitTablet($i)) return;
        $player->getInventory()->addItem($this->createLawsuitTablet());
        $player->sendMessage("§5§l[" . $this->plugin->getColoredOrgName("GS") . "§5§l] §r§l§fВам выдан планшет для работы с исками.");
    }

    public function ensureFineTablet(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isFineTablet($i)) return;
        $player->getInventory()->addItem($this->createFineTablet());
        $player->sendMessage("§b§l[Снаряжение] §r§l§fВам выдан планшет для штрафов.");
    }

    public function ensureWantedItem(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isWantedItem($i)) return;
        $player->getInventory()->addItem($this->createWantedItem());
        $player->sendMessage("§9§l[Снаряжение] §r§l§fВам выдана дубинка для объявления в розыск.");
    }

    public function ensureImmunityTablet(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isImmunityTablet($i)) return;
        $player->getInventory()->addItem($this->createImmunityTablet());
        $player->sendMessage("§6§l[" . $this->plugin->getColoredOrgName("GS") . "§6§l] §r§l§fВам выдан планшет для управления неприкосновенностью.");
    }

    public function ensureFNSTablet(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isFNSTablet($i)) return;
        $player->getInventory()->addItem($this->createFNSTablet());
        $player->sendMessage("§e§l[ФНС] §r§l§fВам выдан служебный планшет ФНС.");
    }

    public function ensureMafiaRope(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isMafiaRope($i)) return;
        $player->getInventory()->addItem($this->createMafiaRope());
        $player->sendMessage("§5§l[ОПГ] §r§l§fВам выданы инструменты для работы.");
    }

    public function ensureDocumentIdentifier(Player $player): void {
        foreach ($player->getInventory()->getContents() as $i) if ($this->isDocumentIdentifier($i)) return;
        $player->getInventory()->addItem($this->createDocumentIdentifier());
        $player->sendMessage("§b§l[Документы] §r§l§fВам выдан индификатор документов.");
    }

    public function removeAllHandcuffs(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isHandcuffs($i)) $p->getInventory()->clear($s); }
    public function removeAllMedkits(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isMedkit($i)) $p->getInventory()->clear($s); }
    public function removeAllLeaderCuffs(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isLeaderCuffs($i)) $p->getInventory()->clear($s); }
    public function removeAllCourtItems(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isCourtItem($i)) $p->getInventory()->clear($s); }
    public function removeAllGPItems(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isProsecutorTablet($i) || $this->isProsecutorDocuments($i)) $p->getInventory()->clear($s); }
    public function removeProsecutorTablet(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isProsecutorTablet($i)) $p->getInventory()->clear($s); }
    public function removeProsecutorDocuments(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isProsecutorDocuments($i)) $p->getInventory()->clear($s); }
    public function removeAllConfiscationTools(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isConfiscationTool($i)) $p->getInventory()->clear($s); }
    public function removeLawsuitTablet(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isLawsuitTablet($i)) $p->getInventory()->clear($s); }
    public function removeFineTablet(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isFineTablet($i)) $p->getInventory()->clear($s); }
    public function removeWantedItem(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isWantedItem($i)) $p->getInventory()->clear($s); }
    public function removeImmunityTablet(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isImmunityTablet($i)) $p->getInventory()->clear($s); }
    public function removeFNSTablet(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isFNSTablet($i)) $p->getInventory()->clear($s); }
    public function removeMafiaRope(Player $p): void {
        foreach ($p->getInventory()->getContents() as $s => $i)
            if ($this->isMafiaRope($i)) $p->getInventory()->clear($s);
    }
    public function removeDocumentIdentifier(Player $p): void { foreach ($p->getInventory()->getContents() as $s => $i) if ($this->isDocumentIdentifier($i)) $p->getInventory()->clear($s); }

    public function syncAllItems(Player $player): void {
        if ($this->canUseHandcuffs($player)) { $this->ensureHandcuffs($player); } else { $this->removeAllHandcuffs($player); }
        if ($this->canUseMedkit($player)) { $this->ensureMedkit($player); } else { $this->removeAllMedkits($player); }
        if ($this->canUseLeaderCuffs($player)) { $this->ensureLeaderCuffs($player); } else { $this->removeAllLeaderCuffs($player); }
        if ($this->plugin->getCourtSystem()->canUseCourtItem($player)) { $this->ensureCourtItem($player); } else { $this->removeAllCourtItems($player); }
        if ($this->canUseProsecutorTablet($player)) { $this->ensureProsecutorTablet($player); } else { $this->removeProsecutorTablet($player); }
        if ($this->canUseProsecutorDocuments($player)) { $this->ensureProsecutorDocuments($player); } else { $this->removeProsecutorDocuments($player); }
        if ($this->canUseConfiscationTool($player)) { $this->ensureConfiscationTool($player); } else { $this->removeAllConfiscationTools($player); }
        if ($this->canUseLawsuitTablet($player)) { $this->ensureLawsuitTablet($player); } else { $this->removeLawsuitTablet($player); }
        if ($this->canUseFineTablet($player)) { $this->ensureFineTablet($player); } else { $this->removeFineTablet($player); }
        if ($this->canUseWantedItem($player)) { $this->ensureWantedItem($player); } else { $this->removeWantedItem($player); }
        if ($this->canUseImmunityTablet($player)) { $this->ensureImmunityTablet($player); } else { $this->removeImmunityTablet($player); }
        if ($this->canUseFNSTablet($player)) { $this->ensureFNSTablet($player); } else { $this->removeFNSTablet($player); }
        if ($this->canUseMafiaRope($player)) {
            $this->ensureMafiaRope($player);
        } else {
            $this->removeMafiaRope($player);
        }
        if ($this->canUseDocumentIdentifier($player)) { $this->ensureDocumentIdentifier($player); } else { $this->removeDocumentIdentifier($player); }
    }
}