<?php

declare(strict_types=1);

namespace InzeOwr\RcEdit\command;

use InzeOwr\RcEdit\Main;
use InzeOwr\RcEdit\processor\BlockProcessor;
use InzeOwr\RcEdit\utils\BlockParser;
use InzeOwr\RcEdit\utils\Helpers;
use InzeOwr\RcEdit\utils\Message;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

/**
 * Обработчик всех команд плагина RcEdit.
 */
class CommandHandler {

	private Main $plugin;
	private BlockProcessor $processor;

	public function __construct(Main $plugin, BlockProcessor $processor) {
		$this->plugin = $plugin;
		$this->processor = $processor;
	}

	/**
	 * Главный диспетчер команд. Вызывается из Main::onCommand().
	 */
	public function handle(CommandSender $sender, Command $command, array $args): bool {
		if (!$sender instanceof Player) {
			$sender->sendMessage(Message::ERR . "Только для игроков.");
			return true;
		}
		if (!$sender->hasPermission("rcedit.use")) {
			$sender->sendMessage(Message::ERR . "Нет прав.");
			return true;
		}

		$session = $this->plugin->getSession($sender);

		return match ($command->getName()) {
			"rcwand"     => $this->rcWand($sender),
			"rcpalke"    => $this->rcPalke($sender, $session),
			"rcsetp"     => $this->rcSetP($sender, $session),
			"rcid"       => $this->rcId($sender, $session),
			"rce"        => $this->rcE($sender, $session, $args),
			"rcset"      => $this->rcSet($sender, $session, $args),
			"rccopy"     => $this->rcCopy($sender, $session),
			"rcpaste"    => $this->rcPaste($sender, $session),
			"rccopyx"    => $this->rcCopyX($sender, $session, $args),
			"rccopyu"    => $this->rcCopyU($sender, $args),
			"rcpastex"   => $this->rcPasteX($sender, $session, $args),
			"rcrotate"   => $this->rcRotate($sender, $session, $args),
			"rcundo"     => $this->rcUndo($sender, $session),
			"rcreturn"   => $this->rcReturn($sender, $session),
			"rcconnect"  => $this->rcConnect($sender, $session, $args),
			default      => false,
		};
	}

	// ================================================================
	// /rcwand — Выдать топорик выделения
	// ================================================================

	private function rcWand(Player $player): bool {
		$wand = VanillaItems::GOLDEN_AXE();
		$wand->setCustomName(TF::RESET . TF::GOLD . TF::BOLD . "✦ " . TF::RESET . TF::GOLD . "RcEdit Wand");
		$wand->setLore([
			TF::GRAY . "ЛКМ по блоку: " . TF::WHITE . "Точка 1",
			TF::GRAY . "ПКМ по блоку: " . TF::WHITE . "Точка 2",
		]);
		$player->getInventory()->addItem($wand);
		$player->sendMessage(Message::SUCCESS . "Топорик выделения выдан.");
		return true;
	}

	// ================================================================
	// /rcpalke — Выдать палку поворота/отсоединения
	// ================================================================

	private function rcPalke(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		$session->clearPalkeSelection();

		$stick = VanillaItems::STICK();
		$stick->setCustomName(TF::RESET . TF::LIGHT_PURPLE . TF::BOLD . "⚙ " . TF::RESET . TF::LIGHT_PURPLE . "RcEdit Палка");
		$stick->setLore([
			TF::GRAY . "ПКМ по блоку: " . TF::WHITE . "Повернуть/Отсоединить",
			TF::GRAY . "ЛКМ по блоку: " . TF::WHITE . "Палка Точка 1",
			TF::GRAY . "ПКМ (с P1): " . TF::WHITE . "Палка Точка 2",
			TF::GRAY . "Затем: " . TF::YELLOW . "/rcsetp",
		]);
		$stick->getNamedTag()->setString("RcPalke", "true");
		$player->getInventory()->addItem($stick);
		$player->sendMessage(Message::SUCCESS . "Палка поворота/отсоединения выдана.");
		$player->sendMessage(Message::PREFIX . "ПКМ по блоку — повернуть/отсоединить один блок.");
		$player->sendMessage(Message::PREFIX . "ЛКМ=P1, ПКМ=P2, затем /rcsetp.");
		return true;
	}

	// ================================================================
	// /rcsetp — Обработать выделение палкой
	// ================================================================

	private function rcSetP(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		if (!$session->hasPalkeSelection()) {
			$player->sendMessage(Message::ERR . "Нет выделения палкой.");
			$player->sendMessage(Message::PREFIX . "Возьмите палку (/rcpalke), ЛКМ=P1, ПКМ=P2.");
			return true;
		}

		$result = $this->processor->processPalkeSelection($player);
		$player->sendMessage(Message::SUCCESS . "Повёрнуто: " . TF::WHITE . $result['rotated'] . TF::GREEN . ", отсоединено: " . TF::WHITE . $result['disconnected'] . TF::GREEN . ".");
		$player->sendMessage(Message::PREFIX . "Введите /rcsetp ещё раз для повторного поворота.");
		return true;
	}

	// ================================================================
	// /rcid — Режим инспектора
	// ================================================================

	private function rcId(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		$state = $session->toggleIdMode();
		if ($state) {
			$player->sendMessage(Message::SUCCESS . "Режим ID " . TF::GREEN . "ВКЛЮЧЕН" . TF::GRAY . ". Тапните по блоку.");
		} else {
			$player->sendMessage(Message::PREFIX . "Режим ID " . TF::RED . "ВЫКЛЮЧЕН.");
		}
		return true;
	}

	// ================================================================
	// /rce — Установить позицию на ногах
	// ================================================================

	private function rcE(Player $player, \InzeOwr\RcEdit\session\Session $session, array $args): bool {
		if (!isset($args[0]) || !in_array($args[0], ["1", "2"])) {
			$player->sendMessage(Message::ERR . "Использование: /rce <1|2>");
			return true;
		}
		$pos = $player->getPosition()->floor();
		if ($args[0] === "1") {
			$session->setPos1($pos);
			$player->sendMessage(Message::SUCCESS . "Точка 1 (ноги): " . TF::WHITE . Helpers::vecStr($pos));
		} else {
			$session->setPos2($pos);
			$player->sendMessage(Message::SUCCESS . "Точка 2 (ноги): " . TF::WHITE . Helpers::vecStr($pos));
		}
		$this->sendSelectionInfo($player, $session);
		return true;
	}

	// ================================================================
	// /rcset — Заполнить выделение блоком (название или StateId)
	// ================================================================

	private function rcSet(Player $player, \InzeOwr\RcEdit\session\Session $session, array $args): bool {
		if (!$session->hasSelection()) {
			$player->sendMessage(Message::ERR . "Сначала выделите область (/rcwand).");
			return true;
		}
		if (!isset($args[0])) {
			$player->sendMessage(Message::ERR . "Использование: /rcset <название_блока|StateId>");
			return true;
		}

		$block = BlockParser::parse($args[0]);
		if ($block === null) {
			$player->sendMessage(Message::ERR . "Блок \"" . $args[0] . "\" не найден.");
			$player->sendMessage(Message::PREFIX . "Укажите название (stone) или StateId (число).");
			return true;
		}

		$count = $session->fillSelection($block);
		$player->sendMessage(Message::SUCCESS . "Установлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
		return true;
	}

	// ================================================================
	// /rccopy — Копировать в буфер
	// ================================================================

	private function rcCopy(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		if (!$session->hasSelection()) {
			$player->sendMessage(Message::ERR . "Сначала выделите область.");
			return true;
		}

		$count = $session->copy();
		if ($count === 0) {
			$player->sendMessage(Message::ERR . "Область пуста.");
			return true;
		}
		$player->sendMessage(Message::SUCCESS . "Скопировано " . TF::WHITE . $count . TF::GREEN . " блоков.");
		$player->sendMessage(Message::PREFIX . "Выделите новую область и /rcpaste");
		$player->sendMessage(Message::PREFIX . "Или /rcrotate <1|2|3> для поворота.");
		return true;
	}

	// ================================================================
	// /rcpaste — Вставить из буфера по выделению
	// ================================================================

	private function rcPaste(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		if (!$session->hasClipboard()) {
			$player->sendMessage(Message::ERR . "Буфер пуст. Сначала /rccopy.");
			return true;
		}
		if (!$session->hasSelection()) {
			$player->sendMessage(Message::ERR . "Выделите область для вставки (точка 1 = начало).");
			return true;
		}

		$count = $session->pasteToSelection();
		if ($count === 0) {
			$player->sendMessage(Message::ERR . "Нечего вставлять.");
			return true;
		}
		$player->sendMessage(Message::SUCCESS . "Вставлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
		return true;
	}

	// ================================================================
	// /rccopyx — Сохранить в файл
	// ================================================================

	private function rcCopyX(Player $player, \InzeOwr\RcEdit\session\Session $session, array $args): bool {
		if (!$session->hasSelection()) {
			$player->sendMessage(Message::ERR . "Сначала выделите область.");
			return true;
		}
		if (!isset($args[0])) {
			$player->sendMessage(Message::ERR . "Использование: /rccopyx <название>");
			return true;
		}

		$name = strtolower(trim($args[0]));

		if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $name)) {
			$player->sendMessage(Message::ERR . "Название может содержать только буквы, цифры, _ и -");
			return true;
		}

		$result = $session->saveSchematic($name);
		if ($result === false) {
			$player->sendMessage(Message::ERR . "Ошибка сохранения.");
			return true;
		}

		$player->sendMessage(Message::SUCCESS . "Постройка сохранена как: " . TF::WHITE . $name);
		$player->sendMessage(Message::PREFIX . "Вставить: /rcpastex " . $name);
		$player->sendMessage(Message::PREFIX . "Удалить: /rccopyu " . $name);
		return true;
	}

	// ================================================================
	// /rccopyu — Удалить сохранённую постройку
	// ================================================================

	private function rcCopyU(Player $player, array $args): bool {
		if (!isset($args[0])) {
			$player->sendMessage(Message::ERR . "Использование: /rccopyu <название>");

			$files = glob($this->plugin->getSchematicsPath() . "*.json");
			if (!empty($files)) {
				$player->sendMessage(Message::PREFIX . "Сохранённые постройки:");
				foreach ($files as $file) {
					$fname = basename($file, ".json");
					$player->sendMessage(Message::PREFIX . " - " . TF::YELLOW . $fname);
				}
			} else {
				$player->sendMessage(Message::PREFIX . "Нет сохранённых построек.");
			}
			return true;
		}

		$name = strtolower(trim($args[0]));
		$path = $this->plugin->getSchematicsPath() . $name . ".json";

		if (!file_exists($path)) {
			$player->sendMessage(Message::ERR . "Постройка \"" . $name . "\" не найдена.");

			$files = glob($this->plugin->getSchematicsPath() . "*.json");
			if (!empty($files)) {
				$player->sendMessage(Message::PREFIX . "Доступные постройки:");
				foreach ($files as $file) {
					$fname = basename($file, ".json");
					$player->sendMessage(Message::PREFIX . " - " . TF::YELLOW . $fname);
				}
			}
			return true;
		}

		unlink($path);
		$player->sendMessage(Message::SUCCESS . "Постройка \"" . TF::WHITE . $name . TF::GREEN . "\" удалена.");
		return true;
	}

	// ================================================================
	// /rcpastex — Вставить из файла на позиции игрока
	// ================================================================

	private function rcPasteX(Player $player, \InzeOwr\RcEdit\session\Session $session, array $args): bool {
		if (!isset($args[0])) {
			$player->sendMessage(Message::ERR . "Использование: /rcpastex <название>");

			$files = glob($this->plugin->getSchematicsPath() . "*.json");
			if (!empty($files)) {
				$player->sendMessage(Message::PREFIX . "Сохранённые постройки:");
				foreach ($files as $file) {
					$fname = basename($file, ".json");
					$player->sendMessage(Message::PREFIX . " - " . TF::YELLOW . $fname);
				}
			} else {
				$player->sendMessage(Message::PREFIX . "Нет сохранённых построек.");
			}
			return true;
		}

		$name = strtolower(trim($args[0]));

		$loaded = $session->loadSchematic($name);
		if (!$loaded) {
			$player->sendMessage(Message::ERR . "Постройка \"" . $name . "\" не найдена.");

			$files = glob($this->plugin->getSchematicsPath() . "*.json");
			if (!empty($files)) {
				$player->sendMessage(Message::PREFIX . "Доступные постройки:");
				foreach ($files as $file) {
					$fname = basename($file, ".json");
					$player->sendMessage(Message::PREFIX . " - " . TF::YELLOW . $fname);
				}
			}
			return true;
		}

		$count = $session->pasteAtPlayer();
		if ($count === 0) {
			$player->sendMessage(Message::ERR . "Нечего вставлять.");
			return true;
		}
		$player->sendMessage(Message::SUCCESS . "Вставлено \"" . TF::WHITE . $name . TF::GREEN . "\": " . TF::WHITE . $count . TF::GREEN . " блоков.");
		return true;
	}

	// ================================================================
	// /rcrotate — Повернуть буфер
	// ================================================================

	private function rcRotate(Player $player, \InzeOwr\RcEdit\session\Session $session, array $args): bool {
		if (!$session->hasClipboard()) {
			$player->sendMessage(Message::ERR . "Буфер пуст. Сначала /rccopy.");
			return true;
		}
		if (!isset($args[0]) || !in_array($args[0], ["1", "2", "3"])) {
			$player->sendMessage(Message::ERR . "Использование: /rcrotate <1|2|3>");
			$player->sendMessage(Message::PREFIX . "1 = 90° вправо");
			$player->sendMessage(Message::PREFIX . "2 = 90° влево");
			$player->sendMessage(Message::PREFIX . "3 = 180° разворот");
			return true;
		}
		$dir = (int)$args[0];
		$session->rotateClipboard($dir);
		$msg = match ($dir) {
			1 => "90° вправо",
			2 => "90° влево",
			3 => "180° (разворот)",
			default => "?"
		};
		$player->sendMessage(Message::SUCCESS . "Буфер повернут на " . TF::WHITE . $msg . TF::GREEN . ".");
		return true;
	}

	// ================================================================
	// /rcundo — Отменить действие
	// ================================================================

	private function rcUndo(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		if ($session->undo()) {
			$player->sendMessage(Message::SUCCESS . "Действие отменено.");
		} else {
			$player->sendMessage(Message::ERR . "Нечего отменять.");
		}
		return true;
	}

	// ================================================================
	// /rcreturn — Вернуть отменённое
	// ================================================================

	private function rcReturn(Player $player, \InzeOwr\RcEdit\session\Session $session): bool {
		if ($session->redo()) {
			$player->sendMessage(Message::SUCCESS . "Действие возвращено.");
		} else {
			$player->sendMessage(Message::ERR . "Нечего возвращать.");
		}
		return true;
	}

	// ================================================================
	// /rcconnect — Заполнить стены/пол/потолок паттерном
	// ================================================================

	private function rcConnect(Player $player, \InzeOwr\RcEdit\session\Session $session, array $args): bool {
		if (count($args) < 2) {
			$player->sendMessage(Message::ERR . "Использование: /rcconnect <блоки> <режим>");
			$player->sendMessage(Message::PREFIX . "Блоки: stone%50,dirt%50 (или StateId)");
			$player->sendMessage(Message::PREFIX . "Режим: 1=стены, 2=пол/потолок, 3=все");
			return true;
		}
		if (!$session->hasSelection()) {
			$player->sendMessage(Message::ERR . "Нет выделения.");
			return true;
		}

		$patternString = $args[0];
		$mode = (int)$args[1];

		if ($mode < 1 || $mode > 3) {
			$player->sendMessage(Message::ERR . "Режим должен быть 1, 2 или 3.");
			return true;
		}

		$pattern = [];
		$parts = explode(",", $patternString);
		foreach ($parts as $part) {
			$d = explode("%", $part);
			$bName = $d[0];
			$chance = isset($d[1]) ? (float)$d[1] : 100.0;
			if ($chance <= 0) continue;
			$blk = BlockParser::parse($bName);
			if ($blk !== null) {
				$pattern[] = ['block' => $blk, 'chance' => $chance];
			} else {
				$player->sendMessage(Message::ERR . "Блок \"" . $bName . "\" не найден, пропущен.");
			}
		}

		if (empty($pattern)) {
			$player->sendMessage(Message::ERR . "Ни один блок не распознан.");
			return true;
		}

		$count = $session->connectPattern($pattern, $mode);
		$player->sendMessage(Message::SUCCESS . "Установлено " . TF::WHITE . $count . TF::GREEN . " блоков.");
		return true;
	}

	// ================================================================
	// Вспомогательное
	// ================================================================

	private function sendSelectionInfo(Player $player, \InzeOwr\RcEdit\session\Session $session): void {
		if ($session->hasSelection()) {
			$bounds = $session->getSelectionBounds();
			$min = $bounds['min'];
			$max = $bounds['max'];
			$sizeX = (int)($max->x - $min->x + 1);
			$sizeY = (int)($max->y - $min->y + 1);
			$sizeZ = (int)($max->z - $min->z + 1);
			$total = $sizeX * $sizeY * $sizeZ;
			$player->sendMessage(Message::PREFIX . "Размер: " . TF::WHITE . "{$sizeX}x{$sizeY}x{$sizeZ}" . TF::GRAY . " ({$total} блоков)");
		}
	}
}
