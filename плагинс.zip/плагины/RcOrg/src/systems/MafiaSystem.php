<?php

namespace InzeOwr\RcOrg\systems;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\forms\MafiaForms;
use InzeOwr\RcOrg\forms\Forms;

class MafiaSystem {

    private Main $plugin;
    private Config $drugData;
    private Config $drugRecipes;

    public const DRUGS = [
        "cocaine" => ["name" => "§fКокаин", "color" => "f", "item" => "GHAST_TEAR"],
        "heroin" => ["name" => "§7Героин", "color" => "7", "item" => "PHANTOM_MEMBRANE"],
        "meth" => ["name" => "§bМетамфетамин", "color" => "b", "item" => "PRISMARINE_CRYSTALS"],
        "weed" => ["name" => "§aМарихуана", "color" => "a", "item" => "FERN"],
        "lsd" => ["name" => "§dЛСД", "color" => "d", "item" => "CHORUS_FRUIT"],
        "mdma" => ["name" => "§eЭкстази", "color" => "e", "item" => "GLOW_BERRIES"]
    ];

    public const MINIGAMES = [
        "sequence" => "Последовательность",
        "math" => "Математика",
        "reaction" => "Реакция",
        "memory" => "Память",
        "pattern" => "Узор",
        "mixing" => "Смешивание"
    ];

    public array $drugMinigames = [
        "cocaine" => "sequence",
        "heroin" => "math",
        "meth" => "reaction",
        "weed" => "memory",
        "lsd" => "pattern",
        "mdma" => "mixing"
    ];

    private array $activeGames = [];

    private array $pendingDeals = [];

    private array $pendingTransfers = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->drugData = new Config($plugin->getDataFolder() . "drugs.json", Config::JSON);
        $this->drugRecipes = new Config($plugin->getDataFolder() . "drug_recipes.json", Config::JSON);

        $this->initRecipes();
    }

    private function initRecipes(): void {
        if ($this->drugRecipes->exists("initialized")) return;

        $this->drugRecipes->set("cocaine", [
            "ingredients" => ["Листья коки", "Серная кислота", "Аммиак"],
            "time" => 180,
            "difficulty" => 3
        ]);

        $this->drugRecipes->set("heroin", [
            "ingredients" => ["Опиум", "Ангидрид уксусной кислоты", "Ацетон"],
            "time" => 240,
            "difficulty" => 4
        ]);

        $this->drugRecipes->set("meth", [
            "ingredients" => ["Эфедрин", "Красный фосфор", "Йод"],
            "time" => 300,
            "difficulty" => 5
        ]);

        $this->drugRecipes->set("weed", [
            "ingredients" => ["Семена конопли", "Удобрения", "Вода"],
            "time" => 120,
            "difficulty" => 2
        ]);

        $this->drugRecipes->set("lsd", [
            "ingredients" => ["Лизергиновая кислота", "Диэтиламид", "Спирт"],
            "time" => 200,
            "difficulty" => 4
        ]);

        $this->drugRecipes->set("mdma", [
            "ingredients" => ["Сафрол", "Изопропанол", "Хлороводород"],
            "time" => 160,
            "difficulty" => 3
        ]);

        $this->drugRecipes->set("initialized", true);
        $this->drugRecipes->save();
    }

    public function canCraftDrugs(Player $player): bool {
        $org = $this->plugin->getPlayerOrg($player->getName());
        $rank = $this->plugin->getPlayerRank($player->getName());
        return ($org === "MF" && $rank >= 6);
    }

    public function getDrugs(string $playerName): array {
        return $this->drugData->get(strtolower($playerName), []);
    }

    public function addDrug(string $playerName, string $drugType, int $amount = 1): void {
        $key = strtolower($playerName);
        $current = $this->drugData->getNested("$key.$drugType", 0);
        $this->drugData->setNested("$key.$drugType", $current + $amount);
        $this->drugData->save();
    }

    public function removeDrug(string $playerName, string $drugType, int $amount = 1): bool {
        $key = strtolower($playerName);
        $current = $this->drugData->getNested("$key.$drugType", 0);

        if ($current < $amount) return false;

        $this->drugData->setNested("$key.$drugType", $current - $amount);
        $this->drugData->save();
        return true;
    }

    public function getDrugCount(string $playerName, string $drugType): int {
        return $this->drugData->getNested(strtolower($playerName) . ".$drugType", 0);
    }

    public function isDrugItem(Item $item): bool {
        $nbt = $item->getNamedTag();
        return $nbt->getTag("drug_type") !== null;
    }

    public function getDrugTypeFromItem(Item $item): ?string {
        $nbt = $item->getNamedTag();
        $drugType = $nbt->getString("drug_type", "");

        if ($drugType === "" || !isset(self::DRUGS[$drugType])) {
            return null;
        }

        return $drugType;
    }

    public function createDrugItem(string $drugType, int $amount = 1): ?Item {
        if (!isset(self::DRUGS[$drugType])) return null;

        $drugInfo = self::DRUGS[$drugType];
        $itemName = $drugInfo['item'];

        $item = match($itemName) {
            "GHAST_TEAR" => VanillaItems::GHAST_TEAR(),
            "PHANTOM_MEMBRANE" => VanillaItems::PHANTOM_MEMBRANE(),
            "PRISMARINE_CRYSTALS" => VanillaItems::PRISMARINE_CRYSTALS(),
            "FERN" => VanillaItems::FERN(),
            "CHORUS_FRUIT" => VanillaItems::CHORUS_FRUIT(),
            "GLOW_BERRIES" => VanillaItems::GLOW_BERRIES(),
            default => null
        };

        if ($item === null) return null;

        $item->setCount($amount);
        $item->setCustomName("{$drugInfo['name']}\n§r§7Нелегальный товар");

        $nbt = $item->getNamedTag();
        $nbt->setString("drug_type", $drugType);
        $item->setNamedTag($nbt);

        return $item;
    }

    public function startCrafting(Player $player, string $drugType): void {
        $name = $player->getName();

        if (isset($this->activeGames[strtolower($name)])) {
            $player->sendMessage("§c§l[Лаборатория] §r§l§fВы уже занимаетесь производством.");
            return;
        }

        if (!isset(self::DRUGS[$drugType])) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fНеизвестный тип наркотика.");
            return;
        }

        $minigameType = $this->drugMinigames[$drugType];
        $drug = self::DRUGS[$drugType];

        $this->activeGames[strtolower($name)] = [
            "drug" => $drugType,
            "minigame" => $minigameType,
            "start_time" => time()
        ];

        $player->sendMessage("§d§l[Лаборатория] §r§l§fНачато производство {$drug['name']}§r§f...");
        $player->sendMessage("§l§7Тип задания: §e" . self::MINIGAMES[$minigameType]);

        $this->launchMinigame($player, $minigameType, $drugType);
    }

    private function launchMinigame(Player $player, string $type, string $drugType): void {
        switch ($type) {
            case "sequence":
                $this->startSequenceGame($player, $drugType);
                break;
            case "math":
                $this->startMathGame($player, $drugType);
                break;
            case "reaction":
                $this->startReactionGame($player, $drugType);
                break;
            case "memory":
                $this->startMemoryGame($player, $drugType);
                break;
            case "pattern":
                $this->startPatternGame($player, $drugType);
                break;
            case "mixing":
                $this->startMixingGame($player, $drugType);
                break;
        }
    }

    private function startSequenceGame(Player $player, string $drugType): void {
        $sequence = [];
        for ($i = 0; $i < 5; $i++) {
            $sequence[] = mt_rand(1, 9);
        }

        $sequenceStr = implode(" - ", $sequence);

        MafiaForms::openSequenceGame($player, $drugType, $sequence, $sequenceStr);
    }

    private function startMathGame(Player $player, string $drugType): void {
        $a = mt_rand(10, 50);
        $b = mt_rand(10, 50);
        $op = ["+", "-", "*"][mt_rand(0, 2)];

        $question = "$a $op $b";
        $answer = 0;

        switch ($op) {
            case "+": $answer = $a + $b; break;
            case "-": $answer = $a - $b; break;
            case "*": $answer = $a * $b; break;
        }

        MafiaForms::openMathGame($player, $drugType, $question, $answer);
    }

    private function startReactionGame(Player $player, string $drugType): void {
        $colors = ["§cКрасный", "§aЗелёный", "§9Синий", "§eЖёлтый"];
        $correct = $colors[mt_rand(0, 3)];

        MafiaForms::openReactionGame($player, $drugType, $correct, $colors);
    }

    private function startMemoryGame(Player $player, string $drugType): void {
        $items = ["Колба", "Пробирка", "Таблетка", "Микроскоп", "Шприц"];
        shuffle($items);
        $shown = array_slice($items, 0, 3);

        MafiaForms::openMemoryGame($player, $drugType, $shown, $items);
    }

    private function startPatternGame(Player $player, string $drugType): void {
        $pattern = [
            [1, 0, 1],
            [0, 1, 0],
            [1, 0, 1]
        ];

        MafiaForms::openPatternGame($player, $drugType, $pattern);
    }

    private function startMixingGame(Player $player, string $drugType): void {
        $recipe = $this->drugRecipes->get($drugType);
        $ingredients = $recipe['ingredients'];

        MafiaForms::openMixingGame($player, $drugType, $ingredients);
    }

    public function completeCrafting(Player $player, string $drugType, bool $success): void {
        $name = strtolower($player->getName());

        if (!isset($this->activeGames[$name])) return;

        unset($this->activeGames[$name]);

        if ($success) {
            $this->addDrug($player->getName(), $drugType, 1);
            $drug = self::DRUGS[$drugType];
            $player->sendMessage("§a§l[Лаборатория] §r§l§fУспешно произведено: {$drug['name']}§r§f!");
            $player->sendMessage("§l§7Наркотик добавлен в ваш тайник.");

            $this->plugin->addLog("MF", "§d§l{$player->getName()} §6§lпроизвёл {$drug['name']}");
        } else {
            $player->sendMessage("§c§l[Лаборатория] §r§l§fПроизводство провалено! Ингредиенты испорчены.");
        }
    }

    public function useDrug(Player $player, string $drugType): void {
        if (!isset(self::DRUGS[$drugType])) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fНеизвестный тип наркотика.");
            return;
        }

        $item = $player->getInventory()->getItemInHand();

        if (!$this->isDrugItem($item)) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fЭто не наркотик.");
            return;
        }

        $itemDrugType = $this->getDrugTypeFromItem($item);

        if ($itemDrugType !== $drugType) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fНесоответствие типа наркотика.");
            return;
        }

        $item->setCount($item->getCount() - 1);
        $player->getInventory()->setItemInHand($item);

        $drugInfo = self::DRUGS[$drugType];

        switch ($drugType) {
            case "cocaine":
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::SPEED(),
                    60 * 20,
                    1
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::JUMP_BOOST(),
                    60 * 20,
                    0
                ));
                break;

            case "heroin":
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::REGENERATION(),
                    90 * 20,
                    2
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::SLOWNESS(),
                    90 * 20,
                    0
                ));
                break;

            case "meth":
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::SPEED(),
                    45 * 20,
                    2
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::STRENGTH(),
                    45 * 20,
                    1
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::HASTE(),
                    45 * 20,
                    1
                ));
                break;

            case "weed":
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::NIGHT_VISION(),
                    120 * 20,
                    0
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::SLOWNESS(),
                    120 * 20,
                    0
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::HUNGER(),
                    120 * 20,
                    0
                ));
                break;

            case "lsd":
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::NIGHT_VISION(),
                    80 * 20,
                    0
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::NAUSEA(),
                    80 * 20,
                    0
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::JUMP_BOOST(),
                    80 * 20,
                    2
                ));
                break;

            case "mdma":
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::ABSORPTION(),
                    70 * 20,
                    2
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::JUMP_BOOST(),
                    70 * 20,
                    1
                ));
                $player->getEffects()->add(new EffectInstance(
                    VanillaEffects::SPEED(),
                    70 * 20,
                    0
                ));
                break;
        }

        $player->sendMessage("§d§l[Наркотики] §r§l§fВы употребили {$drugInfo['name']}§r§f!");
        $player->sendMessage("§l§7Эффекты активированы...");

        $this->plugin->addLog("MF", "§d§l{$player->getName()} §6§lупотребил {$drugInfo['name']}");
    }

    public function createDeal(string $sellerName, string $buyerName, string $drugType, int $amount, int $pricePerUnit): string {
        $dealId = uniqid("deal_");
        $totalPrice = $amount * $pricePerUnit;

        $this->pendingDeals[$dealId] = [
            "seller" => $sellerName,
            "buyer" => $buyerName,
            "drug" => $drugType,
            "amount" => $amount,
            "price_per_unit" => $pricePerUnit,
            "total_price" => $totalPrice,
            "time" => time()
        ];

        return $dealId;
    }

    public function getDeal(string $dealId): ?array {
        return $this->pendingDeals[$dealId] ?? null;
    }

    public function removeDeal(string $dealId): void {
        unset($this->pendingDeals[$dealId]);
    }

    public function acceptDeal(string $dealId, Player $buyer): bool {
        $deal = $this->getDeal($dealId);
        if ($deal === null) {
            $buyer->sendMessage("§c§l[Ошибка] §r§l§fСделка не найдена или истекла.");
            return false;
        }

        $sellerName = $deal['seller'];
        $drugType = $deal['drug'];
        $amount = $deal['amount'];
        $totalPrice = $deal['total_price'];

        $seller = Server::getInstance()->getPlayerExact($sellerName);

        if ($seller === null) {
            $buyer->sendMessage("§c§l[Ошибка] §r§l§fПродавец вышел из игры.");
            $this->removeDeal($dealId);
            return false;
        }

        if ($this->getDrugCount($sellerName, $drugType) < $amount) {
            $buyer->sendMessage("§c§l[Ошибка] §r§l§fУ продавца недостаточно товара.");
            $seller->sendMessage("§c§l[Сделка] §r§l§fУ вас недостаточно товара для сделки.");
            $this->removeDeal($dealId);
            return false;
        }

        $api = \onebone\economyapi\EconomyAPI::getInstance();
        $buyerMoney = $api->myMoney($buyer);

        if ($buyerMoney < $totalPrice) {
            $buyer->sendMessage("§c§l[Ошибка] §r§l§fУ вас недостаточно денег. Требуется: §e" . number_format($totalPrice) . "$");
            $seller->sendMessage("§c§l[Сделка] §r§l§fПокупатель §e{$buyer->getName()} §fне смог оплатить сделку (недостаточно средств).");
            $this->removeDeal($dealId);
            return false;
        }

        $this->removeDrug($sellerName, $drugType, $amount);
        $api->reduceMoney($buyer, $totalPrice);
        $api->addMoney($seller, $totalPrice);

        $drugItem = $this->createDrugItem($drugType, $amount);
        if ($drugItem !== null) {
            $buyer->getInventory()->addItem($drugItem);
        }

        $drugInfo = self::DRUGS[$drugType];

        $buyer->sendMessage("§a§l[Сделка] §r§l§fВы купили §e{$amount}x {$drugInfo['name']} §r§l§fза §e" . number_format($totalPrice) . "§f.");
        $seller->sendMessage("§a§l[Сделка] §r§l§fИгрок §e{$buyer->getName()} §fкупил §e{$amount}x {$drugInfo['name']} §r§l§fза §e" . number_format($totalPrice) . "§f.");

        $this->plugin->addLog("MF", "§d§l{$sellerName} §6§lпродал {$amount}x {$drugInfo['name']} §6§lигроку §d§l{$buyer->getName()} §6§lза " . number_format($totalPrice) . "$");

        $this->removeDeal($dealId);
        return true;
    }

    public function declineDeal(string $dealId, Player $buyer): void {
        $deal = $this->getDeal($dealId);
        if ($deal === null) return;

        $sellerName = $deal['seller'];
        $drugType = $deal['drug'];
        $amount = $deal['amount'];
        $drugInfo = self::DRUGS[$drugType];

        $buyer->sendMessage("§c§l[Сделка] §r§l§fВы отказались от покупки §e{$amount}x {$drugInfo['name']}§f.");

        $seller = Server::getInstance()->getPlayerExact($sellerName);
        if ($seller !== null) {
            $seller->sendMessage("§c§l[Сделка] §r§l§fИгрок §e{$buyer->getName()} §fотказался от покупки §e{$amount}x {$drugInfo['name']}§f.");
        }

        $this->removeDeal($dealId);
    }

    public function createTransfer(string $fromName, string $toName, string $drugType, int $amount): string {
        $transferId = uniqid("transfer_");

        $this->pendingTransfers[$transferId] = [
            "from" => $fromName,
            "to" => $toName,
            "drug" => $drugType,
            "amount" => $amount,
            "time" => time()
        ];

        return $transferId;
    }

    public function getTransfer(string $transferId): ?array {
        return $this->pendingTransfers[$transferId] ?? null;
    }

    public function removeTransfer(string $transferId): void {
        unset($this->pendingTransfers[$transferId]);
    }

    public function acceptTransfer(string $transferId, Player $receiver): bool {
        $transfer = $this->getTransfer($transferId);
        if ($transfer === null) {
            $receiver->sendMessage("§c§l[Ошибка] §r§l§fПередача не найдена или истекла.");
            return false;
        }

        $fromName = $transfer['from'];
        $drugType = $transfer['drug'];
        $amount = $transfer['amount'];

        $from = Server::getInstance()->getPlayerExact($fromName);

        if ($from === null) {
            $receiver->sendMessage("§c§l[Ошибка] §r§l§fОтправитель вышел из игры.");
            $this->removeTransfer($transferId);
            return false;
        }

        if ($this->getDrugCount($fromName, $drugType) < $amount) {
            $receiver->sendMessage("§c§l[Ошибка] §r§l§fУ отправителя недостаточно товара.");
            $from->sendMessage("§c§l[Передача] §r§l§fУ вас недостаточно товара для передачи.");
            $this->removeTransfer($transferId);
            return false;
        }

        $this->removeDrug($fromName, $drugType, $amount);

        $drugItem = $this->createDrugItem($drugType, $amount);
        if ($drugItem !== null) {
            $receiver->getInventory()->addItem($drugItem);
        }

        $drugInfo = self::DRUGS[$drugType];

        $receiver->sendMessage("§a§l[Передача] §r§l§fВы получили §e{$amount}x {$drugInfo['name']} §r§l§fот §e{$fromName}§f.");
        $from->sendMessage("§a§l[Передача] §r§l§fИгрок §e{$receiver->getName()} §fпринял передачу §e{$amount}x {$drugInfo['name']}§f.");

        $this->plugin->addLog("MF", "§d§l{$fromName} §6§lпередал {$amount}x {$drugInfo['name']} §6§lигроку §d§l{$receiver->getName()}");

        $this->removeTransfer($transferId);
        return true;
    }

    public function declineTransfer(string $transferId, Player $receiver): void {
        $transfer = $this->getTransfer($transferId);
        if ($transfer === null) return;

        $fromName = $transfer['from'];
        $drugType = $transfer['drug'];
        $amount = $transfer['amount'];
        $drugInfo = self::DRUGS[$drugType];

        $receiver->sendMessage("§c§l[Передача] §r§l§fВы отказались от получения §e{$amount}x {$drugInfo['name']}§f.");

        $from = Server::getInstance()->getPlayerExact($fromName);
        if ($from !== null) {
            $from->sendMessage("§c§l[Передача] §r§l§fИгрок §e{$receiver->getName()} §fотказался от получения §e{$amount}x {$drugInfo['name']}§f.");
        }

        $this->removeTransfer($transferId);
    }

    public function transferDrug(Player $from, string $targetName, string $drugType, int $amount): void {
        if (!$this->removeDrug($from->getName(), $drugType, $amount)) {
            $from->sendMessage("§c§l[Ошибка] §r§l§fУ вас недостаточно наркотиков для передачи.");
            return;
        }

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target === null) {
            $this->addDrug($from->getName(), $drugType, $amount);
            $from->sendMessage("§c§l[Ошибка] §r§l§fИгрок не найден.");
            return;
        }

        $drugItem = $this->createDrugItem($drugType, $amount);
        if ($drugItem !== null) {
            $target->getInventory()->addItem($drugItem);
        }

        $drug = self::DRUGS[$drugType];
        $from->sendMessage("§a§l[Передача] §r§l§fВы передали §e{$amount}x {$drug['name']} §r§l§fигроку §e{$target->getName()}§f.");
        $target->sendMessage("§a§l[Передача] §r§l§fИгрок §e{$from->getName()} §fпередал вам §e{$amount}x {$drug['name']}§r§f.");

        $this->plugin->addLog("MF", "§d§l{$from->getName()} §6§lпередал {$amount}x {$drug['name']} §6§lигроку §d§l{$target->getName()}");
    }

    public function getTotalDrugs(string $playerName): int {
        $drugs = $this->getDrugs($playerName);
        return array_sum($drugs);
    }

    public function getMostValuableDrug(string $playerName): ?string {
        $drugs = $this->getDrugs($playerName);
        if (empty($drugs)) return null;

        $maxCount = 0;
        $bestDrug = null;

        foreach ($drugs as $type => $count) {
            if ($count > $maxCount && isset(self::DRUGS[$type])) {
                $maxCount = $count;
                $bestDrug = $type;
            }
        }

        return $bestDrug;
    }

    public function clearDrugs(string $playerName): void {
        $this->drugData->remove(strtolower($playerName));
        $this->drugData->save();
    }

    public function getDrugInfo(string $drugType): ?array {
        return self::DRUGS[$drugType] ?? null;
    }

    public function getRecipe(string $drugType): ?array {
        return $this->drugRecipes->get($drugType);
    }
}