<?php

declare(strict_types=1);

namespace InzeOwr\RcBan;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class LimitManager {
    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function getPlayerGroup(string $nickname): string {
        $rcGroup = $this->plugin->getRcGroup();
        return $rcGroup !== null ? $rcGroup->getGroup($nickname) : "";
    }

    public function isStaff(string $nickname): bool {
        $group = $this->getPlayerGroup($nickname);
        if ($group !== "") {
            $staffGroups = $this->plugin->getConfig()->get("staff_groups", []);
            if (in_array($group, $staffGroups, true)) return true;
        }
        $player = $this->plugin->getServer()->getPlayerExact($nickname);
        if ($player !== null && $player->hasPermission("rcban.staff")) return true;
        return false;
    }

    public function getLimitedConfig(string $nickname): ?array {
        $group = $this->getPlayerGroup($nickname);
        if ($group === "") return null;
        $limited = $this->plugin->getConfig()->get("limited_groups", []);
        return isset($limited[$group]) && is_array($limited[$group]) ? $limited[$group] : null;
    }

    public function checkStaffProtection(CommandSender $sender, string $targetName): bool {
        if (!($sender instanceof Player)) return true;
        if ($this->isStaff($targetName)) {
            $sender->sendMessage($this->plugin->msg("cannot_ban_staff"));
            return false;
        }
        return true;
    }

    public function checkSelfBan(CommandSender $sender, string $targetName): bool {
        if ($this->plugin->getConfig()->get("self_ban_protection", true)) {
            if ($sender instanceof Player && strtolower($sender->getName()) === strtolower($targetName)) {
                $sender->sendMessage($this->plugin->msg("self_ban"));
                return false;
            }
        }
        return true;
    }

    public function checkBypass(CommandSender $sender, string $targetName): bool {
        $targetPlayer = $this->plugin->getServer()->getPlayerExact($targetName);
        if ($targetPlayer !== null && $targetPlayer->hasPermission("rcban.bypass")) {
            $sender->sendMessage($this->plugin->msg("target_protected"));
            return false;
        }
        return true;
    }

    public function canBanTarget(CommandSender $sender, string $targetName): bool {
        if (!$this->checkSelfBan($sender, $targetName)) return false;
        if (!$this->checkBypass($sender, $targetName)) return false;
        if (!$this->checkStaffProtection($sender, $targetName)) return false;
        return true;
    }

    public function checkLimitedCommand(CommandSender $sender, string $commandName): bool {
        if (!($sender instanceof Player)) return true;
        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;
        $allowed = $limitCfg["allowed_commands"] ?? [];
        if (!is_array($allowed)) return false;
        if (!in_array($commandName, $allowed, true)) {
            $sender->sendMessage($this->plugin->msg("limited_command"));
            return false;
        }
        return true;
    }

    public function checkLimitedTime(CommandSender $sender, int $minutes): bool {
        if (!($sender instanceof Player)) return true;
        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;
        $maxTime = (int) ($limitCfg["max_time_minutes"] ?? 0);
        if ($maxTime <= 0) return true;
        if ($minutes > $maxTime) {
            $sender->sendMessage($this->plugin->msg("limited_time", [
                "allowed" => $this->plugin->getBanManager()->normalizeTime($maxTime),
                "given" => $this->plugin->getBanManager()->normalizeTime($minutes),
            ]));
            return false;
        }
        return true;
    }

    public function checkAndUseBanLimit(CommandSender $sender): bool {
        if (!($sender instanceof Player)) return true;
        $senderName = $sender->getName();
        $limitCfg = $this->getLimitedConfig($senderName);
        if ($limitCfg === null) return true;
        $maxBans = (int) ($limitCfg["max_bans"] ?? 0);
        $cooldownHours = (int) ($limitCfg["cooldown_hours"] ?? 24);
        if ($maxBans <= 0) return true;

        $senderKey = strtolower($senderName);
        $limitsData = $this->plugin->getLimitsConfig()->get($senderKey, null);
        if (!is_array($limitsData)) {
            $limitsData = ["bans_used" => 0, "period_start" => time()];
        }

        $periodStart = (int) ($limitsData["period_start"] ?? time());
        $bansUsed = (int) ($limitsData["bans_used"] ?? 0);
        $cooldownSeconds = $cooldownHours * 3600;

        if ((time() - $periodStart) >= $cooldownSeconds) {
            $bansUsed = 0;
            $periodStart = time();
        }

        if ($bansUsed >= $maxBans) {
            $resetTime = $periodStart + $cooldownSeconds;
            $remaining = $this->plugin->getBanManager()->getTimeRemaining($resetTime);
            $sender->sendMessage($this->plugin->msg("ban_limit_reached", [
                "max" => $maxBans,
                "remaining" => $remaining,
            ]));
            return false;
        }

        $bansUsed++;
        $this->plugin->getLimitsConfig()->set($senderKey, ["bans_used" => $bansUsed, "period_start" => $periodStart]);
        $this->plugin->getLimitsConfig()->save();

        $left = $maxBans - $bansUsed;
        $resetTime = $periodStart + $cooldownSeconds;
        $remaining = $this->plugin->getBanManager()->getTimeRemaining($resetTime);
        $sender->sendMessage($this->plugin->msg("ban_limit_used", [
            "used" => $bansUsed,
            "max" => $maxBans,
            "left" => $left,
            "remaining" => $remaining,
        ]));

        return true;
    }

    public function checkLimitedUnban(CommandSender $sender, array $banData): bool {
        if (!($sender instanceof Player)) return true;
        $limitCfg = $this->getLimitedConfig($sender->getName());
        if ($limitCfg === null) return true;
        $canUnbanStaff = (bool) ($limitCfg["can_unban_staff"] ?? false);
        if ($canUnbanStaff) return true;
        $banAdmin = $banData["admin"] ?? "";
        if ($this->isStaff($banAdmin)) {
            $sender->sendMessage($this->plugin->msg("cannot_unban_staff_ban"));
            return false;
        }
        return true;
    }

    public function canRemovePermBan(CommandSender $sender): bool {
        if (!($sender instanceof Player)) return true;
        if ($this->isStaff($sender->getName())) return true;
        $sender->sendMessage($this->plugin->msg("perm_ban_only_staff_remove"));
        return false;
    }
}