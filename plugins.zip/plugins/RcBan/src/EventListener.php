<?php

declare(strict_types=1);

namespace InzeOwr\RcBan;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;

class EventListener implements Listener {
    private Main $plugin;
    private array $pendingNotify = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onPlayerLogin(PlayerLoginEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $ip = $player->getNetworkSession()->getIp();

        if ($this->plugin->getBansConfig()->exists($name)) {
            $data = $this->plugin->getBansConfig()->get($name);
            if (isset($data["type"])) {
                if ($data["type"] === "temp") {
                    if (time() >= ($data["expire"] ?? 0)) {
                        $this->plugin->getBansConfig()->remove($name);
                        $this->plugin->getBansConfig()->save();
                    } else {
                        $event->setKickMessage($this->plugin->getKickMessageForBan($data, "account"));
                        $event->cancel();
                        return;
                    }
                } elseif ($data["type"] === "perm") {
                    $event->setKickMessage($this->plugin->getKickMessageForBan($data, "account"));
                    $event->cancel();
                    return;
                }
            }
        }

        foreach ($this->plugin->getIpBansConfig()->getAll() as $bannedName => $data) {
            if (isset($data["ip"]) && $data["ip"] === $ip) {
                $event->setKickMessage($this->plugin->getKickMessageForBan($data, "ip"));
                $event->cancel();
                return;
            }
        }

        if ($this->plugin->getHardBansConfig()->exists($name)) {
            $data = $this->plugin->getHardBansConfig()->get($name);
            if (isset($data["expire"]) && time() >= $data["expire"]) {
                $this->plugin->getHardBansConfig()->remove($name);
                $this->plugin->getHardBansConfig()->save();
            } else {
                if (!isset($data["ip"]) || $data["ip"] !== $ip) {
                    $data["ip"] = $ip;
                    $this->plugin->getHardBansConfig()->set($name, $data);
                    $this->plugin->getHardBansConfig()->save();
                }
                $event->setKickMessage($this->plugin->getKickMessageForBan($data, "hard"));
                $event->cancel();
                return;
            }
        }

        foreach ($this->plugin->getHardBansConfig()->getAll() as $bannedName => $data) {
            if ($bannedName === $name) continue;
            if (isset($data["ip"]) && $data["ip"] === $ip) {
                if (isset($data["expire"]) && time() >= $data["expire"]) {
                    $this->plugin->getHardBansConfig()->remove($bannedName);
                    $this->plugin->getHardBansConfig()->save();
                    continue;
                }
                $event->setKickMessage($this->plugin->getKickMessageForBan($data, "hard"));
                $event->cancel();
                return;
            }
        }
    }

    public function onPlayerJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $ip = $player->getNetworkSession()->getIp();

        if (!$this->plugin->getBanManager()->isBanned($player)) {
            $this->plugin->getBanManager()->hideBannedFrom($player);
        }

        $banData = null;
        $banKind = "account";
        $durationStr = "Перманентно";

        if ($this->plugin->getBansConfig()->exists($name)) {
            $data = $this->plugin->getBansConfig()->get($name);
            if (isset($data["type"])) {
                if ($data["type"] === "temp" && time() < ($data["expire"] ?? 0)) {
                    $banData = $data;
                    $durationStr = $data["duration_str"] ?? $this->plugin->getBanManager()->normalizeTime((int) (($data["expire"] - $data["time"]) / 60));
                } elseif ($data["type"] === "perm") {
                    $banData = $data;
                    $durationStr = "Перманентно";
                }
            }
        }

        if ($banData === null && $this->plugin->getHardBansConfig()->exists($name)) {
            $data = $this->plugin->getHardBansConfig()->get($name);
            if (!isset($data["expire"]) || time() < $data["expire"]) {
                $banData = $data;
                $banKind = "hard";
                $durationStr = $data["duration_str"] ?? "—";
            }
        }

        if ($banData === null) {
            foreach ($this->plugin->getHardBansConfig()->getAll() as $bannedName => $data) {
                if ($bannedName === $name) continue;
                if (isset($data["ip"]) && $data["ip"] === $ip) {
                    if (!isset($data["expire"]) || time() < $data["expire"]) {
                        $banData = $data;
                        $banKind = "hard";
                        $durationStr = $data["duration_str"] ?? "—";
                        break;
                    }
                }
            }
        }

        if ($banData === null) return;

        $this->pendingNotify[] = ["name" => $player->getName(), "time" => time()];
        $player->kick($this->plugin->getKickMessageForBan($banData, $banKind));
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $this->plugin->getBanManager()->setBannedOnline($event->getPlayer(), false);
    }

    public function flushPending(): void {
        if (empty($this->pendingNotify)) return;
        foreach ($this->pendingNotify as $entry) {
            $timeStr = $this->plugin->getBanManager()->formatTimestamp($entry["time"]);
            $this->plugin->notifyStaff($this->plugin->msg("notify_staff_join", [
                "target" => $entry["name"],
                "time" => $timeStr,
            ]));
        }
        $this->pendingNotify = [];
    }

    public function onMove(PlayerMoveEvent $event): void {
        if ($this->plugin->getBanManager()->isBanned($event->getPlayer())) {
            $event->cancel();
        }
    }

    public function onChat(PlayerChatEvent $event): void {
        if ($this->plugin->getBanManager()->isBanned($event->getPlayer())) {
            $event->cancel();
        }
    }

    public function onInteract(PlayerInteractEvent $event): void {
        if ($this->plugin->getBanManager()->isBanned($event->getPlayer())) {
            $event->cancel();
        }
    }

    public function onBreak(BlockBreakEvent $event): void {
        if ($this->plugin->getBanManager()->isBanned($event->getPlayer())) {
            $event->cancel();
        }
    }

    public function onPlace(BlockPlaceEvent $event): void {
        if ($this->plugin->getBanManager()->isBanned($event->getPlayer())) {
            $event->cancel();
        }
    }

    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof Player && $this->plugin->getBanManager()->isBanned($entity)) {
            $event->cancel();
            return;
        }
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player && $this->plugin->getBanManager()->isBanned($damager)) {
                $event->cancel();
            }
        }
    }
}