<?php

declare(strict_types=1);

namespace InzeOwr\RcAuth;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerQuitEvent;

class EventListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $nick = strtolower($player->getName());
        $ip = $player->getNetworkSession()->getIp();

        if ($this->plugin->getBans()->exists($ip)) {
            $unbanTime = $this->plugin->getBans()->get($ip);
            if (time() < $unbanTime) {
                $wait = $unbanTime - time();
                $player->kick("§l§c | Вы заблокированы за подбор пароля\n§l§7 | Попробуйте снова через §e" . $wait . " §7сек");
                return;
            } else {
                $this->plugin->getBans()->remove($ip);
                $this->plugin->getBans()->save();
            }
        }

        $this->plugin->getAuthManager()->setLoginAttempts($nick, 3);
        $this->plugin->getAuthManager()->startAuthTimer($player);

        $player->sendMessage("§l§f | Добро пожаловать, §e" . $player->getName());

        if (!$this->plugin->getDb()->exists($nick)) {
            $this->plugin->getFormFactory()->sendRegisterForm($player);
        } else {
            $data = $this->plugin->getDb()->get($nick);
            if ($this->plugin->getAuthManager()->isIpAuthEnabled($player) && $data["ip"] === $ip) {
                $this->plugin->getAuthManager()->setAuthenticated($player, true);
                $this->plugin->getAuthManager()->cancelAuthTimer($nick);
                $this->plugin->addLog($nick, "Вход выполнен по IP", $ip);
                $player->sendMessage("§l§a | Авторизация успешна. Приятной игры");
            } else {
                $this->plugin->getFormFactory()->sendLoginForm($player);
            }
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $this->plugin->getAuthManager()->cleanupPlayer($event->getPlayer());
    }

    public function onMove(PlayerMoveEvent $event): void {
        if (!$this->plugin->getAuthManager()->isAuthenticated($event->getPlayer())) {
            $event->cancel();
        }
    }

    public function onChat(PlayerChatEvent $event): void {
        if (!$this->plugin->getAuthManager()->isAuthenticated($event->getPlayer())) {
            $event->cancel();
        }
    }
}
