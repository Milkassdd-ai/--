<?php

namespace InzeOwr\RcOrg\systems;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use onebone\economyapi\EconomyAPI;
use InzeOwr\RcDoxc\Main as RcDoxc;
use InzeOwr\RcOrg\Main;

class FineSystem {

    private Main $plugin;
    private Config $fines;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->fines = new Config($plugin->getDataFolder() . "fines.json", Config::JSON);
    }

    public function issueFine(Player $officer, string $targetName, int $amount, string $reason): void {
        if ($this->plugin->getImmunitySystem()->hasImmunity($targetName)) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fУ гражданина статус неприкосновенности!");
            return;
        }
        
        $tOrg = $this->plugin->getPlayerOrg($targetName);
        $tRank = $this->plugin->getPlayerRank($targetName);
        if ($tOrg !== null && $tOrg !== "MF" && $tRank >= 15) {
             $officer->sendMessage("§c§l[Ошибка] §r§l§fЗапрещено штрафовать руководство гос. структур.");
             return;
        }

        $key = strtolower($targetName);
        $id = uniqid();
        $officerOrg = $this->plugin->getPlayerOrg($officer->getName());
        $officerRankName = $this->plugin->getRankName($officerOrg, $this->plugin->getPlayerRank($officer->getName()));
        $orgName = $this->plugin->getOrgName($officerOrg);
        $color = $this->plugin->getOrgColor($officerOrg);
        $coloredOrg = $this->plugin->getColoredOrgName($officerOrg);

        $fineData = [
            "id" => $id,
            "target" => $targetName,
            "officer" => $officer->getName(),
            "officer_info" => "{$officerRankName} ({$orgName})",
            "amount" => $amount,
            "reason" => $reason,
            "date" => time(),
            "status" => "active"
        ];

        $playerFines = $this->fines->get($key, []);
        $playerFines[$id] = $fineData;
        $this->fines->set($key, $playerFines);
        $this->fines->save();

        $amountStr = number_format($amount);

        $officer->sendMessage("§a§l[Штрафы] §r§l§fШтраф на сумму §e{$amountStr}\$ §fуспешно выписан гражданину §e{$targetName}§f.");
        $officer->sendMessage("§l§7Причина: {$reason}");
        
        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target) {
            $target->sendMessage("§c§l[Штрафы] §r§l§fВам выписан штраф на сумму §e{$amountStr}\$§f.");
            $target->sendMessage("§l§fСотрудник: §e{$officerRankName} {$officer->getName()} §7({$coloredOrg}§7)");
            $target->sendMessage("§l§fПричина: §e{$reason}");
            $target->sendMessage("§l§7Оплатите штраф в течение 3 суток через НПС оплаты штрафов!");
        }

        $msg = "§l§{$color}[{$orgName}] §r§l§f{$officerRankName} {$officer->getName()} выписал штраф гражданину §e{$targetName}§f на сумму §e{$amountStr}\$§f. Причина: {$reason}";
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $pOrg = $this->plugin->getPlayerOrg($p->getName());
            if ($pOrg === $officerOrg && $p->getName() !== $officer->getName()) {
                $p->sendMessage($msg);
            }
        }

        $this->plugin->addLog($officerOrg, "Сотрудник {$officer->getName()} выписал штраф {$targetName} на {$amountStr}\$. Причина: {$reason}");
    }

    public function hasFines(string $targetName): bool {
        $fines = $this->fines->get(strtolower($targetName), []);
        if (!is_array($fines)) return false;
        foreach ($fines as $fine) {
            if (isset($fine['status']) && $fine['status'] === 'active') return true;
        }
        return false;
    }

    public function checkExpiredFines(): void {
        $allFines = $this->fines->getAll();
        $changed = false;
        foreach ($allFines as $name => $fines) {
            if (!is_array($fines)) continue;
            foreach ($fines as $id => $data) {
                if (!isset($data['status']) || $data['status'] !== 'active') continue;
                if ((time() - $data['date']) > 259200) {
                    $doxc = Server::getInstance()->getPluginManager()->getPlugin("RcDoxc");
                    if ($doxc instanceof RcDoxc && $doxc->isEnabled()) {
                        $doxc->getDataManager()->removeData($name, 'lic_drive');
                        $doxc->getDataManager()->removeData($name, 'lic_weapon');
                    }
                    
                    $target = Server::getInstance()->getPlayerExact($name);
                    if ($target) {
                        $amountStr = number_format($data['amount']);
                        $target->sendMessage("§c§l[Штрафы] §r§l§fСрок оплаты штрафа на сумму §e{$amountStr}\$ §fистёк!");
                        $target->sendMessage("§l§7Ваши лицензии изъяты. Причина штрафа: {$data['reason']}");
                    }
                    
                    unset($allFines[$name][$id]);
                    $changed = true;
                }
            }
            if (empty($allFines[$name])) unset($allFines[$name]);
        }
        if ($changed) {
            $this->fines->setAll($allFines);
            $this->fines->save();
        }
    }

    public function openFineMenu(Player $player): void {
        $online = [];
        foreach(Server::getInstance()->getOnlinePlayers() as $p) {
            if ($p->getName() !== $player->getName()) {
                $online[] = $p->getName();
            }
        }

        if (empty($online)) {
            $player->sendMessage("§c§l[Штрафы] §r§l§fНа сервере нет других игроков для выдачи штрафа.");
            return;
        }

        $form = new CustomForm(function (Player $player, $data) use ($online) {
            if ($data === null) return;
            $targetIndex = (int)($data[0] ?? 0);
            $reason = trim($data[1] ?? "");
            $amount = (int)($data[2] ?? 0);

            if (!isset($online[$targetIndex])) return;
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину штрафа.");
                return;
            }
            if ($amount <= 0) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fСумма штрафа должна быть больше 0.");
                return;
            }
            if ($amount > 1000000) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fМаксимальная сумма штрафа: 1 000 000\$.");
                return;
            }

            $targetName = $online[$targetIndex];
            $this->issueFine($player, $targetName, $amount, $reason);
        });

        $form->setTitle("§l§bВЫДАЧА ШТРАФА");
        $form->addDropdown("§l§fВыберите гражданина:", $online);
        $form->addInput("§l§fПричина:", "Нарушение ПДД ст. 3.1");
        $form->addInput("§l§fСумма:", "5000");
        $player->sendForm($form);
    }

    public function openPlayerFines(Player $player): void {
        $key = strtolower($player->getName());
        $fines = $this->fines->get($key, []);

        if (!is_array($fines) || empty($fines)) {
            $player->sendMessage("§a§l[Штрафы] §r§l§fУ вас нет неоплаченных штрафов. Ваша репутация чиста.");
            return;
        }

        $activeFines = [];
        foreach ($fines as $id => $fine) {
            if (isset($fine['status']) && $fine['status'] === 'active') {
                $activeFines[$id] = $fine;
            }
        }

        if (empty($activeFines)) {
            $player->sendMessage("§a§l[Штрафы] §r§l§fУ вас нет неоплаченных штрафов.");
            return;
        }

        $ids = array_keys($activeFines);
        $finesList = array_values($activeFines);

        $form = new SimpleForm(function (Player $player, $data) use ($ids, $finesList) {
            if ($data === null) return;
            if (!isset($ids[$data])) return;
            
            $id = $ids[$data];
            $this->openPayFineForm($player, $id, $finesList[$data]);
        });

        $totalAmount = 0;
        foreach ($activeFines as $f) {
            $totalAmount += $f['amount'];
        }

        $form->setTitle("§l§cВАШИ ШТРАФЫ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВсего штрафов: §e" . count($activeFines) . "\n" .
            "§l§fОбщая сумма: §e" . number_format($totalAmount) . "\$\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($finesList as $fine) {
            $amountStr = number_format($fine['amount']);
            $form->addButton("§l§cШтраф: {$amountStr}\$\n§r§l§7От: {$fine['officer_info']}");
        }
        $player->sendForm($form);
    }

    public function openPayFineForm(Player $player, string $id, array $data): void {
        $form = new SimpleForm(function (Player $player, $dataRes) use ($id, $data) {
            if ($dataRes === null) return;

            if ($dataRes === 0) {
                $money = EconomyAPI::getInstance()->myMoney($player);
                if ($money < $data['amount']) {
                    $amountStr = number_format($data['amount']);
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно средств. Требуется: §e{$amountStr}\$");
                    return;
                }
                EconomyAPI::getInstance()->reduceMoney($player, $data['amount']);
                
                $key = strtolower($player->getName());
                $all = $this->fines->get($key, []);
                unset($all[$id]);
                if (empty($all)) {
                    $this->fines->remove($key);
                } else {
                    $this->fines->set($key, $all);
                }
                $this->fines->save();
                
                $amountStr = number_format($data['amount']);
                $player->sendMessage("§a§l[Штрафы] §r§l§fШтраф на сумму §e{$amountStr}\$ §fуспешно оплачен.");

                $officerPlayer = Server::getInstance()->getPlayerExact($data['officer']);
                if ($officerPlayer) {
                    $officerPlayer->sendMessage("§a§l[Штрафы] §r§l§fГражданин §e{$player->getName()} §fоплатил ваш штраф на сумму §e{$amountStr}\$§f.");
                }

            } elseif ($dataRes === 1) {
                $amountStr = number_format($data['amount']);
                $this->plugin->getWantedSystem()->addStars($player->getName(), 3, "Отказ от уплаты штрафа ({$amountStr}\$)");
                $player->sendMessage("§c§l[ВНИМАНИЕ] §r§l§fВы отказались от уплаты штрафа! Вам объявлен розыск (3 звезды).");
                $player->sendMessage("§l§7Штраф при этом НЕ аннулирован.");
            }
        });

        $expires = 259200 - (time() - $data['date']);
        $hours = max(0, floor($expires / 3600));
        $minutes = max(0, floor(($expires % 3600) / 60));
        $amountStr = number_format($data['amount']);

        $form->setTitle("§l§cОПЛАТА ШТРАФА");
        $content = "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fСотрудник: §e{$data['officer_info']}\n";
        $content .= "§l§fПричина: §b{$data['reason']}\n";
        $content .= "§l§fСумма: §e{$amountStr}\$\n";
        $content .= "§l§fДата выдачи: §7" . date("d.m.Y H:i", $data['date']) . "\n";
        $content .= "§l§fОсталось времени: §c{$hours} ч. {$minutes} мин.\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§7При отказе — объявление в розыск (3 звезды).\n";
        $content .= "§l§7При истечении срока — изъятие лицензий.\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
        
        $form->setContent($content);
        $form->addButton("§l§aОПЛАТИТЬ §e{$amountStr}\$");
        $form->addButton("§l§cОТКАЗАТЬСЯ §7(Розыск 3★)");
        $form->addButton("§l§fЗакрыть");
        $player->sendForm($form);
    }
}