<?php

namespace InzeOwr\RcOrg;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;
use pocketmine\world\Position;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\math\Vector3;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\Server;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\ClosureTask;
use onebone\economyapi\EconomyAPI;

use InzeOwr\RcDoxc\Main as RcDoxc;
use InzeOwr\RcGroup\Main as RcGroup;
use InzeOwr\RcOrg\entities\OrgNPC;
use InzeOwr\RcOrg\entities\JailNPC;
use InzeOwr\RcOrg\entities\CourtNPC;
use InzeOwr\RcOrg\entities\LawsuitNPC;
use InzeOwr\RcOrg\entities\FineNPC;
use InzeOwr\RcOrg\forms\Forms;
use InzeOwr\RcOrg\forms\JailForms;
use InzeOwr\RcOrg\forms\FNSForms;
use InzeOwr\RcOrg\forms\MafiaForms;
use InzeOwr\RcOrg\forms\ProsecutorForms;
use InzeOwr\RcOrg\forms\TreasuryForms;
use InzeOwr\RcOrg\systems\CourtSystem;
use InzeOwr\RcOrg\systems\CuffSystem;
use InzeOwr\RcOrg\systems\FineSystem;
use InzeOwr\RcOrg\systems\FNSSystem;
use InzeOwr\RcOrg\systems\ImmunitySystem;
use InzeOwr\RcOrg\systems\ItemManager;
use InzeOwr\RcOrg\systems\MafiaSystem;
use InzeOwr\RcOrg\systems\ProsecutorSystem;
use InzeOwr\RcOrg\systems\TreasurySystem;
use InzeOwr\RcOrg\systems\WantedSystem;
use InzeOwr\RcOrg\tasks\TickTask;

class Main extends PluginBase implements Listener {

    public Config $data;
    public Config $blacklist;
    public Config $logs;
    public Config $orgData;
    private Config $extraConfig;
    private Config $coordConfig;
    public Config $jailData;
    private Config $healData;

    private CourtSystem $courtSystem;
    private ProsecutorSystem $prosecutorSystem;
    private FineSystem $fineSystem;
    private WantedSystem $wantedSystem;
    private ImmunitySystem $immunitySystem;
    private FNSSystem $fnsSystem;
    private ItemManager $itemManager;
    private CuffSystem $cuffSystem;
    private MafiaSystem $mafiaSystem;
    private TreasurySystem $treasurySystem;

    private static $instance;

    private array $cuffed = [];
    public array $jailTimers = [];
    private array $healingPlayers = [];

    public const HIDDEN_ORG = "AP";
    public const WANTED_VIEW_ORGS = ["FSB", "MVD", "GP", "GS", "PV"];

    public function onEnable(): void {
        self::$instance = $this;
        $this->saveDefaultConfig();

        @mkdir($this->getDataFolder());

        $this->data = new Config($this->getDataFolder() . "players.json", Config::JSON);
        $this->blacklist = new Config($this->getDataFolder() . "blacklist.json", Config::JSON);
        $this->logs = new Config($this->getDataFolder() . "org_logs.json", Config::JSON);
        $this->orgData = new Config($this->getDataFolder() . "org_data.json", Config::JSON);
        $this->jailData = new Config($this->getDataFolder() . "jail_data.json", Config::JSON);
        $this->healData = new Config($this->getDataFolder() . "hospital_data.json", Config::JSON);

        
        $this->courtSystem = new CourtSystem($this);
        $this->prosecutorSystem = new ProsecutorSystem($this);
        $this->fineSystem = new FineSystem($this);
        $this->wantedSystem = new WantedSystem($this);
        $this->immunitySystem = new ImmunitySystem($this);
        $this->fnsSystem = new FNSSystem($this);
        $this->itemManager = new ItemManager($this);
        $this->cuffSystem = new CuffSystem($this);
        $this->mafiaSystem = new MafiaSystem($this);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->treasurySystem = new TreasurySystem($this);

        EntityFactory::getInstance()->register(OrgNPC::class, function(World $world, CompoundTag $nbt): OrgNPC {
            return new OrgNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['RcOrgNPC']);

        EntityFactory::getInstance()->register(JailNPC::class, function(World $world, CompoundTag $nbt): JailNPC {
            return new JailNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['RcJailNPC']);

        EntityFactory::getInstance()->register(CourtNPC::class, function(World $world, CompoundTag $nbt): CourtNPC {
            return new CourtNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['RcCourtNPC']);

        EntityFactory::getInstance()->register(LawsuitNPC::class, function(World $world, CompoundTag $nbt): LawsuitNPC {
            return new LawsuitNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['RcLawsuitNPC']);

        EntityFactory::getInstance()->register(FineNPC::class, function(World $world, CompoundTag $nbt): FineNPC {
            return new FineNPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['RcFineNPC']);

        date_default_timezone_set('Europe/Moscow');

        $this->saveResource("config_extra.yml", false);
        $this->extraConfig = new Config($this->getDataFolder() . "config_extra.yml", Config::YAML);

        $this->saveResource("coordinates.yml", false);
        $this->coordConfig = new Config($this->getDataFolder() . "coordinates.yml", Config::YAML);

        $this->loadJailData();
        $this->loadHealData();

        $this->getScheduler()->scheduleRepeatingTask(new TickTask($this), 20);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->fineSystem->checkExpiredFines();
        }), 12000);
    }

    public static function getInstance(): Main {
        return self::$instance;
    }

    public function getExtraConfig(): Config {
        return $this->extraConfig;
    }

    public function getCoordConfig(): Config {
        return $this->coordConfig;
    }

    public function getCourtSystem(): CourtSystem {
        return $this->courtSystem;
    }

    public function getProsecutorSystem(): ProsecutorSystem {
        return $this->prosecutorSystem;
    }

    public function getFineSystem(): FineSystem {
        return $this->fineSystem;
    }

    public function getWantedSystem(): WantedSystem {
        return $this->wantedSystem;
    }

    public function getImmunitySystem(): ImmunitySystem {
        return $this->immunitySystem;
    }

    public function getFNSSystem(): FNSSystem {
        return $this->fnsSystem;
    }

    public function getItemManager(): ItemManager {
        return $this->itemManager;
    }
public function getCuffSystem(): CuffSystem {
    return $this->cuffSystem;
}

public function getMafiaSystem(): MafiaSystem {
    return $this->mafiaSystem;
}
public function getTreasurySystem(): TreasurySystem {
    return $this->treasurySystem;
}
    public function getOrgName(string $orgKey): string {
        $orgs = $this->getConfig()->get("orgs", []);
        return $orgs[$orgKey] ?? $orgKey;
    }

    public function getRealRankName(string $playerName): string {
        $org = $this->getPlayerOrg($playerName);
        if ($org === null) return "Гражданин";
        $rank = $this->getPlayerRank($playerName);
        return $this->getRankName($org, $rank);
    }

    public function getDisplayRank(string $playerName): int {
        $rank = $this->getPlayerRank($playerName);
        return $rank > 100 ? $rank - 100 : $rank;
    }

    public function getRankName(string $org, int $rank): string {
        if ($org === "PV" && $rank > 100) {
            return "§e" . $this->fnsSystem->getFNSRankName($rank - 100) . "§f";
        }
        return $this->getConfig()->get("ranks")[$org][$rank] ?? "Сотрудник";
    }

    public function getOrgColor(string $key, int $rank = 0): string {
        if ($key === "PV" && $rank > 100) return "e";
        return $this->getConfig()->get("colors")[$key] ?? "f";
    }

    public function getColoredOrgName(string $orgKey): string {
        $color = $this->getOrgColor($orgKey);
        $name = $this->getOrgName($orgKey);
        return "§{$color}{$name}";
    }

    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $msg = $event->getMessage();
        $firstChar = mb_substr($msg, 0, 1);

        if ($firstChar === '!') {
            $event->cancel();
            $orgKey = $this->getPlayerOrg($player->getName());
            if ($orgKey === null) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fРация доступна только сотрудникам организаций.");
                return;
            }
            $rank = $this->getPlayerRank($player->getName());
            $rankName = $this->getRankName($orgKey, $rank);
            $color = $this->getOrgColor($orgKey, $rank);
            $cleanMsg = trim(mb_substr($msg, 1));
            if (empty($cleanMsg)) return;
            $format = "§f[R] §l§{$color}{$rankName} {$player->getName()} §r§f»»» {$cleanMsg}";
            foreach ($this->getServer()->getOnlinePlayers() as $p) {
                if ($this->getPlayerOrg($p->getName()) === $orgKey) $p->sendMessage($format);
            }
            $this->getLogger()->info("[OrgChat-$orgKey] " . $player->getName() . ": " . $cleanMsg);
            return;
        }

        if ($firstChar === '*') {
            $event->cancel();
            $orgKey = $this->getPlayerOrg($player->getName());
            if ($orgKey === null) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fВы не можете использовать волну департамента.");
                return;
            }
            if ($orgKey === "MF") {
                $player->sendMessage("§c§l[Ошибка] §r§l§fДоступ к закрытому каналу связи заблокирован.");
                return;
            }
            $rank = $this->getPlayerRank($player->getName());
            if ($rank < 4) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fДоступ к рации департамента разрешен с 4-го ранга.");
                return;
            }
            $cleanMsg = trim(mb_substr($msg, 1));
            if (empty($cleanMsg)) return;

            $rankName = $this->getRankName($orgKey, $rank);
            $orgName = $this->getOrgName($orgKey);
            $color = $this->getOrgColor($orgKey, $rank);

            $format = "§c[D] [{$orgName}] §{$color}{$rankName} §c{$player->getName()}: §f{$cleanMsg}";
            foreach ($this->getServer()->getOnlinePlayers() as $p) {
                $pOrg = $this->getPlayerOrg($p->getName());
                if ($pOrg !== null && $pOrg !== "MF") $p->sendMessage($format);
            }
            $this->getLogger()->info("[DeptChat] " . $player->getName() . ": " . $cleanMsg);
            return;
        }
    }

    public function getFio(string $player): string {
        $doxc = $this->getServer()->getPluginManager()->getPlugin("RcDoxc");
        if ($doxc instanceof RcDoxc && $doxc->isEnabled()) {
            $passport = $doxc->getDataManager()->getData($player, 'passport');
            if ($passport && isset($passport['fio'])) return $passport['fio'];
        }
        return "Гражданин (Нет данных)";
    }

    public function setOrgMessage(string $org, string $msg): void {
        $this->orgData->setNested("$org.message", $msg);
        $this->orgData->save();
    }

    public function getOrgMessage(string $org): string {
        return $this->orgData->getNested("$org.message", "§7Официальных объявлений от руководства на данный момент не поступало.");
    }

    public function setLeaderInfo(string $org, string $nick, string $fio): void {
        $this->orgData->setNested("$org.leader", ["nick" => $nick, "fio" => $fio, "date" => date("d.m.Y")]);
        $this->orgData->save();
    }

    public function getLeaderInfo(string $org): array {
        return $this->orgData->getNested("$org.leader", ["nick" => "Отсутствует", "fio" => "Должность вакантна", "date" => "-"]);
    }

    public function collectSalary(Player $player): void {
        $name = strtolower($player->getName());
        $org = $this->getPlayerOrg($name);
        if (!$org) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fВы не трудоустроены официально.");
            return;
        }

        $rank = $this->getPlayerRank($name);
        if ($rank > 100) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fСотрудники ФНС получают зарплату через личное дело ФНС.");
            return;
        }

        $lastTime = $this->data->getNested("$name.last_salary", 0);
        $time = time();

        if (($time - $lastTime) < 900) {
            $rem = 900 - ($time - $lastTime);
            $min = floor($rem / 60);
            $sec = $rem % 60;
            $player->sendMessage("§c§l[Бухгалтерия] §r§l§fВыплата жалования будет доступна через: §e{$min} мин. {$sec} сек.");
            return;
        }

        $salaries = $this->getConfig()->get("salary_amount", []);
        $amount = $salaries[$rank] ?? 2000;

        EconomyAPI::getInstance()->addMoney($player, $amount);
        $this->data->setNested("$name.last_salary", $time);
        $this->data->save();
        $coloredOrg = $this->getColoredOrgName($org);
        $player->sendMessage("§a§l[Бухгалтерия] §r§l§fНа ваш счет ({$coloredOrg}§f) поступила заработная плата в размере: §e" . number_format($amount) . "\$");
    }

    public function buyRank(Player $player): void {
        $name = strtolower($player->getName());
        $org = $this->getPlayerOrg($name);
        if ($org === null) return;
        $rank = $this->getPlayerRank($name);

        if ($rank > 100) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fСотрудники ФНС не могут покупать ранги. Ожидайте повышения от руководства.");
            return;
        }

        $buyEnabled = $this->orgData->getNested("$org.buy_enabled", true);
        if (!$buyEnabled) {
            $player->sendMessage("§c§l[Повышение] §r§l§fРуководитель запретил повышение за деньги в этой организации.");
            return;
        }

        $maxBuyRank = (int)$this->orgData->getNested("$org.max_buy_rank", 15);
        if ($rank >= $maxBuyRank) {
            $player->sendMessage("§c§l[Повышение] §r§l§fВы достигли максимального ранга для покупки (§e{$maxBuyRank}§f).");
            return;
        }
$nextRank = $rank + 1;
    if ($nextRank >= 16) {
        $player->sendMessage("§c§l[Кадры] §r§l§fДолжность Руководителя (16 ранг) не продается.");
        return;
    }

    $costs = $this->getConfig()->get("rank_costs");
    if (!isset($costs[$nextRank])) {
        $player->sendMessage("§c§l[Ошибка] §r§l§fСтоимость повышения не установлена.");
        return;
    }

    $price = $costs[$nextRank];
    $money = EconomyAPI::getInstance()->myMoney($player);
    if ($money < $price) {
        $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно средств на счете. Требуется: §e" . number_format($price) . "\$");
        return;
    }

    EconomyAPI::getInstance()->reduceMoney($player, $price);
    $this->setPlayerOrg($player->getName(), $org, $nextRank);
    $coloredOrg = $this->getColoredOrgName($org);
    $newRankName = $this->getRankName($org, $nextRank);
    $this->addLog($org, "§c§l{$player->getName()} §6§lоплатил курсы повышения до §e§l{$newRankName} ({$nextRank})");
    $player->sendMessage("§a§l[Кадры] §r§l§fПоздравляем! Вы успешно повышены до должности: §e{$newRankName} §fв {$coloredOrg}");
}

    public function getPlayerOrg(string $playerName): ?string {
        return $this->data->getNested(strtolower($playerName) . ".org", null);
    }

    public function getPlayerRank(string $playerName): int {
        return (int)$this->data->getNested(strtolower($playerName) . ".rank", 0);
    }

    public function getJoinDate(string $playerName): string {
        return $this->data->getNested(strtolower($playerName) . ".join_date", "Неизвестно");
    }

    public function setPlayerOrg(string $playerName, ?string $newOrg, int $newRank = 1, bool $useHistory = false, bool $saveHistory = true): void {
        $currentOrg = $this->getPlayerOrg($playerName);

        if ($currentOrg !== null && $this->prosecutorSystem->isFrozen($currentOrg) && $newOrg !== null) {
            $p = $this->getServer()->getPlayerExact($playerName);
            if ($p) $p->sendMessage("§c§l[" . $this->getColoredOrgName("GP") . "§c§l] §r§l§fКадровые перестановки заморожены.");
            return;
        }

        $key = strtolower($playerName);
        $currentRank = $this->getPlayerRank($playerName);

        if ($currentOrg === "PV" && $newOrg !== "PV" && $currentRank > 100) {
            $this->fnsSystem->clearData($playerName);
        }

        if ($newOrg === null) {
            $this->data->removeNested("$key.org");
            $this->data->removeNested("$key.rank");
            $this->data->removeNested("$key.join_date");

            if ($currentOrg !== null && $saveHistory) {
                if ($currentRank > 100) {
                    $histRank = $this->fnsSystem->getSavedPVRank($playerName);
                    if ($histRank <= 0) $histRank = 5;
                    $this->data->setNested("$key.history.$currentOrg", $histRank);
                } else {
                    $this->data->setNested("$key.history.$currentOrg", $currentRank);
                }
            }

            if ($currentOrg !== null && !$saveHistory) {
                $this->data->removeNested("$key.history.$currentOrg");
            }
        } else {
            if ($currentOrg !== null && $currentOrg !== $newOrg && $currentRank < 16) {
                $histRank = $currentRank > 100 ? $this->fnsSystem->getSavedPVRank($playerName) : $currentRank;
                if ($histRank <= 0 && $currentRank > 100) $histRank = 5;
                $this->data->setNested("$key.history.$currentOrg", $histRank);
            }
            $finalRank = $newRank;
            if ($useHistory && $newRank === 1) {
                $savedRank = $this->data->getNested("$key.history.$newOrg", 0);
                if ($savedRank > 0) $finalRank = $savedRank;
            }
            $this->data->setNested("$key.org", $newOrg);
            $this->data->setNested("$key.rank", $finalRank);
            $this->data->setNested("$key.real_name", $playerName);
            if ($currentOrg !== $newOrg) $this->data->setNested("$key.join_date", date("d.m.y H:i"));
        }
        $this->data->save();
        $this->updateExternalTag($playerName, $newOrg);
    }

    public function updateExternalTag(string $playerName, ?string $org): void {
        $rcGroup = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroup instanceof RcGroup && $rcGroup->isEnabled()) {
            $tag = "§l(§7Гражданин§f)";
            if ($org !== null) {
                $rank = $this->getPlayerRank($playerName);
                $rankName = $this->getRankName($org, $rank);
                $color = $this->getOrgColor($org, $rank);
                $tag = "§l(§{$color}{$rankName}§f)";
            } else {
                $doxc = $this->getServer()->getPluginManager()->getPlugin("RcDoxc");
                if ($doxc instanceof RcDoxc && $doxc->isEnabled()) {
                    $hasPass = $doxc->getDataManager()->getData($playerName, 'passport');
                    $tag = $hasPass ? "§l(§7Гражданин§f)" : "§l(§7Эмигрант§f)";
                }
            }
            $rcGroup->setOrgTag($playerName, $tag);
        }
    }

    public function addLog(string $org, string $text): void {
    $time = date("d.m.Y H:i:s");
    $allLogs = $this->logs->get($org, []);

    $currentTime = time();
    $twoDaysAgo = $currentTime - (2 * 24 * 60 * 60);

    $filteredLogs = [];
    foreach ($allLogs as $logEntry) {
        if (isset($logEntry['timestamp']) && $logEntry['timestamp'] >= $twoDaysAgo) {
            $filteredLogs[] = $logEntry;
        }
    }

    array_unshift($filteredLogs, [
        'timestamp' => $currentTime,
        'formatted_time' => $time,
        'text' => $text
    ]);

    $this->logs->set($org, $filteredLogs);
    $this->logs->save();
}

public function getLogs(string $org): array {
    $rawLogs = $this->logs->get($org, []);
    $formatted = [];

    foreach ($rawLogs as $log) {
        if (is_array($log)) {
            $formatted[] = "§7[{$log['formatted_time']}] {$log['text']}";
        } else {
            $formatted[] = $log;
        }
    }

    return $formatted;
}

    public function addToBlacklist(string $target, string $org, string $admin, string $reason): void {
        $key = strtolower($target);
        if ($this->getPlayerOrg($target) === $org) $this->setPlayerOrg($target, null, 1, false, false);
        $this->blacklist->setNested("$key.$org", ["by" => $admin, "reason" => $reason, "date" => date("d.m.Y H:i")]);
        $this->blacklist->save();

        $coloredOrg = $this->getColoredOrgName($org);

        $p = $this->getServer()->getPlayerExact($target);
        if ($p) {
            $p->sendMessage("§c§l[ЧС] §r§l§fВы были занесены в Черный Список организации {$coloredOrg}§f.");
            $p->sendMessage("§l§7Причина: {$reason} | Сотрудник: {$admin}");
        }
    }

    public function removeFromBlacklist(string $target, string $org): void {
        $key = strtolower($target);
        $this->blacklist->removeNested("$key.$org");
        if (count($this->blacklist->get($key, [])) === 0) $this->blacklist->remove($key);
        $this->blacklist->save();

        $coloredOrg = $this->getColoredOrgName($org);

        $p = $this->getServer()->getPlayerExact($target);
        if ($p) $p->sendMessage("§a§l[ЧС] §r§l§fВы были вынесены из Черного Списка организации {$coloredOrg}§f.");
    }

    public function isBlacklisted(string $target, string $org): bool {
        return $this->blacklist->getNested(strtolower($target) . ".$org") !== null;
    }

    public function getBlacklistInfo(string $target, string $org): ?array {
        return $this->blacklist->getNested(strtolower($target) . ".$org");
    }

    public function processManage(Player $admin, string $myOrg, string $targetName, int $action, string $reason = ""): void {
    $myRank = $this->getPlayerRank($admin->getName());
    $targetOrg = $this->getPlayerOrg($targetName);
    $targetRank = $this->getPlayerRank($targetName);

    if ($targetRank >= 16 && $myRank < 17) {
        $admin->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно полномочий для действий с руководством.");
        return;
    }

    if ($targetRank > 100) {
        $admin->sendMessage("§c§l[Ошибка] §r§l§fЭтот сотрудник состоит в ФНС. Управление им доступно только через меню отделов!");
        return;
    }

    $isGovAction = ($myOrg === "PV" && $myRank >= 13 && $targetOrg !== "PV" && $targetOrg !== "MF");
    if ($targetOrg !== $myOrg && !$isGovAction) {
        $admin->sendMessage("§c§l[Ошибка] §r§l§fГражданин не числится в вашем ведомстве.");
        return;
    }
    if ($isGovAction && $targetRank >= 10) {
        $admin->sendMessage("§c§l[Ошибка] §r§l§f" . $this->getColoredOrgName("PV") . " §fкурирует сотрудников только до 10 порядкового ранга.");
        return;
    }

    $tPlayer = $this->getServer()->getPlayerExact($targetName);
    $coloredOrg = $this->getColoredOrgName($targetOrg ?: $myOrg);
    $adminColoredOrg = $this->getColoredOrgName($myOrg);
    $adminRankName = $this->getRealRankName($admin->getName());

    switch ($action) {
        case 0:
            if ($targetRank >= 15) return;
            if ($isGovAction && ($targetRank + 1) > 10) return;
            $this->setPlayerOrg($targetName, $targetOrg, $targetRank + 1);
            $newRankName = $this->getRealRankName($targetName);
            $newRankNum = $targetRank + 1;
$this->addLog($targetOrg, "§c§l{$admin->getName()} §7§l({$adminRankName}§7§l) §6§lповысил §b§l{$targetName} §6§lдо §e§l{$newRankName} ({$newRankNum})");
            $admin->sendMessage("§a§l[Кадры] §r§l§fСотрудник §e{$targetName} §fуспешно повышен до {$newRankName} §fв {$coloredOrg}§f.");
            if ($tPlayer) {
                $tPlayer->sendMessage("§a§l[Кадры] §r§l§fВы были повышены до {$newRankName} §fв {$coloredOrg}§f.");
                $tPlayer->sendMessage("§l§7Руководитель: {$adminRankName} §7{$admin->getName()} ({$adminColoredOrg}§7)");
            }
            break;
        case 1:
            if ($targetRank <= 1) return;
            $this->setPlayerOrg($targetName, $targetOrg, $targetRank - 1);
            $newRankName = $this->getRealRankName($targetName);
            $newRankNum = $targetRank - 1;
$this->addLog($targetOrg, "§c§l{$admin->getName()} §7§l({$adminRankName}§7§l) §6§lпонизил §b§l{$targetName} §6§lдо §e§l{$newRankName} ({$newRankNum})");
            $admin->sendMessage("§a§l[Кадры] §r§l§fСотрудник §e{$targetName} §fуспешно понижен до {$newRankName} §fв {$coloredOrg}§f.");
            if ($tPlayer) {
                $tPlayer->sendMessage("§c§l[Кадры] §r§l§fВы были понижены до {$newRankName} §fв {$coloredOrg}§f.");
                $tPlayer->sendMessage("§l§7Руководитель: {$adminRankName} §7{$admin->getName()} ({$adminColoredOrg}§7)");
            }
            break;
        case 2:
            $oldRankName = $this->getRealRankName($targetName);
            $this->setPlayerOrg($targetName, null, 1, false, false);

            if ($targetOrg) {
                $key = strtolower($targetName);
                $this->data->removeNested("$key.history.$targetOrg");
                $this->data->save();
            }

            $this->addLog($targetOrg, "§c§l{$admin->getName()} §7§l({$adminRankName}§7§l) §6§lуволил §b§l{$targetName} §6§l({$oldRankName}§6§l)");
            $admin->sendMessage("§c§l[Кадры] §r§l§fСотрудник §e{$targetName} §f({$oldRankName}§f) уволен из {$coloredOrg}§f.");
            if ($tPlayer) {
                $tPlayer->sendMessage("§c§l[Кадры] §r§l§fВы были уволены из {$coloredOrg}§f.");
                $tPlayer->sendMessage("§l§7Ваша должность: {$oldRankName}");
                $tPlayer->sendMessage("§l§7Руководитель: {$adminRankName} §7{$admin->getName()} ({$adminColoredOrg}§7)");
            }
            break;
        case 3:
            $this->addToBlacklist($targetName, $targetOrg ?: $myOrg, $admin->getName(), $reason);
            $this->addLog($targetOrg ?: $myOrg, "§c§l{$admin->getName()} §7§l({$adminRankName}§7§l) §6§lзанёс §b§l{$targetName} §6§lв ЧС. Причина: §e§l{$reason}");
            $admin->sendMessage("§c§l[Кадры] §r§l§fГражданин §e{$targetName} §fзанесен в Черный Список {$coloredOrg}§f.");
            break;
    }
}

    public function tryJoin(Player $player, string $orgKey): void {
    $coloredOrg = $this->getColoredOrgName($orgKey);

    if ($this->prosecutorSystem->isFrozen($orgKey)) {
        $player->sendMessage("§c§l[Отказ] §r§l§fВ данный момент в {$coloredOrg} §fпроходит прокурорская проверка. Набор приостановлен.");
        return;
    }

    if ($orgKey !== "MF" && $this->courtSystem->hasCriminalRecord($player->getName())) {
        $player->sendMessage("§c§l[Отказ] §r§l§fВам отказано в трудоустройстве в {$coloredOrg}§f. У вас имеется непогашенная судимость.");
        return;
    }

    if ($this->isBlacklisted($player->getName(), $orgKey)) {
        $info = $this->getBlacklistInfo($player->getName(), $orgKey);
        $player->sendMessage("§c§l[Отказ] §r§l§fВы находитесь в Черном Списке {$coloredOrg}§f!");
        $player->sendMessage("§l§7Причина: {$info['reason']} (от {$info['by']})");
        return;
    }

    $currentOrg = $this->getPlayerOrg($player->getName());
    $currentRank = $this->getPlayerRank($player->getName());
    if ($currentOrg !== null && $currentRank >= 16 && $currentRank <= 100) {
        $player->sendMessage("§c§l[Ошибка] §r§l§fРуководящий состав не может менять место работы.");
        return;
    }

    $savedRank = $this->data->getNested(strtolower($player->getName()) . ".history.$orgKey", 0);
    if ($savedRank == 0) {
        $cost = $this->getConfig()->get("costs")[$orgKey];
        $money = EconomyAPI::getInstance()->myMoney($player);
        if ($money < $cost) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно средств. Стоимость пошлины: " . number_format($cost) . "\$");
            return;
        }
        EconomyAPI::getInstance()->reduceMoney($player, $cost);
    }

    if (!$this->checkDocs($player, 'passport')) {
        $player->sendMessage("§c§l[Отказ] §r§l§fОтсутствует паспорт.");
        return;
    }
    if (!$this->checkDocs($player, 'medcard')) {
        $player->sendMessage("§c§l[Отказ] §r§l§fОтсутствует медицинская карта.");
        return;
    }
    if (($orgKey === "FSB" || $orgKey === "MVD" || $orgKey === "GP") && !$this->checkDocs($player, 'lic_weapon')) {
        $player->sendMessage("§c§l[Отказ] §r§l§fОтсутствует лицензия на оружие.");
        return;
    }

    if ($orgKey === "PV") {
        $hasHistoryPV = ($this->data->getNested(strtolower($player->getName()) . ".history.PV", 0) >= 1);
        if (!$hasHistoryPV && ($currentOrg === null || $currentRank < 6)) {
            $player->sendMessage("§c§l[Отказ] §r§l§fВ " . $this->getColoredOrgName("PV") . " §fтребуется опыт работы в любой организации (6+ ранг).");
            return;
        }
    } elseif ($orgKey === "FSB") {
        $hasHistoryFSB = ($this->data->getNested(strtolower($player->getName()) . ".history.FSB", 0) >= 1);
        if (!$hasHistoryFSB && !((($currentOrg === "ARMI" || $currentOrg === "MVD") && $currentRank >= 5))) {
            $player->sendMessage("§c§l[Отказ] §r§l§fВ " . $this->getColoredOrgName("FSB") . " §fтребуется опыт работы в " . $this->getColoredOrgName("ARMI") . "§f/" . $this->getColoredOrgName("MVD") . " §f(5+ ранг).");
            return;
        }
    }

    $isFirstJoin = ($savedRank == 0 && $currentOrg !== $orgKey);

    $this->setPlayerOrg($player->getName(), $orgKey, 1, true);
    $finalRank = $this->getPlayerRank($player->getName());
    $rankName = $this->getRankName($orgKey, $finalRank);

    if ($isFirstJoin) {
        $this->addLog($orgKey, "§b§l{$player->getName()} §6§lвступил в организацию (§e§l{$rankName} ({$finalRank})§6§l)");
    }

    $player->sendMessage("§a§l[Кадры] §r§l§fВы успешно трудоустроены в {$coloredOrg}§f. Добро пожаловать!");
    $player->sendMessage("§l§7Ваша должность: §e{$rankName} ({$finalRank})");
}

    public function assembleOrg(Player $leader, string $orgKey): void {
        $count = 0;
        $coloredOrg = $this->getColoredOrgName($orgKey);
        $leaderRankName = $this->getRealRankName($leader->getName());
        foreach ($this->getServer()->getOnlinePlayers() as $p) {
            if ($p->getName() === $leader->getName()) continue;
            if ($this->getPlayerOrg($p->getName()) === $orgKey) {
                $p->teleport($leader->getPosition());
                $p->sendMessage("§6§l[Строй] §r§l§f{$leaderRankName} §e{$leader->getName()} §fобъявил всеобщий сбор {$coloredOrg}§f!");
                $count++;
            }
        }
        $leader->sendMessage("§a§l[Рация] §r§l§fВсеобщий строй {$coloredOrg}§f! Прибыло сотрудников: §e$count");
    }

    public function setRankDirect(Player $admin, string $targetName, int $newRank): void {
    if (strtolower($admin->getName()) === strtolower($targetName)) return;
    $org = $this->getPlayerOrg($targetName);
    if (!$org || $newRank >= 16) return;
    $this->setPlayerOrg($targetName, $org, $newRank);
    $coloredOrg = $this->getColoredOrgName($org);
    $rankName = $this->getRankName($org, $newRank);
    $this->addLog($org, "§c§l{$admin->getName()} §6§l(Администратор) назначил §b§l{$targetName} §6§lна §e§l{$rankName} ({$newRank})");
    $admin->sendMessage("§a§l[Система] §r§l§fРанг §e{$rankName} §fуспешно выдан §e{$targetName} §fв {$coloredOrg}§f.");
    $tPlayer = $this->getServer()->getPlayerExact($targetName);
    if ($tPlayer) {
        $tPlayer->sendMessage("§a§l[Система] §r§l§fАдминистратор §e{$admin->getName()} §fназначил вас на должность §e{$rankName} §fв {$coloredOrg}§f.");
    }
}

    public function checkDocs(Player $player, string $type): bool {
        $doxc = $this->getServer()->getPluginManager()->getPlugin("RcDoxc");
        if (!$doxc instanceof RcDoxc || !$doxc->isEnabled()) return true;
        $dm = $doxc->getDataManager();
        $dt = $dm->getData($player->getName(), $type);
        return $dt && (!isset($dt['expiry']) || time() <= $dt['expiry']);
    }

    
    public function hasCriminalRecord(string $playerName): bool {
        return $this->courtSystem->hasCriminalRecord($playerName);
    }
    public function getCriminalRecords(string $playerName): array {
        return $this->courtSystem->getCriminalRecords($playerName);
    }
    public function addCriminalRecord(string $targetName, string $judgeName, string $reason): bool {
        return $this->courtSystem->addCriminalRecord($targetName, $judgeName, $reason);
    }
    public function removeCriminalRecord(string $targetName, int $index): bool {
        return $this->courtSystem->removeCriminalRecord($targetName, $index);
    }
    public function canUseCourtItem(Player $player): bool {
        return $this->courtSystem->canUseCourtItem($player);
    }

    public function handleNpcTouch(Player $player, OrgNPC $npc): void {
        $orgKey = $npc->getOrgTag();
        $curOrg = $this->getPlayerOrg($player->getName());

        $item = $player->getInventory()->getItemInHand();
        if ($this->itemManager->isProsecutorDocuments($item)) {
            if ($orgKey === "MF") {
                $player->sendMessage("§c§l[Ошибка] §r§l§fПроведение проверок в " . $this->getColoredOrgName("MF") . " §fневозможно.");
                return;
            }
            if ($this->itemManager->canUseProsecutorDocuments($player)) {
                ProsecutorForms::openInspectionMenu($player, $orgKey);
                return;
            }
        }

        if ($curOrg === $orgKey) Forms::openOrgMenu($player, $orgKey);
        else Forms::openJoinMenu($player, $orgKey);
    }

    public function cuffPlayer(Player $officer, Player $target): void {
        if ($this->immunitySystem->hasImmunity($target->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fУ гражданина §e{$target->getName()} §fдействует статус неприкосновенности!");
            return;
        }

        $tName = strtolower($target->getName());
        $oName = strtolower($officer->getName());

        if ($this->isCuffed($target->getName())) {
            $cuffOfficer = $this->getOfficer($target->getName());
            if ($cuffOfficer === $oName) {
                $this->uncuffPlayer($target->getName());
                $officer->sendMessage("§e§l[Рация] §r§l§fВы сняли наручники с гражданина §e{$target->getName()}§f. Задержанный отпущен.");
                $target->sendMessage("§a§l[Информация] §r§l§fОфицер §e{$officer->getName()} §fснял с вас наручники. Вы свободны.");
                return;
            } else {
                $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин задержан другим офицером.");
                return;
            }
        }

        if ($this->isJailed($target->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин уже отбывает наказание в изоляторе временного содержания.");
            return;
        }

        $targetOrg = $this->getPlayerOrg($target->getName());
        $targetRank = $this->getPlayerRank($target->getName());
        if ($targetOrg !== null && $targetOrg !== "MF" && $targetRank >= 15 && $targetRank <= 100) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fЗапрещено задерживать высокопоставленных сотрудников. Используйте спецнаручники.");
            return;
        }
        if ($targetOrg === "FSB" || $targetOrg === "MVD") {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fЗапрещено задерживать действующих сотрудников " . $this->getColoredOrgName($targetOrg) . "§f.");
            return;
        }
        if ($oName === $tName) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fВы не можете задержать самого себя.");
            return;
        }
        if ($officer->getPosition()->distance($target->getPosition()) > 5) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fПодозреваемый находится слишком далеко для задержания.");
            return;
        }
        if (count($this->getCuffedByOfficer($officer->getName())) >= 2) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fВы не можете конвоировать более 2 задержанных одновременно.");
            return;
        }
        if ($this->isHealing($target->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин проходит лечение в " . $this->getColoredOrgName("GB") . "§f. Задержание невозможно.");
            return;
        }

        $this->cuffed[$tName] = $oName;

        $officerOrg = $this->getPlayerOrg($officer->getName());
        $rankName = $this->getRealRankName($officer->getName());
        $coloredOrg = $this->getColoredOrgName($officerOrg);

        $target->sendMessage("§c§l ЗАДЕРЖАНИЕ");
        $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $target->sendMessage("§r§l§fВы были задержаны сотрудником ведомства {$coloredOrg}§f.");
        $target->sendMessage("§r§l§fДолжность: {$rankName}");
        $target->sendMessage("§r§l§fОфицер: §e{$officer->getName()}");
        $target->sendMessage("§r§l§7Следуйте за конвоиром. Сопротивление бесполезно.");
        $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        $officer->sendMessage("§a§l[Рация] §r§l§fПодозреваемый §e{$target->getName()} §fуспешно задержан и закован в наручники.");
        $officer->sendMessage("§l§7Доставьте задержанного к терминалу изолятора для оформления.");
    }

    public function handleLeaderCuffs(Player $officer, Player $target): void {
        $tName = strtolower($target->getName());
        $oName = strtolower($officer->getName());

        if ($oName === $tName) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fВы не можете задержать самого себя.");
            return;
        }
        if ($officer->getPosition()->distance($target->getPosition()) > 5) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fПодозреваемый находится слишком далеко.");
            return;
        }

        if ($this->isJailed($target->getName())) {
            JailForms::openLeaderJailMenu($officer, $target->getName());
            return;
        }

        if ($this->isCuffed($target->getName())) {
            $cuffOfficer = $this->getOfficer($target->getName());
            if ($cuffOfficer === $oName) {
                $this->uncuffPlayer($target->getName());
                $officer->sendMessage("§e§l[Рация] §r§l§fВы сняли наручники с §e{$target->getName()}§f.");
                $target->sendMessage("§a§l[Информация] §r§l§fС вас сняты наручники. Вы свободны.");
                return;
            } else {
                $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин задержан другим офицером.");
                return;
            }
        }

        if ($this->isHealing($target->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин проходит лечение. Задержание невозможно.");
            return;
        }
        if (count($this->getCuffedByOfficer($officer->getName())) >= 2) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fВы не можете конвоировать более 2 задержанных одновременно.");
            return;
        }

        $this->cuffed[$tName] = $oName;

        $officerOrg = $this->getPlayerOrg($officer->getName());
        $rankName = $this->getRealRankName($officer->getName());
        $coloredOrg = $this->getColoredOrgName($officerOrg);

        $target->sendMessage("§c§l ЗАДЕРЖАНИЕ (Спецоперация)");
        $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $target->sendMessage("§r§l§fВы были задержаны старшим офицером {$coloredOrg}§f.");
        $target->sendMessage("§r§l§fДолжность: {$rankName}");
        $target->sendMessage("§r§l§fОфицер: §e{$officer->getName()}");
        $target->sendMessage("§r§l§7Следуйте за конвоиром.");
        $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        $officer->sendMessage("§a§l[Рация] §r§l§fПодозреваемый §e{$target->getName()} §fзадержан спецнаручниками.");
        $officer->sendMessage("§l§7Доставьте задержанного к терминалу изолятора.");
    }

    public function uncuffPlayer(string $targetName): void {
        $key = strtolower($targetName);
        if (isset($this->cuffed[$key])) {
            unset($this->cuffed[$key]);
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target !== null) {
                $target->setNoClientPredictions(false);
            }
        }
    }

    public function isCuffed(string $name): bool {
        return isset($this->cuffed[strtolower($name)]);
    }

    public function getOfficer(string $targetName): ?string {
        return $this->cuffed[strtolower($targetName)] ?? null;
    }

    public function getCuffedByOfficer(string $officerName): array {
        $result = [];
        $oName = strtolower($officerName);
        foreach ($this->cuffed as $target => $officer) {
            if ($officer === $oName) $result[] = $target;
        }
        return $result;
    }

    private function loadJailData(): void {
        foreach ($this->jailData->getAll() as $name => $data) {
            if (isset($data['release_time']) && $data['release_time'] > time()) {
                $this->jailTimers[strtolower($name)] = (int)$data['release_time'];
            } else {
                $this->jailData->remove($name);
            }
        }
        $this->jailData->save();
    }

    public function jailPlayer(Player $officer, string $targetName, int $seconds, string $reason): void {
        if ($this->immunitySystem->hasImmunity($targetName)) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fУ гражданина §e{$targetName} §fдействует статус неприкосновенности!");
            return;
        }

        $tKey = strtolower($targetName);

        if ($this->isJailed($targetName)) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин уже отбывает срок в изоляторе временного содержания.");
            return;
        }
        if ($seconds < 60) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fМинимальный срок содержания под стражей — 60 секунд.");
            return;
        }
        $maxTime = $this->getMaxJailTime($officer);
        if ($seconds > $maxTime) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fМаксимальный срок для вашей должности: " . $this->formatTime($maxTime));
            return;
        }
        if (empty(trim($reason))) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать основание для содержания под стражей.");
            return;
        }
        if (!$this->isCuffed($targetName)) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин не находится в ваших наручниках.");
            return;
        }
        $cuffOfficer = $this->getOfficer($targetName);
        if ($cuffOfficer !== strtolower($officer->getName())) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fЭтот гражданин задержан другим офицером.");
            return;
        }

        $targetOrg = $this->getPlayerOrg($targetName);
        $targetRank = $this->getPlayerRank($targetName);
        if ($targetOrg !== null && $targetOrg !== "MF" && $targetRank >= 15 && $targetRank <= 100) {
            if (!$this->itemManager->canUseLeaderCuffs($officer)) {
                $officer->sendMessage("§c§l[Ошибка] §r§l§fДля задержания руководства используйте спецнаручники.");
                $this->uncuffPlayer($targetName);
                return;
            }
        }

        $this->uncuffPlayer($targetName);

        $releaseTime = time() + $seconds;
        $this->jailTimers[$tKey] = $releaseTime;

        $officerOrg = $this->getPlayerOrg($officer->getName());
        $officerRankName = $this->getRealRankName($officer->getName());
        $coloredOfficerOrg = $this->getColoredOrgName($officerOrg);

        $this->jailData->set($tKey, [
            "release_time" => $releaseTime,
            "reason" => $reason,
            "officer" => $officer->getName(),
            "officer_rank" => $officerRankName,
            "officer_org" => $this->getOrgName($officerOrg),
            "date" => date("d.m.Y H:i:s")
        ]);
        $this->jailData->save();

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $this->teleportToJail($target);
            $target->sendMessage("§c§l ПРИГОВОР");
            $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            $target->sendMessage("§r§l§fВы помещены в изолятор временного содержания.");
            $target->sendMessage("§r§l§fСрок: §e" . $this->formatTime($seconds));
            $target->sendMessage("§r§l§fОснование: §e{$reason}");
            $target->sendMessage("§r§l§fОфицер: {$officerRankName} §f{$officer->getName()} §7({$coloredOfficerOrg}§7)");
            $target->sendMessage("§r§l§7Ожидайте окончания срока. Побег невозможен.");
            $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        }

        $officer->sendMessage("§a§l[Рация] §r§l§fГражданин §e{$targetName} §fпомещён в изолятор.");
        $officer->sendMessage("§l§7Срок: " . $this->formatTime($seconds) . " | Основание: {$reason}");

        if ($officerOrg) {
    $this->addLog($officerOrg, "§c§l{$officer->getName()} §6§lпоместил §b§l{$targetName} §6§lв изолятор (§e§l" . $this->formatTime($seconds) . "§6§l). Основание: §e§l{$reason}");
}
    }

    public function releasePlayer(string $name): void {
    $key = strtolower($name);

    $jailInfo = $this->getJailInfo($name);
    if ($jailInfo !== null && isset($jailInfo['nrp_jail']) && $jailInfo['nrp_jail'] === true) {
        return;
    }

    unset($this->jailTimers[$key]);
    $this->jailData->remove($key);
    $this->jailData->save();

    $player = Server::getInstance()->getPlayerExact($name);
    if ($player !== null) {
        $player->setNoClientPredictions(false);
        $this->teleportToRelease($player);
        $player->sendMessage("§a§l ОСВОБОЖДЕНИЕ");
        $player->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $player->sendMessage("§r§l§fВаш срок содержания в изоляторе истёк.");
        $player->sendMessage("§r§l§fВы свободны. Соблюдайте законодательство.");
        $player->sendMessage("§r§l§7При повторном нарушении срок будет увеличен.");
        $player->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }
}

    public function forceReleasePlayer(Player $officer, string $targetName): void {
    if (!$this->isJailed($targetName)) {
        $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин не находится в изоляторе.");
        return;
    }

    $jailInfo = $this->getJailInfo($targetName);
    if ($jailInfo !== null && isset($jailInfo['nrp_jail']) && $jailInfo['nrp_jail'] === true) {
        if (!$officer->hasPermission("rcorg.admin")) {
            $officer->sendMessage("§c§l[Ошибка] §r§l§fГражданин отбывает наказание за NRP. Досрочное освобождение доступно только администрации (§e/rcunjail§f).");
            return;
        }
    }

    $key = strtolower($targetName);
    unset($this->jailTimers[$key]);
    $this->jailData->remove($key);
    $this->jailData->save();

    $officerOrg = $this->getPlayerOrg($officer->getName());
    $officerRankName = $this->getRealRankName($officer->getName());
    $coloredOfficerOrg = $this->getColoredOrgName($officerOrg);

    $target = Server::getInstance()->getPlayerExact($targetName);
    if ($target !== null) {
        $target->setNoClientPredictions(false);
        $this->teleportToRelease($target);
        $target->sendMessage("§a§l ДОСРОЧНОЕ ОСВОБОЖДЕНИЕ");
        $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $target->sendMessage("§r§l§fВы досрочно освобождены по решению старшего офицера.");
        $target->sendMessage("§r§l§fОфицер: {$officerRankName} §f{$officer->getName()} §7({$coloredOfficerOrg}§7)");
        $target->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    $officer->sendMessage("§a§l[Рация] §r§l§fГражданин §e{$targetName} §fдосрочно освобождён.");

    if ($officerOrg) {
        $this->addLog($officerOrg, "§c§l{$officer->getName()} §6§lдосрочно освободил §b§l{$targetName} §6§lиз изолятора");
    }
}

    public function isJailed(string $name): bool {
        $key = strtolower($name);
        if (!isset($this->jailTimers[$key])) return false;
        if ($this->jailTimers[$key] <= time()) {
            $this->releasePlayer($name);
            return false;
        }
        return true;
    }

    public function getJailRemainingTime(string $name): int {
        $key = strtolower($name);
        if (!isset($this->jailTimers[$key])) return 0;
        return max(0, $this->jailTimers[$key] - time());
    }

    public function getJailInfo(string $name): ?array {
        $key = strtolower($name);
        $data = $this->jailData->get($key, null);
        return is_array($data) ? $data : null;
    }

    public function getMaxJailTime(Player $officer): int {
        $rank = $this->getPlayerRank($officer->getName());
        if ($rank > 100) $rank = 10;
        $base = $this->extraConfig->getNested("jail.base_time", 120);
        $perRank = $this->extraConfig->getNested("jail.time_per_rank", 180);
        $extra = max(0, $rank - 4) * $perRank;
        return $base + $extra;
    }

    public function teleportToJail(Player $player): void {
        $pos = $this->getCoordPosition("jail.spawn");
        if ($pos !== null) $player->teleport($pos);
    }

    public function teleportToRelease(Player $player): void {
        $pos = $this->getCoordPosition("jail.release");
        if ($pos !== null) $player->teleport($pos);
    }

    public function isInJailZone(Player $player): bool {
        return $this->isInZone($player, "jail.zone");
    }

    private function loadHealData(): void {
        foreach ($this->healData->getAll() as $name => $data) {
            if (isset($data['heal_time']) && $data['heal_time'] > time()) {
                $this->healingPlayers[strtolower($name)] = (int)$data['heal_time'];
            } else {
                $this->healData->remove($name);
            }
        }
        $this->healData->save();
    }

    public function sendToHospital(Player $player): void {
        $key = strtolower($player->getName());

        if (isset($this->healingPlayers[$key]) && $this->healingPlayers[$key] > time()) {
            $this->teleportToHospital($player);
            return;
        }

        $healTime = $this->extraConfig->getNested("hospital.self_heal_time", 120);
        $readyTime = time() + $healTime;

        $this->healingPlayers[$key] = $readyTime;
        $this->healData->set($key, [
            "heal_time" => $readyTime,
            "date" => date("d.m.Y H:i:s")
        ]);
        $this->healData->save();

        $this->teleportToHospital($player);

        $coloredGB = $this->getColoredOrgName("GB");

        $player->sendMessage("§c§l ГОСПИТАЛИЗАЦИЯ");
        $player->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $player->sendMessage("§r§l§fВы доставлены в {$coloredGB}§f.");
        $player->sendMessage("§r§l§fДиагноз: §eТяжёлые множественные травмы.");
        $player->sendMessage("§r§l§fСамолечение доступно через: §e" . $this->formatTime($healTime));
        $player->sendMessage("§r§l§fИли дождитесь помощи медицинского сотрудника.");
        $player->sendMessage("§r§l§7Покидать территорию больницы до выписки запрещено.");
        $player->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    public function healByDoctor(Player $doctor, Player $patient): void {
        $pKey = strtolower($patient->getName());
        $coloredGB = $this->getColoredOrgName("GB");

        if (!$this->isHealing($patient->getName())) {
            $doctor->sendMessage("§c§l[{$coloredGB}§c§l] §r§l§fГражданин не нуждается в медицинской помощи.");
            return;
        }
        if ($doctor->getPosition()->distance($patient->getPosition()) > 5) {
            $doctor->sendMessage("§c§l[Ошибка] §r§l§fПациент находится слишком далеко для оказания помощи.");
            return;
        }
        if (strtolower($doctor->getName()) === $pKey) {
            $doctor->sendMessage("§c§l[Ошибка] §r§l§fВрач не может оказывать помощь самому себе.");
            return;
        }
        if ($this->isCuffed($patient->getName())) {
            $doctor->sendMessage("§c§l[Ошибка] §r§l§fПациент находится под стражей. Лечение невозможно.");
            return;
        }
        if ($this->isJailed($patient->getName())) {
            $doctor->sendMessage("§c§l[Ошибка] §r§l§fПациент отбывает наказание. Медицинская помощь недоступна.");
            return;
        }

        $this->dischargePlayer($patient->getName());

        $doctorOrg = $this->getPlayerOrg($doctor->getName());
        $rankName = $this->getRealRankName($doctor->getName());
        $coloredDoctorOrg = $this->getColoredOrgName($doctorOrg);

        $patient->sendMessage("§a§l ВЫПИСКА");
        $patient->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $patient->sendMessage("§r§l§fВам оказана квалифицированная медицинская помощь.");
        $patient->sendMessage("§r§l§fЛечащий врач: {$rankName} §f{$doctor->getName()} §7({$coloredDoctorOrg}§7)");
        $patient->sendMessage("§r§l§fСтатус: §aЗдоров");
        $patient->sendMessage("§r§l§fВы можете покинуть территорию больницы.");
        $patient->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        $patient->setHealth($patient->getMaxHealth());

        $doctor->sendMessage("§a§l[{$coloredGB}§a§l] §r§l§fПациент §e{$patient->getName()} §fуспешно выписан.");

        $this->addLog("GB", "§c§l{$doctor->getName()} §6§lоказал помощь пациенту §b§l{$patient->getName()}");
}
    public function checkSelfHeal(Player $player): bool {
        $key = strtolower($player->getName());
        if (!isset($this->healingPlayers[$key])) return false;
        if ($this->healingPlayers[$key] <= time()) {
            $this->dischargePlayer($player->getName());
            $player->setHealth($player->getMaxHealth());
            $coloredGB = $this->getColoredOrgName("GB");
            $player->sendMessage("§a§l ВЫПИСКА");
            $player->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            $player->sendMessage("§r§l§fВаше состояние стабилизировалось.");
            $player->sendMessage("§r§l§fВы выписаны из {$coloredGB}§f.");
            $player->sendMessage("§r§l§fСтатус: §aЗдоров");
            $player->sendMessage("§r§l§7Берегите здоровье, гражданин.");
            $player->sendMessage("§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            return true;
        }
        return false;
    }

    public function dischargePlayer(string $name): void {
        $key = strtolower($name);
        unset($this->healingPlayers[$key]);
        $this->healData->remove($key);
        $this->healData->save();
    }

    public function isHealing(string $name): bool {
        return isset($this->healingPlayers[strtolower($name)]);
    }

    public function getHealRemainingTime(string $name): int {
        $key = strtolower($name);
        if (!isset($this->healingPlayers[$key])) return 0;
        return max(0, $this->healingPlayers[$key] - time());
    }

    public function teleportToHospital(Player $player): void {
        $pos = $this->getCoordPosition("hospital.spawn");
        if ($pos !== null) $player->teleport($pos);
    }

    public function isInHospitalZone(Player $player): bool {
        return $this->isInZone($player, "hospital.zone");
    }

    public function getCoordPosition(string $path): ?Position {
        $worldName = $this->coordConfig->getNested("$path.world", "world");
        $world = Server::getInstance()->getWorldManager()->getWorldByName($worldName);
        if ($world === null) {
            Server::getInstance()->getWorldManager()->loadWorld($worldName);
            $world = Server::getInstance()->getWorldManager()->getWorldByName($worldName);
        }
        if ($world === null) return null;
        $x = (float)$this->coordConfig->getNested("$path.x", 0);
        $y = (float)$this->coordConfig->getNested("$path.y", 65);
        $z = (float)$this->coordConfig->getNested("$path.z", 0);
        return new Position($x, $y, $z, $world);
    }

    public function isInZone(Player $player, string $path): bool {
        $worldName = $this->coordConfig->getNested("$path.world", "world");
        if ($player->getWorld()->getFolderName() !== $worldName) return false;
        $pos = $player->getPosition();
        $x1 = min($this->coordConfig->getNested("$path.x1", 0), $this->coordConfig->getNested("$path.x2", 0));
        $x2 = max($this->coordConfig->getNested("$path.x1", 0), $this->coordConfig->getNested("$path.x2", 0));
        $y1 = min($this->coordConfig->getNested("$path.y1", 0), $this->coordConfig->getNested("$path.y2", 0));
        $y2 = max($this->coordConfig->getNested("$path.y1", 0), $this->coordConfig->getNested("$path.y2", 0));
        $z1 = min($this->coordConfig->getNested("$path.z1", 0), $this->coordConfig->getNested("$path.z2", 0));
        $z2 = max($this->coordConfig->getNested("$path.z1", 0), $this->coordConfig->getNested("$path.z2", 0));
        return ($pos->x >= $x1 && $pos->x <= $x2 && $pos->y >= $y1 && $pos->y <= $y2 && $pos->z >= $z1 && $pos->z <= $z2);
    }

    public function formatTime(int $seconds): string {
        if ($seconds <= 0) return "0 сек.";
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $secs = $seconds % 60;
        $parts = [];
        if ($hours > 0) $parts[] = "{$hours} ч.";
        if ($minutes > 0) $parts[] = "{$minutes} мин.";
        if ($secs > 0 || empty($parts)) $parts[] = "{$secs} сек.";
        return implode(" ", $parts);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        $this->updateExternalTag($name, $this->getPlayerOrg($name));

        if ($this->fineSystem->hasFines($name)) {
            $player->sendMessage("§c§l[ВНИМАНИЕ] §r§l§fУ вас имеются неоплаченные штрафы! Оплатите их через НПС оплаты штрафов во избежание последствий.");
        }

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player): void {
            if (!$player->isOnline()) return;
            $this->itemManager->syncAllItems($player);
        }), 10);

        if ($this->isJailed($name)) {
            $remaining = $this->getJailRemainingTime($name);
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player, $remaining): void {
                if (!$player->isOnline()) return;
                $this->teleportToJail($player);
                $player->sendMessage("§c§l[Изолятор] §r§l§fВы продолжаете отбывать наказание.");
                $player->sendMessage("§l§fОсталось: §e" . $this->formatTime($remaining));
            }), 15);
        }

        if ($this->isHealing($name)) {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player): void {
                if (!$player->isOnline()) return;
                if (!$this->checkSelfHeal($player)) {
                    $remaining = $this->getHealRemainingTime($player->getName());
                    $this->teleportToHospital($player);
                    $coloredGB = $this->getColoredOrgName("GB");
                    $player->sendMessage("§c§l[{$coloredGB}§c§l] §r§l§fВы продолжаете проходить лечение.");
                    if ($remaining > 0) {
                        $player->sendMessage("§l§fДо выписки: §e" . $this->formatTime($remaining));
                    }
                }
            }), 15);
        }

        $this->courtSystem->checkOfflineNotifications($player);

        if ($this->wantedSystem->hasStars($name)) {
            $stars = $this->wantedSystem->getStars($name);
            $player->sendMessage("§c§l[ВНИМАНИЕ] §r§l§fВы находитесь в федеральном розыске! (§e{$stars} ур.§f)");
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
    $player = $event->getPlayer();
    $name = $player->getName();

    $this->prosecutorSystem->stopInspectionByPlayer($name);

    if ($this->isCuffed($name)) {
        $this->cuffSystem->handleCuffedQuit($player);
    }

    if ($this->cuffSystem->isBound($name)) {
        $this->cuffSystem->handleBaggedQuit($player);
    }

    if ($this->wantedSystem->hasStars($name)) {
        $stars = $this->wantedSystem->getStars($name);
        $time = $stars * 600;

        $this->jailTimers[strtolower($name)] = time() + $time;
        $this->jailData->set(strtolower($name), [
            "release_time" => time() + $time,
            "reason" => "Выход из игры при розыске ($stars ур.)",
            "officer" => "Система",
            "officer_rank" => "Server",
            "officer_org" => "Server",
            "date" => date("d.m.Y H:i:s")
        ]);
        $this->jailData->save();
        $this->wantedSystem->clearStars($name);
    }
    $this->wantedSystem->stopTracking($name);
}

    public function onRespawn(PlayerRespawnEvent $event): void {
        $player = $event->getPlayer();

        if ($this->isJailed($player->getName())) {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player): void {
                if ($player->isOnline() && $this->isJailed($player->getName())) {
                    $this->teleportToJail($player);
                    $player->sendMessage("§c§l[Изолятор] §r§l§fПопытка побега пресечена. Вы возвращены в камеру.");
                }
            }), 5);
            return;
        }

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player): void {
            if ($player->isOnline() && !$this->isHealing($player->getName())) {
                $this->sendToHospital($player);
            }
        }), 5);
    }

    public function onMove(PlayerMoveEvent $event): void {
    $player = $event->getPlayer();
    $name = $player->getName();

    $from = $event->getFrom();
    $to = $event->getTo();
    if ((int)$from->x === (int)$to->x && (int)$from->y === (int)$to->y && (int)$from->z === (int)$to->z) {
        return;
    }

    if ($this->cuffSystem->isTied($name)) {
        $this->cuffSystem->handleTiedMovement($player);
        return;
    }

    if ($this->cuffSystem->isBound($name)) {
        $this->cuffSystem->handleBoundMovement($player);
        return;
    }

    if ($this->isCuffed($name)) {
        $officerName = $this->getOfficer($name);
        if ($officerName !== null) {
            $officer = $this->getServer()->getPlayerExact($officerName);
            if ($officer !== null && $officer->isOnline()) {
                if ($player->getPosition()->distance($officer->getPosition()) > 3) {
                    $oPos = $officer->getPosition();
                    $dir = $officer->getDirectionVector()->multiply(-1.5);
                    $player->teleport($oPos->add($dir->x, 0, $dir->z));
                }
            }
        }
        return;
    }

    if ($this->isJailed($name)) {
        if (!$this->isInJailZone($player)) {
            $this->teleportToJail($player);
            $player->sendMessage("§c§l[Изолятор] §r§l§fПопытка покинуть зону содержания пресечена.");
        }
        return;
    }

    if ($this->isHealing($name)) {
        if ($this->checkSelfHeal($player)) return;
        if (!$this->isInHospitalZone($player)) {
            $this->teleportToHospital($player);
            $player->sendMessage("§c§l[" . $this->getColoredOrgName("GB") . "§c§l] §r§l§fВам запрещено покидать территорию до официальной выписки.");
        }
        return;
    }
}

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
    $damager = $event->getDamager();
    $target = $event->getEntity();

    if (!$damager instanceof Player || !$target instanceof Player) return;

    $item = $damager->getInventory()->getItemInHand();
    $im = $this->itemManager;

    if ($im->isProsecutorTablet($item)) {
        $event->cancel();
        if ($im->canUseProsecutorTablet($damager)) {
            $targetOrg = $this->getPlayerOrg($target->getName());
            if ($targetOrg === "MF") {
                $damager->sendMessage("§c§l[Ошибка] §r§l§fДоступ к досье сотрудников " . $this->getColoredOrgName("MF") . " §fневозможен.");
                return;
            }
            ProsecutorForms::openDossierMenu($damager, $target->getName());
        }
        return;
    }

    if ($im->isConfiscationTool($item)) {
        $event->cancel();
        if ($im->canUseConfiscationTool($damager)) {
            Forms::openConfiscationMenu($damager, $target->getName());
        } else {
            $damager->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет прав на изъятие документов.");
        }
        return;
    }

    if ($im->isMafiaRope($item)) {
        $event->cancel();
        if ($im->canUseMafiaRope($damager)) {
            if ($damager->getPosition()->distance($target->getPosition()) > 5) {
                $damager->sendMessage("§c§l[Ошибка] §r§l§fЖертва слишком далеко.");
                return;
            }
            MafiaForms::openMafiaBindMenu($damager);
        } else {
            $damager->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к инструментам ОПГ.");
        }
        return;
    }

    if ($im->isHandcuffs($item)) {
        $event->cancel();
        if ($im->canUseHandcuffs($damager)) {
            $this->cuffPlayer($damager, $target);
        } else {
            $damager->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет полномочий для использования спецсредств.");
        }
        return;
    }

    if ($im->isLeaderCuffs($item)) {
        $event->cancel();
        if ($im->canUseLeaderCuffs($damager)) {
            $this->handleLeaderCuffs($damager, $target);
        } else {
            $damager->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет полномочий для использования спецнаручников.");
        }
        return;
    }

    if ($im->isMedkit($item)) {
        $event->cancel();
        if ($im->canUseMedkit($damager)) {
            $this->healByDoctor($damager, $target);
        } else {
            $damager->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет полномочий для оказания медицинской помощи.");
        }
        return;
    }

    if ($im->isCourtItem($item)) {
        $event->cancel();
        if ($this->courtSystem->canUseCourtItem($damager)) {
            $this->courtSystem->openCourtMenu($damager, $target->getName());
        } else {
            $damager->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет судебных полномочий.");
        }
        return;
    }
}

    public function onDropItem(PlayerDropItemEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($this->itemManager->isSpecialItem($item)) {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use ($player): void {
                if (!$player->isOnline()) return;
                $this->itemManager->syncAllItems($player);
            }), 40);
        }
    }

    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if (!$entity instanceof Player) return;

        if ($this->isCuffed($entity->getName())) { $event->cancel(); return; }
        if ($this->isJailed($entity->getName())) { $event->cancel(); return; }
        if ($this->isHealing($entity->getName())) { $event->cancel(); return; }
    }

    public function onItemUse(PlayerItemUseEvent $event): void {
    $player = $event->getPlayer();
    $item = $event->getItem();

    if ($this->isCuffed($player->getName())) { $event->cancel(); return; }
    if ($this->isJailed($player->getName())) { $event->cancel(); return; }
    if ($this->isHealing($player->getName())) { $event->cancel(); return; }

    $im = $this->itemManager;

    if ($im->isLawsuitTablet($item)) {
        if ($im->canUseLawsuitTablet($player)) {
            $this->courtSystem->openJudgeLawsuitList($player);
        } else {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к судебным делам.");
        }
    }

    if ($im->isFineTablet($item)) {
        if ($im->canUseFineTablet($player)) {
            $this->fineSystem->openFineMenu($player);
        } else {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к системе штрафов.");
        }
    }

    if ($im->isWantedItem($item)) {
        if ($im->canUseWantedItem($player)) {
            $this->wantedSystem->openWantedMenu($player);
        } else {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к базе розыска.");
        }
    }

    if ($im->isImmunityTablet($item)) {
        if ($im->canUseImmunityTablet($player)) {
            $this->immunitySystem->openImmunityMenu($player);
        } else {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к реестру неприкосновенности.");
        }
    }

    if ($im->isFNSTablet($item)) {
        if ($im->canUseFNSTablet($player)) {
            FNSForms::openFNSTabletMenu($player);
        } else {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к планшету ФНС.");
        }
    }

    if ($im->isHandcuffs($item)) {
        $event->cancel();
        if ($im->canUseHandcuffs($player)) {
            CuffForms::openCuffActionsMenu($player);
        }
        return;
    }

    if ($im->isLeaderCuffs($item)) {
        $event->cancel();
        if ($im->canUseLeaderCuffs($player)) {
            CuffForms::openCuffActionsMenu($player);
        }
        return;
    }

    if ($im->isMafiaRope($item)) {
        $event->cancel();
        if ($im->canUseMafiaRope($player)) {
            MafiaForms::openMafiaBindMenu($player);
        } else {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет доступа к инструментам ОПГ.");
        }
        return;
    }

    if ($this->mafiaSystem->isDrugItem($item)) {
        $event->cancel();
        $drugType = $this->mafiaSystem->getDrugTypeFromItem($item);
        if ($drugType !== null) {
            MafiaForms::openDrugUseMenu($player, $drugType);
        }
        return;
    }
}
    public function handleJailNpcTouch(Player $player): void {
        if (!$this->itemManager->canUseHandcuffs($player) && !$this->itemManager->canUseLeaderCuffs($player)) {
            $player->sendMessage("§c§l[Терминал Изолятора] §r§l§fДоступ запрещён. Требуется удостоверение сотрудника силового ведомства.");
            return;
        }
        $cuffedList = $this->getCuffedByOfficer($player->getName());
        if (empty($cuffedList)) {
            $player->sendMessage("§c§l[Терминал Изолятора] §r§l§fУ вас нет задержанных граждан для оформления.");
            $player->sendMessage("§l§7Сначала задержите подозреваемого с помощью наручников.");
            return;
        }
        JailForms::openCuffedList($player, $cuffedList);
    }

    public function handleLawsuitNpcTouch(Player $player): void {
        if (!$this->checkDocs($player, 'passport')) {
            $player->sendMessage("§c§l[" . $this->getColoredOrgName("GS") . "§c§l] §r§l§fДля подачи иска требуется паспорт.");
            return;
        }
        $this->courtSystem->openFileLawsuitForm($player);
    }

    public function handleFineNpcTouch(Player $player): void {
        $this->fineSystem->openPlayerFines($player);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "rcleader") {
            if (!$sender->hasPermission("rcorg.admin")) return false;
            if (count($args) < 1) return $sender->sendMessage("§e/rcleader <Nick> [ORG] [1|2] (или 0 для снятия)") && true;
            $target = $sender->getName();
            $orgKey = null;
            $rank = 0;
            $remove = false;
            if (count($args) === 1 && $args[0] === "0") $remove = true;
            elseif (count($args) === 2) {
                if ($args[1] === "0") {
                    $target = $args[0];
                    $remove = true;
                } else {
                    $orgKey = strtoupper($args[0]);
                    $rank = ($args[1] == 2 ? 17 : 16);
                }
            } elseif (count($args) >= 3) {
                $target = $args[0];
                $orgKey = strtoupper($args[1]);
                $rank = ($args[2] == 2 ? 17 : 16);
            }
            if ($remove) {
                $oldOrg = $this->getPlayerOrg($target);
                $this->setPlayerOrg($target, null, 1, false, false);

                if ($oldOrg) {
                    $key = strtolower($target);
                    $this->data->removeNested("$key.history.$oldOrg");
                    $this->data->save();
                }

                $sender->sendMessage("§a§l[Система] §r§l§fЛидер/Админ §e$target §fснят" . ($oldOrg ? " из " . $this->getColoredOrgName($oldOrg) : "") . "§f.");
                $tPlayer = $this->getServer()->getPlayerExact($target);
                if ($tPlayer) {
                    $tPlayer->sendMessage("§c§l[Система] §r§l§fВы были сняты с руководящей должности администратором §e{$sender->getName()}§f.");
                }
            } elseif ($orgKey && isset($this->getConfig()->get("orgs")[$orgKey])) {
                $coloredOrg = $this->getColoredOrgName($orgKey);
                $rankName = $this->getRankName($orgKey, $rank);
                $this->setPlayerOrg($target, $orgKey, $rank);
                $this->setLeaderInfo($orgKey, $target, $this->getFio($target));
                $sender->sendMessage("§a§l[Система] §r§l§fНазначен новый руководитель: §e$target §fв {$coloredOrg}§f (§e{$rankName}§f).");
                $tPlayer = $this->getServer()->getPlayerExact($target);
                if ($tPlayer) {
                    $tPlayer->sendMessage("§a§l[Система] §r§l§fАдминистратор §e{$sender->getName()} §fназначил вас на должность §e{$rankName} §fв {$coloredOrg}§f.");
                }
            }
            return true;
        }

        if ($command->getName() === "rclogorg") {
            if (!$sender instanceof Player) return false;
            $org = $this->getPlayerOrg($sender->getName());
            if ($org) Forms::openOrgMenu($sender, $org);
            else $sender->sendMessage("§c§l[Ошибка] §r§l§fВы не состоите в организации.");
            return true;
        }

        if ($command->getName() === "rcspawnorg") {
            if (!$sender instanceof Player) return false;
            if (count($args) < 2) return false;
            $org = strtoupper($args[0]);
            $act = (int)$args[1];
            if (!isset($this->getConfig()->get("orgs")[$org])) return false;
            $coloredOrg = $this->getColoredOrgName($org);
            if ($act === 1) {
                $nbt = CompoundTag::create()->setString("org_tag", $org);
                $npc = new OrgNPC($sender->getLocation(), $sender->getSkin(), $nbt);
                $npc->setNameTag("§l§e" . $this->getOrgName($org) . "\n§r§fНажмите");
                $npc->spawnToAll();
                $sender->sendMessage("§a§l[Система] §r§l§fNPC {$coloredOrg} §fуспешно установлен.");
            } elseif ($act === 2) {
                foreach ($sender->getWorld()->getNearbyEntities($sender->getBoundingBox()->expandedCopy(5, 5, 5)) as $e) {
                    if ($e instanceof OrgNPC && $e->getOrgTag() === $org) $e->close();
                }
                $sender->sendMessage("§a§l[Система] §r§l§fБлижайшие NPC {$coloredOrg} §fудалены.");
            }
            return true;
        }

        if ($command->getName() === "rcfraction") {
            if (!$sender instanceof Player) return false;
            if (!$sender->hasPermission("rcorg.admin")) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
                return true;
            }
            if (count($args) < 1) {
                $sender->sendMessage("§e§l/rcfraction 1 §r§l§f— установить НПС терминала изолятора");
                $sender->sendMessage("§e§l/rcfraction 2 §r§l§f— удалить ближайшие НПС терминала");
                return true;
            }
            $act = (int)$args[0];
            if ($act === 1) {
                $nbt = CompoundTag::create();
                $npc = new JailNPC($sender->getLocation(), $sender->getSkin(), $nbt);
                $npc->spawnToAll();
                $sender->sendMessage("§a§l[Система] §r§l§fТерминал изолятора успешно установлен.");
            } elseif ($act === 2) {
                $count = 0;
                foreach ($sender->getWorld()->getNearbyEntities($sender->getBoundingBox()->expandedCopy(5, 5, 5)) as $e) {
                    if ($e instanceof JailNPC) { $e->close(); $count++; }
                }
                $sender->sendMessage("§a§l[Система] §r§l§fУдалено терминалов: $count");
            }
            return true;
        }

        if ($command->getName() === "rcsud") {
            if (!$sender instanceof Player) return false;
            if (!$sender->hasPermission("rcorg.admin")) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
                return true;
            }
            if (count($args) < 1) {
                $sender->sendMessage("§e§l/rcsud 1 §r§l§f— установить НПС судимостей");
                $sender->sendMessage("§e§l/rcsud 2 §r§l§f— удалить ближайшие НПС судимостей");
                return true;
            }
            $act = (int)$args[0];
            if ($act === 1) {
                $nbt = CompoundTag::create();
                $npc = new CourtNPC($sender->getLocation(), $sender->getSkin(), $nbt);
                $npc->spawnToAll();
                $sender->sendMessage("§a§l[Система] §r§l§fНПС судимостей успешно установлен.");
            } elseif ($act === 2) {
                $count = 0;
                foreach ($sender->getWorld()->getNearbyEntities($sender->getBoundingBox()->expandedCopy(5, 5, 5)) as $e) {
                    if ($e instanceof CourtNPC) { $e->close(); $count++; }
                }
                $sender->sendMessage("§a§l[Система] §r§l§fУдалено НПС: $count");
            }
            return true;
        }

        if ($command->getName() === "rclawsuit") {
            if (!$sender instanceof Player || !$sender->hasPermission("rcorg.admin")) return false;
            $nbt = CompoundTag::create();
            $npc = new LawsuitNPC($sender->getLocation(), $sender->getSkin(), $nbt);
            $npc->spawnToAll();
            $sender->sendMessage("§a§l[Система] §r§l§fNPC подачи исков создан.");
            return true;
        }

        if ($command->getName() === "rchtraf") {
            if (!$sender instanceof Player || !$sender->hasPermission("rcorg.admin")) return false;
            $nbt = CompoundTag::create();
            $npc = new FineNPC($sender->getLocation(), $sender->getSkin(), $nbt);
            $npc->spawnToAll();
            $sender->sendMessage("§a§l[Система] §r§l§fNPC оплаты штрафов создан.");
            return true;
        }

        if ($command->getName() === "rccoord") {
            if (!$sender instanceof Player) return false;
            if (!$sender->hasPermission("rcorg.admin")) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
                return true;
            }
            if (count($args) < 1) {
                $sender->sendMessage("§e§l━━━ Координаты RcOrg ━━━");
                $sender->sendMessage("§e§l/rccoord jail.spawn §r§l§f— точка спавна в камере");
                $sender->sendMessage("§e§l/rccoord jail.release §r§l§f— точка выхода из тюрьмы");
                $sender->sendMessage("§e§l/rccoord jail.zone.1 §r§l§f— угол 1 зоны тюрьмы");
                $sender->sendMessage("§e§l/rccoord jail.zone.2 §r§l§f— угол 2 зоны тюрьмы");
                $sender->sendMessage("§e§l/rccoord hospital.spawn §r§l§f— точка спавна в больнице");
                $sender->sendMessage("§e§l/rccoord hospital.zone.1 §r§l§f— угол 1 зоны больницы");
                $sender->sendMessage("§e§l/rccoord hospital.zone.2 §r§l§f— угол 2 зоны больницы");
                $sender->sendMessage("§e§l━━━━━━━━━━━━━━━━━━━━━");
                return true;
            }

            $type = strtolower($args[0]);
            $pos = $sender->getPosition();
            $worldName = $sender->getWorld()->getFolderName();
            $x = round($pos->x, 1);
            $y = round($pos->y, 1);
            $z = round($pos->z, 1);

            switch ($type) {
                case "jail.spawn":
                    $this->coordConfig->setNested("jail.spawn.world", $worldName);
                    $this->coordConfig->setNested("jail.spawn.x", $x);
                    $this->coordConfig->setNested("jail.spawn.y", $y);
                    $this->coordConfig->setNested("jail.spawn.z", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fТочка спавна тюрьмы установлена: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                case "jail.release":
                    $this->coordConfig->setNested("jail.release.world", $worldName);
                    $this->coordConfig->setNested("jail.release.x", $x);
                    $this->coordConfig->setNested("jail.release.y", $y);
                    $this->coordConfig->setNested("jail.release.z", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fТочка выхода из тюрьмы установлена: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                case "jail.zone.1":
                    $this->coordConfig->setNested("jail.zone.world", $worldName);
                    $this->coordConfig->setNested("jail.zone.x1", $x);
                    $this->coordConfig->setNested("jail.zone.y1", $y);
                    $this->coordConfig->setNested("jail.zone.z1", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fУгол 1 зоны тюрьмы установлен: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                case "jail.zone.2":
                    $this->coordConfig->setNested("jail.zone.world", $worldName);
                    $this->coordConfig->setNested("jail.zone.x2", $x);
                    $this->coordConfig->setNested("jail.zone.y2", $y);
                    $this->coordConfig->setNested("jail.zone.z2", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fУгол 2 зоны тюрьмы установлен: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                case "hospital.spawn":
                    $this->coordConfig->setNested("hospital.spawn.world", $worldName);
                    $this->coordConfig->setNested("hospital.spawn.x", $x);
                    $this->coordConfig->setNested("hospital.spawn.y", $y);
                    $this->coordConfig->setNested("hospital.spawn.z", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fТочка спавна больницы установлена: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                case "hospital.zone.1":
                    $this->coordConfig->setNested("hospital.zone.world", $worldName);
                    $this->coordConfig->setNested("hospital.zone.x1", $x);
                    $this->coordConfig->setNested("hospital.zone.y1", $y);
                    $this->coordConfig->setNested("hospital.zone.z1", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fУгол 1 зоны больницы установлен: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                case "hospital.zone.2":
                    $this->coordConfig->setNested("hospital.zone.world", $worldName);
                    $this->coordConfig->setNested("hospital.zone.x2", $x);
                    $this->coordConfig->setNested("hospital.zone.y2", $y);
                    $this->coordConfig->setNested("hospital.zone.z2", $z);
                    $sender->sendMessage("§a§l[Координаты] §r§l§fУгол 2 зоны больницы установлен: §e{$x}, {$y}, {$z} ({$worldName})");
                    break;
                default:
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fНеизвестный тип координат. Используйте §e/rccoord §fдля справки.");
                    return true;
            }
            $this->coordConfig->save();
            return true;
        }

        if ($command->getName() === "rcproverkaorg") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cТолько для игроков.");
                return true;
            }

            $sys = $this->prosecutorSystem;

            if (!$sys->canConfirmStrike($sender)) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет прав для подтверждения выговоров.");
                return true;
            }

            if (count($args) < 1) {
                $sender->sendMessage("§e§l/rcproverkaorg yes <id> §r§l§f— подтвердить выговор");
                $sender->sendMessage("§e§l/rcproverkaorg no <id> <причина> §r§l§f— отклонить выговор");
                $sender->sendMessage("§e§l/rcproverkaorg list §r§l§f— список ожидающих");
                return true;
            }

            $action = strtolower($args[0]);

            if ($action === "list") {
                ProsecutorForms::openPendingStrikesMenu($sender);
                return true;
            }

            if ($action === "yes") {
                if (!isset($args[1])) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fУкажите ID выговора.");
                    return true;
                }

                $id = $args[1];
                $strike = $sys->getPendingStrike($id);

                if ($strike === null) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fВыговор не найден или уже обработан.");
                    return true;
                }

                $orgKey = $strike['org'];
                $currentStrikes = $sys->getStrikes($orgKey);
                $isThirdStrike = ($currentStrikes >= 2);

                if ($isThirdStrike && !$sys->canConfirmThirdStrike($sender)) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fТретий выговор (снятие лидера) может подтвердить только CURATOR, GLADMIN, MANAGER, OWNER или CREATOR.");
                    return true;
                }

                $sys->confirmPendingStrike($id, $sender->getName());
                $sender->sendMessage("§a§l[Система] §r§l§fВыговор подтверждён.");
                return true;
            }

            if ($action === "no") {
                if (!isset($args[1])) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fУкажите ID выговора.");
                    return true;
                }

                $id = $args[1];
                $strike = $sys->getPendingStrike($id);

                if ($strike === null) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fВыговор не найден или уже обработан.");
                    return true;
                }

                $reasonParts = array_slice($args, 2);
                $reason = implode(" ", $reasonParts);

                if (empty($reason)) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину отклонения.");
                    $sender->sendMessage("§e§l/rcproverkaorg no {$id} <причина>");
                    return true;
                }

                $sys->denyPendingStrike($id, $sender->getName(), $reason);
                $sender->sendMessage("§a§l[Система] §r§l§fВыговор отклонён.");
                return true;
            }

            $sender->sendMessage("§c§l[Ошибка] §r§l§fНеизвестное действие. Используйте yes/no/list.");
            return true;
        }

        if ($command->getName() === "rcsetrang") {
            if (!$sender->hasPermission("rcorg.admin")) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
                return true;
            }

            if (count($args) < 2) {
                $sender->sendMessage("§e§l/rcsetrang <ORG> <ранг> §r§l§f— выдать себе ранг");
                $sender->sendMessage("§e§l/rcsetrang <Nick> <ORG> <ранг> §r§l§f— выдать игроку ранг");
                $sender->sendMessage("§l§7Ранг: от 1 до 15");
                return true;
            }

            $target = null;
            $orgKey = null;
            $newRank = 0;

            if (count($args) === 2) {
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§c§l[Ошибка] §r§l§fУкажите ник игрока.");
                    return true;
                }
                $target = $sender->getName();
                $orgKey = strtoupper($args[0]);
                $newRank = (int)$args[1];
            } elseif (count($args) >= 3) {
                $target = $args[0];
                $orgKey = strtoupper($args[1]);
                $newRank = (int)$args[2];
            }

            if (!isset($this->getConfig()->get("orgs")[$orgKey])) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fОрганизация §e{$orgKey} §fне найдена.");
                return true;
            }

            if ($newRank < 1 || $newRank > 15) {
                $sender->sendMessage("§c§l[Ошибка] §r§l§fРанг должен быть от 1 до 15.");
                return true;
            }

            $this->setPlayerOrg($target, $orgKey, $newRank);

            $coloredOrg = $this->getColoredOrgName($orgKey);
            $rankName = $this->getRankName($orgKey, $newRank);

            $this->addLog($orgKey, "§c§l{$sender->getName()} §6§l(Администратор) назначил §b§l{$target} §6§lна §e§l{$rankName} ({$newRank})");

            $sender->sendMessage("§a§l[Система] §r§l§fИгроку §e{$target} §fвыдан ранг §e{$rankName} ({$newRank}) §fв {$coloredOrg}§f.");

            $tPlayer = $this->getServer()->getPlayerExact($target);
            if ($tPlayer && $tPlayer !== $sender) {
                $tPlayer->sendMessage("§a§l[Система] §r§l§fАдминистратор §e{$sender->getName()} §fназначил вас на должность §e{$rankName} ({$newRank}) §fв {$coloredOrg}§f.");
            }

            return true;
        }

if ($command->getName() === "rcuncuff") {
    if (!$sender->hasPermission("rcorg.admin")) {
        $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
        return true;
    }

    if (count($args) < 1) {
        $sender->sendMessage("§e§l/rcuncuff <ник> §r§l§f— снять все ограничения");
        return true;
    }

    $targetName = $args[0];
    $this->cuffSystem->adminUncuff($targetName, $sender);
    return true;
}

if ($command->getName() === "rcunjail") {
    if (!$sender->hasPermission("rcorg.admin")) {
        $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
        return true;
    }

    if (count($args) < 1) {
        $sender->sendMessage("§e§l/rcunjail <ник> §r§l§f— освободить из тюрьмы");
        return true;
    }

    $targetName = $args[0];
    $this->cuffSystem->adminUnjail($targetName, $sender);
    return true;
}
    if ($command->getName() === "rckaznaorg") {
    if (!$sender->hasPermission("rcorg.admin")) {
        $sender->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно прав.");
        return true;
    }
    TreasuryForms::openAdminFundMenu($sender);
    return true;
}
        return true;
    }
}