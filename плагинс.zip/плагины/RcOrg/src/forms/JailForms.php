<?php

namespace InzeOwr\RcOrg\forms;

use pocketmine\player\Player;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use onebone\economyapi\EconomyAPI;
use InzeOwr\RcOrg\Main;

class JailForms {

    public static function openCuffedList(Player $officer, array $cuffedList): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use ($cuffedList) {
            if ($data === null) return;
            if (!isset($cuffedList[$data])) return;

            $targetName = $cuffedList[$data];
            $main = Main::getInstance();

            if (!$main->isCuffed($targetName)) {
                $player->sendMessage("§c§l[Терминал] §r§fЗадержанный уже был освобождён.");
                return;
            }
            $cuffOfficer = $main->getOfficer($targetName);
            if ($cuffOfficer !== strtolower($player->getName())) {
                $player->sendMessage("§c§l[Терминал] §r§fЭтот гражданин задержан другим офицером.");
                return;
            }

            self::openJailForm($player, $targetName);
        });

        $form->setTitle("§l§cТЕРМИНАЛ ИЗОЛЯТОРА");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fВыберите задержанного гражданина\n" .
            "§l§fдля оформления содержания под стражей.\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $main = Main::getInstance();
        foreach ($cuffedList as $name) {
            $fio = $main->getFio($name);
            $form->addButton("§l{$name}\n§r§l§7{$fio}");
        }

        $officer->sendForm($form);
    }

    public static function openJailForm(Player $officer, string $targetName): void {
        $main = Main::getInstance();
        $maxTime = $main->getMaxJailTime($officer);
        $maxMinutes = max(1, (int)floor($maxTime / 60));

        $form = new CustomForm(function (Player $player, ?array $data) use ($targetName, $main) {
            if ($data === null) {
                $main->uncuffPlayer($targetName);
                $player->sendMessage("§e§l[Терминал] §r§fОформление отменено. Задержанный освобождён из-под стражи.");
                return;
            }

            $minutes = (int)($data[1] ?? 2);
            $reason = trim($data[2] ?? "");

            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§fНеобходимо указать основание для содержания под стражей.");
                return;
            }
            if ($minutes < 1) {
                $player->sendMessage("§c§l[Ошибка] §r§fМинимальный срок содержания — 1 минута.");
                return;
            }
            if (!$main->isCuffed($targetName)) {
                $player->sendMessage("§c§l[Ошибка] §r§fЗадержанный был освобождён.");
                return;
            }

            $seconds = $minutes * 60;
            $main->jailPlayer($player, $targetName, $seconds, $reason);
        });

        $fio = $main->getFio($targetName);
        $officerOrg = $main->getPlayerOrg($officer->getName()) ?? "";
        $officerRankName = $main->getRankName($officerOrg, $main->getPlayerRank($officer->getName()));
        $orgName = $main->getOrgName($officerOrg);

        $form->setTitle("§l§cОФОРМЛЕНИЕ ЗАДЕРЖАНИЯ");

        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fЗадержанный: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОфицер: §e{$officer->getName()}\n" .
            "§l§fДолжность: §e{$officerRankName}\n" .
            "§l§fВедомство: §e{$orgName}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fМакс. срок: §e{$maxMinutes} мин.\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addSlider("§l§fСрок содержания (мин.)", 1, $maxMinutes, 1, 2);
        $form->addInput("§l§fОснование задержания:", "Нарушение общественного порядка");

        $officer->sendForm($form);
    }

    public static function openLeaderJailMenu(Player $officer, string $targetName): void {
        $main = Main::getInstance();
        $fio = $main->getFio($targetName);
        $remaining = $main->getJailRemainingTime($targetName);
        $info = $main->getJailInfo($targetName);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $main) {
            if ($data === null) return;

            if ($data === 0) {
                $main->forceReleasePlayer($player, $targetName);
            } elseif ($data === 1) {
                $main->forceReleasePlayer($player, $targetName);
                $target = $player->getServer()->getPlayerExact($targetName);
                if ($target !== null && $target->isOnline()) {
                    $main->handleLeaderCuffs($player, $target);
                } else {
                    $player->sendMessage("§c§l[Ошибка] §r§fИгрок не в сети.");
                }
            }
        });

        $form->setTitle("§l§cСПЕЦОПЕРАЦИЯ");
        $reasonText = $info['reason'] ?? 'Не указана';
        $officerText = $info['officer'] ?? 'Система';
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fЗаключённый: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fОсталось: §e" . $main->formatTime($remaining) . "\n" .
            "§l§fПричина: §e{$reasonText}\n" .
            "§l§fОфицер: §e{$officerText}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§aОсвободить досрочно");
        $form->addButton("§l§eПересадить (новый срок)");

        $officer->sendForm($form);
    }

    public static function openCourtMenu(Player $judge, string $targetName): void {
        $main = Main::getInstance();
        $fio = $main->getFio($targetName);
        $hasCriminal = $main->hasCriminalRecord($targetName);

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $main, $hasCriminal) {
            if ($data === null) return;

            if ($data === 0) {
                self::openAddCriminalForm($player, $targetName);
            } elseif ($data === 1) {
                if (!$hasCriminal) {
                    $player->sendMessage("§c§l[Суд] §r§fУ гражданина нет судимостей.");
                    return;
                }
                $records = $main->getCriminalRecords($targetName);
                self::openRemoveCriminalList($player, $targetName, $records);
            }
        });

        $form->setTitle("§l§5СУДЕБНЫЕ ДЕЙСТВИЯ");
        $statusText = $hasCriminal ? "§cИмеется судимость" : "§aСудимостей нет";
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fСтатус: {$statusText}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§cВыдать судимость");
        $form->addButton("§l§aСнять судимость");

        $judge->sendForm($form);
    }

    public static function openAddCriminalForm(Player $judge, string $targetName): void {
        $main = Main::getInstance();

        $form = new CustomForm(function (Player $player, ?array $data) use ($targetName, $main) {
            if ($data === null) return;

            $reason = trim($data[1] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§fНеобходимо указать основание для вынесения приговора.");
                return;
            }

            $main->addCriminalRecord($targetName, $player->getName(), $reason);
            $player->sendMessage("§a§l[Суд] §r§fСудимость вынесена гражданину §e{$targetName}§f.");
        });

        $fio = $main->getFio($targetName);
        $judgeOrg = $main->getPlayerOrg($judge->getName()) ?? "GS";
        $judgeRankName = $main->getRankName($judgeOrg, $main->getPlayerRank($judge->getName()));

        $form->setTitle("§l§5ВЫНЕСЕНИЕ ПРИГОВОРА");

        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fПодсудимый: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСудья: §e{$judge->getName()}\n" .
            "§l§fДолжность: §e{$judgeRankName}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addInput("§l§fОснование приговора:", "Укажите причину");

        $judge->sendForm($form);
    }

    public static function openRemoveCriminalList(Player $judge, string $targetName, array $records): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $records) {
            if ($data === null) return;
            if (!isset($records[$data])) return;

            $main = Main::getInstance();
            if ($main->canUseCourtItem($player) || $player->hasPermission("rcorg.admin")) {
                $main->removeCriminalRecord($targetName, $data);
                $player->sendMessage("§a§l[Суд] §r§fСудимость снята с гражданина §e{$targetName}§f.");

                $target = $player->getServer()->getPlayerExact($targetName);
                if ($target !== null) {
                    $target->sendMessage("§a§l[Суд] §r§fВаша судимость была погашена решением суда.");
                }

                $main->addLog("GS", "Судья {$player->getName()} снял судимость с гражданина {$targetName}.");
            } else {
                $player->sendMessage("§c§l[Ошибка] §r§fУ вас нет полномочий для снятия судимости.");
            }
        });

        $form->setTitle("§l§5СНЯТИЕ СУДИМОСТИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fВыберите судимость для снятия:\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($records as $i => $record) {
            $form->addButton("§l§c#" . ($i + 1) . "\n§r§l§7{$record['reason']}");
        }

        $judge->sendForm($form);
    }

    public static function openCourtNpcMenu(Player $player): void {
        $main = Main::getInstance();
        $records = $main->getCriminalRecords($player->getName());

        if (empty($records)) {
            $player->sendMessage("§a§l[Суд] §r§fУ вас нет судимостей. Ваша репутация чиста.");
            return;
        }

        self::openMyCriminalRecords($player, $records);
    }

    public static function openMyCriminalRecords(Player $player, array $records): void {
        $main = Main::getInstance();
        $fio = $main->getFio($player->getName());

        $form = new SimpleForm(function (Player $player, ?int $data) use ($records) {
            if ($data === null) return;
            if (!isset($records[$data])) return;

            $record = $records[$data];
            self::openMyCriminalDetail($player, $record, $data);
        });

        $form->setTitle("§l§5ВАШИ СУДИМОСТИ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$player->getName()}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fВсего судимостей: §e" . count($records) . "\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($records as $i => $record) {
            $form->addButton("§l§cСудимость #" . ($i + 1) . "\n§r§l§7{$record['date']}");
        }

        $player->sendForm($form);
    }

    public static function openMyCriminalDetail(Player $player, array $record, int $index): void {
        $main = Main::getInstance();

        $form = new SimpleForm(function (Player $player, ?int $data) use ($index, $main) {
            if ($data === null) return;

            if ($data === 0) {
                $cost = 2500000;
                $money = EconomyAPI::getInstance()->myMoney($player);
                if ($money < $cost) {
                    $player->sendMessage("§c§l[Суд] §r§fНедостаточно средств для погашения судимости. Требуется: §e" . number_format($cost) . "$");
                    return;
                }

                EconomyAPI::getInstance()->reduceMoney($player, $cost);
                $result = $main->removeCriminalRecord($player->getName(), $index);
                if ($result) {
                    $player->sendMessage("§a§l[Суд] §r§fСудимость успешно погашена. С вашего счёта списано: §e" . number_format($cost) . "$");

                    if (!$main->hasCriminalRecord($player->getName())) {
                        $player->sendMessage("§a§l[Суд] §r§fВсе судимости погашены. Вам доступно трудоустройство в государственные структуры.");
                    }

                    $main->addLog("GS", "Гражданин {$player->getName()} самостоятельно погасил судимость #{$index} за " . number_format($cost) . "$.");
                } else {
                    $player->sendMessage("§c§l[Ошибка] §r§fНе удалось погасить судимость.");
                }
            }
        });

        $form->setTitle("§l§5ДЕЛО #" . ($index + 1));
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСудья: §e{$record['judge']}\n" .
            "§l§fФИО судьи: §e{$record['judge_fio']}\n" .
            "§l§fДолжность: §e{$record['judge_rank']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОснование: §e{$record['reason']}\n" .
            "§l§fДата: §e{$record['date']}\n" .
            "§l§fВремя (МСК): §e{$record['time']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСтоимость погашения: §e2 500 000$\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        $form->addButton("§l§aПогасить судимость за 2 500 000$");

        $player->sendForm($form);
    }

    public static function openCriminalRecordView(Player $player, string $targetName, array $records): void {
        if (empty($records)) {
            $player->sendMessage("§a§l[Суд] §r§fУ гражданина §e{$targetName} §fсудимостей не обнаружено.");
            return;
        }

        $main = Main::getInstance();

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $records) {
            if ($data === null) return;
            if (!isset($records[$data])) return;

            $record = $records[$data];
            self::openCriminalRecordDetailView($player, $targetName, $record, $data);
        });

        $fio = $main->getFio($targetName);
        $form->setTitle("§l§5СУДИМОСТИ: {$targetName}");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fФИО: §e{$fio}\n" .
            "§l§fВсего судимостей: §e" . count($records) . "\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        foreach ($records as $i => $record) {
            $form->addButton("§l§cСудимость #" . ($i + 1) . "\n§r§l§7{$record['date']}");
        }

        $player->sendForm($form);
    }

    public static function openCriminalRecordDetailView(Player $player, string $targetName, array $record, int $index): void {
        $main = Main::getInstance();
        $canRemove = $main->canUseCourtItem($player) || $player->hasPermission("rcorg.admin");

        $form = new SimpleForm(function (Player $player, ?int $data) use ($targetName, $index, $main, $canRemove) {
            if ($data === null) return;

            if ($canRemove && $data === 0) {
                $main->removeCriminalRecord($targetName, $index);
                $player->sendMessage("§a§l[Суд] §r§fСудимость снята с гражданина §e{$targetName}§f.");

                $target = $player->getServer()->getPlayerExact($targetName);
                if ($target !== null) {
                    $target->sendMessage("§a§l[Суд] §r§fВаша судимость была погашена решением суда.");
                }
                $main->addLog("GS", "Судья {$player->getName()} снял судимость #{$index} с гражданина {$targetName}.");
            }
        });

        $fio = $main->getFio($targetName);

        $form->setTitle("§l§5ДЕЛО #" . ($index + 1));
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОбвиняемый: §e{$targetName}\n" .
            "§l§fФИО обвиняемого: §e{$fio}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fСудья: §e{$record['judge']}\n" .
            "§l§fФИО судьи: §e{$record['judge_fio']}\n" .
            "§l§fДолжность: §e{$record['judge_rank']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fОснование: §e{$record['reason']}\n" .
            "§l§fДата: §e{$record['date']}\n" .
            "§l§fВремя (МСК): §e{$record['time']}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        );

        if ($canRemove) {
            $form->addButton("§l§aСнять данную судимость");
        }

        $player->sendForm($form);
    }

    public static function openLeaderJailMenuSelect(Player $officer, array $online): void {
        $main = Main::getInstance();
        $form = new SimpleForm(function (Player $player, ?int $data) use ($online, $main) {
            if ($data === null) return;
            if (!isset($online[$data])) return;
            $targetName = $online[$data];
            self::openLeaderJailMenu($player, $targetName);
        });
        $form->setTitle("§l§cСПЕЦОПЕРАЦИЯ");
        $form->setContent("§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n§l§fВыберите заключённого:\n§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯");
        foreach ($online as $name) {
            $remaining = $main->getJailRemainingTime($name);
            $fio = $main->getFio($name);
            $form->addButton("§l{$name}\n§r§l§7{$fio} | " . $main->formatTime($remaining));
        }
        $officer->sendForm($form);
    }

}
