<?php

declare(strict_types=1);

namespace InzeOwr\RcTel;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerEntityInteractEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityMotionEvent;
use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\entity\Location;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;
use pocketmine\world\Position;
use pocketmine\math\Vector3;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener {

    private static Main $instance;

    private Config $phoneData;
    private Config $bankData;
    private Config $transferData;
    private Config $smsData;
    private Config $depositData;
    private Config $npcData;
    private Config $transferLog;

    /** @var array<string, string> */
    private array $pinSessions = [];

    private array $taxiCategories = [
        "public" => ["name" => "Общественные места", "desc" => "ЗАГС, Авто-школа, Военкомат, Парк, Вокзал, Церковь, Автосалон"],
        "government" => ["name" => "Гос. организации", "desc" => "Правительство, Суд, Прокуратура, Полиция, Больница, Армия, СМИ"],
        "entertainment" => ["name" => "Развлечения", "desc" => "Бар (Мафия), Казино"],
        "jobs" => ["name" => "Подработки", "desc" => "Лесопилка, Шахта, Магазин, Ферма, Столовая, Кофейня"],
        "shops" => ["name" => "Магазины", "desc" => "Мебельный, Строительный, Продуктовый"]
    ];

    public function onLoad(): void {
        self::$instance = $this;
    }

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->saveResource("config.yml", false);

        @mkdir($this->getDataFolder() . "data/", 0777, true);
        $this->phoneData = new Config($this->getDataFolder() . "data/phones.json", Config::JSON);
        $this->bankData = new Config($this->getDataFolder() . "data/banks.json", Config::JSON);
        $this->transferData = new Config($this->getDataFolder() . "data/transfers.json", Config::JSON);
        $this->smsData = new Config($this->getDataFolder() . "data/sms.json", Config::JSON);
        $this->depositData = new Config($this->getDataFolder() . "data/deposits.json", Config::JSON);
        $this->npcData = new Config($this->getDataFolder() . "data/npcs.json", Config::JSON);
        $this->transferLog = new Config($this->getDataFolder() . "data/transfer_log.json", Config::JSON);

        EntityFactory::getInstance()->register(TelNPC::class, function(World $world, CompoundTag $nbt): TelNPC {
            return new TelNPC(EntityDataHelper::parseLocation($nbt, $world), TelNPC::parseSkinNBT($nbt), $nbt);
        }, ['RcTelNPC', 'rctel:npc']);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->processDeposits();
        }), 20 * 60 * 5);
    }

    public function onDisable(): void {
        $this->phoneData->save();
        $this->bankData->save();
        $this->transferData->save();
        $this->smsData->save();
        $this->depositData->save();
        $this->npcData->save();
        $this->transferLog->save();
    }

    public static function getInstance(): Main {
        return self::$instance;
    }

    // ==================== ЭКОНОМИКА ====================

    public function getMoney(string $name): float {
        $eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($eco !== null) return (float)$eco->myMoney($name);
        return 0.0;
    }

    public function takeMoney(string $name, float $amount): bool {
        $eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($eco !== null) return $eco->reduceMoney($name, $amount) === 1;
        return false;
    }

    public function addMoney(string $name, float $amount): bool {
        $eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($eco !== null) return $eco->addMoney($name, $amount) === 1;
        return false;
    }

    // ==================== ТЕЛЕФОН И СИМКА ====================

    public function hasSim(string $name): bool {
        $data = $this->phoneData->get(strtolower($name), null);
        return $data !== null && isset($data["sim"]) && $data["sim"] === true;
    }

    public function hasPhone(string $name): bool {
        $data = $this->phoneData->get(strtolower($name), null);
        return $data !== null && isset($data["phone"]) && $data["phone"] === true;
    }

    public function getPhoneNumber(string $name): string {
        $data = $this->phoneData->get(strtolower($name), null);
        return $data["number"] ?? "Нет номера";
    }

    public function getPhoneBalance(string $name): float {
        $data = $this->phoneData->get(strtolower($name), null);
        return (float)($data["balance"] ?? 0.0);
    }

    public function setPhoneBalance(string $name, float $amount): void {
        $data = $this->phoneData->get(strtolower($name), []);
        $data["balance"] = $amount;
        $this->phoneData->set(strtolower($name), $data);
        $this->phoneData->save();
    }

    public function addPhoneBalance(string $name, float $amount): void {
        $this->setPhoneBalance($name, $this->getPhoneBalance($name) + $amount);
    }

    public function takePhoneBalance(string $name, float $amount): bool {
        $current = $this->getPhoneBalance($name);
        if ($current >= $amount) {
            $this->setPhoneBalance($name, $current - $amount);
            return true;
        }
        return false;
    }

    public function getBatteryPercent(string $name): int {
        $data = $this->phoneData->get(strtolower($name), null);
        return (int)($data["battery"] ?? 100);
    }

    public function randomizeBattery(string $name): void {
        $data = $this->phoneData->get(strtolower($name), []);
        $current = $data["battery"] ?? 100;
        $change = mt_rand(-20, 15);
        $data["battery"] = max(5, min(100, $current + $change));
        $this->phoneData->set(strtolower($name), $data);
        $this->phoneData->save();
    }

    public function generatePhoneNumber(): string {
        $code = str_pad((string)mt_rand(900, 999), 3, "0", STR_PAD_LEFT);
        $p1 = str_pad((string)mt_rand(0, 999), 3, "0", STR_PAD_LEFT);
        $p2 = str_pad((string)mt_rand(0, 99), 2, "0", STR_PAD_LEFT);
        $p3 = str_pad((string)mt_rand(0, 99), 2, "0", STR_PAD_LEFT);
        return "+7 ($code) $p1-$p2-$p3";
    }

    public function buySim(Player $player): void {
        $name = $player->getName();
        $price = $this->getConfig()->get("sim-price", 600);
        if ($this->hasSim($name)) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fУ вас уже есть сим-карта.");
            return;
        }
        if ($this->getMoney($name) < $price) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств. Нужно: §e" . number_format($price) . " руб.");
            return;
        }
        $this->takeMoney($name, (float)$price);
        $number = $this->generatePhoneNumber();
        $data = $this->phoneData->get(strtolower($name), []);
        $data["sim"] = true;
        $data["number"] = $number;
        $data["balance"] = 0.0;
        $data["battery"] = 100;
        $data["contacts"] = [];
        $this->phoneData->set(strtolower($name), $data);
        $this->phoneData->save();
        $player->sendMessage("§8§l[§aRcTel§8] §r§fСим-карта приобретена! Ваш номер: §b§l" . $number);
        $player->sendMessage("§8§l[§aRcTel§8] §r§fТеперь купите телефон в салоне связи.");
    }

    public function buyPhone(Player $player): void {
        $name = $player->getName();
        $price = $this->getConfig()->get("phone-price", 1600);
        if (!$this->hasSim($name)) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fСначала купите сим-карту.");
            return;
        }
        if ($this->hasPhone($name)) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fУ вас уже есть телефон.");
            return;
        }
        if ($this->getMoney($name) < $price) {
            $player->sendMessage("§8§l[§cОшибка§8] §r§fНедостаточно средств. Нужно: §e" . number_format($price) . " руб.");
            return;
        }
        $this->takeMoney($name, (float)$price);
        $data = $this->phoneData->get(strtolower($name), []);
        $data["phone"] = true;
        $this->phoneData->set(strtolower($name), $data);
        $this->phoneData->save();
        $this->givePhoneItem($player);
        $player->sendMessage("§8§l[§aRcTel§8] §r§fТелефон приобретён! Нажмите книжкой по блоку.");
    }

    public function givePhoneItem(Player $player): void {
        $item = VanillaItems::BOOK();
        $item->setCustomName("§l§6Телефон\n§r§7Нажмите по блоку");
        $item->setLore(["§r", "§r§f§lМобильный телефон", "§r§7Нажмите по блоку для открытия", "§r", "§r§e§lRcTel §r§7by InzeOwr"]);
        $nbt = $item->getNamedTag();
        $nbt->setString("rctel_phone", "true");
        $nbt->setString("rctel_owner", $player->getName());
        $item->setNamedTag($nbt);
        $player->getInventory()->addItem($item);
    }

    public function isPhoneItem(Item $item): bool {
        return $item->getNamedTag()->getString("rctel_phone", "") === "true";
    }

    public function findPlayerByPartialName(string $partial): ?string {
        $partial = strtolower($partial);
        foreach ($this->getServer()->getOnlinePlayers() as $p) {
            if (str_starts_with(strtolower($p->getName()), $partial)) return $p->getName();
        }
        foreach ($this->phoneData->getAll() as $name => $data) {
            if (str_starts_with(strtolower((string)$name), $partial)) return (string)$name;
        }
        return null;
    }

    // ==================== КОНТАКТЫ ====================

    public function getContacts(string $name): array {
        $data = $this->phoneData->get(strtolower($name), []);
        return $data["contacts"] ?? [];
    }

    public function addContact(string $name, string $contactName): void {
        $data = $this->phoneData->get(strtolower($name), []);
        if (!isset($data["contacts"])) $data["contacts"] = [];
        $contactNumber = $this->getPhoneNumber($contactName);
        $data["contacts"][strtolower($contactName)] = ["name" => $contactName, "number" => $contactNumber, "added" => time()];
        $this->phoneData->set(strtolower($name), $data);
        $this->phoneData->save();
    }

    public function removeContact(string $name, string $contactName): void {
        $data = $this->phoneData->get(strtolower($name), []);
        if (isset($data["contacts"][strtolower($contactName)])) {
            unset($data["contacts"][strtolower($contactName)]);
            $this->phoneData->set(strtolower($name), $data);
            $this->phoneData->save();
        }
    }

    // ==================== БАНКОВСКИЕ СЧЕТА ====================

    public function getPlayerAccounts(string $name): array {
        $data = $this->bankData->get(strtolower($name), []);
        return $data["accounts"] ?? [];
    }

    public function getAccountCount(string $name): int {
        return count($this->getPlayerAccounts($name));
    }

    public function createAccount(string $name, string $accountName, string $pin): ?string {
        if ($this->getAccountCount($name) >= 3) return null;
        $accountId = "ACC-" . strtoupper(substr(md5($name . time() . mt_rand()), 0, 8));
        $data = $this->bankData->get(strtolower($name), []);
        if (!isset($data["accounts"])) $data["accounts"] = [];
        $data["accounts"][$accountId] = [
            "name" => $accountName, "pin" => $pin, "balance" => 0.0, "created" => time(),
            "frozen" => false, "frozen_by" => null, "frozen_at" => 0,
            "blocked" => false, "blocked_by" => null, "blocked_at" => 0, "blocked_until" => 0
        ];
        $this->bankData->set(strtolower($name), $data);
        $this->bankData->save();
        return $accountId;
    }

    public function getAccountBalance(string $name, string $accountId): float {
        $accounts = $this->getPlayerAccounts($name);
        return (float)($accounts[$accountId]["balance"] ?? 0.0);
    }

    public function setAccountBalance(string $name, string $accountId, float $amount): void {
        $data = $this->bankData->get(strtolower($name), []);
        if (isset($data["accounts"][$accountId])) {
            $data["accounts"][$accountId]["balance"] = $amount;
            $this->bankData->set(strtolower($name), $data);
            $this->bankData->save();
        }
    }

    public function addAccountBalance(string $name, string $accountId, float $amount): void {
        if (!$this->canOperateAccount($name, $accountId)) return;
        $this->setAccountBalance($name, $accountId, $this->getAccountBalance($name, $accountId) + $amount);
    }

    public function takeAccountBalance(string $name, string $accountId, float $amount): bool {
        if (!$this->canOperateAccount($name, $accountId)) return false;
        $current = $this->getAccountBalance($name, $accountId);
        if ($current >= $amount) {
            $this->setAccountBalance($name, $accountId, $current - $amount);
            return true;
        }
        return false;
    }

    public function verifyPin(string $name, string $accountId, string $pin): bool {
        $accounts = $this->getPlayerAccounts($name);
        return isset($accounts[$accountId]) && $accounts[$accountId]["pin"] === $pin;
    }

    public function setPinSession(string $name, string $accountId): void {
        $this->pinSessions[strtolower($name)] = $accountId;
    }

    public function hasPinSession(string $name, string $accountId): bool {
        return isset($this->pinSessions[strtolower($name)]) && $this->pinSessions[strtolower($name)] === $accountId;
    }

    public function clearPinSession(string $name): void {
        unset($this->pinSessions[strtolower($name)]);
    }

    // ==================== ЗАМОРОЗКА СЧЕТОВ (ФНС) ====================

    public function freezeAccount(string $name, string $accountId, string $frozenBy): void {
        $data = $this->bankData->get(strtolower($name), []);
        if (!isset($data["accounts"][$accountId])) return;
        $data["accounts"][$accountId]["frozen"] = true;
        $data["accounts"][$accountId]["frozen_by"] = $frozenBy;
        $data["accounts"][$accountId]["frozen_at"] = time();
        $this->bankData->set(strtolower($name), $data);
        $this->bankData->save();
    }

    public function unfreezeAccount(string $name, string $accountId): void {
        $data = $this->bankData->get(strtolower($name), []);
        if (!isset($data["accounts"][$accountId])) return;
        $data["accounts"][$accountId]["frozen"] = false;
        $data["accounts"][$accountId]["frozen_by"] = null;
        $data["accounts"][$accountId]["frozen_at"] = 0;
        $this->bankData->set(strtolower($name), $data);
        $this->bankData->save();
    }

    public function isAccountFrozen(string $name, string $accountId): bool {
        $accounts = $this->getPlayerAccounts($name);
        return (bool)($accounts[$accountId]["frozen"] ?? false);
    }

    public function getFreezeInfo(string $name, string $accountId): ?array {
        $accounts = $this->getPlayerAccounts($name);
        if (!isset($accounts[$accountId]) || !($accounts[$accountId]["frozen"] ?? false)) return null;
        return [
            "by" => $accounts[$accountId]["frozen_by"] ?? "Неизвестно",
            "at" => $accounts[$accountId]["frozen_at"] ?? 0
        ];
    }

    // ==================== БЛОКИРОВКА СЧЕТОВ (ФНС) ====================

    public function blockAccount(string $name, string $accountId, string $blockedBy, ?int $duration = null): void {
        $data = $this->bankData->get(strtolower($name), []);
        if (!isset($data["accounts"][$accountId])) return;
        $data["accounts"][$accountId]["blocked"] = true;
        $data["accounts"][$accountId]["blocked_by"] = $blockedBy;
        $data["accounts"][$accountId]["blocked_at"] = time();
        $data["accounts"][$accountId]["blocked_until"] = ($duration !== null) ? (time() + $duration) : -1;
        $this->bankData->set(strtolower($name), $data);
        $this->bankData->save();
    }

    public function unblockAccount(string $name, string $accountId): void {
        $data = $this->bankData->get(strtolower($name), []);
        if (!isset($data["accounts"][$accountId])) return;
        $data["accounts"][$accountId]["blocked"] = false;
        $data["accounts"][$accountId]["blocked_by"] = null;
        $data["accounts"][$accountId]["blocked_at"] = 0;
        $data["accounts"][$accountId]["blocked_until"] = 0;
        $this->bankData->set(strtolower($name), $data);
        $this->bankData->save();
    }

    public function isAccountBlocked(string $name, string $accountId): bool {
        $accounts = $this->getPlayerAccounts($name);
        if (!isset($accounts[$accountId])) return false;
        if (!($accounts[$accountId]["blocked"] ?? false)) return false;
        $until = $accounts[$accountId]["blocked_until"] ?? 0;
        if ($until === -1) return true;
        if ($until > 0 && $until <= time()) {
            $this->unblockAccount($name, $accountId);
            return false;
        }
        return $until > time() || $until === -1;
    }

    public function getBlockInfo(string $name, string $accountId): ?array {
        $accounts = $this->getPlayerAccounts($name);
        if (!isset($accounts[$accountId]) || !($accounts[$accountId]["blocked"] ?? false)) return null;
        $until = $accounts[$accountId]["blocked_until"] ?? 0;
        return [
            "by" => $accounts[$accountId]["blocked_by"] ?? "Неизвестно",
            "at" => $accounts[$accountId]["blocked_at"] ?? 0,
            "until" => $until,
            "permanent" => ($until === -1)
        ];
    }

    public function canOperateAccount(string $name, string $accountId): bool {
        if ($this->isAccountFrozen($name, $accountId)) return false;
        if ($this->isAccountBlocked($name, $accountId)) return false;
        return true;
    }

    public function getAccountRestrictionReason(string $name, string $accountId): ?string {
        if ($this->isAccountFrozen($name, $accountId)) return "Счёт заморожен решением ФНС";
        if ($this->isAccountBlocked($name, $accountId)) return "Счёт заблокирован решением ФНС";
        return null;
    }

    public function deleteAccountByFNS(string $name, string $accountId): float {
        $total = 0.0;
        $accounts = $this->getPlayerAccounts($name);
        if (isset($accounts[$accountId])) {
            $total += (float)($accounts[$accountId]["balance"] ?? 0.0);
        }
        $deposits = $this->getDeposits($name, $accountId);
        foreach ($deposits as $dep) {
            $total += (float)($dep["amount"] ?? 0.0);
        }
        $depData = $this->depositData->get(strtolower($name), []);
        if (isset($depData[$accountId])) {
            unset($depData[$accountId]);
            $this->depositData->set(strtolower($name), $depData);
            $this->depositData->save();
        }
        $data = $this->bankData->get(strtolower($name), []);
        if (isset($data["accounts"][$accountId])) {
            unset($data["accounts"][$accountId]);
            $this->bankData->set(strtolower($name), $data);
            $this->bankData->save();
        }
        return $total;
    }

    // ==================== ЛОГИРОВАНИЕ ПЕРЕВОДОВ ====================

    public function logTransfer(string $from, string $to, float $amount, string $type = "transfer"): void {
        $time = time();
        $fromKey = strtolower($from);
        $toKey = strtolower($to);

        $senderLogs = $this->transferLog->get($fromKey, []);
        array_unshift($senderLogs, ["dir" => "out", "with" => $to, "sum" => $amount, "type" => $type, "t" => $time]);
        $senderLogs = array_slice($senderLogs, 0, 200);
        $this->transferLog->set($fromKey, $senderLogs);

        $receiverLogs = $this->transferLog->get($toKey, []);
        array_unshift($receiverLogs, ["dir" => "in", "with" => $from, "sum" => $amount, "type" => $type, "t" => $time]);
        $receiverLogs = array_slice($receiverLogs, 0, 200);
        $this->transferLog->set($toKey, $receiverLogs);

        $this->transferLog->save();
    }

    public function getTransferHistory(string $name, int $days = 7): array {
        $logs = $this->transferLog->get(strtolower($name), []);
        $cutoff = time() - ($days * 86400);
        $result = [];
        foreach ($logs as $entry) {
            if (($entry['t'] ?? 0) >= $cutoff) {
                $result[] = $entry;
            }
        }
        return $result;
    }

    // ==================== ДЕПОЗИТЫ ====================

    public function getDeposits(string $name, string $accountId): array {
        $data = $this->depositData->get(strtolower($name), []);
        return $data[$accountId] ?? [];
    }

    public function createDeposit(string $name, string $accountId, float $amount, int $days): bool {
        if (!$this->canOperateAccount($name, $accountId)) return false;
        if (!$this->takeAccountBalance($name, $accountId, $amount)) return false;
        $rates = $this->getConfig()->get("deposit-rates", []);
        $percent = $rates[$days]["percent"] ?? 5;
        $data = $this->depositData->get(strtolower($name), []);
        if (!isset($data[$accountId])) $data[$accountId] = [];
        $depositId = "DEP-" . strtoupper(substr(md5(time() . mt_rand()), 0, 6));
        $data[$accountId][$depositId] = [
            "amount" => $amount, "original_amount" => $amount, "percent" => $percent,
            "days" => $days, "created" => time(), "expires" => time() + ($days * 86400), "last_accrual" => time()
        ];
        $this->depositData->set(strtolower($name), $data);
        $this->depositData->save();
        return true;
    }

    public function addToDeposit(string $name, string $accountId, string $depositId, float $amount): bool {
        if (!$this->canOperateAccount($name, $accountId)) return false;
        if (!$this->takeAccountBalance($name, $accountId, $amount)) return false;
        $data = $this->depositData->get(strtolower($name), []);
        if (isset($data[$accountId][$depositId])) {
            $data[$accountId][$depositId]["amount"] += $amount;
            $this->depositData->set(strtolower($name), $data);
            $this->depositData->save();
            return true;
        }
        return false;
    }

    public function withdrawDeposit(string $name, string $accountId, string $depositId): float {
        if (!$this->canOperateAccount($name, $accountId)) return 0.0;
        $data = $this->depositData->get(strtolower($name), []);
        if (isset($data[$accountId][$depositId])) {
            $amount = $data[$accountId][$depositId]["amount"];
            unset($data[$accountId][$depositId]);
            $this->depositData->set(strtolower($name), $data);
            $this->depositData->save();
            $this->addAccountBalance($name, $accountId, $amount);
            return $amount;
        }
        return 0.0;
    }

    public function processDeposits(): void {
        $allDeposits = $this->depositData->getAll();
        $now = time();
        $changed = false;
        foreach ($allDeposits as $playerName => &$accounts) {
            foreach ($accounts as $accountId => &$deposits) {
                foreach ($deposits as $depositId => &$deposit) {
                    $daysSinceLast = (int)(($now - $deposit["last_accrual"]) / 86400);
                    if ($daysSinceLast >= 1) {
                        $dailyRate = $deposit["percent"] / $deposit["days"];
                        $interest = $deposit["amount"] * ($dailyRate / 100) * $daysSinceLast;
                        $deposit["amount"] += $interest;
                        $deposit["last_accrual"] = $now;
                        $changed = true;
                    }
                }
            }
        }
        unset($accounts, $deposits, $deposit);
        if ($changed) {
            $this->depositData->setAll($allDeposits);
            $this->depositData->save();
        }
    }

    // ==================== ТАКСИ ====================

    public function calculateTaxiPrice(Player $player, float $x, float $y, float $z, string $world): float {
        $pricePerBlock = $this->getConfig()->get("taxi-price-per-block", 0.5);
        $minPrice = $this->getConfig()->get("taxi-min-price", 50);
        if ($player->getWorld()->getFolderName() !== $world) return $minPrice * 5;
        $distance = $player->getPosition()->distance(new Vector3($x, $y, $z));
        return max($minPrice, round($distance * $pricePerBlock));
    }

    public function getTaxiCategories(): array {
        return $this->taxiCategories;
    }

    // ==================== ПЕРЕВОДЫ ====================

    public function getDailyTransferred(string $name): float {
        $data = $this->transferData->get(strtolower($name), []);
        $today = date("Y-m-d");
        if (($data["date"] ?? "") !== $today) return 0.0;
        return (float)($data["amount"] ?? 0.0);
    }

    public function addDailyTransferred(string $name, float $amount): void {
        $data = $this->transferData->get(strtolower($name), []);
        $today = date("Y-m-d");
        if (($data["date"] ?? "") !== $today) {
            $data = ["date" => $today, "amount" => 0.0, "pending" => $data["pending"] ?? []];
        }
        $data["amount"] = ($data["amount"] ?? 0.0) + $amount;
        $this->transferData->set(strtolower($name), $data);
        $this->transferData->save();
    }

    public function getRemainingLimit(string $name): float {
        $limit = $this->getConfig()->get("transfer-daily-limit", 100000);
        return max(0, $limit - $this->getDailyTransferred($name));
    }

    public function addPendingTransfer(string $target, string $from, float $amount): void {
        $data = $this->transferData->get(strtolower($target), []);
        if (!isset($data["pending"])) $data["pending"] = [];
        $data["pending"][] = ["from" => $from, "amount" => $amount, "time" => time()];
        $this->transferData->set(strtolower($target), $data);
        $this->transferData->save();

        $this->logTransfer($from, $target, $amount, "transfer");
    }

    public function getPendingTransfers(string $name): array {
        $data = $this->transferData->get(strtolower($name), []);
        return $data["pending"] ?? [];
    }

    public function clearPendingTransfers(string $name): void {
        $data = $this->transferData->get(strtolower($name), []);
        $data["pending"] = [];
        $this->transferData->set(strtolower($name), $data);
        $this->transferData->save();
    }

    public function notifyPendingTransfers(Player $player): void {
        $pending = $this->getPendingTransfers($player->getName());
        if (!empty($pending)) {
            $total = 0.0;
            foreach ($pending as $t) {
                $player->sendMessage("§8§l[§aПеревод§8] §r§fОт §b" . $t["from"] . " §f- §e" . number_format($t["amount"], 2) . " руб. §7(" . date("d.m H:i", $t["time"]) . ")");
                $total += $t["amount"];
            }
            $player->sendMessage("§8§l[§aПеревод§8] §r§fИтого: §e" . number_format($total, 2) . " руб.");
            $this->clearPendingTransfers($player->getName());
        }
    }

    // ==================== СМС ====================

    public function getSmsInbox(string $name): array {
        $data = $this->smsData->get(strtolower($name), []);
        return $data["inbox"] ?? [];
    }

    public function addSmsMessage(string $name, string $from, string $message): void {
        $data = $this->smsData->get(strtolower($name), []);
        if (!isset($data["inbox"])) $data["inbox"] = [];
        $data["inbox"][] = ["from" => $from, "message" => $message, "time" => time(), "read" => false];
        if (count($data["inbox"]) > 50) array_shift($data["inbox"]);
        $this->smsData->set(strtolower($name), $data);
        $this->smsData->save();
    }

    public function getUnreadSmsCount(string $name): int {
        $data = $this->smsData->get(strtolower($name), []);
        $count = 0;
        foreach (($data["inbox"] ?? []) as $msg) {
            if (!($msg["read"] ?? true)) $count++;
        }
        return $count;
    }

    public function markAllSmsRead(string $name): void {
        $data = $this->smsData->get(strtolower($name), []);
        if (isset($data["inbox"])) {
            foreach ($data["inbox"] as &$msg) $msg["read"] = true;
            unset($msg);
            $this->smsData->set(strtolower($name), $data);
            $this->smsData->save();
        }
    }

    public function notifyPendingSms(Player $player): void {
        if (!$this->hasSim($player->getName()) || !$this->hasPhone($player->getName())) return;
        $data = $this->smsData->get(strtolower($player->getName()), []);
        $pending = [];
        foreach (($data["inbox"] ?? []) as $msg) {
            if (!($msg["read"] ?? true)) $pending[] = $msg;
        }
        if (!empty($pending)) {
            foreach (array_slice($pending, 0, 5) as $msg) {
                $player->sendMessage("§8§l[§9СМС§8] §r§fОт §b" . $msg["from"] . "§f: §7\"" . $msg["message"] . "\" §7(" . date("d.m H:i", $msg["time"]) . ")");
            }
            if (count($pending) > 5) {
                $player->sendMessage("§8§l[§9СМС§8] §r§7И ещё " . (count($pending) - 5) . " непрочитанных.");
            }
            $this->markAllSmsRead($player->getName());
        }
    }

    // ==================== NPC ВЗАИМОДЕЙСТВИЕ ====================

    public function handleNpcInteract(Player $player, TelNPC $npc): void {
        $type = $npc->getNpcType();
        if ($type === "shop") {
            Forms::openShopMenu($player);
        } else {
            Forms::openBankMainMenu($player);
        }
    }

    // ==================== КОМАНДЫ ====================

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§c§lТолько из игры!");
            return true;
        }
        switch ($command->getName()) {
            case "rctell":
                $this->spawnNPC($sender, "shop");
                return true;
            case "rcbank":
                $this->spawnNPC($sender, "bank");
                return true;
        }
        return false;
    }

    private function spawnNPC(Player $player, string $type): void {
        $location = $player->getLocation();
        $skin = $player->getSkin();
        $nbt = CompoundTag::create();
        $nbt->setString("NpcType", $type);
        $skinTag = CompoundTag::create();
        $skinTag->setString("Name", $skin->getSkinId());
        $skinTag->setByteArray("Data", $skin->getSkinData());
        $skinTag->setByteArray("CapeData", $skin->getCapeData());
        $skinTag->setString("GeometryName", $skin->getGeometryName());
        $skinTag->setString("GeometryData", $skin->getGeometryData());
        $nbt->setTag("Skin", $skinTag);
        $entity = new TelNPC($location, $skin, $nbt);
        $entity->setNpcType($type);
        if ($type === "shop") {
            $entity->setNameTag("§l§6Салон связи\n§r§fСим-карты и телефоны\n§7Нажмите для покупки");
        } else {
            $entity->setNameTag("§l§3Банк\n§r§fФинансовые услуги\n§7Нажмите для управления");
        }
        $entity->spawnToAll();
        $npcs = $this->npcData->getAll();
        $npcs[$type . "_" . count($npcs)] = ["type" => $type, "x" => $location->getX(), "y" => $location->getY(), "z" => $location->getZ(), "world" => $location->getWorld()->getFolderName()];
        $this->npcData->setAll($npcs);
        $this->npcData->save();
        $typeName = $type === "shop" ? "салона связи" : "банка";
        $player->sendMessage("§8§l[§aRcTel§8] §r§fNPC " . $typeName . " создан!");
    }

    // ==================== СОБЫТИЯ ====================

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        if ($this->hasPhone($name) && $this->hasSim($name)) {
            $this->randomizeBattery($name);
            $hasPhoneItem = false;
            foreach ($player->getInventory()->getContents() as $item) {
                if ($this->isPhoneItem($item)) { $hasPhoneItem = true; break; }
            }
            if (!$hasPhoneItem) $this->givePhoneItem($player);
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player): void {
                if (!$player->isOnline()) return;
                $battery = $this->getBatteryPercent($player->getName());
                $batteryColor = $battery <= 20 ? "§c" : ($battery <= 50 ? "§e" : "§a");
                $player->sendMessage("§8§l[§6Телефон§8] §r§fЗаряд: " . $batteryColor . $battery . "%");
                $this->notifyPendingTransfers($player);
                $this->notifyPendingSms($player);
            }), 60);
        }
        $this->clearPinSession($name);
    }

    public function onPlayerEntityInteract(PlayerEntityInteractEvent $event): void {
        $player = $event->getPlayer();
        $entity = $event->getEntity();
        if ($entity instanceof TelNPC) $this->handleNpcInteract($player, $entity);
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        if ($this->isPhoneItem($item)) {
            $event->cancel();
            $name = $player->getName();
            if (!$this->hasSim($name)) { $player->sendMessage("§8§l[§cОшибка§8] §r§fНет сим-карты."); return; }
            if (!$this->hasPhone($name)) { $player->sendMessage("§8§l[§cОшибка§8] §r§fНет телефона."); return; }
            $owner = $item->getNamedTag()->getString("rctel_owner", "");
            if (strtolower($owner) !== strtolower($name)) { $player->sendMessage("§8§l[§cОшибка§8] §r§fЭто не ваш телефон."); return; }
            Forms::openPhoneMain($player);
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof TelNPC) {
            $event->cancel();
            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if ($damager instanceof Player) $this->handleNpcInteract($damager, $entity);
            }
        }
    }

    public function onEntityMotion(EntityMotionEvent $event): void {
        if ($event->getEntity() instanceof TelNPC) $event->cancel();
    }
}

// ==================== NPC ENTITY ====================

class TelNPC extends Human {
    private string $npcType = "shop";
    protected function getInitialSizeInfo(): EntitySizeInfo { return new EntitySizeInfo(1.8, 0.6, 1.62); }
    public static function getNetworkTypeId(): string { return "rctel:npc"; }
    public function getName(): string { return "RcTelNPC"; }
    public function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setNameTagAlwaysVisible(true);
        $this->setHasGravity(false);
        $this->setNoClientPredictions(true);
        $type = $nbt->getString("NpcType", "shop");
        $this->npcType = $type;
        if ($type === "shop") {
            $this->setNameTag("§l§6Салон связи\n§r§fСим-карты и телефоны\n§7Нажмите для покупки");
        } else {
            $this->setNameTag("§l§3Банк\n§r§fФинансовые услуги\n§7Нажмите для управления");
        }
    }
    public function getNpcType(): string { return $this->npcType; }
    public function setNpcType(string $type): void { $this->npcType = $type; }
    public function saveNBT(): CompoundTag { $nbt = parent::saveNBT(); $nbt->setString("NpcType", $this->npcType); return $nbt; }
    public static function parseSkinNBT(CompoundTag $nbt): Skin {
        $skinTag = $nbt->getCompoundTag("Skin");
        if ($skinTag !== null) {
            return new Skin($skinTag->getString("Name", "Standard_Custom"), $skinTag->getByteArray("Data", str_repeat("\x00", 8192)), $skinTag->getByteArray("CapeData", ""), $skinTag->getString("GeometryName", ""), $skinTag->getString("GeometryData", ""));
        }
        return new Skin("Standard_Custom", str_repeat("\x00", 8192));
    }
    public function attack(EntityDamageEvent $source): void { $source->cancel(); }
    public function entityBaseTick(int $tickDiff = 1): bool { $this->motion = $this->motion->withComponents(0.0, 0.0, 0.0); return parent::entityBaseTick($tickDiff); }
    public function canBeMovedByCurrents(): bool { return false; }
}
