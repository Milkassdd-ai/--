<?php

namespace InzeOwr\RcOrg\forms;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\forms\FNSForms;
use InzeOwr\RcOrg\forms\TreasuryForms;
use InzeOwr\RcOrg\forms\MafiaForms;
use InzeOwr\RcOrg\forms\ProsecutorForms;
use InzeOwr\RcOrg\systems\WantedSystem;
use InzeOwr\RcOrg\systems\ProsecutorSystem;
use InzeOwr\RcOrg\systems\FNSSystem;
use InzeOwr\RcOrg\systems\CourtSystem;

class Forms {

   public static function openJoinMenu(Player $player, string $orgKey): void {
    $api = Main::getInstance();

    if ($orgKey === "MF") {
        self::openMafiaJoinMenu($player);
        return;
    }

    $costs = $api->getConfig()->get("costs");
    if (empty($orgKey) || !isset($costs[$orgKey])) return;

    $coloredOrg = $api->getColoredOrgName($orgKey);
    $cost = $costs[$orgKey];
    $sep = "§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯";

    $totalCount = 0;
    $onlineCount = 0;
    foreach ($api->data->getAll() as $key => $data) {
        if (isset($data['org']) && $data['org'] === $orgKey) {
            $totalCount++;
            $realName = $data['real_name'] ?? $key;
            if (Server::getInstance()->getPlayerExact($realName) !== null) {
                $onlineCount++;
            }
        }
    }

    $leaderInfo = self::getOrgLeader($orgKey);

    $savedRank = $api->data->getNested(strtolower($player->getName()) . ".history.$orgKey", 0);
    $restoreStr = "";
    if ($savedRank > 0) {
        $savedRankName = $api->getRankName($orgKey, $savedRank);
        $restoreStr  = "\n{$sep}\n";
        $restoreStr .= "§a§lВосстановление: §e§l{$savedRankName} §7§l({$savedRank} ранг)\n";
        $restoreStr .= "§7§lПошлина не взимается.";
    }

    $needWeapon = ($orgKey === "FSB" || $orgKey === "MVD" || $orgKey === "GP");

    $txt  = "§6§lПриёмная комиссия\n\n";
    $txt .= "{$sep}\n";
    $txt .= "§6§lНачальник: §e§l" . $leaderInfo['fio'] . " §7§l(" . $leaderInfo['nick'] . ")\n";
    $txt .= "§6§lСотрудников: §e§l{$onlineCount} §6§lна службе §7§l/ §e§l{$totalCount} §6§lвсего\n";
    $txt .= "{$sep}\n";
    $txt .= "§6§lТребования к кандидату:\n";
    $txt .= "§e§l  Паспорт гражданина\n";
    $txt .= "§e§l  Медицинская карта\n";
    if ($needWeapon) $txt .= "§e§l  Лицензия на оружие\n";
    if ($savedRank <= 0) {
        $txt .= "{$sep}\n";
        $txt .= "§6§lПошлина за оформление: §e§l" . number_format($cost) . "\$\n";
    }
    $txt .= $restoreStr;

    $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey) {
        if ($data === 0) $api->tryJoin($player, $orgKey);
    });

    $form->setTitle("§6§l" . $api->getOrgName($orgKey));
    $form->setContent($txt);
    $form->addButton("§a§lПодписать контракт\n§7§lВступить / восстановиться");
    $form->addButton("§c§lПокинуть офис\n§7§lОтмена");
    $player->sendForm($form);
}

    public static function getOrgLeader(string $orgKey): array {
        $api = Main::getInstance();

        foreach ($api->data->getAll() as $name => $data) {
            if (isset($data['org']) && $data['org'] === $orgKey && isset($data['rank']) && $data['rank'] === 16) {
                $realName = $data['real_name'] ?? $name;
                return [
                    'nick' => $realName,
                    'fio' => $api->getFio($realName),
                    'date' => $data['join_date'] ?? "Неизвестно"
                ];
            }
        }

        return [
            'nick' => "Вакансия",
            'fio' => "Должность вакантна",
            'date' => "-"
        ];
    }

    public static function openOrgMenu(Player $player, string $orgKey): void {
    $api = Main::getInstance();

    if ($orgKey === "MF") {
        self::openMafiaMenu($player);
        return;
    }

    $rank = $api->getPlayerRank($player->getName());
    $dispRank = $api->getDisplayRank($player->getName());
    $realRankName = $api->getRealRankName($player->getName());
    $coloredOrg = $api->getColoredOrgName($orgKey);
    $orgColor = "§" . $api->getOrgColor($orgKey, $rank);
    $perms = $api->getConfig()->get("permissions");

    $msg = $api->getOrgMessage($orgKey);

    $leaderInfo = self::getOrgLeader($orgKey);
    $sep = "§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯";

    $totalCount = 0;
    $onlineCount = 0;
    foreach ($api->data->getAll() as $key => $data) {
        if (isset($data['org']) && $data['org'] === $orgKey) {
            $totalCount++;
            $realName = $data['real_name'] ?? $key;
            if (Server::getInstance()->getPlayerExact($realName) !== null) {
                $onlineCount++;
            }
        }
    }

    $strikesStr = "";
    $strikesCount = 0;
    if ($orgKey !== "GP") {
        $strikesCount = $api->getProsecutorSystem()->getStrikes($orgKey);
        if ($strikesCount <= 0) {
            $strikesStr = "\n§a§lВыговоров: §e§l0/3 §a§l— нарушений нет";
        } elseif ($strikesCount === 1) {
            $strikesStr = "\n§e§lВыговоров: §6§l1/3 §e§l— предупреждение";
        } elseif ($strikesCount === 2) {
            $strikesStr = "\n§c§lВыговоров: §4§l2/3 §c§l— критическое состояние";
        } else {
            $strikesStr = "\n§4§lВыговоров: §4§l{$strikesCount}/3 §c§l— грозит снятие лидера";
        }
    }

    $inspectionStr = "";
    if ($api->getProsecutorSystem()->isFrozen($orgKey)) {
        $inspectionStr = "\n\n§4§lВнимание: §c§lпроходит прокурорская проверка.\n§c§lКадровые изменения временно заблокированы.";
    }

    $content  = "§6§lСводка ведомства\n";
    $content .= "§7§l{$msg}\n\n";
    $content .= "{$sep}\n";
    $content .= "§6§lНачальник: §e§l" . $leaderInfo['fio'] . " §7§l(" . $leaderInfo['nick'] . ")\n";
    $content .= "§6§lДата назначения: §7§l" . $leaderInfo['date'] . "\n";
    $content .= "{$sep}\n";
    $content .= "§6§lСотрудников: §e§l{$onlineCount} §6§lна службе §7§l/ §e§l{$totalCount} §6§lвсего\n";
    $content .= "§6§lВаше звание: §e§l{$realRankName} §7§l({$dispRank})\n";
    $content .= $strikesStr;
    $content .= $inspectionStr;
    $treasuryBalance = $api->getTreasurySystem()->getBalance($orgKey);
$content .= "§6§lКазна: §a§l" . number_format($treasuryBalance) . "\$\n";

    $buttons = [];
    $buttons[] = ["text" => "§e§lЛичное дело\n§7§lДосье, финансы, карьера", "action" => "personal"];

    if ($rank >= 16) {
    $buttons[] = ["text" => "§6§lКазна\n§7§lУправление финансами", "action" => "treasury"];
    $buttons[] = ["text" => "§b§lНастройка организации\n§7§lИнформация и управление", "action" => "orgsettings"];
}

    if ($orgKey === "CMU" && $rank >= 10) {
        $buttons[] = ["text" => "§b§lНаписать новость\n§7§lПубликация в СМИ", "action" => "smi"];
    }

    if ($rank >= 15) {
        $buttons[] = ["text" => "§d§lРедактировать сводку\n§7§lОбновление новостей ведомства", "action" => "message"];
    }

    $buttons[] = ["text" => "§b§lБаза сотрудников\n§7§lСписок и управление", "action" => "employees"];

    if ($orgKey === "PV") {
        $fnsRank = $api->getFNSSystem()->getFNSRank($player->getName());
        if ($rank >= 16 || $fnsRank > 0) {
            $buttons[] = ["text" => "§6§lОтделы\n§7§lФНС и подразделения", "action" => "departments"];
        }
    }

    $buttons[] = ["text" => "§3§lЖурнал приказов\n§7§lИстория событий", "action" => "logs"];
    $buttons[] = ["text" => "§c§lБаза розыска\n§7§lРозыскные дела", "action" => "wanted"];

    if ($rank >= $perms['kick']) {
        $buttons[] = ["text" => "§4§lЧёрный список\n§7§lАрхив нарушителей", "action" => "blacklist"];
    }

    if ($rank >= $perms['assemble']) {
        $buttons[] = ["text" => "§6§lОбъявить сбор\n§7§lОбщее построение", "action" => "assemble"];
    }

    if ($rank >= 17 && $orgKey !== "GP" && $strikesCount > 0) {
        $buttons[] = ["text" => "§d§lСнять выговор\n§7§lОтменить взыскание ({$strikesCount}/3)", "action" => "removestrike"];
    }

    $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $buttons) {
        if ($data === null) return;
        $action = $buttons[$data]['action'] ?? null;
        switch ($action) {
            case 'personal':     self::openPersonalFile($player, $orgKey); break;
            case 'employees':    self::openEmployeeList($player, $orgKey); break;
            case 'departments':  FNSForms::openDepartmentsMenu($player); break;
            case 'logs':         self::openLogs($player, $orgKey); break;
            case 'blacklist':    self::openBlacklistMenu($player); break;
            case 'assemble':     $api->assembleOrg($player, $orgKey); break;
            case 'message':      self::openMessageForm($player, $orgKey); break;
            case 'smi':          self::openSmiForm($player, $orgKey); break;
            case 'removestrike': ProsecutorForms::openRemoveStrikeMenu($player, $orgKey); break;
            case 'wanted':       self::openWantedList($player, $orgKey); break;
            case 'treasury':     TreasuryForms::openTreasuryMenu($player, $orgKey); break;
            case 'orgsettings': self::openOrgSettingsMenu($player, $orgKey); break;
        }
    });

    $form->setTitle("§6§l" . $api->getOrgName($orgKey));
    $form->setContent($content);
    foreach ($buttons as $btn) $form->addButton($btn['text']);
    $player->sendForm($form);
}

    public static function openGovOrgList(Player $player): void {
        $api = Main::getInstance();
        $myOrg = $api->getPlayerOrg($player->getName());
        $coloredPV = $api->getColoredOrgName("PV");

        if ($myOrg !== "PV") {
            $player->sendMessage("§c§l[Ошибка] §r§l§fДоступ только для сотрудников {$coloredPV}§f.");
            return;
        }

        $allOrgs = $api->getConfig()->get("orgs", []);
        $orgKeys = [];

        foreach ($allOrgs as $key => $name) {
            if ($key === "MF" || $key === "PV" || $key === Main::HIDDEN_ORG) continue;
            $orgKeys[] = $key;
        }

        if (empty($orgKeys)) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fНет доступных организаций.");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($orgKeys) {
            if ($data === null) return;

            if ($data === 0) {
                $orgKey = Main::getInstance()->getPlayerOrg($player->getName());
                if ($orgKey) self::openEmployeeList($player, $orgKey);
                return;
            }

            $index = $data - 1;
            if (!isset($orgKeys[$index])) return;
            self::openGovOrgEmployees($player, $orgKeys[$index]);
        });

        $form->setTitle("§l§6РЕЕСТР ОРГАНИЗАЦИЙ");
        $form->setContent("§l§fВыберите организацию для просмотра:");

        $form->addButton("§l§e← НАЗАД К СОТРУДНИКАМ");

        foreach ($orgKeys as $key) {
            $coloredOrg = $api->getColoredOrgName($key);
            $count = 0;
            foreach ($api->data->getAll() as $nick => $d) {
                if (isset($d['org']) && $d['org'] === $key) $count++;
            }
            $form->addButton("§l{$coloredOrg}\n§r§l§7Сотрудников: {$count}");
        }

        $player->sendForm($form);
    }

    public static function openGovOrgEmployees(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $all = [];

        foreach ($api->data->getAll() as $key => $data) {
            if (isset($data['org']) && $data['org'] === $orgKey) {
                $realName = $data['real_name'] ?? $key;
                $isOnline = Server::getInstance()->getPlayerExact($realName) !== null;
                $status = $isOnline ? "§a[На службе]" : "§c[Не в сети]";

                $dispRank = $api->getDisplayRank($realName);
                $all[] = ["status" => $status, "disp_rank" => $dispRank, "name" => $realName];
            }
        }

        usort($all, fn($a, $b) => $b['disp_rank'] <=> $a['disp_rank']);

        $form = new SimpleForm(function (Player $player, $data) use ($orgKey, $all) {
            if ($data === null) return;
            if ($data === 0) {
                self::openGovOrgList($player);
                return;
            }
            $index = $data - 1;
            if (!isset($all[$index])) return;
            self::openGovEmployeeProfile($player, $orgKey, $all[$index]['name']);
        });

        $form->setTitle("§l§9СОТРУДНИКИ | {$coloredOrg}");
        $form->setContent("§l§fВсего сотрудников: §e" . count($all));

        $form->addButton("§l§e← НАЗАД К ОРГАНИЗАЦИЯМ");

        foreach ($all as $emp) {
            $rName = $api->getRealRankName($emp['name']);
            $dispRank = $emp['disp_rank'];
            $form->addButton("§l{$emp['name']}\n§r§l§7{$rName} §7({$dispRank}) {$emp['status']}");
        }

        $player->sendForm($form);
    }

    public static function openGovEmployeeProfile(Player $player, string $orgKey, string $targetName): void {
        $api = Main::getInstance();
        $myRank = $api->getPlayerRank($player->getName());
        $targetOrg = $api->getPlayerOrg($targetName);
        $targetRank = $api->getPlayerRank($targetName);
        $targetFio = $api->getFio($targetName);
        $joinDate = $api->getJoinDate($targetName);
        $isOnline = Server::getInstance()->getPlayerExact($targetName) ? "§aВ сети" : "§cНе в сети";
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $coloredPV = $api->getColoredOrgName("PV");

        $dispRank = $api->getDisplayRank($targetName);
        $rName = $api->getRealRankName($targetName);

        $content = "§l§eДОСЬЕ СОТРУДНИКА:\n\n";
        $content .= "§r§l§fФИО: §b{$targetFio}\n";
        $content .= "§l§fПозывной: §7{$targetName}\n";
        $content .= "§l§fОрганизация: {$coloredOrg}\n";
        $content .= "§l§fДолжность: {$rName} §f({$dispRank})\n";
        $content .= "§l§fСтатус: {$isOnline}\n";
        $content .= "§l§fДата зачисления: §7{$joinDate}\n";

        $hasCriminal = $api->getCourtSystem()->hasCriminalRecord($targetName);
        if ($hasCriminal) {
            $content .= "\n§l§cВНИМАНИЕ: У гражданина имеется судимость!\n";
        }

        $hasWanted = $api->getWantedSystem()->hasStars($targetName);
        if ($hasWanted) {
            $stars = $api->getWantedSystem()->getStars($targetName);
            $content .= "§l§cРОЗЫСК: " . str_repeat("★", $stars) . "\n";
        }

        $buttons = [];
        $buttons[] = ["text" => "§l§e← НАЗАД К СОТРУДНИКАМ", "action" => "back"];

        $canManageGov = ($myRank >= 15 && $targetRank <= 10 && $targetName !== $player->getName());
        $canFireGov = ($myRank >= 16 && $targetRank <= 13 && $targetName !== $player->getName());

        if ($canManageGov) {
            $buttons[] = ["text" => "§l§aПОВЫСИТЬ В ЗВАНИИ\n§r§l§7Приказ {$coloredPV}", "action" => "promote"];
            $buttons[] = ["text" => "§l§eПОНИЗИТЬ В ЗВАНИИ\n§r§l§7Приказ {$coloredPV}", "action" => "demote"];
        }

        if ($canFireGov) {
            $buttons[] = ["text" => "§l§cУВОЛИТЬ\n§r§l§7Приказ {$coloredPV}", "action" => "fire"];
        }

        if ($targetOrg === "PV") {
            $fns = $api->getFNSSystem();
            $canInviteFNS = $fns->canInviteToFNS($player);
            $targetNotInFNS = !$fns->isInFNS($targetName);
            $targetHasMinRank = ($targetRank >= FNSSystem::MIN_PV_RANK);
            $notSelf = (strtolower($player->getName()) !== strtolower($targetName));

            if ($canInviteFNS && $targetNotInFNS && $targetHasMinRank && $notSelf) {
                $buttons[] = ["text" => "§l§6ПРИНЯТЬ В ФНС\n§r§l§7Федеральная Налоговая Служба", "action" => "fns_invite"];
            }
        }

        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $targetName, $buttons, $targetRank, $coloredPV) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;

            $act = $buttons[$data]['action'];

            if ($act === "back") {
                self::openGovOrgEmployees($player, $orgKey);
                return;
            }

            if ($act === "fns_invite") {
                FNSForms::openInviteToFNSConfirm($player, $targetName);
                return;
            }

            $myRank = $api->getPlayerRank($player->getName());
            $coloredOrg = $api->getColoredOrgName($orgKey);

            if ($act === "promote") {
                if ($myRank < 15) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно полномочий.");
                    return;
                }
                if ($targetRank >= 10) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§f{$coloredPV} §fможет повышать сотрудников только до 10 ранга.");
                    return;
                }
                if ($api->getCourtSystem()->hasCriminalRecord($targetName)) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНевозможно повысить сотрудника с непогашенной судимостью.");
                    return;
                }
                $newRank = $targetRank + 1;
                if ($newRank > 10) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fПовышение выше 10 ранга запрещено для {$coloredPV}§f.");
                    return;
                }
                $api->setPlayerOrg($targetName, $orgKey, $newRank);
                $newRankName = $api->getRealRankName($targetName);
                $adminRankName = $api->getRealRankName($player->getName());
                $api->addLog($orgKey, "{$coloredPV} ({$player->getName()}) повысило сотрудника {$targetName} до {$newRankName}.");
                $api->addLog("PV", "Сотрудник {$player->getName()} повысил {$targetName} ({$coloredOrg}§f) до {$newRankName}.");
                $player->sendMessage("§a§l[{$coloredPV}§a§l] §r§l§fСотрудник §e{$targetName} §fповышен до {$newRankName} §fв {$coloredOrg}§f.");
                $tPlayer = Server::getInstance()->getPlayerExact($targetName);
                if ($tPlayer) {
                    $tPlayer->sendMessage("§a§l[{$coloredPV}§a§l] §r§l§fВы повышены до {$newRankName} §fв {$coloredOrg}§f.");
                    $tPlayer->sendMessage("§l§7По распоряжению: {$adminRankName} §7{$player->getName()} ({$coloredPV}§7)");
                }
            }

            if ($act === "demote") {
                if ($myRank < 15) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно полномочий.");
                    return;
                }
                if ($targetRank > 10) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§f{$coloredPV} §fможет понижать сотрудников только до 10 ранга.");
                    return;
                }
                if ($targetRank <= 1) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fСотрудник уже на минимальном ранге.");
                    return;
                }
                $newRank = $targetRank - 1;
                $api->setPlayerOrg($targetName, $orgKey, $newRank);
                $newRankName = $api->getRealRankName($targetName);
                $adminRankName = $api->getRealRankName($player->getName());
                $api->addLog($orgKey, "{$coloredPV} ({$player->getName()}) понизило сотрудника {$targetName} до {$newRankName}.");
                $api->addLog("PV", "Сотрудник {$player->getName()} понизил {$targetName} ({$coloredOrg}§f) до {$newRankName}.");
                $player->sendMessage("§a§l[{$coloredPV}§a§l] §r§l§fСотрудник §e{$targetName} §fпонижен до {$newRankName} §fв {$coloredOrg}§f.");
                $tPlayer = Server::getInstance()->getPlayerExact($targetName);
                if ($tPlayer) {
                    $tPlayer->sendMessage("§c§l[{$coloredPV}§c§l] §r§l§fВы понижены до {$newRankName} §fв {$coloredOrg}§f.");
                    $tPlayer->sendMessage("§l§7По распоряжению: {$adminRankName} §7{$player->getName()} ({$coloredPV}§7)");
                }
            }

            if ($act === "fire") {
                if ($myRank < 16) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНедостаточно полномочий.");
                    return;
                }
                if ($targetRank > 13) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§f{$coloredPV} §fможет увольнять сотрудников только до 13 ранга.");
                    return;
                }
                $oldRankName = $api->getRealRankName($targetName);
                $adminRankName = $api->getRealRankName($player->getName());
                $api->setPlayerOrg($targetName, null);
                $api->addLog($orgKey, "{$coloredPV} ({$player->getName()}) уволило сотрудника {$targetName} ({$oldRankName}).");
                $api->addLog("PV", "Сотрудник {$player->getName()} уволил {$targetName} ({$oldRankName}) из {$coloredOrg}§f.");
                $player->sendMessage("§c§l[{$coloredPV}§c§l] §r§l§fСотрудник §e{$targetName} §f({$oldRankName}§f) уволен из {$coloredOrg}§f.");
                $tPlayer = Server::getInstance()->getPlayerExact($targetName);
                if ($tPlayer) {
                    $tPlayer->sendMessage("§c§l[{$coloredPV}§c§l] §r§l§fВы уволены из {$coloredOrg}§f.");
                    $tPlayer->sendMessage("§l§7Ваша должность: {$oldRankName}");
                    $tPlayer->sendMessage("§l§7По распоряжению: {$adminRankName} §7{$player->getName()} ({$coloredPV}§7)");
                }
            }
        });

        $form->setTitle("§l§8Досье: {$targetName}");
        $form->setContent($content);

        foreach ($buttons as $btn) {
            $form->addButton($btn['text']);
        }

        $player->sendForm($form);
    }

    public static function openEmployeeList(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $myRank = $api->getPlayerRank($player->getName());
        $all = [];

        foreach ($api->data->getAll() as $key => $data) {
            if (isset($data['org']) && $data['org'] === $orgKey) {
                $realName = $data['real_name'] ?? $key;
                $isOnline = Server::getInstance()->getPlayerExact($realName) !== null;
                $status = $isOnline ? "§a[На службе]" : "§c[Не в сети]";

                $dispRank = $api->getDisplayRank($realName);

                $all[$realName] = ["status" => $status, "disp_rank" => $dispRank, "name" => $realName];
            }
        }

        usort($all, fn($a, $b) => $b['disp_rank'] <=> $a['disp_rank']);
        $allIndexed = array_values($all);

        $buttons = [];
        $isPV = ($orgKey === "PV");

        if ($isPV) {
            $buttons[] = ["text" => "§l§6РЕЕСТР ОРГАНИЗАЦИЙ\n§r§l§7Все ведомства и сотрудники", "action" => "gov_orgs", "name" => null];
        }

        foreach ($allIndexed as $emp) {
            $rName = $api->getRealRankName($emp['name']);
            $dispRank = $emp['disp_rank'];
            $buttons[] = [
                "text" => "§l{$emp['name']}\n§r§l§7{$rName} §7({$dispRank}) {$emp['status']}",
                "action" => "profile",
                "name" => $emp['name']
            ];
        }

        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $buttons) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;

            $action = $buttons[$data]['action'];

            if ($action === "gov_orgs") {
                self::openGovOrgList($player);
                return;
            }

            if ($action === "profile") {
                $targetName = $buttons[$data]['name'];
                if ($targetName !== null) {
                    self::openEmployeeProfile($player, $orgKey, $targetName);
                }
            }
        });

        $form->setTitle("§l§9РЕЕСТР СОТРУДНИКОВ | {$coloredOrg}");
        $form->setContent("§l§fВсего сотрудников: §e" . count($allIndexed));

        foreach ($buttons as $btn) {
            $form->addButton($btn['text']);
        }

        $player->sendForm($form);
    }

    public static function openEmployeeProfile(Player $player, string $orgKey, string $targetName): void {
        $api = Main::getInstance();
        $myRank = $api->getPlayerRank($player->getName());
        $targetRank = $api->getPlayerRank($targetName);
        $targetFio = $api->getFio($targetName);
        $joinDate = $api->getJoinDate($targetName);
        $isOnline = Server::getInstance()->getPlayerExact($targetName) ? "§aВ сети" : "§cНе в сети";
        $coloredOrg = $api->getColoredOrgName($orgKey);

        $dispRank = $api->getDisplayRank($targetName);
        $rName = $api->getRealRankName($targetName);

        $content = "§l§eДОСЬЕ ГРАЖДАНИНА:\n\n";
        $content .= "§r§l§fФИО: §b$targetFio\n";
        $content .= "§l§fПозывной: §7$targetName\n";
        $content .= "§l§fОрганизация: {$coloredOrg}\n";
        $content .= "§l§fДолжность: {$rName} §f({$dispRank})\n";
        $content .= "§l§fСтатус: $isOnline\n";
        $content .= "§l§fДата зачисления: §7$joinDate\n";

        $hasCriminal = $api->getCourtSystem()->hasCriminalRecord($targetName);
        if ($hasCriminal) {
            $content .= "\n§l§cВНИМАНИЕ: У гражданина имеется судимость!\n";
        }

        $hasWanted = $api->getWantedSystem()->hasStars($targetName);
        if ($hasWanted) {
            $stars = $api->getWantedSystem()->getStars($targetName);
            $content .= "§l§cРОЗЫСК: " . str_repeat("★", $stars) . "\n";
        }

        $canManage = ($myRank >= 14 && $targetRank < 16 && $targetName !== $player->getName());

        $buttons = [];
        if ($canManage) {
            if ($myRank >= 15) $buttons[] = ["text" => "§l§cУВОЛИТЬ (KICK)\n§r§l§7Приказ о снятии", "action" => 2];
            if ($myRank >= 14) $buttons[] = ["text" => "§l§aПОВЫСИТЬ В ЗВАНИИ\n§r§l§7Приказ о назначении", "action" => 0];
            if ($myRank >= 14) $buttons[] = ["text" => "§l§eПОНИЗИТЬ В ЗВАНИИ\n§r§l§7Дисциплинарное взыскание", "action" => 1];
            if ($myRank >= 16) $buttons[] = ["text" => "§l§bСПЕЦ. НАЗНАЧЕНИЕ\n§r§l§7Внеочередное звание", "action" => 4];
            if ($myRank >= 15) $buttons[] = ["text" => "§l§4ЗАНЕСТИ В ЧС\n§r§l§cЛичное дело в архив", "action" => 3];
        }

        if ($orgKey === "PV") {
            $fns = $api->getFNSSystem();
            $canInviteFNS = $fns->canInviteToFNS($player);
            $targetNotInFNS = !$fns->isInFNS($targetName);
            $targetHasMinRank = ($targetRank >= FNSSystem::MIN_PV_RANK);
            $notSelf = (strtolower($player->getName()) !== strtolower($targetName));

            if ($canInviteFNS && $targetNotInFNS && $targetHasMinRank && $notSelf) {
                $buttons[] = ["text" => "§l§6ПРИНЯТЬ В ФНС\n§r§l§7Федеральная Налоговая Служба", "action" => "fns_invite"];
            }
        }

        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $targetName, $buttons) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;

            $act = $buttons[$data]['action'];

            if ($act === "fns_invite") {
                FNSForms::openInviteToFNSConfirm($player, $targetName);
                return;
            }

            if ($act === 0 || $act === 4) {
                if ($api->getCourtSystem()->hasCriminalRecord($targetName)) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНевозможно повысить сотрудника с непогашенной судимостью.");
                    return;
                }
                if ($api->isBlacklisted($targetName, $orgKey)) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fНевозможно повысить сотрудника, находящегося в Черном Списке.");
                    return;
                }
            }

            if ($act === 4) {
                $myRank = $api->getPlayerRank($player->getName());
                if ($myRank < 16) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fВыдача ранга доступна только с 16 ранга.");
                    return;
                }
                self::openSetRankForm($player, $orgKey, $targetName);
            } elseif ($act === 2) {
                $api->processManage($player, $orgKey, $targetName, 2);
            } elseif ($act === 3) {
                self::openBlacklistReason($player, $orgKey, $targetName);
            } else {
                $api->processManage($player, $orgKey, $targetName, $act);
            }
        });

        $form->setTitle("§l§8Личное дело: $targetName");
        $form->setContent($content);

        if (empty($buttons)) {
            $form->addButton("§l§fЗакрыть\n§r§l§7Вернуться назад");
        } else {
            foreach ($buttons as $btn) $form->addButton($btn['text']);
        }

        $player->sendForm($form);
    }

    public static function openPersonalFile(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $rank = $api->getPlayerRank($player->getName());
        $dispRank = $api->getDisplayRank($player->getName());
        $realRankName = $api->getRealRankName($player->getName());
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $fio = $api->getFio($player->getName());
        $joinDate = $api->getJoinDate($player->getName());

        $lastTime = $api->data->getNested(strtolower($player->getName()) . ".last_salary", 0);
        $diff = 900 - (time() - $lastTime);
        $salaryTime = ($diff > 0) ? "§c" . floor($diff/60)." мин. ".($diff%60)." сек." : "§aСредства готовы к выдаче";

        $nextRank = $rank + 1;
        $nextRankName = ($nextRank >= 16) ? "§6Максимальный уровень" : $api->getRankName($orgKey, $nextRank);
        $price = $api->getConfig()->get("rank_costs")[$nextRank] ?? 0;
        $priceStr = ($nextRank >= 16) ? "§7Недоступно" : "§e" . number_format($price) . "\$";

        $content = "§l§9ДОСЬЕ СОТРУДНИКА:\n\n";
        $content .= "§r§l§fФИО: §b$fio\n";
        $content .= "§l§fПозывной: §7{$player->getName()}\n";
        $content .= "§l§fОрганизация: {$coloredOrg}\n";
        $content .= "§l§fСпециальное звание: {$realRankName} §f({$dispRank})\n";
        $content .= "§l§fДата зачисления: §7$joinDate\n\n";

        $content .= "§l§6КАРЬЕРНЫЙ РОСТ:\n";
        $content .= "§r§l§fСледующее звание: §b$nextRankName\n";
        $content .= "§l§fСтоимость курсов: $priceStr\n\n";

        $content .= "§l§aБУХГАЛТЕРИЯ:\n";
        $content .= "§r§l§fСтатус выплаты: $salaryTime\n";

        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey) {
            if ($data === null) return;
            switch ($data) {
                case 0: $api->buyRank($player); break;
                case 1: $api->collectSalary($player); break;
                case 2: self::openConfirmLeaveForm($player); break;
            }
        });

        $form->setTitle("§l§eЛичное дело");
        $form->setContent($content);
        $form->addButton("§l§aОПЛАТИТЬ КУРСЫ\n§r§l§7Повышение квалификации");
        $form->addButton("§l§eПОЛУЧИТЬ ВЫПЛАТУ\n§r§l§7Забрать жалование");
        $form->addButton("§l§cРАСТОРГНУТЬ КОНТРАКТ\n§r§l§4Уволиться по С/Ж");
        $player->sendForm($form);
    }

    public static function openConfirmLeaveForm(Player $player): void {
    $api = Main::getInstance();
    $org = $api->getPlayerOrg($player->getName());
    $coloredOrg = $org ? $api->getColoredOrgName($org) : "";

    $form = new ModalForm(function (Player $player, ?bool $data) use ($api, $org, $coloredOrg) {
        if ($data === null) return;

        if ($data === true) {
            if ($org) {
                $rank = $api->getPlayerRank($player->getName());

                if ($rank >= 16) {
                    $player->sendMessage("§c§l[Ошибка] §r§l§fРуководящий состав не может уволиться по собственному желанию. Обратитесь к администрации.");
                    return;
                }

                $rankName = $api->getRealRankName($player->getName());
                $api->addLog($org, "§b§l{$player->getName()} §6§l({$rankName}§6§l) уволился по §e§lС/Ж");
            }

            $api->getFNSSystem()->clearData($player->getName());

            $api->setPlayerOrg($player->getName(), null, 1, false, false);

            if ($org) {
                $key = strtolower($player->getName());
                $api->data->removeNested("$key.history.$org");
                $api->data->save();
            }

            $player->sendMessage("§c§l[Отдел Кадров] §r§l§fВаш рапорт одобрен. Вы уволены из {$coloredOrg} §fпо собственному желанию.");
        } else {
            $player->sendMessage("§a§l[Отдел Кадров] §r§l§fВы отменили процедуру увольнения.");
        }
    });

    $form->setTitle("§l§4РАСТОРЖЕНИЕ КОНТРАКТА");
    $form->setContent(
        "§l§cВНИМАНИЕ!\n\n" .
        "§r§l§fВы инициировали процедуру увольнения из {$coloredOrg}§f.\n\n" .
        "§l§7> Ваше текущее звание будет аннулировано.\n" .
        "§l§7> ИСТОРИЯ ВАШИХ РАНГОВ БУДЕТ СТЕРТА!\n" .
        "§l§7> Восстановление возможно только с 1 ранга.\n\n" .
        "§l§fВы уверены что хотите уволиться?"
    );
    $form->setButton1("§l§cДА, УВОЛИТЬСЯ");
    $form->setButton2("§l§aНЕТ, ОСТАТЬСЯ");
    $player->sendForm($form);
}

    public static function openSmiForm(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $rank = $api->getPlayerRank($player->getName());
        $coloredOrg = $api->getColoredOrgName($orgKey);

        if ($orgKey !== "CMU") return;

        if ($rank < 10) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fДоступ к СМИ разрешен с 10-го ранга.");
            return;
        }

        $lastSmi = $api->data->getNested(strtolower($player->getName()) . ".last_smi", 0);
        $diff = 60 - (time() - $lastSmi);
        if ($diff > 0) {
            $player->sendMessage("§c§l[{$coloredOrg}§c§l] §r§l§fСледующая публикация доступна через: §e{$diff} сек.");
            return;
        }

        $form = new CustomForm(function (Player $player, $data) use ($api, $orgKey) {
            if ($data === null) return;

            $line1 = trim($data[0] ?? "");
            $line2 = trim($data[1] ?? "");
            $line3 = trim($data[2] ?? "");
            $line4 = trim($data[3] ?? "");
            $coloredOrg = $api->getColoredOrgName($orgKey);

            if (empty($line1) && empty($line2) && empty($line3) && empty($line4)) {
                $player->sendMessage("§c§l[{$coloredOrg}§c§l] §r§l§fНовость не может быть пустой.");
                return;
            }

            $lastSmi = $api->data->getNested(strtolower($player->getName()) . ".last_smi", 0);
            $diff = 60 - (time() - $lastSmi);
            if ($diff > 0) {
                $player->sendMessage("§c§l[{$coloredOrg}§c§l] §r§l§fСледующая публикация доступна через: §e{$diff} сек.");
                return;
            }

            $rankName = $api->getRealRankName($player->getName());

            $lines = [];
            if (!empty($line1)) $lines[] = $line1;
            if (!empty($line2)) $lines[] = $line2;
            if (!empty($line3)) $lines[] = $line3;
            if (!empty($line4)) $lines[] = $line4;
            $newsText = implode("\n§r§l§f", $lines);

            $broadcast = "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
            $broadcast .= "§l§9[СМИ] {$coloredOrg}\n";
            $broadcast .= "§r§l§fОт: {$rankName} §f{$player->getName()}\n";
            $broadcast .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
            $broadcast .= "§r§l§f{$newsText}\n";
            $broadcast .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";

            foreach ($api->getServer()->getOnlinePlayers() as $p) {
                $p->sendMessage($broadcast);
            }

            $api->data->setNested(strtolower($player->getName()) . ".last_smi", time());
            $api->data->save();

            $api->addLog($orgKey, "Сотрудник {$player->getName()} опубликовал новость через СМИ.");
            $player->sendMessage("§a§l[{$coloredOrg}§a§l] §r§l§fНовость успешно опубликована.");
        });

        $form->setTitle("§l§9СРЕДСТВА МАССОВОЙ ИНФОРМАЦИИ");
        $form->addInput("§l§fСтрока 1:", "Заголовок новости");
        $form->addInput("§l§fСтрока 2:", "Текст (необязательно)");
        $form->addInput("§l§fСтрока 3:", "Текст (необязательно)");
        $form->addInput("§l§fСтрока 4:", "Текст (необязательно)");
        $player->sendForm($form);
    }

    public static function openBlacklistMenu(Player $player): void {
        $api = Main::getInstance();
        $org = $api->getPlayerOrg($player->getName());
        $coloredOrg = $org ? $api->getColoredOrgName($org) : "";

        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) return;
            if ($data === 0) self::openAddToBlacklist($player);
            if ($data === 1) self::openRemoveFromBlacklist($player);
        });
        $form->setTitle("§l§4АРХИВ НАРУШИТЕЛЕЙ | {$coloredOrg}");
        $form->addButton("§l§cВНЕСТИ ГРАЖДАНИНА\n§r§l§7Выдать ЧС");
        $form->addButton("§l§aРЕЕСТР ЧС\n§r§l§7Просмотр и Амнистия");
        $player->sendForm($form);
    }

    public static function openAddToBlacklist(Player $player): void {
        $api = Main::getInstance();
        $myOrg = $api->getPlayerOrg($player->getName());
        if (!$myOrg) { $player->sendMessage("§c§l[Ошибка] §r§l§fОшибка доступа."); return; }
        $coloredOrg = $api->getColoredOrgName($myOrg);

        $form = new CustomForm(function (Player $player, $data) use ($myOrg) {
            if ($data === null) return;
            $target = trim($data[0] ?? "");
            $reason = trim($data[1] ?? "");
            if (empty($target) || empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fЗаполните все поля.");
                return;
            }
            $api = Main::getInstance();
            $api->addToBlacklist($target, $myOrg, $player->getName(), $reason);
            $coloredOrg = $api->getColoredOrgName($myOrg);
            $api->addLog($myOrg, "Руководитель {$player->getName()} занес гражданина {$target} в ЧС. Причина: $reason");
            $player->sendMessage("§c§l[Кадры] §r§l§fГражданин §e{$target} §fзанесен в Черный Список {$coloredOrg}§f.");
        });
        $form->setTitle("§l§cВнесение в базу | {$coloredOrg}");
        $form->addInput("§l§fПозывной (Ник) нарушителя:", "Steve");
        $form->addInput("§l§fОснование (Причина):", "Нарушение устава");
        $player->sendForm($form);
    }

    public static function openRemoveFromBlacklist(Player $player): void {
        $api = Main::getInstance();
        $myOrg = $api->getPlayerOrg($player->getName());
        if (!$myOrg) return;

        $coloredOrg = $api->getColoredOrgName($myOrg);

        $list = [];
        $all = $api->blacklist->getAll();

        foreach ($all as $nick => $orgs) {
            if (isset($orgs[$myOrg])) {
                $list[] = ["name" => $nick, "info" => $orgs[$myOrg]];
            }
        }

        if (empty($list)) {
            $player->sendMessage("§a§l[Архив] §r§l§fСписок нарушителей {$coloredOrg} §fчист.");
            return;
        }

        $form = new SimpleForm(function (Player $player, $data) use ($api, $myOrg, $list) {
            if ($data === null) return;
            if (!isset($list[$data])) return;
            $target = $list[$data];
            self::openBlacklistInfo($player, $target['name'], $myOrg, $target['info']);
        });

        $form->setTitle("§l§4ЧЕРНЫЙ СПИСОК | {$coloredOrg}");
        $form->setContent("§l§fВсего в ЧС: §e" . count($list));
        foreach ($list as $entry) {
            $displayName = ucfirst($entry['name']);
            $form->addButton("§l$displayName\n§r§l§c{$entry['info']['reason']}");
        }
        $player->sendForm($form);
    }

    public static function openBlacklistInfo(Player $player, string $targetName, string $org, array $info): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($org);

        $form = new SimpleForm(function (Player $player, $data) use ($targetName, $org, $coloredOrg) {
            if ($data === 0) {
                Main::getInstance()->removeFromBlacklist($targetName, $org);
                $player->sendMessage("§a§l[Архив] §r§l§fГражданин §e$targetName §fамнистирован в {$coloredOrg}§f.");
                Main::getInstance()->addLog($org, "Руководитель {$player->getName()} вынес {$targetName} из ЧС.");
            }
        });

        $form->setTitle("§l§8Дело: $targetName");
        $content = "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fНарушитель: §e$targetName\n";
        $content .= "§l§fОрганизация: {$coloredOrg}\n";
        $content .= "§l§fСотрудник, выдавший ЧС: §b{$info['by']}\n";
        $content .= "§l§fДата занесения: §7{$info['date']}\n";
        $content .= "§l§fПричина: §c{$info['reason']}\n";
        $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";

        $form->setContent($content);
        $form->addButton("§l§aАМНИСТИРОВАТЬ\n§r§l§7Убрать из базы");
        $form->addButton("§l§cЗАКРЫТЬ");
        $player->sendForm($form);
    }

    public static function openBlacklistReason(Player $player, string $orgKey, string $target): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);

        $form = new CustomForm(function (Player $player, $data) use ($orgKey, $target) {
            if ($data === null) return;
            $reason = trim($data[1] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУкажите причину занесения в ЧС.");
                return;
            }
            $api = Main::getInstance();
            $api->addToBlacklist($target, $orgKey, $player->getName(), $reason);
            $coloredOrg = $api->getColoredOrgName($orgKey);
            $api->addLog($orgKey, "Руководитель {$player->getName()} занес гражданина {$target} в ЧС. Причина: $reason");
            $player->sendMessage("§c§l[Кадры] §r§l§fГражданин §e{$target} §fзанесен в Черный Список {$coloredOrg}§f.");
        });
        $form->setTitle("§l§4ЗАНЕСЕНИЕ В ЧС: $target");
        $form->addLabel("§l§fОрганизация: {$coloredOrg}\n§l§fГражданин: §e{$target}\n\n§l§7Укажите причину и номер статьи для занесения сотрудника в Черный Список:");
        $form->addInput("§l§7Основание:", "Грубое нарушение устава 1.1");
        $player->sendForm($form);
    }

    public static function openSetRankForm(Player $player, string $orgKey, string $target): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);

        $form = new CustomForm(function (Player $player, $data) use ($target) {
            if ($data === null) return;
            $myRank = Main::getInstance()->getPlayerRank($player->getName());
            if ($myRank < 16) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fВыдача ранга доступна только с 16 ранга.");
                return;
            }
            Main::getInstance()->setRankDirect($player, $target, (int)$data[0]);
        });
        $form->setTitle("§l§bСПЕЦ. НАЗНАЧЕНИЕ: $target");
        $form->addSlider("§l§fВыберите порядковый ранг ({$coloredOrg}§f):", 1, 15, 1, 1);
        $player->sendForm($form);
    }

    public static function openMessageForm(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);

        $form = new CustomForm(function (Player $player, $data) use ($orgKey, $coloredOrg) {
            if ($data === null || empty(trim($data[0] ?? ""))) return;
            Main::getInstance()->setOrgMessage($orgKey, $data[0]);
            $player->sendMessage("§a§l[Система] §r§l§fОбъявление {$coloredOrg} §fуспешно опубликовано.");
        });
        $form->setTitle("§l§eНОВОСТИ ВЕДОМСТВА | {$coloredOrg}");
        $form->addInput("§l§fТекст объявления:", "", Main::getInstance()->getOrgMessage($orgKey));
        $player->sendForm($form);
    }

    public static function openConfiscationMenu(Player $player, string $targetName): void {
        $api = Main::getInstance();
        $org = $api->getPlayerOrg($player->getName());
        $rank = $api->getPlayerRank($player->getName());
        $coloredGB = $api->getColoredOrgName("GB");
        $isHospital = ($org === "GB" && $rank >= 14);
        $isPower = (($org === "FSB" || $org === "MVD" || $org === "GP" || $org === "GS") && $rank >= 14);

        if (!$isHospital && !$isPower) {
            $player->sendMessage("§c§l[Ошибка] §r§l§fУ вас нет прав на изъятие документов.");
            return;
        }

        $buttons = [];

        if ($isPower) {
            $buttons[] = ["type" => "lic_weapon", "name" => "Лицензию на оружие", "label" => "§l§cЛицензия на оружие"];
            $buttons[] = ["type" => "lic_drive", "name" => "Водительские права", "label" => "§l§cВодительские права"];
        }

        if ($isHospital) {
            $buttons[] = ["type" => "medcard", "name" => "Медицинскую карту", "label" => "§l§cМедицинская карта"];
        }

        $coloredOrg = $api->getColoredOrgName($org);

        $form = new SimpleForm(function (Player $player, $data) use ($targetName, $buttons) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;

            $doxc = Main::getInstance()->getServer()->getPluginManager()->getPlugin("RcDoxc");
            if (!$doxc || !$doxc->isEnabled()) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fСистема документов недоступна.");
                return;
            }

            $selected = $buttons[$data];
            self::openConfiscationReason($player, $targetName, $selected['type'], $selected['name']);
        });

        $form->setTitle("§l§cИЗЪЯТИЕ ДОКУМЕНТОВ");
        $form->setContent(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fВаше ведомство: {$coloredOrg}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§7Выберите документ для изъятия:"
        );

        foreach ($buttons as $btn) {
            $form->addButton($btn['label']);
        }

        $player->sendForm($form);
    }

    public static function openConfiscationReason(Player $player, string $targetName, string $type, string $docName): void {
        $form = new CustomForm(function (Player $player, $data) use ($targetName, $type, $docName) {
            if ($data === null) return;

            $reason = trim($data[1] ?? "");
            if (empty($reason)) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fНеобходимо указать причину изъятия.");
                return;
            }

            $api = Main::getInstance();
            $doxc = $api->getServer()->getPluginManager()->getPlugin("RcDoxc");
            if (!$doxc || !$doxc->isEnabled()) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fСистема документов недоступна.");
                return;
            }

            $hasDoc = $doxc->getDataManager()->getData($targetName, $type);
            if (!$hasDoc) {
                $player->sendMessage("§c§l[Ошибка] §r§l§fУ гражданина §e{$targetName} §fотсутствует §e{$docName}§f.");
                return;
            }

            $doxc->getDataManager()->removeData($targetName, $type);

            $org = $api->getPlayerOrg($player->getName());
            $rankName = $api->getRealRankName($player->getName());
            $coloredOrg = $api->getColoredOrgName($org);

            $player->sendMessage("§a§l[Изъятие] §r§l§fВы изъяли §e{$docName} §fу гражданина §e{$targetName}§f.");
            $player->sendMessage("§l§fПричина: §7{$reason}");

            $target = $api->getServer()->getPlayerExact($targetName);
            if ($target) {
                $target->sendMessage("§c§l[ВНИМАНИЕ] §r§l§fУ вас изъяли §e{$docName}§f!");
                $target->sendMessage("§l§fСотрудник: {$rankName} §f{$player->getName()} §7({$coloredOrg}§7)");
                $target->sendMessage("§l§fПричина: §7{$reason}");
            }

            if ($org) {
                $api->addLog($org, "Сотрудник {$player->getName()} изъял {$docName} у {$targetName}. Причина: {$reason}");
            }
        });

        $form->setTitle("§l§cИЗЪЯТИЕ: {$docName}");
        $form->addLabel(
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§fГражданин: §e{$targetName}\n" .
            "§l§fДокумент: §e{$docName}\n" .
            "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" .
            "§l§cВнимание! Действие необратимо."
        );
        $form->addInput("§l§fУкажите причину изъятия:", "Нарушение ст. 2.5 КоАП");
        $player->sendForm($form);
    }

    public static function openLogs(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $logs = $api->getLogs($orgKey);
        $form = new SimpleForm(function($p, $d){});
        $form->setTitle("§l§9ЖУРНАЛ СОБЫТИЙ | {$coloredOrg}");
        $text = implode("\n", $logs);
        $form->setContent($text ?: "§l§7Записей в журнале не обнаружено.");
        $form->addButton("§l§fЗакрыть");
        $player->sendForm($form);
    }

public static function openMafiaMenu(Player $player): void {
    $api = Main::getInstance();
    $orgKey = "MF";

    $rank = $api->getPlayerRank($player->getName());
    $dispRank = $api->getDisplayRank($player->getName());
    $realRankName = $api->getRealRankName($player->getName());
    $perms = $api->getConfig()->get("permissions");

    $msg = $api->getOrgMessage($orgKey);

    $leaderInfo = self::getOrgLeader($orgKey);
    $leaderTitle = "Главарь";
    $leaderStr = "§l§5{$leaderTitle}: §d" . $leaderInfo['fio'] . " §7(" . $leaderInfo['nick'] . ")\n§l§fВ деле с: §7" . $leaderInfo['date'];

    $content = "§5§l☠ СЕМЬЯ ☠\n\n";
    $content .= "§l§dСООБЩЕНИЕ ОТ БОССА:§r\n§l§f$msg\n\n";
    $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    $content .= "$leaderStr\n";
    $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    $content .= "§l§fТвоя кличка: §d{$realRankName} §f({$dispRank})\n";
    $content .= "§l§7Деньги решают всё. Семья — превыше всего.";

    $buttons = [];
    $buttons[] = ["text" => "§l§5МОЁ ДОСЬЕ\n§r§l§7Бабки, статус, репутация", "action" => "personal"];

    if ($rank >= 15) {
        $buttons[] = ["text" => "§l§dСООБЩЕНИЕ СЕМЬЕ\n§r§l§7Указ от босса", "action" => "message"];
    }

    $buttons[] = ["text" => "§l§cБРАТВА\n§r§l§7Список пацанов", "action" => "employees"];
    $buttons[] = ["text" => "§l§8ЛЕТОПИСЬ\n§r§l§7История дел семьи", "action" => "logs"];

    if ($rank >= 6) {
    $buttons[] = ["text" => "§l§5ЛАБОРАТОРИЯ\n§r§l§7Производство наркотиков", "action" => "lab"];
    $buttons[] = ["text" => "§l§8ТАЙНИК\n§r§l§7Ваши запасы", "action" => "stash"];
}
    if ($rank >= $perms['kick']) {
        $buttons[] = ["text" => "§l§4КРЫСЫ\n§r§l§7Чёрный список предателей", "action" => "blacklist"];
    }

    if ($rank >= $perms['assemble']) {
        $buttons[] = ["text" => "§l§6СХОДКА\n§r§l§7Собрать братву", "action" => "assemble"];
    }

    $buttons[] = ["text" => "§l§7УЙТИ В ТЕНЬ\n§r§l§8Закрыть меню", "action" => "close"];

    $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $buttons) {
        if ($data === null) return;
        $action = $buttons[$data]['action'] ?? null;
        switch ($action) {
            case 'personal': self::openMafiaPersonalFile($player); break;
            case 'employees': self::openMafiaEmployeeList($player); break;
            case 'logs': self::openMafiaLogs($player); break;
            case 'blacklist': self::openMafiaBlacklistMenu($player); break;
            case 'assemble': self::assembleMafia($player); break;
            case 'message': self::openMafiaMessageForm($player); break;
            case 'close': break;
            case 'lab': MafiaForms::openDrugCraftMenu($player); break;
case 'stash': MafiaForms::openDrugInventory($player); break;
        }
    });

    $form->setTitle("§l§5☠ Семья ☠");
    $form->setContent($content);
    foreach ($buttons as $btn) $form->addButton($btn['text']);
    $player->sendForm($form);
}

public static function openMafiaJoinMenu(Player $player): void {
    $api = Main::getInstance();
    $costs = $api->getConfig()->get("costs");
    $cost = $costs["MF"] ?? 5000;

    $form = new SimpleForm(function (Player $player, $data) use ($api) {
        if ($data === 0) $api->tryJoin($player, "MF");
    });

    $txt = "§5§l☠ ВЕРБОВКА В СЕМЬЮ ☠\n\n";
    $txt .= "§r§l§fЭй, фраерок. Слышал, ты ищешь работёнку?\n\n";
    $txt .= "§l§dУ нас всё по-простому:\n";
    $txt .= "§r§l§f• Делаешь что говорят\n";
    $txt .= "§l§f• Не сдаёшь своих\n";
    $txt .= "§l§f• Приносишь бабки в общак\n\n";
    $txt .= "§l§fВзнос в общак: §e" . number_format($cost) . "\$\n\n";
    $txt .= "§l§7[!] Если ты уже был в деле — взнос не нужен.\n\n";
    $txt .= "§l§4ПРАВИЛА:\n§r§l§7• Предашь — найдём и закопаем\n§l§7• Язык за зубами\n§l§7• Семья — это святое";

    $form->setTitle("§l§5Вербовка");
    $form->setContent($txt);
    $form->addButton("§l§5ВСТУПИТЬ В СЕМЬЮ\n§r§l§7Дать клятву верности");
    $form->addButton("§l§7Я ПЕРЕДУМАЛ\n§r§l§8Свалить отсюда");
    $player->sendForm($form);
}

public static function openMafiaPersonalFile(Player $player): void {
    $api = Main::getInstance();
    $name = $player->getName();
    $orgKey = "MF";

    $rank = $api->getPlayerRank($name);
    $rankName = $api->getRealRankName($name);
    $joinDate = $api->getJoinDate($name);
    $fio = $api->getFio($name);

    $economy = \onebone\economyapi\EconomyAPI::getInstance();
    $money = $economy->myMoney($player);

    $content = "§5§l☠ ДОСЬЕ ☠\n\n";
    $content .= "§l§fПогоняло: §d{$rankName}\n";
    $content .= "§l§fУровень: §e{$rank}\n";
    $content .= "§l§fПо паспорту: §7{$fio}\n";
    $content .= "§l§fВ семье с: §7{$joinDate}\n\n";
    $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    $content .= "§l§fБабки на кармане: §e" . number_format($money) . "\$\n";
    $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
    $content .= "§l§7Чем выше в иерархии — тем больше уважения.";

    $buttons = [];
    $buttons[] = ["text" => "§l§eПОЛУЧИТЬ ДОЛЮ\n§r§l§7Забрать свою часть", "action" => "salary"];
    $buttons[] = ["text" => "§l§6ПОДНЯТЬСЯ\n§r§l§7Купить статус выше", "action" => "buyrank"];
    $buttons[] = ["text" => "§l§cСВАЛИТЬ ИЗ СЕМЬИ\n§r§l§7Уйти на покой", "action" => "leave"];
    $buttons[] = ["text" => "§l§7НАЗАД\n§r§l§8В главное меню", "action" => "back"];

    $form = new SimpleForm(function (Player $player, $data) use ($api, $buttons) {
        if ($data === null) return;
        $action = $buttons[$data]['action'] ?? null;
        switch ($action) {
            case 'salary':
                $api->collectSalary($player);
                break;
            case 'buyrank':
                $api->buyRank($player);
                break;
            case 'leave':
                self::openMafiaLeaveConfirm($player);
                break;
            case 'back':
                self::openMafiaMenu($player);
                break;
        }
    });

    $form->setTitle("§l§5Моё досье");
    $form->setContent($content);
    foreach ($buttons as $btn) $form->addButton($btn['text']);
    $player->sendForm($form);
}

public static function openMafiaLeaveConfirm(Player $player): void {
    $api = Main::getInstance();

    $form = new ModalForm(function (Player $player, ?bool $data) use ($api) {
        if ($data === true) {
            $rank = $api->getPlayerRank($player->getName());
            if ($rank >= 16) {
                $player->sendMessage("§c§l[Семья] §r§l§fПахан не может просто так уйти. Найди преемника.");
                return;
            }
            $api->setPlayerOrg($player->getName(), null);
            $player->sendMessage("§7§l[Семья] §r§l§fТы вышел из дела. Но помни — семья не забывает...");
        } else {
            self::openMafiaPersonalFile($player);
        }
    });

    $form->setTitle("§l§4Уйти из семьи?");
    $form->setContent("§l§fТы уверен, что хочешь свалить?\n\n§l§7Путь назад будет непростым.\n§l§7Твой статус сохранится, но доверие — нет.\n\n§l§4Предателей не любят.");
    $form->setButton1("§l§4ДА, УХОЖУ");
    $form->setButton2("§l§2НЕТ, ОСТАЮСЬ");
    $player->sendForm($form);
}

public static function openMafiaEmployeeList(Player $player): void {
    $api = Main::getInstance();
    $myRank = $api->getPlayerRank($player->getName());
    $perms = $api->getConfig()->get("permissions");

    $members = [];
    $allData = $api->data->getAll();
    foreach ($allData as $name => $data) {
        if (isset($data['org']) && $data['org'] === "MF") {
            $members[] = [
                "name" => $data['real_name'] ?? $name,
                "rank" => $data['rank'] ?? 1
            ];
        }
    }

    usort($members, fn($a, $b) => $b['rank'] <=> $a['rank']);

    $content = "§5§l☠ БРАТВА ☠\n\n";
    $content .= "§l§fВсего пацанов: §d" . count($members) . "\n\n";
    $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

    foreach ($members as $m) {
        $rankName = $api->getRankName("MF", $m['rank']);
        $online = Server::getInstance()->getPlayerExact($m['name']) !== null;
        $status = $online ? "§a●" : "§c●";
        $content .= "{$status} §d{$rankName} §f— §7{$m['name']}\n";
    }

    $content .= "§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";

    $buttons = [];

    if ($myRank >= $perms['promote']) {
        $buttons[] = ["text" => "§l§6ПОВЫСИТЬ ПАЦАНА\n§r§l§7Дать статус выше", "action" => "promote"];
        $buttons[] = ["text" => "§l§eПОНИЗИТЬ ПАЦАНА\n§r§l§7Опустить по иерархии", "action" => "demote"];
    }
    if ($myRank >= $perms['kick']) {
        $buttons[] = ["text" => "§l§cВЫГНАТЬ ИЗ СЕМЬИ\n§r§l§7Убрать из дела", "action" => "kick"];
    }
    $buttons[] = ["text" => "§l§7НАЗАД\n§r§l§8В главное меню", "action" => "back"];

    $form = new SimpleForm(function (Player $player, $data) use ($buttons) {
        if ($data === null) return;
        $action = $buttons[$data]['action'] ?? null;
        switch ($action) {
            case 'promote': self::openMafiaManageForm($player, "promote"); break;
            case 'demote': self::openMafiaManageForm($player, "demote"); break;
            case 'kick': self::openMafiaManageForm($player, "kick"); break;
            case 'back': self::openMafiaMenu($player); break;
            case 'removestrike':      ProsecutorForms::openRemoveStrikeMenu($player, $orgKey); break;
        }
    });

    $form->setTitle("§l§5Братва");
    $form->setContent($content);
    foreach ($buttons as $btn) $form->addButton($btn['text']);
    $player->sendForm($form);
}

public static function openMafiaManageForm(Player $player, string $actionType): void {
    $api = Main::getInstance();

    $titles = [
        "promote" => "Повысить пацана",
        "demote" => "Понизить пацана",
        "kick" => "Выгнать из семьи"
    ];

    $form = new CustomForm(function (Player $player, ?array $data) use ($api, $actionType) {
        if ($data === null) return;

        $targetName = trim($data[0] ?? "");
        if (empty($targetName)) {
            $player->sendMessage("§c§l[Семья] §r§l§fУкажи погоняло пацана.");
            return;
        }

        $targetOrg = $api->getPlayerOrg($targetName);
        if ($targetOrg !== "MF") {
            $player->sendMessage("§c§l[Семья] §r§l§fЭтот чел не из нашей семьи.");
            return;
        }

        $reason = $data[1] ?? "";

        switch ($actionType) {
            case "promote":
                $api->processManage($player, "MF", $targetName, 0, $reason);
                break;
            case "demote":
                $api->processManage($player, "MF", $targetName, 1, $reason);
                break;
            case "kick":
                $api->processManage($player, "MF", $targetName, 2, $reason);
                break;
        }
    });

    $form->setTitle("§l§5" . ($titles[$actionType] ?? "Действие"));
    $form->addInput("§fВведи ник пацана:", "Nick");
    if ($actionType === "kick") {
        $form->addInput("§fПричина (необязательно):", "Крыса, предатель...");
    }
    $player->sendForm($form);
}

public static function openMafiaLogs(Player $player): void {
    $api = Main::getInstance();
    $logs = $api->getLogs("MF");

    $content = "§5§l☠ ЛЕТОПИСЬ СЕМЬИ ☠\n\n";

    if (empty($logs)) {
        $content .= "§l§7История семьи только начинается...";
    } else {
        foreach (array_slice($logs, 0, 20) as $log) {
            $content .= "§7• {$log}\n";
        }
    }

    $form = new SimpleForm(function (Player $player, $data) {
        if ($data === 0) self::openMafiaMenu($player);
    });

    $form->setTitle("§l§5Летопись");
    $form->setContent($content);
    $form->addButton("§l§7НАЗАД\n§r§l§8В главное меню");
    $player->sendForm($form);
}

public static function openMafiaBlacklistMenu(Player $player): void {
    $api = Main::getInstance();
    $perms = $api->getConfig()->get("permissions");
    $myRank = $api->getPlayerRank($player->getName());

    $blacklistData = $api->blacklist->getAll();
    $mfBlacklist = [];
    foreach ($blacklistData as $name => $orgs) {
        if (isset($orgs['MF'])) {
            $mfBlacklist[$name] = $orgs['MF'];
        }
    }

    $content = "§4§l☠ КРЫСЫ ☠\n\n";
    $content .= "§l§7Те, кто предал семью:\n\n";

    if (empty($mfBlacklist)) {
        $content .= "§l§aСписок чист. Пока...\n";
    } else {
        foreach ($mfBlacklist as $name => $info) {
            $content .= "§c• §f{$name}\n";
            $content .= "  §7Причина: {$info['reason']}\n";
            $content .= "  §7Внёс: {$info['by']} ({$info['date']})\n\n";
        }
    }

    $buttons = [];
    if ($myRank >= $perms['blacklist']) {
        $buttons[] = ["text" => "§l§4ДОБАВИТЬ КРЫСУ\n§r§l§7Внести в чёрный список", "action" => "add"];
        $buttons[] = ["text" => "§l§2ПРОСТИТЬ\n§r§l§7Убрать из списка", "action" => "remove"];
    }
    $buttons[] = ["text" => "§l§7НАЗАД\n§r§l§8В главное меню", "action" => "back"];

    $form = new SimpleForm(function (Player $player, $data) use ($buttons) {
        if ($data === null) return;
        $action = $buttons[$data]['action'] ?? null;
        switch ($action) {
            case 'add': self::openMafiaBlacklistAdd($player); break;
            case 'remove': self::openMafiaBlacklistRemove($player); break;
            case 'back': self::openMafiaMenu($player); break;
        }
    });

    $form->setTitle("§l§4Крысы");
    $form->setContent($content);
    foreach ($buttons as $btn) $form->addButton($btn['text']);
    $player->sendForm($form);
}

public static function openMafiaBlacklistAdd(Player $player): void {
    $api = Main::getInstance();

    $form = new CustomForm(function (Player $player, ?array $data) use ($api) {
        if ($data === null) {
            self::openMafiaBlacklistMenu($player);
            return;
        }

        $targetName = trim($data[0] ?? "");
        $reason = trim($data[1] ?? "Предательство");

        if (empty($targetName)) {
            $player->sendMessage("§c§l[Семья] §r§l§fУкажи ник крысы.");
            return;
        }

        $api->addToBlacklist($targetName, "MF", $player->getName(), $reason);
        $api->addLog("MF", "{$player->getName()} внёс {$targetName} в чёрный список. Причина: {$reason}");
        $player->sendMessage("§4§l[Семья] §r§l§f{$targetName} теперь в списке крыс.");
    });

    $form->setTitle("§l§4Добавить крысу");
    $form->addInput("§fНик предателя:", "Nick");
    $form->addInput("§fПричина:", "Сдал ментам, украл из общака...");
    $player->sendForm($form);
}

public static function openMafiaBlacklistRemove(Player $player): void {
    $api = Main::getInstance();

    $form = new CustomForm(function (Player $player, ?array $data) use ($api) {
        if ($data === null) {
            self::openMafiaBlacklistMenu($player);
            return;
        }

        $targetName = trim($data[0] ?? "");

        if (empty($targetName)) {
            $player->sendMessage("§c§l[Семья] §r§l§fУкажи ник.");
            return;
        }

        if (!$api->isBlacklisted($targetName, "MF")) {
            $player->sendMessage("§c§l[Семья] §r§l§fЭтот чел не в списке крыс.");
            return;
        }

        $api->removeFromBlacklist($targetName, "MF");
        $api->addLog("MF", "{$player->getName()} убрал {$targetName} из чёрного списка.");
        $player->sendMessage("§a§l[Семья] §r§l§f{$targetName} прощён. Пока что...");
    });

    $form->setTitle("§l§2Простить");
    $form->addInput("§fНик:", "Nick");
    $player->sendForm($form);
}

public static function openMafiaMessageForm(Player $player): void {
    $api = Main::getInstance();
    $currentMsg = $api->getOrgMessage("MF");

    $form = new CustomForm(function (Player $player, ?array $data) use ($api) {
        if ($data === null) {
            self::openMafiaMenu($player);
            return;
        }

        $newMsg = trim($data[0] ?? "");
        if (empty($newMsg)) {
            $player->sendMessage("§c§l[Семья] §r§l§fСообщение не может быть пустым.");
            return;
        }

        $api->setOrgMessage("MF", $newMsg);
        $api->addLog("MF", "{$player->getName()} обновил указ для семьи.");
        $player->sendMessage("§a§l[Семья] §r§l§fУказ обновлён. Братва увидит.");
    });

    $form->setTitle("§l§5Указ для семьи");
    $form->addInput("§fНовое сообщение:", "Сегодня делаем дело...", $currentMsg);
    $player->sendForm($form);
}

public static function assembleMafia(Player $player): void {
    $api = Main::getInstance();
    $count = 0;
    $myRankName = $api->getRealRankName($player->getName());

    foreach (Server::getInstance()->getOnlinePlayers() as $p) {
        if ($p->getName() === $player->getName()) continue;
        if ($api->getPlayerOrg($p->getName()) === "MF") {
            $p->teleport($player->getPosition());
            $p->sendMessage("§5§l[СХОДКА] §r§l§d{$myRankName} §f{$player->getName()} §7собирает братву!");
            $count++;
        }
    }

    $player->sendMessage("§5§l[Семья] §r§l§fСходка объявлена. Прибыло пацанов: §d{$count}");
}

public static function openWantedList(Player $player, string $orgKey): void {
    $api = Main::getInstance();
    if (!in_array($orgKey, Main::WANTED_VIEW_ORGS)) {
        $player->sendMessage("§c§l[Ошибка] §r§l§fБаза розыска доступна только правоохранительным органам.");
        return;
    }
    $wantedSystem = $api->getWantedSystem();

    $wantedPlayers = [];
    foreach (Server::getInstance()->getOnlinePlayers() as $p) {
        $name = $p->getName();
        if ($wantedSystem->hasStars($name)) {
            $stars = $wantedSystem->getStars($name);
            $wantedPlayers[] = ["name" => $name, "stars" => $stars];
        }
    }

    usort($wantedPlayers, fn($a, $b) => $b['stars'] <=> $a['stars']);

    $form = new SimpleForm(function (Player $player, $data) use ($api, $wantedPlayers) {
        if ($data === null) return;
        if (!isset($wantedPlayers[$data])) return;
        $target = $wantedPlayers[$data];
        self::openWantedProfile($player, $target['name']);
    });

    $form->setTitle("§6§lБаза розыска");

    if (empty($wantedPlayers)) {
        $form->setContent(
            "§6§lРозыскных дел: §e§l0\n\n" .
            "§7§lАктивных розыскных дел не обнаружено.\n" .
            "§7§lВсе граждане законопослушны."
        );
        $form->addButton("§c§lЗакрыть\n§7§lВернуться назад");
    } else {
        $form->setContent(
            "§6§lРозыскных дел: §c§l" . count($wantedPlayers) . "\n\n" .
            "§7§lНажмите на гражданина для просмотра дела."
        );
        foreach ($wantedPlayers as $w) {
            $starsStr = str_repeat("★", $w['stars']);
            $form->addButton("§c§l" . $w['name'] . "\n§7§lУровень розыска: §e§l{$starsStr} ({$w['stars']})");
        }
    }

    $player->sendForm($form);
}

public static function openWantedProfile(Player $player, string $targetName): void {
    $api = Main::getInstance();
    $wantedSystem = $api->getWantedSystem();

    if (!$wantedSystem->hasStars($targetName)) {
        $player->sendMessage("§c§l[Розыск] §r§6§lГражданин §e§l{$targetName} §6§lбольше не числится в розыске.");
        return;
    }

    $stars = $wantedSystem->getStars($targetName);
    $starsStr = str_repeat("★", $stars);
    $info = $wantedSystem->getWantedInfo($targetName);
    $reason = $info['reason'] ?? "Не указана";
    $issuedBy = $info['by'] ?? "Система";
    $date = $info['date'] ?? "Неизвестно";
    $fio = $api->getFio($targetName);
    $sep = "§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯";

    $isOnline = Server::getInstance()->getPlayerExact($targetName) !== null;
    $statusStr = $isOnline ? "§a§lВ сети" : "§c§lНе в сети";

    $content  = "{$sep}\n";
    $content .= "§6§lФИО: §b§l{$fio}\n";
    $content .= "§6§lПозывной: §7§l{$targetName}\n";
    $content .= "§6§lСтатус: {$statusStr}\n";
    $content .= "{$sep}\n";
    $content .= "§6§lУровень розыска: §c§l{$starsStr} §e§l({$stars})\n";
    $content .= "§6§lПричина: §7§l{$reason}\n";
    $content .= "§6§lВыдал: §7§l{$issuedBy}\n";
    $content .= "§6§lДата: §7§l{$date}\n";
    $content .= "{$sep}";

    $form = new SimpleForm(function (Player $player, $data) use ($api, $targetName, $isOnline) {
        if ($data === null) return;
        if ($data === 0 && $isOnline) {
            $api->getWantedSystem()->startTracking($player->getName(), $targetName);
            $player->sendMessage("§6§l[Розыск] §e§lОтслеживание гражданина §6§l{$targetName} §e§lактивировано.");
            $player->sendMessage("§7§lРасстояние отображается на экране. Для отмены перезайдите.");
        }
    });

    $form->setTitle("§6§lДело: {$targetName}");
    $form->setContent($content);

    if ($isOnline) {
        $form->addButton("§e§lОпределить местоположение\n§7§lНачать отслеживание");
    } else {
        $form->addButton("§8§lГражданин не в сети\n§7§lОтслеживание недоступно");
    }

    $player->sendForm($form);
}


    public static function openOrgSettingsMenu(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $orgName = $api->getOrgName($orgKey);
        $sep = "§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯";
        $onlineCount = 0;
        $totalCount = 0;
        foreach ($api->data->getAll() as $key => $d) {
            if (isset($d["org"]) && $d["org"] === $orgKey) {
                $totalCount++;
                if (Server::getInstance()->getPlayerExact($d["real_name"] ?? $key) !== null) $onlineCount++;
            }
        }
        $leaderInfo = self::getOrgLeader($orgKey);
        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $coloredOrg, $orgName) {
            if ($data === null) { self::openOrgMenu($player, $orgKey); return; }
            switch ($data) {
                case 0: self::openRanksInfoMenu($player, $orgKey); break;
                case 1: self::openRankBuySettingsMenu($player, $orgKey); break;
                case 2: TreasuryForms::openTreasuryMenu($player, $orgKey); break;
            }
        });
        $form->setTitle("§l§b" . $orgName . " — Настройка");
        $form->setContent(
            "{$sep}\n" .
            "§b§lНастройка: {$coloredOrg}\n" .
            "{$sep}\n" .
            "§b§lРуководитель: §e§l" . $leaderInfo["fio"] . " §7§l(" . $leaderInfo["nick"] . ")\n" .
            "§b§lСотрудников: §e§l" . $onlineCount . " §b§lна службе §7§l/ §e§l" . $totalCount . " §b§lвсего\n" .
            "{$sep}"
        );
        $form->addButton("§l§eСписок рангов и зарплат\n§r§l§7Информация о должностях");
        $form->addButton("§l§aПовышение за деньги\n§r§l§7Настройка доступных рангов");
        $form->addButton("§l§6Казна организации\n§r§l§7Управление финансами");
        $player->sendForm($form);
    }

    public static function openRanksInfoMenu(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $ranks = $api->getConfig()->get("ranks")[$orgKey] ?? [];
        $salaries = $api->getConfig()->get("salary_amount") ?? [];
        $rankCosts = $api->getConfig()->get("rank_costs") ?? [];
        $sep = "§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯";
        $content = "{$sep}\n";
        $content .= "§e§lСписок должностей: {$coloredOrg}\n";
        $content .= "{$sep}\n\n";
        foreach ($ranks as $num => $name) {
            $salary = $salaries[$num] ?? 0;
            $cost = $rankCosts[$num] ?? 0;
            $costStr = $cost > 0 ? "§7(повышение: §e" . number_format($cost) . "\$§7)" : "";
            $content .= "§l§e" . $num . ". §f" . $name . " §7— §a" . number_format($salary) . "\$ §f/ 20 мин. {$costStr}\n";
        }
        $form = new SimpleForm(function (Player $player, $data) use ($orgKey) {
            if ($data === null) { self::openOrgSettingsMenu($player, $orgKey); return; }
        });
        $form->setTitle("§l§eДолжности и зарплаты");
        $form->setContent($content);
        $form->addButton("§l§6Назад");
        $player->sendForm($form);
    }

    public static function openRankBuySettingsMenu(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $orgData = $api->orgData;
        $maxBuyRank = (int)$orgData->getNested("$orgKey.max_buy_rank", 15);
        $buyEnabled = $orgData->getNested("$orgKey.buy_enabled", true);
        $sep = "§8§l⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯";
        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $coloredOrg, $orgData, $maxBuyRank, $buyEnabled) {
            if ($data === null) { self::openOrgSettingsMenu($player, $orgKey); return; }
            if ($data === 0) {
                $newEnabled = !$buyEnabled;
                $orgData->setNested("$orgKey.buy_enabled", $newEnabled);
                $orgData->save();
                $status = $newEnabled ? "§aвключено" : "§cотключено";
                $player->sendMessage("§a§l[Настройка] §r§l§fПовышение за деньги: {$status}§f.");
                self::openRankBuySettingsMenu($player, $orgKey);
                return;
            }
            if ($data >= 1 && $data <= 14) {
                $rank = $data;
                $orgData->setNested("$orgKey.max_buy_rank", $rank);
                $orgData->save();
                $rankName = $api->getRankName($orgKey, $rank);
                $player->sendMessage("§a§l[Настройка] §r§l§fМаксимальный ранг для покупки: §e{$rankName} ({$rank})§f.");
                self::openRankBuySettingsMenu($player, $orgKey);
                return;
            }
        });
        $status = $buyEnabled ? "§aВключено" : "§cОтключено";
        $maxRankName = $api->getRankName($orgKey, $maxBuyRank);
        $form->setTitle("§l§aПовышение за деньги");
        $form->setContent(
            "{$sep}\n" .
            "§a§lПовышение за деньги: {$coloredOrg}\n" .
            "{$sep}\n" .
            "§l§fСтатус: {$status}\n" .
            "§l§fМакс. ранг для покупки: §e{$maxRankName} ({$maxBuyRank})\n" .
            "{$sep}\n" .
            "§l§7Выберите до какого ранга разрешено\n§l§7повышение за деньги (2-15), или отключите.\n" .
            "{$sep}"
        );
        $toggleText = $buyEnabled ? "§l§cОТКЛЮЧИТЬ повышение за деньги" : "§l§aВКЛЮЧИТЬ повышение за деньги";
        $form->addButton($toggleText);
        $ranks = $api->getConfig()->get("ranks")[$orgKey] ?? [];
        for ($i = 2; $i <= 15; $i++) {
            $rankName = $ranks[$i] ?? "Ранг {$i}";
            $marker = ($i <= $maxBuyRank && $buyEnabled) ? "§a✓ " : "§7";
            $form->addButton("{$marker}§l{$i}. §f{$rankName}");
        }
        $player->sendForm($form);
    }

}
