<?php

namespace InzeOwr\RcOrg\entities;

use pocketmine\entity\Human;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\world\World;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\systems\CourtSystem;

class OrgNPC extends Human {
    private string $orgTag = "";

    public function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->orgTag = $nbt->getString("org_tag", "");
        $this->setNoClientPredictions();
        $this->setNameTagAlwaysVisible(true);
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString("org_tag", $this->orgTag);
        return $nbt;
    }

    public function getOrgTag(): string {
        return $this->orgTag;
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
    }

    public function onInteract(Player $player, Vector3 $clickPos): bool {
        if ($this->orgTag === "JAIL") {
            Main::getInstance()->handleJailNpcTouch($player);
        } else {
            Main::getInstance()->handleNpcTouch($player, $this);
        }
        return true;
    }
}
