<?php

namespace InzeOwr\RcOrg\tasks;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\systems\WantedSystem;
use InzeOwr\RcOrg\systems\ItemManager;
use InzeOwr\RcOrg\systems\CuffSystem;

class TickTask extends Task {
    private Main $plugin;
    private int $tickCounter = 0;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $this->tickCounter++;

        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $name = $player->getName();

            $stars = $this->plugin->getWantedSystem()->getStars($name);
            $starStr = "";
            if ($stars > 0) {
                $starStr = "§c§lРОЗЫСК: " . str_repeat("★", $stars);
            }

            if ($this->plugin->isCuffed($name)) {
                $officerName = $this->plugin->getOfficer($name) ?? "Неизвестен";
                $player->sendTip(
                    "§c§l ВЫ ЗАДЕРЖАНЫ §r\n" .
                    "§l§fКонвоир: §e{$officerName}\n" .
                    "§l§7Следуйте за сотрудником" . ($starStr ? "\n{$starStr}" : "")
                );
                continue;
            }

            if ($this->plugin->isJailed($name)) {
                $remaining = $this->plugin->getJailRemainingTime($name);
                if ($remaining <= 0) {
                    $this->plugin->releasePlayer($name);
                    continue;
                }
                $info = $this->plugin->getJailInfo($name);
                $reason = $info['reason'] ?? 'Не указана';
                $officer = $info['officer'] ?? 'Система';
                $player->sendTip(
                    "§c§l ИЗОЛЯТОР §r\n" .
                    "§l§fОсталось: §e" . $this->plugin->formatTime($remaining) . "\n" .
                    "§l§fПричина: §7{$reason}\n" .
                    "§l§fОфицер: §7{$officer}"
                );
                continue;
            }

            if ($this->plugin->isHealing($name)) {
                if ($this->plugin->checkSelfHeal($player)) continue;
                $remaining = $this->plugin->getHealRemainingTime($name);
                if ($remaining > 0) {
                    $player->sendTip(
                        "§c§l ГОСПИТАЛИЗАЦИЯ §r\n" .
                        "§l§fДо самовыписки: §e" . $this->plugin->formatTime($remaining) . "\n" .
                        "§l§7Или дождитесь медработника"
                    );
                } else {
                    $player->sendTip(
                        "§a§l ВЫПИСКА ДОСТУПНА §r\n" .
                        "§l§fПокиньте территорию больницы"
                    );
                }
                continue;
            }

            if ($starStr !== "") {
                $player->sendTip($starStr);
            }

            if ($this->tickCounter % 30 === 0) {
                $this->plugin->getItemManager()->syncAllItems($player);
                Main::getInstance()->getCuffSystem()->onTick();
            }
        }

        $this->plugin->getWantedSystem()->tickTracking();

        if ($this->tickCounter >= 72000) {
            $this->tickCounter = 0;
        }
    }
}
