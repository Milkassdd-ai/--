<?php

declare(strict_types=1);

namespace InzeOwr\RcAuth;

use pocketmine\player\Player;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;

class FormFactory {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function sendRegisterForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) {
                $player->kick("§l§c | Регистрация обязательна");
                return;
            }

            // $data[0] = логин, $data[1] = пароль, $data[2] = подтверждение, $data[3] = почта
            // Label удалён — теперь ровно 4 элемента, массив приходит размером 4 ✓

            $login    = strtolower($data[0] ?? "");
            $pass     = $data[1] ?? "";
            $confirm  = $data[2] ?? "";
            $gmail    = $data[3] ?? "none";

            if (strlen($pass) < 4) {
                $player->sendMessage("§l§c | Слишком короткий пароль");
                $this->sendRegisterForm($player);
                return;
            }

            if ($pass !== $confirm) {
                $player->sendMessage("§l§c | Пароли не совпадают");
                $this->sendRegisterForm($player);
                return;
            }

            $nick      = strtolower($player->getName());
            $lowerPass = strtolower($pass);
            if ($lowerPass === $nick || $lowerPass === $login) {
                $player->sendMessage("§l§c | Пароль не должен совпадать с ником или логином");
                $this->sendRegisterForm($player);
                return;
            }

            $hashAlgo = defined("PASSWORD_ARGON2ID") ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
            $this->plugin->getDb()->set($nick, [
                "login"    => $data[0] ?? $player->getName(),
                "password" => password_hash($pass, $hashAlgo),
                "gmail"    => ($gmail !== "") ? $gmail : "none",
                "ip"       => $player->getNetworkSession()->getIp()
            ]);
            $this->plugin->getDb()->save();

            $this->plugin->getAuthManager()->setAuthenticated($player, true);
            $this->plugin->getAuthManager()->cancelAuthTimer($nick);
            $this->plugin->addLog($nick, "Первичная регистрация", $player->getNetworkSession()->getIp());
            $player->sendMessage("§l§a | Авторизация успешна. Приятной игры");
        });

        // Информация вынесена в заголовок — Label убран, чтобы $data всегда был размером 4
        $form->setTitle(
            "§l§9RussianCraft | Регистрация\n" .
            "§r§7Почта нужна для восстановления пароля.\n" .
            "§cНе используйте ник/логин как пароль. Мин. длина: 4 символа."
        );
        $form->addInput("§l§e | Ваш Логин\n§fЛогин лучше создавать непохожим на пароль", "§lПридумайте логин");
        $form->addInput("§l§e | Ваш Пароль",          "§lПридумайте пароль");
        $form->addInput("§l§e | Повторите Пароль",    "§lПовторите пароль");
        $form->addInput("§l§e | Почта (необязательно)", "§lВаш gmail");
        // addLabel() убран — именно он вызывал несоответствие размера массива ответа
        $player->sendForm($form);
    }

    public function sendLoginForm(Player $player, string $error = ""): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) {
                $player->kick("§l§c | Авторизуйтесь");
                return;
            }

            $nick   = strtolower($player->getName());
            $pass   = $data[0] ?? "";
            $stored = $this->plugin->getDb()->get($nick);

            if (password_verify($pass, $stored["password"])) {
                $stored["ip"] = $player->getNetworkSession()->getIp();
                $this->plugin->getDb()->set($nick, $stored);
                $this->plugin->getDb()->save();

                $this->plugin->getAuthManager()->setAuthenticated($player, true);
                $this->plugin->getAuthManager()->cancelAuthTimer($nick);
                $this->plugin->addLog($nick, "Успешный вход по паролю", $player->getNetworkSession()->getIp());
                $player->sendMessage("§l§a | Авторизация успешна. Приятной игры");
            } else {
                $rem = $this->plugin->getAuthManager()->decreaseLoginAttempts($nick);
                if ($rem <= 0) {
                    $ip = $player->getNetworkSession()->getIp();
                    $this->plugin->getBans()->set($ip, time() + 300);
                    $this->plugin->getBans()->save();
                    $this->plugin->addLog($nick, "БАН IP (3 ошибки)", $ip);
                    $player->kick("§l§c | Вы ввели неверный пароль 3 раза\n§l§7 | Ваш IP заблокирован на 5 минут");
                    return;
                }
                $this->sendLoginForm($player, "§l§c | Неверный пароль. Осталось попыток: " . $rem);
            }
        });

        $form->setTitle("§l§6RussianCraft | Вход");
        $label = $error !== "" ? $error . "\n" : "§l§f | Введите данные для входа в систему\n";
        $form->addInput($label . "§l§e | Пароль", "§lВаш пароль");
        $player->sendForm($form);
    }

    public function sendSettingsForm(Player $player): void {
        $nick   = strtolower($player->getName());
        $ipAuth = $this->plugin->getAuthManager()->isIpAuthEnabled($player);
        $status = $ipAuth ? "§aВключено" : "§cВыключено";

        $form = new SimpleForm(function (Player $player, ?int $data) use ($nick) {
            if ($data === null) {
                return;
            }
            if ($data === 0) {
                $newState = !$this->plugin->getAuthManager()->isIpAuthEnabled($player);
                $this->plugin->getAuthManager()->setIpAuthEnabled($nick, $newState);
                $msg = $newState ? "§l§a | Вход по IP включен" : "§l§c | Вход по IP выключен";
                $player->sendMessage($msg);
            } elseif ($data === 1) {
                $this->sendChangeEmailForm($player);
            }
        });

        $form->setTitle("§l§9RussianCraft | Настройки аккаунта");
        $form->setContent("§l§f | Управление привязкой и почтой");
        $form->addButton("§l§e | Вход по IP\n" . $status);
        $form->addButton("§l§b | Сменить почту");
        $form->addButton("§l§c | Закрыть");
        $player->sendForm($form);
    }

    public function sendChangeEmailForm(Player $player): void {
        $form = new CustomForm(function (Player $player, ?array $data) {
            if ($data === null) {
                return;
            }

            $pass     = $data[0] ?? "";
            $newEmail = $data[1] ?? "";
            $nick     = strtolower($player->getName());
            $stored   = $this->plugin->getDb()->get($nick);

            if (!password_verify($pass, $stored["password"])) {
                $player->sendMessage("§l§c | Неверный пароль");
                return;
            }

            $stored["gmail"] = ($newEmail !== "") ? $newEmail : "none";
            $this->plugin->getDb()->set($nick, $stored);
            $this->plugin->getDb()->save();
            $player->sendMessage("§l§a | Почта успешно изменена");
        });

        $form->setTitle("§l§9RussianCraft | Смена почты");
        $form->addInput("§l§e | Текущий пароль", "§lВаш пароль");
        $form->addInput("§l§e | Новая почта",    "§lВаш gmail");
        $player->sendForm($form);
    }
}
