<?php

declare(strict_types=1);

namespace InzeOwr\RcBan;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\scheduler\ClosureTask;
use pocketmine\player\Player;

class Main extends PluginBase {
    private const DEFAULT_MESSAGES = [
        "no_permission" => "§l§cУ вас нет прав",
        "only_players" => "§l§cТолько для игроков",
        "usage_rcban" => "§l§cИспользование: /rcban <ник> <время> [-s] <причина>",
        "usage_rcunban" => "§l§cИспользование: /rcunban <ник> [-p] <причина>",
        "usage_rcpban" => "§l§cИспользование: /rcpban <ник> [-s] <причина>",
        "usage_rcbanip" => "§l§cИспользование: /rcbanip <ник> [-s] <причина>",
        "usage_rcunbanip" => "§l§cИспользование: /rcunbanip <ник> <причина>",
        "usage_rchardban" => "§l§cИспользование: /rchardban <ник> <время> [-s] <причина>",
        "usage_rcunhardban" => "§l§cИспользование: /rcunhardban <ник> <причина>",
        "usage_rcbaninfo" => "§l§cИспользование: /rcbaninfo <ник>",
        "usage_rcbanlist" => "§l§cИспользование: /rcbanlist [страница]",
        "time_examples" => "§l§cПримеры времени: 10m, 2h, 1d, 1ms, 1g, 1g2h",
        "silent_flag_only_staff" => "§l§cФлаг -s доступен только администраторам",
        "reason_required" => "§l§cУкажите причину",
        "incorrect_time" => "§l§cУкажите корректное время",
        "player_not_found" => "§l§cИгрок не найден",
        "target_not_banned" => "§l§cИгрок не имеет блокировки аккаунта",
        "target_not_ipbanned" => "§l§cИгрок не имеет блокировки по IP",
        "target_not_hardbanned" => "§l§cИгрок не имеет хард-блокировки",
        "already_perm_banned" => "§l§cИгрок уже имеет блокировку аккаунта навсегда",
        "already_temp_banned" => "§l§cИгрок уже имеет временную блокировку до: {expire}. Блокировка будет перезаписана",
        "self_ban" => "§l§cВы не можете выдать наказание самому себе",
        "target_protected" => "§l§cВы не можете выдать наказание этому игроку",
        "cannot_ban_staff" => "§l§cВы не можете выдать наказание администратору",
        "cannot_unban_staff_ban" => "§l§cВы не можете снять наказание, выданное администратором",
        "perm_ban_only_staff_remove" => "§l§cСнятие блокировки аккаунта навсегда доступно только администраторам",
        "limited_command" => "§l§cВаша привилегия не позволяет использовать эту команду",
        "limited_time" => "§l§cМаксимальное время блокировки для вашей привилегии: {allowed}. Вы указали: {given}",
        "ban_limit_reached" => "§l§cВы исчерпали лимит блокировок ({max}). Сброс через: {remaining}",
        "ban_limit_used" => "§l§cИспользовано блокировок: {used}/{max}. Осталось: {left}. Сброс через: {remaining}",
        "ban_success" => "§l§c{issuer} выдал блокировку аккаунта игроку {target} по причине: {reason} до: {expire}",
        "ban_success_silent" => "§l§c{issuer} выдал блокировку аккаунта игроку {target} по причине: {reason} до: {expire}",
        "unban_success" => "§l§c{issuer} снял блокировку аккаунта игроку {target} по причине: {reason}",
        "unpban_success" => "§l§c{issuer} снял блокировку аккаунта навсегда игроку {target} по причине: {reason}",
        "unban_previous_admin" => "§l§c - Блокировка была выдана: {previous_issuer}",
        "pban_success" => "§l§c{issuer} выдал блокировку аккаунта навсегда игроку {target} по причине: {reason}",
        "pban_success_silent" => "§l§c{issuer} выдал блокировку аккаунта навсегда игроку {target} по причине: {reason}",
        "banip_success" => "§l§c{issuer} выдал блокировку по IP игроку {target} по причине: {reason}",
        "banip_success_silent" => "§l§c{issuer} выдал блокировку по IP игроку {target} по причине: {reason}",
        "unbanip_success" => "§l§c{issuer} снял блокировку по IP игроку {target} по причине: {reason}",
        "hardban_success" => "§l§c{issuer} выдал хард-блокировку игроку {target} по причине: {reason} до: {expire}",
        "hardban_success_silent" => "§l§c{issuer} выдал хард-блокировку игроку {target} по причине: {reason} до: {expire}",
        "unhardban_success" => "§l§c{issuer} снял хард-блокировку игроку {target} по причине: {reason}",
        "kick_temp_ban" => "§l§c{issuer} выдал вам блокировку аккаунта по причине: {reason} до: {expire}",
        "kick_perm_ban" => "§l§c{issuer} выдал вам блокировку аккаунта навсегда по причине: {reason}",
        "kick_ip_ban" => "§l§c{issuer} выдал вам блокировку по IP по причине: {reason}",
        "kick_hard_ban" => "§l§c{issuer} выдал вам хард-блокировку по причине: {reason} до: {expire}",
        "kick_banned" => "§l§cВы заблокированы на сервере",
        "kick_login_banned" => "§l§cВы заблокированы на сервере",
        "group_info" => "§l§cГруппа игрока {target}: {group}",
        "no_bans_found" => "§l§cБлокировок не найдено для игрока {target}",
        "ban_info_temp" => "§l§cБлокировка аккаунта игрока {target}\n§l§cВыдал: {issuer}\n§l§cПричина: {reason}\n§l§cДо: {expire}\n§l§cОсталось: {remaining}",
        "ban_info_perm" => "§l§cБлокировка аккаунта навсегда игрока {target}\n§l§cВыдал: {issuer}\n§l§cПричина: {reason}",
        "ban_info_ip" => "§l§cБлокировка по IP игрока {target}\n§l§cВыдал: {issuer}\n§l§cПричина: {reason}",
        "ban_info_hard" => "§l§cХард-блокировка игрока {target}\n§l§cВыдал: {issuer}\n§l§cПричина: {reason}\n§l§cДо: {expire}\n§l§cОсталось: {remaining}",
        "ban_expired_info" => "§l§cБлокировка истекла",
        "banlist_title" => "§l§cСписок блокировок (стр. {page}/{max}, всего: {total})",
        "banlist_empty" => "§l§cСписок пуст",
        "banlist_entry_ban" => "§l§c{type} {name} | {issuer} | {reason}",
        "banlist_entry_ip" => "§l§cIP {name} | {issuer} | {reason}",
        "banlist_entry_hard" => "§l§c{type} {name} | {issuer} | {reason}",
        "ban_form_title" => "§l§cБлокировка",
        "ban_form_admin" => "§l§cВыдал: {issuer}",
        "ban_form_nick" => "§l§cНикнейм: {nick}",
        "ban_form_reason" => "§l§cПричина: {reason}",
        "ban_form_expire" => "§l§cДо: {expire}",
        "ban_form_never" => "Навсегда",
        "ban_form_extra" => "§l§cНе согласны с наказанием? Вы вправе подать обжалование.",
        "ban_form_button" => "§l§cЗакрыть",
        "notify_staff_join" => "§l§cИгрок {target} находится в блокировке, заходил на сервер в {time}",
        "staff_prefix" => "§l§c",
    ];

    private Config $bansConfig;
    private Config $ipBansConfig;
    private Config $hardBansConfig;
    private Config $limitsConfig;
    private BanManager $banManager;
    private LimitManager $limitManager;
    private FormFactory $formFactory;
    private ?\InzeOwr\RcGroup\Main $rcGroup = null;

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        @mkdir($this->getDataFolder() . "data/", 0777, true);
        $this->bansConfig = new Config($this->getDataFolder() . "data/bans.json", Config::JSON);
        $this->ipBansConfig = new Config($this->getDataFolder() . "data/ipbans.json", Config::JSON);
        $this->hardBansConfig = new Config($this->getDataFolder() . "data/hardbans.json", Config::JSON);
        $this->limitsConfig = new Config($this->getDataFolder() . "data/limits.json", Config::JSON);

        $rcGroupPlugin = $this->getServer()->getPluginManager()->getPlugin("RcGroup");
        if ($rcGroupPlugin instanceof \InzeOwr\RcGroup\Main) {
            $this->rcGroup = $rcGroupPlugin;
        }

        $this->banManager = new BanManager($this);
        $this->limitManager = new LimitManager($this);
        $this->formFactory = new FormFactory($this);
        $listener = new EventListener($this);
        $this->getServer()->getPluginManager()->registerEvents($listener, $this);
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function () use ($listener): void {
            $listener->flushPending();
        }), 100);

        $this->banManager->cleanExpired();
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (): void {
            $this->banManager->cleanExpired();
        }), 20 * 300);
    }

    protected function onDisable(): void {
        $this->bansConfig->save();
        $this->ipBansConfig->save();
        $this->hardBansConfig->save();
        $this->limitsConfig->save();
    }


    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        switch (strtolower($command->getName())) {
            case "rcban":
                $this->handleBan($sender, $args);
                return true;
            case "rcunban":
                $this->handleUnban($sender, $args);
                return true;
            case "rcpban":
                $this->handlePBan($sender, $args);
                return true;
            case "rcbanip":
                $this->handleBanIP($sender, $args);
                return true;
            case "rcunbanip":
                $this->handleUnbanIP($sender, $args);
                return true;
            case "rchardban":
                $this->handleHardBan($sender, $args);
                return true;
            case "rcunhardban":
                $this->handleUnhardBan($sender, $args);
                return true;
            case "rcbaninfo":
                $this->handleBanInfo($sender, $args);
                return true;
            case "rcbanlist":
                $this->handleBanList($sender, $args);
                return true;
        }
        return false;
    }

    public function getBansConfig(): Config {
        return $this->bansConfig;
    }

    public function getIpBansConfig(): Config {
        return $this->ipBansConfig;
    }

    public function getHardBansConfig(): Config {
        return $this->hardBansConfig;
    }

    public function getLimitsConfig(): Config {
        return $this->limitsConfig;
    }

    public function getBanManager(): BanManager {
        return $this->banManager;
    }

    public function getLimitManager(): LimitManager {
        return $this->limitManager;
    }

    public function getFormFactory(): FormFactory {
        return $this->formFactory;
    }

    public function getRcGroup(): ?\InzeOwr\RcGroup\Main {
        return $this->rcGroup;
    }

    public function msg(string $key, array $r = []): string {
        $text = self::DEFAULT_MESSAGES[$key] ?? $this->getConfig()->getNested("messages." . $key, $key);
        foreach ($r as $k => $v) {
            $text = str_replace("{" . $k . "}", (string) $v, $text);
        }
        return $text;
    }

    public function formatIssuer(string $adminName): string {
        if (strcasecmp($adminName, "Console") === 0) {
            return "Администратор " . $adminName;
        }
        return ($this->getLimitManager()->isStaff($adminName) ? "Администратор " : "Игрок ") . $adminName;
    }

    public function getIssuerFromData(array $data): string {
        if (isset($data["issuer"]) && is_string($data["issuer"]) && $data["issuer"] !== "") {
            return $data["issuer"];
        }
        return $this->formatIssuer((string) ($data["admin"] ?? "—"));
    }

    public function getKickMessageForBan(array $data, string $kind = "account"): string {
        $issuer = $this->getIssuerFromData($data);
        $reason = (string) ($data["reason"] ?? "—");
        $expire = isset($data["expire"]) && (int) $data["expire"] > 0 ? $this->getBanManager()->formatTimestamp((int) $data["expire"]) : "Навсегда";

        if ($kind === "ip") {
            return $this->msg("kick_ip_ban", ["issuer" => $issuer, "reason" => $reason]);
        }
        if ($kind === "hard") {
            return $this->msg("kick_hard_ban", ["issuer" => $issuer, "reason" => $reason, "expire" => $expire]);
        }
        if (($data["type"] ?? "") === "perm") {
            return $this->msg("kick_perm_ban", ["issuer" => $issuer, "reason" => $reason]);
        }
        return $this->msg("kick_temp_ban", ["issuer" => $issuer, "reason" => $reason, "expire" => $expire]);
    }

    public function broadcast(string $message): void {
        if ($this->getConfig()->get("broadcast_bans", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    public function broadcastUnban(string $message): void {
        if ($this->getConfig()->get("broadcast_unbans", true)) {
            $this->getServer()->broadcastMessage($message);
        }
    }

    public function notifyStaff(string $message): void {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if ($this->getLimitManager()->isStaff($player->getName())) {
                $player->sendMessage($this->msg("staff_prefix") . $message);
            }
        }
    }

    public function logAction(string $message): void {
        if ($this->getConfig()->get("log_actions", true)) {
            $this->getLogger()->info(\pocketmine\utils\TextFormat::clean($message));
        }
    }


    public function parseFlags(array $args): array {
        $silent = false;
        $perm = false;
        $clean = [];
        foreach ($args as $arg) {
            $lower = strtolower($arg);
            if ($lower === "-s") { $silent = true; continue; }
            if ($lower === "-p") { $perm = true; continue; }
            $clean[] = $arg;
        }
        return ["silent" => $silent, "perm" => $perm, "args" => $clean];
    }

    public function getAdminName(CommandSender $sender): string {
        return $sender instanceof Player ? $sender->getName() : "Console";
    }

    public function handleBan(CommandSender $sender, array $args): void {
        if (count($args) < 3) {
            $sender->sendMessage($this->msg("usage_rcban"));
            $sender->sendMessage($this->msg("time_examples"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rcban")) return;

        $targetInput = array_shift($args);
        $timeStr = array_shift($args);
        $flags = $this->parseFlags($args);
        $silent = $flags["silent"];
        $reason = implode(" ", $flags["args"]);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);
        $targetName = $this->getBanManager()->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);

        if ($silent && $sender instanceof Player && !$this->getLimitManager()->isStaff($adminName)) {
            $sender->sendMessage($this->msg("silent_flag_only_staff"));
            return;
        }
        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getLimitManager()->canBanTarget($sender, $targetName)) return;

        $minutes = $this->getBanManager()->parseTime($timeStr);
        if ($minutes === null) {
            $sender->sendMessage($this->msg("incorrect_time"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedTime($sender, $minutes)) return;

        if ($this->getBansConfig()->exists($targetKey)) {
            $existing = $this->getBansConfig()->get($targetKey);
            if (isset($existing["type"])) {
                if ($existing["type"] === "perm") {
                    $sender->sendMessage($this->msg("already_perm_banned"));
                    return;
                }
                if ($existing["type"] === "temp" && isset($existing["expire"]) && $existing["expire"] > time()) {
                    $sender->sendMessage($this->msg("already_temp_banned", [
                        "expire" => $this->getBanManager()->formatTimestamp($existing["expire"]),
                    ]));
                }
            }
        }

        if (!$this->getLimitManager()->checkAndUseBanLimit($sender)) return;

        $expireTime = time() + ($minutes * 60);
        $expireStr = $this->getBanManager()->formatTimestamp($expireTime);
        $durationStr = $this->getBanManager()->normalizeTime($minutes);

        $banData = [
            "type" => "temp",
            "admin" => $adminName,
            "issuer" => $issuer,
            "reason" => $reason,
            "time" => time(),
            "expire" => $expireTime,
            "date" => $this->getBanManager()->formatTimestamp(time()),
            "duration_str" => $durationStr,
        ];

        $this->getBansConfig()->set($targetKey, $banData);
        $this->getBansConfig()->save();

        $targetPlayer = $this->getServer()->getPlayerExact($targetName) ?? $this->getBanManager()->findPlayer($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->kick($this->getKickMessageForBan($banData, "account"));
        }

        if ($silent) {
            $this->notifyStaff($this->msg("ban_success_silent", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
                "expire" => $expireStr,
                "duration" => $durationStr,
            ]));
        } else {
            $this->broadcast($this->msg("ban_success", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
                "expire" => $expireStr,
                "duration" => $durationStr,
            ]));
        }

        $this->logAction("[RcBan] " . $adminName . " выдал блокировку " . $targetName . " на " . $durationStr . ". Причина: " . $reason . ($silent ? " [тихо]" : ""));
    }

    public function handleUnban(CommandSender $sender, array $args): void {
        if (count($args) < 2) {
            $sender->sendMessage($this->msg("usage_rcunban"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rcunban")) return;

        $targetInput = array_shift($args);
        $flags = $this->parseFlags($args);
        $removePerm = $flags["perm"];
        $reason = implode(" ", $flags["args"]);
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);

        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getBansConfig()->exists($targetKey)) {
            $sender->sendMessage($this->msg("target_not_banned"));
            return;
        }

        $banData = $this->getBansConfig()->get($targetKey);
        if (isset($banData["type"]) && $banData["type"] === "perm" && !$removePerm) {
            $sender->sendMessage($this->msg("target_not_banned") . " Перманент. Добавьте -p.");
            return;
        }
        if (isset($banData["type"]) && $banData["type"] === "perm" && $removePerm) {
            if (!$this->getLimitManager()->canRemovePermBan($sender)) return;
        }
        if (!$this->getLimitManager()->checkLimitedUnban($sender, $banData)) return;

        $previousIssuer = $this->getIssuerFromData($banData);
        $this->getBansConfig()->remove($targetKey);
        $this->getBansConfig()->save();

        $unbanMessageKey = (isset($banData["type"]) && $banData["type"] === "perm") ? "unpban_success" : "unban_success";
        $this->broadcastUnban($this->msg($unbanMessageKey, [
            "issuer" => $issuer,
            "target" => $targetInput,
            "reason" => $reason,
        ]));
        $this->broadcastUnban($this->msg("unban_previous_admin", [
            "previous_issuer" => $previousIssuer,
        ]));
        $this->logAction("[RcBan] " . $adminName . " снял блокировку " . $targetInput . ". Причина: " . $reason);
    }

    public function handlePBan(CommandSender $sender, array $args): void {
        if (count($args) < 2) {
            $sender->sendMessage($this->msg("usage_rcpban"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rcpban")) return;

        $targetInput = array_shift($args);
        $flags = $this->parseFlags($args);
        $silent = $flags["silent"];
        $reason = implode(" ", $flags["args"]);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);
        $targetName = $this->getBanManager()->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);

        if ($silent && $sender instanceof Player && !$this->getLimitManager()->isStaff($adminName)) {
            $sender->sendMessage($this->msg("silent_flag_only_staff"));
            return;
        }
        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getLimitManager()->canBanTarget($sender, $targetName)) return;

        $banData = [
            "type" => "perm",
            "admin" => $adminName,
            "issuer" => $issuer,
            "reason" => $reason,
            "time" => time(),
            "expire" => -1,
            "date" => $this->getBanManager()->formatTimestamp(time()),
            "duration_str" => "Перманентно",
        ];

        $this->getBansConfig()->set($targetKey, $banData);
        $this->getBansConfig()->save();

        $targetPlayer = $this->getServer()->getPlayerExact($targetName) ?? $this->getBanManager()->findPlayer($targetInput);
        if ($targetPlayer !== null) {
            $targetPlayer->kick($this->getKickMessageForBan($banData, "account"));
        }

        if ($silent) {
            $this->notifyStaff($this->msg("pban_success_silent", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
            ]));
        } else {
            $this->broadcast($this->msg("pban_success", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
            ]));
        }

        $this->logAction("[RcBan] " . $adminName . " выдал перманентную блокировку " . $targetName . ". Причина: " . $reason . ($silent ? " [тихо]" : ""));
    }

    public function handleBanIP(CommandSender $sender, array $args): void {
        if (count($args) < 2) {
            $sender->sendMessage($this->msg("usage_rcbanip"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rcbanip")) return;

        $targetInput = array_shift($args);
        $flags = $this->parseFlags($args);
        $silent = $flags["silent"];
        $reason = implode(" ", $flags["args"]);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);
        $targetName = $this->getBanManager()->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);

        if ($silent && $sender instanceof Player && !$this->getLimitManager()->isStaff($adminName)) {
            $sender->sendMessage($this->msg("silent_flag_only_staff"));
            return;
        }
        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getLimitManager()->canBanTarget($sender, $targetName)) return;

        $ip = $this->getBanManager()->getPlayerIP($targetName);
        if ($ip === null) {
            $sender->sendMessage($this->msg("player_not_found"));
            return;
        }

        $banData = [
            "admin" => $adminName,
            "issuer" => $issuer,
            "reason" => $reason,
            "ip" => $ip,
            "time" => time(),
            "date" => $this->getBanManager()->formatTimestamp(time()),
        ];

        $this->getIpBansConfig()->set($targetKey, $banData);
        $this->getIpBansConfig()->save();

        foreach ($this->getServer()->getOnlinePlayers() as $online) {
            if ($online->getNetworkSession()->getIp() === $ip) {
                $online->kick($this->getKickMessageForBan($banData, "ip"));
            }
        }

        if ($silent) {
            $this->notifyStaff($this->msg("banip_success_silent", [
                "issuer" => $issuer,
                "target" => $targetName,
                "ip" => $ip,
                "reason" => $reason,
            ]));
        } else {
            $this->broadcast($this->msg("banip_success", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
            ]));
        }

        $this->logAction("[RcBan] " . $adminName . " IP-блокировка " . $targetName . ". Причина: " . $reason . ($silent ? " [тихо]" : ""));
    }

    public function handleUnbanIP(CommandSender $sender, array $args): void {
        if (count($args) < 2) {
            $sender->sendMessage($this->msg("usage_rcunbanip"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rcunbanip")) return;

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);

        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getIpBansConfig()->exists($targetKey)) {
            $sender->sendMessage($this->msg("target_not_ipbanned"));
            return;
        }

        $banData = $this->getIpBansConfig()->get($targetKey);
        $previousIssuer = is_array($banData) ? $this->getIssuerFromData($banData) : "—";
        if (is_array($banData) && !$this->getLimitManager()->checkLimitedUnban($sender, $banData)) return;

        $this->getIpBansConfig()->remove($targetKey);
        $this->getIpBansConfig()->save();

        $this->broadcastUnban($this->msg("unbanip_success", [
            "issuer" => $issuer,
            "target" => $targetInput,
            "reason" => $reason,
        ]));
        $this->broadcastUnban($this->msg("unban_previous_admin", [
            "previous_issuer" => $previousIssuer,
        ]));
        $this->logAction("[RcBan] " . $adminName . " снял IP-блокировку " . $targetInput . ". Причина: " . $reason);
    }

    public function handleHardBan(CommandSender $sender, array $args): void {
        if (count($args) < 3) {
            $sender->sendMessage($this->msg("usage_rchardban"));
            $sender->sendMessage($this->msg("time_examples"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rchardban")) return;

        $targetInput = array_shift($args);
        $timeStr = array_shift($args);
        $flags = $this->parseFlags($args);
        $silent = $flags["silent"];
        $reason = implode(" ", $flags["args"]);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);
        $targetName = $this->getBanManager()->resolveTargetName($targetInput);
        $targetKey = strtolower($targetName);

        if ($silent && $sender instanceof Player && !$this->getLimitManager()->isStaff($adminName)) {
            $sender->sendMessage($this->msg("silent_flag_only_staff"));
            return;
        }
        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getLimitManager()->canBanTarget($sender, $targetName)) return;

        $minutes = $this->getBanManager()->parseTime($timeStr);
        if ($minutes === null) {
            $sender->sendMessage($this->msg("incorrect_time"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedTime($sender, $minutes)) return;

        $ip = $this->getBanManager()->getPlayerIP($targetName);
        if ($ip === null) {
            $sender->sendMessage($this->msg("player_not_found"));
            return;
        }
        if (!$this->getLimitManager()->checkAndUseBanLimit($sender)) return;

        $expireTime = time() + ($minutes * 60);
        $expireStr = $this->getBanManager()->formatTimestamp($expireTime);
        $durationStr = $this->getBanManager()->normalizeTime($minutes);

        $banData = [
            "admin" => $adminName,
            "issuer" => $issuer,
            "reason" => $reason,
            "ip" => $ip,
            "time" => time(),
            "expire" => $expireTime,
            "date" => $this->getBanManager()->formatTimestamp(time()),
            "duration_str" => $durationStr,
        ];

        $this->getHardBansConfig()->set($targetKey, $banData);
        $this->getHardBansConfig()->save();

        foreach ($this->getServer()->getOnlinePlayers() as $online) {
            if ($online->getNetworkSession()->getIp() === $ip) {
                $online->kick($this->getKickMessageForBan($banData, "hard"));
            }
        }

        if ($silent) {
            $this->notifyStaff($this->msg("hardban_success_silent", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
                "expire" => $expireStr,
                "duration" => $durationStr,
            ]));
        } else {
            $this->broadcast($this->msg("hardban_success", [
                "issuer" => $issuer,
                "target" => $targetName,
                "reason" => $reason,
                "expire" => $expireStr,
                "duration" => $durationStr,
            ]));
        }

        $this->logAction("[RcBan] " . $adminName . " хард-блокировка " . $targetName . " на " . $durationStr . ". Причина: " . $reason . ($silent ? " [тихо]" : ""));
    }

    public function handleUnhardBan(CommandSender $sender, array $args): void {
        if (count($args) < 2) {
            $sender->sendMessage($this->msg("usage_rcunhardban"));
            return;
        }
        if (!$this->getLimitManager()->checkLimitedCommand($sender, "rcunhardban")) return;

        $targetInput = array_shift($args);
        $reason = implode(" ", $args);
        $targetKey = strtolower($targetInput);
        $adminName = $this->getAdminName($sender);
        $issuer = $this->formatIssuer($adminName);

        if (empty(trim($reason))) {
            $sender->sendMessage($this->msg("reason_required"));
            return;
        }
        if (!$this->getHardBansConfig()->exists($targetKey)) {
            $sender->sendMessage($this->msg("target_not_hardbanned"));
            return;
        }

        $banData = $this->getHardBansConfig()->get($targetKey);
        $previousIssuer = is_array($banData) ? $this->getIssuerFromData($banData) : "—";
        if (!$this->getLimitManager()->checkLimitedUnban($sender, $banData)) return;

        $this->getHardBansConfig()->remove($targetKey);
        $this->getHardBansConfig()->save();

        $this->broadcastUnban($this->msg("unhardban_success", [
            "issuer" => $issuer,
            "target" => $targetInput,
            "reason" => $reason,
        ]));
        $this->broadcastUnban($this->msg("unban_previous_admin", [
            "previous_issuer" => $previousIssuer,
        ]));
        $this->logAction("[RcBan] " . $adminName . " снял хард-блокировку " . $targetInput . ". Причина: " . $reason);
    }

    public function handleBanInfo(CommandSender $sender, array $args): void {
        if (count($args) < 1) {
            $sender->sendMessage($this->msg("usage_rcbaninfo"));
            return;
        }

        $target = $args[0];
        $targetKey = strtolower($target);
        $found = false;

        $group = $this->getLimitManager()->getPlayerGroup($target);
        if ($group !== "") {
            $sender->sendMessage($this->msg("group_info", [
                "target" => $target,
                "group" => $group,
            ]));
        }

        if ($this->getBansConfig()->exists($targetKey)) {
            $data = $this->getBansConfig()->get($targetKey);
            $found = true;
            if (!isset($data["type"])) goto ipCheck;

            if ($data["type"] === "temp") {
                if (time() >= ($data["expire"] ?? 0)) {
                    $sender->sendMessage($this->msg("ban_expired_info"));
                    $this->getBansConfig()->remove($targetKey);
                    $this->getBansConfig()->save();
                } else {
                    $sender->sendMessage($this->msg("ban_info_temp", [
                        "target" => $target,
                        "issuer" => $this->getIssuerFromData($data),
                        "reason" => $data["reason"] ?? "—",
                        "expire" => $this->getBanManager()->formatTimestamp($data["expire"]),
                        "remaining" => $this->getBanManager()->getTimeRemaining($data["expire"]),
                    ]));
                }
            } elseif ($data["type"] === "perm") {
                $sender->sendMessage($this->msg("ban_info_perm", [
                    "target" => $target,
                    "issuer" => $this->getIssuerFromData($data),
                    "reason" => $data["reason"] ?? "—",
                ]));
            }
        }

        ipCheck:

        if ($this->getIpBansConfig()->exists($targetKey)) {
            $data = $this->getIpBansConfig()->get($targetKey);
            $found = true;
            $sender->sendMessage($this->msg("ban_info_ip", [
                "target" => $target,
                "issuer" => $this->getIssuerFromData($data),
                "reason" => $data["reason"] ?? "—",
            ]));
        }

        if ($this->getHardBansConfig()->exists($targetKey)) {
            $data = $this->getHardBansConfig()->get($targetKey);
            $found = true;
            if (isset($data["expire"]) && time() >= $data["expire"]) {
                $sender->sendMessage($this->msg("ban_expired_info"));
                $this->getHardBansConfig()->remove($targetKey);
                $this->getHardBansConfig()->save();
            } else {
                $expireStr = isset($data["expire"]) ? $this->getBanManager()->formatTimestamp($data["expire"]) : "Никогда";
                $sender->sendMessage($this->msg("ban_info_hard", [
                    "target" => $target,
                    "issuer" => $this->getIssuerFromData($data),
                    "reason" => $data["reason"] ?? "—",
                    "expire" => $expireStr,
                    "remaining" => isset($data["expire"]) ? $this->getBanManager()->getTimeRemaining($data["expire"]) : "Навсегда",
                ]));
            }
        }

        if (!$found) {
            $sender->sendMessage($this->msg("no_bans_found", [
                "target" => $target,
            ]));
        }
    }

    public function handleBanList(CommandSender $sender, array $args): void {
        $page = isset($args[0]) && is_numeric($args[0]) ? max(1, (int) $args[0]) : 1;
        $perPage = 8;
        $allBans = [];

        foreach ($this->getBansConfig()->getAll() as $name => $data) {
            if (!isset($data["type"])) continue;
            $type = match ($data["type"]) {
                "perm" => "ПЕРМ",
                "temp" => (time() >= ($data["expire"] ?? 0)) ? "ИСТЁК" : "АКТИВ",
                default => "—",
            };
            $allBans[] = $this->msg("banlist_entry_ban", [
                "type" => $type,
                "name" => $name,
                "issuer" => $this->getIssuerFromData($data),
                "reason" => $data["reason"] ?? "—",
            ]);
        }

        foreach ($this->getIpBansConfig()->getAll() as $name => $data) {
            $allBans[] = $this->msg("banlist_entry_ip", [
                "name" => $name,
                "issuer" => $this->getIssuerFromData($data),
                "reason" => $data["reason"] ?? "—",
            ]);
        }

        foreach ($this->getHardBansConfig()->getAll() as $name => $data) {
            $expired = isset($data["expire"]) && time() >= $data["expire"];
            $type = $expired ? "ХАРД(ист.)" : "ХАРД";
            $allBans[] = $this->msg("banlist_entry_hard", [
                "type" => $type,
                "name" => $name,
                "issuer" => $this->getIssuerFromData($data),
                "reason" => $data["reason"] ?? "—",
            ]);
        }

        $total = count($allBans);
        $maxPage = max(1, (int) ceil($total / $perPage));
        $page = min($page, $maxPage);

        $sender->sendMessage($this->msg("banlist_title", [
            "page" => $page,
            "max" => $maxPage,
            "total" => $total,
        ]));

        if ($total === 0) {
            $sender->sendMessage($this->msg("banlist_empty"));
        } else {
            $offset = ($page - 1) * $perPage;
            $slice = array_slice($allBans, $offset, $perPage);
            $i = $offset + 1;
            foreach ($slice as $line) {
                $sender->sendMessage("§l§c | " . $i . ". §r§c" . $line);
                $i++;
            }
        }
    }
}