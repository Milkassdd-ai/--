<?php

namespace InzeOwr\RcOrg\forms;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\systems\TreasurySystem;

class TreasuryForms {

    public static function openTreasuryMenu(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $treasury = $api->getTreasurySystem();
        $rank = $api->getPlayerRank($player->getName());
        if ($api->getPlayerOrg($player->getName()) !== $orgKey || $rank < 16) {
            $player->sendMessage("§c§l[Казна] §r§l§fУ вас нет доступа к управлению казной.");
            return;
        }
        $balance = $treasury->getBalance($orgKey);
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $sep = "";

        $remaining = $treasury->getRemainingWithdrawLimit($player->getName());

        $content  = "§6§lОрганизация: {$coloredOrg}\n";
        $content .= "§6§lБаланс казны: §a§l" . number_format($balance) . "\$\n";
        if ($rank === 16) {
            $content .= "§6§lДоступно к снятию сегодня: §e§l" . number_format($remaining) . "\$\n";
        }
        $content .= "\n§7§lВыберите действие:";

        $buttons = [];
        $buttons[] = ["text" => "§a§lПополнить казну\n§7§lВнести средства из личного счёта", "action" => "deposit"];
        $buttons[] = ["text" => "§c§lСнять из казны\n§7§lПеревести на личный счёт", "action" => "withdraw"];
        $buttons[] = ["text" => "§e§lВыдать премию\n§7§lВсем или выборочно", "action" => "bonus"];

        if ($orgKey === "PV") {
            $buttons[] = ["text" => "§6§lФинансирование ведомств\n§7§lВыделить средства организациям", "action" => "gov_fund"];
        }
        $buttons[] = ["text" => "§7§lНАЗАД\n§8§lВернуться в меню", "action" => "back"];

        $form = new SimpleForm(function (Player $player, $data) use ($api, $orgKey, $buttons) {
            if ($data === null) return;
            $action = $buttons[$data]['action'] ?? null;
            switch ($action) {
                case 'deposit':  self::openDepositForm($player, $orgKey); break;
                case 'withdraw': self::openWithdrawForm($player, $orgKey); break;
                case 'bonus':    self::openBonusMenu($player, $orgKey); break;
                case 'gov_fund': self::openGovFundMenu($player); break;
                case 'back': $orgKey === "MF" ? Forms::openMafiaMenu($player) : Forms::openOrgMenu($player, $orgKey); break;
            }
        });

        $form->setTitle("§6§lКазна — " . $api->getOrgName($orgKey));
        $form->setContent($content);
        foreach ($buttons as $btn) $form->addButton($btn['text']);
        $player->sendForm($form);
    }

    public static function openDepositForm(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $balance = $api->getTreasurySystem()->getBalance($orgKey);
        $sep = "";

        $form = new CustomForm(function (Player $player, $data) use ($api, $orgKey) {
            if ($data === null) return;
            $amount = (float)($data[0] ?? 0);
            if ($amount <= 0) {
                $player->sendMessage("§c§l[Казна] §6§lУкажите корректную сумму.");
                return;
            }
            $api->getTreasurySystem()->deposit($player, $orgKey, $amount);
        });

        $form->setTitle("§6§lПополнение казны");
        $form->addInput(
            "§6§lСумма пополнения:\n§6§lОрганизация: {$coloredOrg}\n§6§lТекущий баланс: §a§l" . number_format($balance) . "\$\n§6§lМинимум: §e§l100\$",
            "Введите сумму..."
        );
        $player->sendForm($form);
    }

    public static function openWithdrawForm(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $treasury = $api->getTreasurySystem();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $balance = $treasury->getBalance($orgKey);
        $rank = $api->getPlayerRank($player->getName());
        $remaining = $treasury->getRemainingWithdrawLimit($player->getName());
        $sep = "";

        $limitStr = $rank === 16
            ? "\n§6§lДоступно к снятию сегодня: §e§l" . number_format($remaining) . "\$"
            : "";

        $form = new CustomForm(function (Player $player, $data) use ($api, $orgKey) {
            if ($data === null) return;
            $amount = (float)($data[0] ?? 0);
            if ($amount <= 0) {
                $player->sendMessage("§c§l[Казна] §6§lУкажите корректную сумму.");
                return;
            }
            $api->getTreasurySystem()->withdraw($player, $orgKey, $amount);
        });

        $form->setTitle("§6§lСнятие из казны");
        $form->addInput(
            "§6§lСумма снятия:\n§6§lОрганизация: {$coloredOrg}\n§6§lТекущий баланс: §a§l" . number_format($balance) . "\${$limitStr}\n§6§lМинимум: §e§l100\$",
            "Введите сумму..."
        );
        $player->sendForm($form);
    }

    public static function openBonusMenu(Player $player, string $orgKey): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $balance = $api->getTreasurySystem()->getBalance($orgKey);
        $sep = "";

        $onlineMembers = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($api->getPlayerOrg($p->getName()) === $orgKey && $p->getName() !== $player->getName()) {
                $remaining = $api->getTreasurySystem()->getRemainingBonusLimit($p->getName());
                $rankName = $api->getRealRankName($p->getName());
                $onlineMembers[] = [
                    "name" => $p->getName(),
                    "remaining" => $remaining,
                    "rank" => $rankName
                ];
            }
        }

        $membersStr = "";
        if (!empty($onlineMembers)) {
            $membersStr = "\n§6§lСотрудники онлайн:\n";
            foreach ($onlineMembers as $m) {
                $membersStr .= "§e§l  " . $m['name'] . " §7§l(" . $m['rank'] . "§7§l) — лимит: §a§l" . number_format($m['remaining']) . "\$\n";
            }
        } else {
            $membersStr = "\n§c§lНет онлайн сотрудников.";
        }

        $memberNames = array_column($onlineMembers, 'name');
        array_unshift($memberNames, "§a§lВсем онлайн сотрудникам");

        $form = new CustomForm(function (Player $player, $data) use ($api, $orgKey, $onlineMembers, $memberNames) {
            if ($data === null) return;

            $targetIndex = (int)($data[0] ?? 0);
            $amount = (float)($data[1] ?? 0);

            if ($amount <= 0) {
                $player->sendMessage("§c§l[Казна] §6§lУкажите корректную сумму.");
                return;
            }

            if ($amount > 50000) {
                $player->sendMessage("§c§l[Казна] §6§lМаксимальная премия одному сотруднику в неделю: §e§l50,000\$");
                return;
            }

            $treasury = $api->getTreasurySystem();

            if ($targetIndex === 0) {
                $treasury->giveBonusToAll($player, $orgKey, $amount);
            } else {
                $realIndex = $targetIndex - 1;
                if (!isset($onlineMembers[$realIndex])) return;
                $targetName = $onlineMembers[$realIndex]['name'];
                $treasury->giveBonusToPlayer($player, $orgKey, $targetName, $amount);
            }
        });

        $form->setTitle("§6§lВыдача премии");
        $form->addDropdown(
            "§6§lПолучатель:\n§6§lОрганизация: {$coloredOrg}\n§6§lБаланс казны: §a§l" . number_format($balance) . "\$\n§6§lМакс. в неделю на сотрудника: §e§l50,000\${$membersStr}",
            $memberNames
        );
        $form->addInput("§6§lСумма премии:", "Введите сумму...");
        $player->sendForm($form);
    }

    public static function openInsufficientFundsMenu(Player $player, string $orgKey, float $requested, float $shortage, float $available, string $target): void {
        $api = Main::getInstance();
        $coloredOrg = $api->getColoredOrgName($orgKey);
        $sep = "";

        $targetStr = $target === "all" ? "всем онлайн сотрудникам" : "сотруднику §e§l{$target}";

        $form = new ModalForm(function (Player $player, ?bool $data) use ($api, $orgKey, $available, $target) {
            if ($data === null || $data === false) return;

            $treasury = $api->getTreasurySystem();

            if ($target === "all") {
                $treasury->giveBonusToAll($player, $orgKey, $available);
            } else {
                $treasury->giveBonusToPlayer($player, $orgKey, $target, $available);
            }
        });

        $form->setTitle("§6§lНедостаточно средств");
        $form->setContent(
            "§6§lОрганизация: {$coloredOrg}\n" .
            "§6§lЗапрошено: §c§l" . number_format($requested) . "\$\n" .
            "§6§lНе хватает: §c§l" . number_format($shortage) . "\$\n" .
            "§6§lДоступно в казне: §a§l" . number_format($available) . "\$\n\n" .
            "§7§lВыдать {$targetStr} имеющиеся §a§l" . number_format($available) . "\$§7§l?"
        );
        $form->setButton1("§a§lВыдать имеющееся");
        $form->setButton2("§c§lОтмена");
        $player->sendForm($form);
    }

    public static function openGovFundMenu(Player $player): void {
        $api = Main::getInstance();
        $treasury = $api->getTreasurySystem();
        $pvBalance = $treasury->getBalance("PV");
        $sep = "";

        $orgs = $api->getConfig()->get("orgs", []);
        $orgList = ["§a§lВсем организациям"];
        $orgKeys = [];

        foreach ($orgs as $key => $name) {
            if ($key === "MF" || $key === "PV") continue;
            $hasLeader = false;
            foreach ($api->data->getAll() as $pKey => $data) {
                if (isset($data['org']) && $data['org'] === $key && isset($data['rank']) && $data['rank'] === 16) {
                    $hasLeader = true;
                    break;
                }
            }
            $leaderStr = $hasLeader ? "§a§l(руководитель назначен)" : "§c§l(нет руководителя)";
            $orgList[] = "§e§l" . $name . " §7§l" . $leaderStr;
            $orgKeys[] = $key;
        }

        $form = new CustomForm(function (Player $player, $data) use ($api, $orgKeys) {
            if ($data === null) return;

            $targetIndex = (int)($data[0] ?? 0);
            $amount = (float)($data[1] ?? 0);

            if ($amount <= 0) {
                $player->sendMessage("§c§l[Казна] §6§lУкажите корректную сумму.");
                return;
            }

            $treasury = $api->getTreasurySystem();

            if ($targetIndex === 0) {
                $treasury->govFundAll($player, $amount);
            } else {
                $realIndex = $targetIndex - 1;
                if (!isset($orgKeys[$realIndex])) return;
                $treasury->govFundSingle($player, $orgKeys[$realIndex], $amount);
            }
        });

        $form->setTitle("§6§lФинансирование ведомств");
        $form->addDropdown(
            "§6§lПолучатель:\n§6§lКазна Правительства: §a§l" . number_format($pvBalance) . "\$\n§7§lПри выдаче всем — сумма делится поровну.\n§7§lОрганизации без руководителя пропускаются.",
            $orgList
        );
        $form->addInput("§6§lСумма:", "Введите сумму...");
        $player->sendForm($form);
    }

    public static function openAdminFundMenu(\pocketmine\command\CommandSender $sender): void {
        $api = Main::getInstance();
        $sep = "";

        $orgs = $api->getConfig()->get("orgs", []);
        $orgList = ["§a§lВсем организациям"];
        $orgKeys = [];

        foreach ($orgs as $key => $name) {
            if ($key === "MF") continue;
            $hasLeader = false;
            foreach ($api->data->getAll() as $pKey => $data) {
                if (isset($data['org']) && $data['org'] === $key && isset($data['rank']) && $data['rank'] === 16) {
                    $hasLeader = true;
                    break;
                }
            }
            $leaderStr = $hasLeader ? "§a§l(руководитель назначен)" : "§c§l(нет руководителя)";
            $orgList[] = "§e§l" . $name . " §7§l" . $leaderStr;
            $orgKeys[] = $key;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§c§l[Казна] §6§lКоманда доступна только для игроков.");
            return;
        }

        $form = new CustomForm(function (Player $player, $data) use ($api, $orgKeys) {
            if ($data === null) return;

            $targetIndex = (int)($data[0] ?? 0);
            $amount = (float)($data[1] ?? 0);

            if ($amount <= 0) {
                $player->sendMessage("§c§l[Казна] §6§lУкажите корректную сумму.");
                return;
            }

            $treasury = $api->getTreasurySystem();

            if ($targetIndex === 0) {
                $treasury->adminFundAll($player, $amount);
            } else {
                $realIndex = $targetIndex - 1;
                if (!isset($orgKeys[$realIndex])) return;
                $result = $treasury->adminFundOrg($orgKeys[$realIndex], $amount, $player->getName());
                $coloredOrg = $api->getColoredOrgName($orgKeys[$realIndex]);
                if ($result === "ok") {
                    $player->sendMessage("§6§l[Казна] §a§l" . number_format($amount) . "\$ §e§lзачислено в казну {$coloredOrg}");
                } else {
                    $player->sendMessage("§c§l[Казна] §6§lОрганизация {$coloredOrg} §6§lне имеет назначенного руководителя.");
                }
            }
        });

        $form->setTitle("§6§lАдмин — пополнение казны");
        $form->addDropdown(
            "§6§lПолучатель:\n§7§lСредства выдаются сервером.\n§7§lОрганизации без руководителя пропускаются.",
            $orgList
        );
        $form->addInput("§6§lСумма:", "Введите сумму...");
        $sender->sendForm($form);
    }
}