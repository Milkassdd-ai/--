<?php

declare(strict_types=1);

namespace InzeOwr\RcBan;

use pocketmine\player\Player;
use pocketmine\world\Position;

class BanManager {
    private Main $plugin;
    private array $bannedOnline = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function isBanned(Player $player): bool {
        return isset($this->bannedOnline[strtolower($player->getName())]);
    }

    public function setBannedOnline(Player $player, bool $value): void {
        $nick = strtolower($player->getName());
        if ($value) {
            $this->bannedOnline[$nick] = true;
        } else {
            unset($this->bannedOnline[$nick]);
        }
    }

    public function cleanExpired(): void {
        $now = time();
        $cleaned = false;
        foreach ($this->plugin->getBansConfig()->getAll() as $name => $data) {
            if (!isset($data["type"])) continue;
            if ($data["type"] === "temp" && isset($data["expire"]) && $data["expire"] <= $now) {
                $this->plugin->getBansConfig()->remove($name);
                $cleaned = true;
            }
        }
        foreach ($this->plugin->getHardBansConfig()->getAll() as $name => $data) {
            if (isset($data["expire"]) && $data["expire"] <= $now) {
                $this->plugin->getHardBansConfig()->remove($name);
                $cleaned = true;
            }
        }
        if ($cleaned) {
            $this->plugin->getBansConfig()->save();
            $this->plugin->getHardBansConfig()->save();
        }
    }

    public function teleportToLimbo(Player $player): void {
        $worldName = $this->plugin->getConfig()->get("ban_spawn_world", "world");
        $x = (float) $this->plugin->getConfig()->get("ban_spawn_x", 0.0);
        $y = (float) $this->plugin->getConfig()->get("ban_spawn_y", 300.0);
        $z = (float) $this->plugin->getConfig()->get("ban_spawn_z", 0.0);

        $manager = $this->plugin->getServer()->getWorldManager();
        if (!$manager->isWorldLoaded($worldName)) {
            $manager->loadWorld($worldName);
        }
        $world = $manager->getWorldByName($worldName);
        if ($world === null) return;

        $player->teleport(new Position($x, $y, $z, $world));
        $player->setInvisible(true);
        $player->setNameTagVisible(false);

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $online) {
            if ($online !== $player) {
                $online->hidePlayer($player);
            }
        }
    }

    public function hideBannedFrom(Player $newPlayer): void {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $online) {
            if ($online === $newPlayer) continue;
            if ($this->isBanned($online)) {
                $newPlayer->hidePlayer($online);
            }
        }
    }

    public function formatTimestamp(int $timestamp): string {
        $dt = new \DateTime("@{$timestamp}");
        $dt->setTimezone(new \DateTimeZone("Europe/Moscow"));
        return $dt->format("d.m.y - H:i:s");
    }

    public function getTimeRemaining(int $expireTimestamp): string {
        $diff = $expireTimestamp - time();
        if ($diff <= 0) return $this->plugin->msg("ban_expired_info");
        $days = (int) floor($diff / 86400);
        $hours = (int) floor(($diff % 86400) / 3600);
        $minutes = (int) floor(($diff % 3600) / 60);
        $seconds = (int) ($diff % 60);
        $parts = [];
        if ($days > 0) $parts[] = $days . " дн.";
        if ($hours > 0) $parts[] = $hours . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";
        if ($seconds > 0 && $days === 0) $parts[] = $seconds . " сек.";
        return empty($parts) ? "менее минуты" : implode(" ", $parts);
    }

    public function parseTime(string $input): ?int {
        $input = strtolower(trim($input));
        if (preg_match_all('/(\d+)(g|ms|d|h|m)/', $input, $matches, PREG_SET_ORDER) && count($matches) > 0) {
            $totalMinutes = 0;
            foreach ($matches as $match) {
                $totalMinutes += $this->toMinutes((int) $match[1], $match[2]);
            }
            if ($totalMinutes <= 0) return null;
        } elseif (is_numeric($input)) {
            $totalMinutes = (int) $input;
            if ($totalMinutes <= 0) return null;
        } else {
            return null;
        }
        $maxMinutes = 365 * 525960;
        if ($totalMinutes > $maxMinutes) return null;
        $maxTime = (int) $this->plugin->getConfig()->get("max_ban_time", 0);
        if ($maxTime > 0 && $totalMinutes > $maxTime) return null;
        return $totalMinutes;
    }

    private function toMinutes(int $val, string $unit): int {
        return match ($unit) {
            "m" => $val,
            "h" => $val * 60,
            "d" => $val * 1440,
            "ms" => $val * 43200,
            "g" => $val * 525960,
            default => 0,
        };
    }

    public function normalizeTime(int $totalMinutes): string {
        $years = (int) floor($totalMinutes / 525960);
        $rest = $totalMinutes % 525960;
        $months = (int) floor($rest / 43200);
        $rest = $rest % 43200;
        $days = (int) floor($rest / 1440);
        $rest = $rest % 1440;
        $hours = (int) floor($rest / 60);
        $minutes = $rest % 60;
        $parts = [];
        if ($years > 0) $parts[] = $years . " " . $this->pluralYear($years);
        if ($months > 0) $parts[] = $months . " " . $this->pluralMonth($months);
        if ($days > 0) $parts[] = $days . " " . $this->pluralDay($days);
        if ($hours > 0) $parts[] = $hours . " ч.";
        if ($minutes > 0) $parts[] = $minutes . " мин.";
        return empty($parts) ? "менее минуты" : implode(" ", $parts);
    }

    private function pluralYear(int $n): string {
        $n = abs($n) % 100; $n1 = $n % 10;
        if ($n >= 11 && $n <= 19) return "лет";
        if ($n1 === 1) return "год";
        if ($n1 >= 2 && $n1 <= 4) return "года";
        return "лет";
    }

    private function pluralMonth(int $n): string {
        $n = abs($n) % 100; $n1 = $n % 10;
        if ($n >= 11 && $n <= 19) return "месяцев";
        if ($n1 === 1) return "месяц";
        if ($n1 >= 2 && $n1 <= 4) return "месяца";
        return "месяцев";
    }

    private function pluralDay(int $n): string {
        $n = abs($n) % 100; $n1 = $n % 10;
        if ($n >= 11 && $n <= 19) return "дней";
        if ($n1 === 1) return "день";
        if ($n1 >= 2 && $n1 <= 4) return "дня";
        return "дней";
    }

    public function getPlayerIP(string $name): ?string {
        $player = $this->plugin->getServer()->getPlayerExact($name);
        return $player !== null ? $player->getNetworkSession()->getIp() : null;
    }

    public function findPlayer(string $name): ?Player {
        $name = strtolower($name);
        $found = null;
        $delta = PHP_INT_MAX;
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $pName = strtolower($player->getName());
            if ($pName === $name) return $player;
            if (str_starts_with($pName, $name)) {
                $curDelta = strlen($pName) - strlen($name);
                if ($curDelta < $delta) {
                    $found = $player;
                    $delta = $curDelta;
                }
            }
        }
        return $found;
    }

    public function resolveTargetName(string $input): string {
        $player = $this->findPlayer($input);
        return $player !== null ? $player->getName() : $input;
    }
}