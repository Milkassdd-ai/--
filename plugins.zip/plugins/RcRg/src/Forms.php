<?php

declare(strict_types=1);

namespace InzeOwr\RcRg;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use onebone\economyapi\EconomyAPI;

class Forms {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    /**
     * Покупка свободной квартиры у государства
     */
    public function openBuyForm(Player $player, array &$region): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use (&$region) {
            if ($data === null) return;
            if ($data === 0) {
                $this->processBuyFromState($player, $region);
            }
        });

        $price = $this->formatPrice($region["price"]);
        $balance = $this->formatPrice((int)EconomyAPI::getInstance()->myMoney($player));

        $form->setTitle("§l§9Администрация г. Береговой");
        $form->setContent(
            "§l§0Управление жилым фондом\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Объект: §l§fКвартира\n" .
            "§l§9Статус: §l§aДоступна к приобретению\n" .
            "§l§9Кадастровая стоимость: §l§6" . $price . " ₽\n" .
            "§l§9Ваш баланс: §l§e" . $balance . " ₽\n\n" .
            "§l§7Подтвердите приобретение объекта\n" .
            "§l§7недвижимости в личную собственность."
        );
        $form->addButton("§l§2Приобрести квартиру");
        $form->addButton("§l§4Отказаться");

        $player->sendForm($form);
    }

    /**
     * Квартира занята — для постороннего
     */
    public function openOccupiedForm(Player $player, array &$region): void {
        $form = new SimpleForm(function (Player $player, ?int $data) {});

        $form->setTitle("§l§9Администрация г. Береговой");
        $form->setContent(
            "§l§0Управление жилым фондом\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Объект: §l§fКвартира\n" .
            "§l§9Статус: §l§cЗанята\n" .
            "§l§9Собственник: §l§b" . ($region["owner"] ?? "—") . "\n\n" .
            "§l§7Данный объект недвижимости\n" .
            "§l§7является частной собственностью."
        );
        $form->addButton("§l§8Закрыть");

        $player->sendForm($form);
    }

    /**
     * Главная форма владельца
     */
    public function openOwnerForm(Player $player, array &$region, string $regionName): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use (&$region, $regionName) {
            if ($data === null) return;
            switch ($data) {
                case 0:
                    $this->openSellChoiceForm($player, $region, $regionName);
                    break;
                case 1:
                    $this->openAddMemberForm($player, $region, $regionName);
                    break;
                case 2:
                    $this->openRemoveMemberForm($player, $region, $regionName);
                    break;
            }
        });

        $price = $this->formatPrice($region["price"]);
        $members = $region["members"] ?? [];
        $membersList = empty($members) ? "§l§7Нет зарегистрированных" : "§l§b" . implode("§l§f, §l§b", $members);

        $form->setTitle("§l§9Управление квартирой");
        $form->setContent(
            "§l§0Личный кабинет собственника\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Собственник: §l§b" . $player->getName() . "\n" .
            "§l§9Кадастровая стоимость: §l§6" . $price . " ₽\n" .
            "§l§9Жильцы: " . $membersList . "\n\n" .
            "§l§7Выберите необходимое действие."
        );
        $form->addButton("§l§6Продать квартиру");
        $form->addButton("§l§2Зарегистрировать жильца");
        $form->addButton("§l§4Выселить жильца");

        $player->sendForm($form);
    }

    /**
     * Выбор способа продажи
     */
    private function openSellChoiceForm(Player $player, array &$region, string $regionName): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use (&$region, $regionName) {
            if ($data === null) return;
            switch ($data) {
                case 0:
                    $this->openSellToStateConfirm($player, $region, $regionName);
                    break;
                case 1:
                    $this->openSellToCitizenList($player, $region, $regionName);
                    break;
                case 2:
                    break;
            }
        });

        $fullPrice = $region["price"];
        $stateReturn = (int)floor($fullPrice * 0.70);
        $maxCitizenPrice = (int)floor($fullPrice * 1.40);
        $minCitizenPrice = $fullPrice;

        $form->setTitle("§l§9Продажа квартиры");
        $form->setContent(
            "§l§0Отдел сделок с недвижимостью\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Кадастровая стоимость: §l§6" . $this->formatPrice($fullPrice) . " ₽\n\n" .
            "§l§eПродажа государству:\n" .
            "§l§7Возврат §l§a70% §l§7кадастровой стоимости\n" .
            "§l§7Сумма возврата: §l§a" . $this->formatPrice($stateReturn) . " ₽\n\n" .
            "§l§eПродажа гражданину:\n" .
            "§l§7Минимальная цена: §l§6" . $this->formatPrice($minCitizenPrice) . " ₽\n" .
            "§l§7Максимальная цена §l§d(140%)§l§7: §l§6" . $this->formatPrice($maxCitizenPrice) . " ₽\n\n" .
            "§l§cПродажа ниже кадастровой стоимости\n" .
            "§l§cзапрещена законодательством."
        );
        $form->addButton("§l§9Продать государству");
        $form->addButton("§l§eПродать гражданину");
        $form->addButton("§l§4Отмена");

        $player->sendForm($form);
    }

    /**
     * Подтверждение продажи государству
     */
    private function openSellToStateConfirm(Player $player, array &$region, string $regionName): void {
        $form = new SimpleForm(function (Player $player, ?int $data) use (&$region, $regionName) {
            if ($data === null) return;
            if ($data === 0) {
                $this->processSellToState($player, $region, $regionName);
            }
        });

        $stateReturn = (int)floor($region["price"] * 0.70);

        $form->setTitle("§l§9Подтверждение продажи");
        $form->setContent(
            "§l§0Отдел сделок с недвижимостью\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Тип сделки: §l§fПродажа государству\n" .
            "§l§9Кадастровая стоимость: §l§6" . $this->formatPrice($region["price"]) . " ₽\n" .
            "§l§9Сумма возврата §l§d(70%)§l§9: §l§a" . $this->formatPrice($stateReturn) . " ₽\n\n" .
            "§l§cВнимание! §l§7После продажи вы\n" .
            "§l§7утратите право собственности.\n" .
            "§l§7Все жильцы будут выселены.\n\n" .
            "§l§eПодтвердите операцию."
        );
        $form->addButton("§l§2Подтвердить продажу");
        $form->addButton("§l§4Отмена");

        $player->sendForm($form);
    }

    /**
     * Выбор покупателя из онлайна
     */
    private function openSellToCitizenList(Player $player, array &$region, string $regionName): void {
        $online = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if (strtolower($p->getName()) !== strtolower($player->getName())) {
                $online[] = $p->getName();
            }
        }

        if (empty($online)) {
            $player->sendMessage("§c§l✦ §c§lНет доступных граждан для совершения сделки");
            return;
        }

        $form = new SimpleForm(function (Player $player, ?int $data) use ($online, &$region, $regionName) {
            if ($data === null) return;
            if (!isset($online[$data])) return;
            $this->openSellToCitizenPriceForm($player, $region, $regionName, $online[$data]);
        });

        $form->setTitle("§l§9Выбор покупателя");
        $form->setContent(
            "§l§0Отдел сделок с недвижимостью\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§7Выберите гражданина для\n" .
            "§l§7совершения сделки."
        );

        foreach ($online as $name) {
            $form->addButton("§l§0" . $name);
        }

        $player->sendForm($form);
    }

    /**
     * Ввод суммы продажи
     */
    private function openSellToCitizenPriceForm(Player $player, array &$region, string $regionName, string $targetName): void {
        $form = new CustomForm(function (Player $player, ?array $data) use (&$region, $regionName, $targetName) {
            if ($data === null) return;

            $priceInput = $data[1] ?? "";
            if (!is_numeric($priceInput) || (int)$priceInput <= 0) {
                $player->sendMessage("§c§l✦ §c§lУкажите корректную сумму сделки");
                return;
            }

            $sellPrice = (int)$priceInput;
            $minPrice = $region["price"];
            $maxPrice = (int)floor($region["price"] * 1.40);

            if ($sellPrice < $minPrice) {
                $player->sendMessage("§c§l✦ §c§lСумма не может быть ниже кадастровой стоимости");
                $player->sendMessage("§7§l  Минимум: §f§l" . $this->formatPrice($minPrice) . " ₽");
                $player->sendMessage("§c§l  Продажа ниже рыночной стоимости запрещена");
                return;
            }

            if ($sellPrice > $maxPrice) {
                $player->sendMessage("§c§l✦ §c§lСумма не может превышать 140% кадастровой стоимости");
                $player->sendMessage("§7§l  Максимум: §f§l" . $this->formatPrice($maxPrice) . " ₽");
                return;
            }

            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target === null) {
                $player->sendMessage("§c§l✦ §c§lГражданин §f§l" . $targetName . " §c§lне в сети");
                return;
            }

            $this->openCitizenBuyConfirmForm($target, $player, $region, $regionName, $sellPrice);
            $player->sendMessage("§a§l✦ §a§lПредложение направлено гражданину §f§l" . $targetName);
            $player->sendMessage("§7§l  Ожидайте ответа покупателя");
        });

        $minPrice = $region["price"];
        $maxPrice = (int)floor($region["price"] * 1.40);

        $form->setTitle("§l§9Сумма сделки");
        $form->addLabel(
            "§l§0Отдел сделок с недвижимостью\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Покупатель: §l§b" . $targetName . "\n" .
            "§l§9Кадастровая стоимость: §l§6" . $this->formatPrice($region["price"]) . " ₽\n\n" .
            "§l§eДопустимый диапазон:\n" .
            "§l§7Минимум §l§d(100%)§l§7: §l§6" . $this->formatPrice($minPrice) . " ₽\n" .
            "§l§7Максимум §l§d(140%)§l§7: §l§6" . $this->formatPrice($maxPrice) . " ₽\n\n" .
            "§l§cПродажа ниже кадастровой стоимости\n" .
            "§l§cзапрещена законодательством.\n\n" .
            "§l§eУкажите сумму сделки:"
        );
        $form->addInput("§l§8Сумма (₽)", "Введите сумму");

        $player->sendForm($form);
    }

    /**
     * Подтверждение покупки (форма покупателю)
     */
    private function openCitizenBuyConfirmForm(Player $buyer, Player $seller, array &$region, string $regionName, int $sellPrice): void {
        $form = new SimpleForm(function (Player $buyer, ?int $data) use ($seller, &$region, $regionName, $sellPrice) {
            if ($data === null) return;

            if ($data === 0) {
                $this->processSellToCitizen($buyer, $seller, $region, $regionName, $sellPrice);
            } else {
                $buyer->sendMessage("§7§l✦ §7§lВы отклонили предложение о покупке");
                $sellerOnline = Server::getInstance()->getPlayerExact($seller->getName());
                if ($sellerOnline !== null) {
                    $sellerOnline->sendMessage("§c§l✦ §c§lГражданин §f§l" . $buyer->getName() . " §c§lотклонил предложение");
                }
            }
        });

        $balanceFormatted = $this->formatPrice((int)EconomyAPI::getInstance()->myMoney($buyer));

        $form->setTitle("§l§9Предложение о покупке");
        $form->setContent(
            "§l§0Отдел сделок с недвижимостью\n" .
            "§l§8Береговая область, г. Береговой\n\n" .
            "§l§9Тип сделки: §l§fПокупка у гражданина\n" .
            "§l§9Продавец: §l§b" . $seller->getName() . "\n" .
            "§l§9Кадастровая стоимость: §l§6" . $this->formatPrice($region["price"]) . " ₽\n" .
            "§l§9Цена продавца: §l§e" . $this->formatPrice($sellPrice) . " ₽\n" .
            "§l§9Ваш баланс: §l§a" . $balanceFormatted . " ₽\n\n" .
            "§l§7Гражданин §l§b" . $seller->getName() . " §l§7предлагает\n" .
            "§l§7Вам приобрести квартиру.\n\n" .
            "§l§eПодтвердите сделку."
        );
        $form->addButton("§l§2Приобрести");
        $form->addButton("§l§4Отклонить");

        $buyer->sendForm($form);
    }

    /**
     * Добавление жильца
     */
    public function openAddMemberForm(Player $player, array &$region, string $regionName): void {
        $online = [];
        $members = $region["members"] ?? [];
        $ownerLower = strtolower($region["owner"] ?? "");

        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $pName = $p->getName();
            $pLower = strtolower($pName);
            if ($pLower !== strtolower($player->getName()) &&
                $pLower !== $ownerLower &&
                !in_array($pName, $members)) {
                $online[] = $pName;
            }
        }

        if (empty($online)) {
            $player->sendMessage("§c§l✦ §c§lНет доступных граждан для регистрации");
            return;
        }

        $form = new SimpleForm(function (Player $player, ?int $data) use ($online, &$region, $regionName) {
            if ($data === null) return;
            if (!isset($online[$data])) return;
            $this->processAddMember($player, $region, $regionName, $online[$data]);
        });

        $form->setTitle("§l§9Регистрация жильца");
        $form->setContent(
            "§l§0Паспортный стол г. Береговой\n" .
            "§l§8Береговая область\n\n" .
            "§l§7Выберите гражданина для\n" .
            "§l§7регистрации по месту проживания."
        );

        foreach ($online as $name) {
            $form->addButton("§l§0" . $name);
        }

        $player->sendForm($form);
    }

    /**
     * Выселение жильца
     */
    public function openRemoveMemberForm(Player $player, array &$region, string $regionName): void {
        $members = $region["members"] ?? [];

        if (empty($members)) {
            $player->sendMessage("§7§l✦ §7§lВ квартире нет зарегистрированных жильцов");
            return;
        }

        $form = new SimpleForm(function (Player $player, ?int $data) use ($members, &$region, $regionName) {
            if ($data === null) return;
            if (!isset($members[$data])) return;
            $this->processRemoveMember($player, $region, $regionName, $members[$data]);
        });

        $form->setTitle("§l§9Выселение жильца");
        $form->setContent(
            "§l§0Паспортный стол г. Береговой\n" .
            "§l§8Береговая область\n\n" .
            "§l§7Выберите гражданина для снятия\n" .
            "§l§7с регистрации по месту проживания.\n\n" .
            "§l§cВнимание: §l§7после выселения\n" .
            "§l§7гражданин утратит доступ к квартире."
        );

        foreach ($members as $name) {
            $form->addButton("§l§4" . $name);
        }

        $player->sendForm($form);
    }

    // ============ ОБРАБОТКА ============

    private function processBuyFromState(Player $player, array &$region): void {
        if ($region["owner"] !== null) {
            $player->sendMessage("§c§l✦ §c§lКвартира уже приобретена другим гражданином");
            return;
        }

        $economy = EconomyAPI::getInstance();
        $balance = $economy->myMoney($player);
        $price = $region["price"];

        if ($balance < $price) {
            $need = $this->formatPrice($price - (int)$balance);
            $player->sendMessage("§c§l✦ §c§lНедостаточно средств для сделки");
            $player->sendMessage("§7§l  Не хватает: §f§l" . $need . " ₽");
            return;
        }

        $economy->reduceMoney($player, $price);
        $region["owner"] = $player->getName();
        $region["members"] = [];
        $this->plugin->saveRegionData($region["name"], $region);
        $this->plugin->updateApartmentSign($region);

        $player->sendMessage("§a§l✦ §a§lПоздравляем с приобретением квартиры!");
        $player->sendMessage("§6§l  Сумма сделки: §f§l" . $this->formatPrice($price) . " ₽");
        $player->sendMessage("§b§l  Добро пожаловать домой, §f§l" . $player->getName() . "§b§l!");
    }

    private function processSellToState(Player $player, array &$region, string $regionName): void {
        if ($region["owner"] === null || strtolower($region["owner"]) !== strtolower($player->getName())) {
            $player->sendMessage("§c§l✦ §c§lВы не являетесь собственником");
            return;
        }

        $returnAmount = (int)floor($region["price"] * 0.70);
        EconomyAPI::getInstance()->addMoney($player, $returnAmount);

        $oldMembers = $region["members"] ?? [];
        $region["owner"] = null;
        $region["members"] = [];
        $this->plugin->saveRegionData($regionName, $region);
        $this->plugin->updateApartmentSign($region);

        $player->sendMessage("§a§l✦ §a§lКвартира продана государству");
        $player->sendMessage("§6§l  Зачислено: §f§l" . $this->formatPrice($returnAmount) . " ₽");

        foreach ($oldMembers as $memberName) {
            $member = Server::getInstance()->getPlayerExact($memberName);
            if ($member !== null) {
                $member->sendMessage("§c§l✦ §c§lКвартира продана государству");
                $member->sendMessage("§7§l  Вы сняты с регистрации");
            }
        }
    }

    private function processSellToCitizen(Player $buyer, Player $seller, array &$region, string $regionName, int $sellPrice): void {
        $currentRegion = $this->plugin->getRegionData($regionName);
        if ($currentRegion === null || $currentRegion["owner"] === null ||
            strtolower($currentRegion["owner"]) !== strtolower($seller->getName())) {
            $buyer->sendMessage("§c§l✦ §c§lСделка отменена — продавец не является собственником");
            return;
        }

        $minPrice = $currentRegion["price"];
        $maxPrice = (int)floor($currentRegion["price"] * 1.40);

        if ($sellPrice < $minPrice || $sellPrice > $maxPrice) {
            $buyer->sendMessage("§c§l✦ §c§lСделка отменена — некорректная сумма");
            $sellerOnline = Server::getInstance()->getPlayerExact($seller->getName());
            if ($sellerOnline !== null) {
                $sellerOnline->sendMessage("§c§l✦ §c§lСделка отменена — ошибка суммы");
            }
            return;
        }

        $economy = EconomyAPI::getInstance();
        $buyerBalance = $economy->myMoney($buyer);

        if ($buyerBalance < $sellPrice) {
            $need = $this->formatPrice($sellPrice - (int)$buyerBalance);
            $buyer->sendMessage("§c§l✦ §c§lНедостаточно средств");
            $buyer->sendMessage("§7§l  Не хватает: §f§l" . $need . " ₽");

            $sellerOnline = Server::getInstance()->getPlayerExact($seller->getName());
            if ($sellerOnline !== null) {
                $sellerOnline->sendMessage("§c§l✦ §c§lСделка не состоялась — у покупателя нет средств");
            }
            return;
        }

        $economy->reduceMoney($buyer, $sellPrice);
        $economy->addMoney($seller, $sellPrice);

        $oldMembers = $currentRegion["members"] ?? [];
        $region["owner"] = $buyer->getName();
        $region["members"] = [];
        $this->plugin->saveRegionData($regionName, $region);
        $this->plugin->updateApartmentSign($region);

        $buyer->sendMessage("§a§l✦ §a§lКвартира приобретена у гражданина §f§l" . $seller->getName());
        $buyer->sendMessage("§6§l  Сумма: §f§l" . $this->formatPrice($sellPrice) . " ₽");
        $buyer->sendMessage("§b§l  Добро пожаловать домой, §f§l" . $buyer->getName() . "§b§l!");

        $sellerOnline = Server::getInstance()->getPlayerExact($seller->getName());
        if ($sellerOnline !== null) {
            $sellerOnline->sendMessage("§a§l✦ §a§lКвартира продана гражданину §f§l" . $buyer->getName());
            $sellerOnline->sendMessage("§6§l  Зачислено: §f§l" . $this->formatPrice($sellPrice) . " ₽");
        }

        foreach ($oldMembers as $memberName) {
            $member = Server::getInstance()->getPlayerExact($memberName);
            if ($member !== null) {
                $member->sendMessage("§c§l✦ §c§lКвартира продана новому собственнику");
                $member->sendMessage("§7§l  Вы сняты с регистрации");
            }
        }
    }

    private function processAddMember(Player $player, array &$region, string $regionName, string $memberName): void {
        if (!isset($region["members"])) {
            $region["members"] = [];
        }

        if (in_array($memberName, $region["members"])) {
            $player->sendMessage("§c§l✦ §c§lГражданин §f§l" . $memberName . " §c§lуже зарегистрирован");
            return;
        }

        $region["members"][] = $memberName;
        $this->plugin->saveRegionData($regionName, $region);

        $player->sendMessage("§a§l✦ §a§lГражданин §f§l" . $memberName . " §a§lзарегистрирован");

        $target = Server::getInstance()->getPlayerExact($memberName);
        if ($target !== null) {
            $target->sendMessage("§a§l✦ §a§lВы зарегистрированы в квартире §f§l" . $player->getName());
            $target->sendMessage("§b§l  Вам доступно проживание и обустройство");
        }
    }

    private function processRemoveMember(Player $player, array &$region, string $regionName, string $memberName): void {
        if (!isset($region["members"])) {
            $region["members"] = [];
        }

        $key = array_search($memberName, $region["members"]);
        if ($key === false) {
            $player->sendMessage("§c§l✦ §c§lГражданин §f§l" . $memberName . " §c§lне зарегистрирован");
            return;
        }

        unset($region["members"][$key]);
        $region["members"] = array_values($region["members"]);
        $this->plugin->saveRegionData($regionName, $region);

        $player->sendMessage("§a§l✦ §a§lГражданин §f§l" . $memberName . " §a§lвыселен");

        $target = Server::getInstance()->getPlayerExact($memberName);
        if ($target !== null) {
            $target->sendMessage("§c§l✦ §c§lВы выселены из квартиры §f§l" . $player->getName());
            $target->sendMessage("§7§l  Доступ к квартире прекращён");
        }
    }

    public function formatPrice(int $price): string {
        return number_format($price, 0, '', '.');
    }
}