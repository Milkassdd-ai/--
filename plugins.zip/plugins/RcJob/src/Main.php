<?php

declare(strict_types=1);

namespace InzeOwr\RcJob;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\Wood;
use pocketmine\block\Wheat;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\world\Position;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\scheduler\ClosureTask;
use pocketmine\nbt\tag\CompoundTag;

class Main extends PluginBase implements Listener {

    private static Main $instance;

    private Config $jobData;
    private Config $playerData;
    private Config $npcData;

    private array $selections = [];
    private array $activeWorkers = [];
    private array $jobZones = [];
    private array $computerNpcState = [];
    private array $warehouseTargets = [];
    private array $logsBrokenInZone = [];
    private array $pendingCaptchas = [];

    private float $boostMultiplier = 1.0;
    private int $boostEndTime = 0;

    private FormManager $formManager;

    public const SKILL_XP = [
        1 => 0,
        2 => 1000,
        3 => 3000,
        4 => 6000,
        5 => 10000
    ];

    public const JOB_PAY = [
        1 => [4, 8],
        2 => [15, 20],
        3 => [6, 10],
        4 => [6, 10]
    ];

    public const JOB_PAY_PER_LEVEL = [
        3 => [
            1 => [6, 10],
            2 => [8, 12],
            3 => [10, 15],
            4 => [13, 18],
            5 => [16, 22]
        ]
    ];

    public const JOB_NAMES = [
        1 => "Фермер",
        2 => "Компьютерный Мастер",
        3 => "Дровосек",
        4 => "Кладовщик"
    ];

    public const MAX_BLOCKS_PER_DAY = 1000;
    public const LEAVE_DISTANCE = 5;

    public const TOOL_NAMES = [
        "screwdriver" => "§l§eОтвёртка",
        "flashlight" => "§l§eФонарик",
        "soldering" => "§l§eПаяльник",
        "cable" => "§l§eКабель"
    ];

    public const COMPUTER_PARTS = [
        "Материнская плата",
        "Видеокарта",
        "Блок питания",
        "Оперативная память",
        "Жёсткий диск",
        "Процессор",
        "Система охлаждения",
        "Сетевая карта"
    ];

    public const COMPUTER_PROBLEMS = [
        [
            "text" => "§eУ меня компьютер не включается, из блока питания идёт запах гари. Похоже сгорел контакт внутри.",
            "tool" => "soldering",
            "part" => "Блок питания"
        ],
        [
            "text" => "§eЭкран погас и не реагирует. Внутри что-то отошло, нужно посмотреть контакты видеокарты.",
            "tool" => "screwdriver",
            "part" => "Видеокарта"
        ],
        [
            "text" => "§eКомпьютер сильно тормозит и перегревается. Кулер не крутится, нужно разобрать и проверить.",
            "tool" => "screwdriver",
            "part" => "Система охлаждения"
        ],
        [
            "text" => "§eНет интернета, лампочки на задней панели не горят. Нужно проверить подключение.",
            "tool" => "cable",
            "part" => "Сетевая карта"
        ],
        [
            "text" => "§eКомпьютер пищит при включении и не загружается. Нужно посмотреть внутрь, темно ничего не видно.",
            "tool" => "flashlight",
            "part" => "Оперативная память"
        ],
        [
            "text" => "§eЖёсткий диск щёлкает и не определяется. Нужно открутить крепления и заменить кабель.",
            "tool" => "screwdriver",
            "part" => "Жёсткий диск"
        ],
        [
            "text" => "§eПроцессор перегревается до 100 градусов. Нужно снять кулер, посмотреть термопасту.",
            "tool" => "screwdriver",
            "part" => "Процессор"
        ],
        [
            "text" => "§eМатеринская плата не подаёт признаков жизни. Какой-то проводок отпаялся.",
            "tool" => "soldering",
            "part" => "Материнская плата"
        ]
    ];

    public function onEnable(): void {
        self::$instance = $this;

        $this->saveDefaultConfig();
        @mkdir($this->getDataFolder());

        $this->jobData = new Config($this->getDataFolder() . "jobs.yml", Config::YAML);
        $this->playerData = new Config($this->getDataFolder() . "playerdata.yml", Config::YAML);
        $this->npcData = new Config($this->getDataFolder() . "npcs.yml", Config::YAML);

        $this->loadJobZones();
        $this->loadBoost();

        $this->formManager = new FormManager($this);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        JobNPC::register($this);
        WorkerNPC::register($this);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->tickWorkers();
        }), 20);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->tickWarehouseParticles();
        }), 5);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->sendCaptchaToAll();
        }), 6000);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->checkCaptchaTimeouts();
        }), 20);

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->respawnAllNPCs();
        }), 20);
    }

    public function onDisable(): void {
        foreach($this->activeWorkers as $name => $data) {
            $this->endWork($name, true);
        }
        $this->playerData->save();
        $this->jobData->save();
    }

    public static function getInstance(): Main {
        return self::$instance;
    }

    public function getFormManager(): FormManager {
        return $this->formManager;
    }

    private function giveMoney(string $playerName, float $amount): void {
        $player = $this->getServer()->getPlayerExact($playerName);
        if($player === null) return;

        $eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if($eco !== null) {
            \onebone\economyapi\EconomyAPI::getInstance()->addMoney($player, $amount);
        }
    }

    private function loadBoost(): void {
        $this->boostMultiplier = (float)$this->jobData->get("boost_multiplier", 1.0);
        $this->boostEndTime = (int)$this->jobData->get("boost_end_time", 0);

        if(time() >= $this->boostEndTime) {
            $this->boostMultiplier = 1.0;
            $this->boostEndTime = 0;
        }
    }

    private function saveBoost(): void {
        $this->jobData->set("boost_multiplier", $this->boostMultiplier);
        $this->jobData->set("boost_end_time", $this->boostEndTime);
        $this->jobData->save();
    }

    public function isBoostActive(): bool {
        return $this->boostMultiplier > 1.0 && time() < $this->boostEndTime;
    }

    public function getBoostMultiplier(): float {
        return $this->boostMultiplier;
    }

    private function parseTime(string $timeStr): int {
        $unit = substr($timeStr, -1);
        $value = (int)substr($timeStr, 0, -1);
        if($value <= 0) return 0;

        return match($unit) {
            's' => $value,
            'm' => $value * 60,
            'h' => $value * 3600,
            'd' => $value * 86400,
            default => 0
        };
    }

    private function respawnAllNPCs(): void {
        $mainNpcs = $this->npcData->get("main_npcs", []);
        foreach($mainNpcs as $npcInfo) {
            $world = $this->getServer()->getWorldManager()->getWorldByName($npcInfo["world"]);
            if($world === null) continue;
            $location = new \pocketmine\entity\Location(
                $npcInfo["x"], $npcInfo["y"], $npcInfo["z"],
                $world, $npcInfo["yaw"], $npcInfo["pitch"]
            );
            $nbt = CompoundTag::create();
            $nbt->setInt("JobId", $npcInfo["jobId"]);
            $entity = new JobNPC($location, JobNPC::createDefaultSkin(), $nbt);
            $entity->spawnToAll();
        }

        $workerNpcs = $this->npcData->get("worker_npcs", []);
        foreach($workerNpcs as $npcInfo) {
            $world = $this->getServer()->getWorldManager()->getWorldByName($npcInfo["world"]);
            if($world === null) continue;
            $location = new \pocketmine\entity\Location(
                $npcInfo["x"], $npcInfo["y"], $npcInfo["z"],
                $world, $npcInfo["yaw"], $npcInfo["pitch"]
            );
            $nbt = CompoundTag::create();
            $nbt->setInt("JobId", $npcInfo["jobId"]);
            $nbt->setInt("WorkerNpcId", $npcInfo["npcId"]);
            $entity = new WorkerNPC($location, WorkerNPC::createDefaultSkin(), $nbt);
            $entity->spawnToAll();
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if(!$sender instanceof Player) {
            $sender->sendMessage("§c§l[RcJob] §eТолько для игроков!");
            return true;
        }

        if(!$sender->hasPermission("rcjob.admin")) {
            $sender->sendMessage("§c§l[RcJob] §eУ вас нет прав!");
            return true;
        }

        $cmdName = strtolower($command->getName());

        switch($cmdName) {
            case "rcjob":
                if(!isset($args[0])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcjob <1|2|3|4>");
                    return true;
                }
                $jobId = (int)$args[0];
                if($jobId < 1 || $jobId > 4) {
                    $sender->sendMessage("§c§l[RcJob] §eНомер от 1 до 4!");
                    return true;
                }
                $this->spawnMainNPC($sender, $jobId);
                return true;

            case "rcjobpoint":
                if(!isset($args[0]) || !isset($args[1])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcjobpoint <1|2|3|4> <1|2>");
                    return true;
                }
                $jobId = (int)$args[0];
                $pointNum = (int)$args[1];
                if($jobId < 1 || $jobId > 4) {
                    $sender->sendMessage("§c§l[RcJob] §eНомер от 1 до 4!");
                    return true;
                }
                if($pointNum < 1 || $pointNum > 2) {
                    $sender->sendMessage("§c§l[RcJob] §eТочка 1 или 2!");
                    return true;
                }
                $this->handlePointSelection($sender, $jobId, $pointNum);
                return true;

            case "rcspawnnpcjob":
                if(!isset($args[0])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcspawnnpcjob <2|3|4>");
                    return true;
                }
                $jobId = (int)$args[0];
                if($jobId < 2 || $jobId > 4) {
                    $sender->sendMessage("§c§l[RcJob] §eНомер от 2 до 4!");
                    return true;
                }
                $this->spawnWorkerNPC($sender, $jobId);
                return true;

            case "rcjobboost":
                if(!isset($args[0]) || !isset($args[1])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcjobboost <множитель> <время>");
                    $sender->sendMessage("§7Пример: /rcjobboost 2 1h");
                    $sender->sendMessage("§7Время: s/m/h/d (сек/мин/час/день)");
                    return true;
                }
                $multiplier = (float)$args[0];
                if($multiplier <= 1.0) {
                    $sender->sendMessage("§c§l[RcJob] §eМножитель должен быть больше 1!");
                    return true;
                }
                $seconds = $this->parseTime($args[1]);
                if($seconds <= 0) {
                    $sender->sendMessage("§c§l[RcJob] §eНеверный формат времени! Пример: 30m, 1h, 1d");
                    return true;
                }
                $this->boostMultiplier = $multiplier;
                $this->boostEndTime = time() + $seconds;
                $this->saveBoost();
                $this->getServer()->broadcastMessage("§a§l[RcJob] §eБуст §bx{$multiplier} §eактивирован на §b{$args[1]}§e!");
                $sender->sendMessage("§a§l[RcJob] §eБуст установлен! Не действует на 5 уровень.");
                return true;

            case "rcjoblevel":
                if(!isset($args[0]) || !isset($args[1])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcjoblevel <ник> <1-5>");
                    return true;
                }
                $targetName = $args[0];
                $newLevel = (int)$args[1];
                if($newLevel < 1 || $newLevel > 5) {
                    $sender->sendMessage("§c§l[RcJob] §eУровень от 1 до 5!");
                    return true;
                }
                $target = $this->getServer()->getPlayerExact($targetName);
                if($target === null) {
                    $sender->sendMessage("§c§l[RcJob] §eИгрок не найден!");
                    return true;
                }
                if(!$this->isWorking($target->getName())) {
                    $sender->sendMessage("§c§l[RcJob] §eИгрок сейчас не работает!");
                    return true;
                }
                $jobId = $this->getWorkerJob($target->getName());
                $pData = $this->getPlayerData($target->getName());
                $pData["job_{$jobId}_level"] = $newLevel;
                $pData["job_{$jobId}_xp"] = self::SKILL_XP[$newLevel] ?? 0;
                $this->savePlayerData($target->getName(), $pData);
                $jobName = self::JOB_NAMES[$jobId] ?? "Подработка";
                $sender->sendMessage("§a§l[RcJob] §eИгроку §b{$targetName} §eустановлен §b{$newLevel} §eуровень в §b{$jobName}");
                $target->sendMessage("§a§l[RcJob] §eАдмин установил вам §b{$newLevel} §eуровень в §b{$jobName}§e!");
                return true;

            case "rcjobstats":
                if(!isset($args[0])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcjobstats <ник>");
                    return true;
                }
                $targetName = $args[0];
                $this->formManager->openStatsForm($sender, $targetName);
                return true;

            case "rcjobremove":
                if(!isset($args[0])) {
                    $sender->sendMessage("§e§l[RcJob] §b/rcjobremove <1|2|3|4>");
                    return true;
                }
                $jobId = (int)$args[0];
                if($jobId < 1 || $jobId > 4) {
                    $sender->sendMessage("§c§l[RcJob] §eНомер от 1 до 4!");
                    return true;
                }
                $this->removeJob($sender, $jobId);
                return true;
        }

        return false;
    }

    private function removeJob(Player $player, int $jobId): void {
        $jobName = self::JOB_NAMES[$jobId] ?? "Подработка";

        foreach($this->activeWorkers as $name => $data) {
            if($data["job"] === $jobId) {
                $this->endWork($name);
            }
        }

        foreach($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach($world->getEntities() as $entity) {
                if($entity instanceof JobNPC && $entity->getJobId() === $jobId) {
                    $entity->flagForDespawn();
                }
                if($entity instanceof WorkerNPC && $entity->getJobId() === $jobId) {
                    $entity->flagForDespawn();
                }
            }
        }

        $mainNpcs = $this->npcData->get("main_npcs", []);
        $mainNpcs = array_values(array_filter($mainNpcs, fn($n) => $n["jobId"] !== $jobId));
        $this->npcData->set("main_npcs", $mainNpcs);

        $workerNpcs = $this->npcData->get("worker_npcs", []);
        $workerNpcs = array_values(array_filter($workerNpcs, fn($n) => $n["jobId"] !== $jobId));
        $this->npcData->set("worker_npcs", $workerNpcs);

        $this->npcData->save();

        unset($this->jobZones[$jobId]);
        $this->jobData->remove("job_$jobId");
        $this->jobData->save();

        $player->sendMessage("§a§l[RcJob] §eПодработка §b{$jobName} §eудалена!");
        $player->sendMessage("§7Зона, НПС удалены. Данные игроков сохранены.");
    }

    private function handlePointSelection(Player $player, int $jobId, int $pointNum): void {
        $name = $player->getName();
        $pos = $player->getPosition()->floor();
        $world = $player->getWorld()->getFolderName();

        if(!isset($this->selections[$name])) {
            $this->selections[$name] = [];
        }

        if($pointNum === 1) {
            $this->selections[$name]["pos1"] = $pos;
            $this->selections[$name]["job"] = $jobId;
            $this->selections[$name]["world"] = $world;
            $player->sendMessage("§a§l[RcJob] §eТочка 1: §b{$pos->x}, {$pos->y}, {$pos->z}");
        } elseif($pointNum === 2) {
            if(!isset($this->selections[$name]["pos1"]) || !isset($this->selections[$name]["job"]) || $this->selections[$name]["job"] !== $jobId) {
                $player->sendMessage("§c§l[RcJob] §eСначала точку 1!");
                return;
            }
            $this->selections[$name]["pos2"] = $pos;
            $player->sendMessage("§a§l[RcJob] §eТочка 2: §b{$pos->x}, {$pos->y}, {$pos->z}");

            $this->saveJobZone($jobId, [
                "pos1" => ["x" => $this->selections[$name]["pos1"]->x, "y" => $this->selections[$name]["pos1"]->y, "z" => $this->selections[$name]["pos1"]->z],
                "pos2" => ["x" => $pos->x, "y" => $pos->y, "z" => $pos->z],
                "world" => $world
            ]);
            $jobName = self::JOB_NAMES[$jobId] ?? "Подработка";
            $player->sendMessage("§a§l[RcJob] §eЗона '§b$jobName§e' сохранена!");
            unset($this->selections[$name]);
        }
    }

    private function saveJobZone(int $jobId, array $data): void {
        $this->jobZones[$jobId] = $data;
        $this->jobData->set("job_$jobId", $data);
        $this->jobData->save();
    }

    private function loadJobZones(): void {
        for($i = 1; $i <= 4; $i++) {
            $data = $this->jobData->get("job_$i", null);
            if($data !== null) {
                $this->jobZones[$i] = $data;
            }
        }
    }

    public function getJobZone(int $jobId): ?array {
        return $this->jobZones[$jobId] ?? null;
    }

    public function isInZone(Vector3 $pos, int $jobId, string $world): bool {
        $zone = $this->jobZones[$jobId] ?? null;
        if($zone === null) return false;
        if(($zone["world"] ?? "") !== $world) return false;

        $p1 = $zone["pos1"];
        $p2 = $zone["pos2"];

        $minX = min($p1["x"], $p2["x"]);
        $maxX = max($p1["x"], $p2["x"]);
        $minY = min($p1["y"], $p2["y"]);
        $maxY = max($p1["y"], $p2["y"]);
        $minZ = min($p1["z"], $p2["z"]);
        $maxZ = max($p1["z"], $p2["z"]);

        return $pos->x >= $minX && $pos->x <= $maxX
            && $pos->y >= $minY && $pos->y <= $maxY
            && $pos->z >= $minZ && $pos->z <= $maxZ;
    }

    public function isNearZone(Vector3 $pos, int $jobId, string $world): bool {
        $zone = $this->jobZones[$jobId] ?? null;
        if($zone === null) return false;
        if(($zone["world"] ?? "") !== $world) return false;

        $p1 = $zone["pos1"];
        $p2 = $zone["pos2"];

        $centerX = ($p1["x"] + $p2["x"]) / 2;
        $centerY = ($p1["y"] + $p2["y"]) / 2;
        $centerZ = ($p1["z"] + $p2["z"]) / 2;
        $center = new Vector3($centerX, $centerY, $centerZ);

        $sizeX = abs($p1["x"] - $p2["x"]) / 2;
        $sizeY = abs($p1["y"] - $p2["y"]) / 2;
        $sizeZ = abs($p1["z"] - $p2["z"]) / 2;
        $maxRadius = sqrt($sizeX ** 2 + $sizeY ** 2 + $sizeZ ** 2) + self::LEAVE_DISTANCE;

        return $pos->distance($center) <= $maxRadius;
    }

    public function getBarrelsInZone(int $jobId): array {
        $zone = $this->getJobZone($jobId);
        if($zone === null) return [];

        $worldName = $zone["world"];
        $world = $this->getServer()->getWorldManager()->getWorldByName($worldName);
        if($world === null) return [];

        $p1 = $zone["pos1"];
        $p2 = $zone["pos2"];

        $minX = (int)min($p1["x"], $p2["x"]);
        $maxX = (int)max($p1["x"], $p2["x"]);
        $minY = (int)min($p1["y"], $p2["y"]);
        $maxY = (int)max($p1["y"], $p2["y"]);
        $minZ = (int)min($p1["z"], $p2["z"]);
        $maxZ = (int)max($p1["z"], $p2["z"]);

        $barrels = [];
        for($x = $minX; $x <= $maxX; $x++) {
            for($y = $minY; $y <= $maxY; $y++) {
                for($z = $minZ; $z <= $maxZ; $z++) {
                    $block = $world->getBlockAt($x, $y, $z);
                    if($block->getTypeId() === VanillaBlocks::BARREL()->getTypeId()) {
                        $barrels[] = new Vector3($x, $y, $z);
                    }
                }
            }
        }
        return $barrels;
    }

    private function spawnMainNPC(Player $player, int $jobId): void {
        $location = $player->getLocation();
        $nbt = CompoundTag::create();
        $nbt->setInt("JobId", $jobId);
        $entity = new JobNPC($location, JobNPC::createDefaultSkin(), $nbt);
        $entity->spawnToAll();

        $mainNpcs = $this->npcData->get("main_npcs", []);
        $mainNpcs[] = [
            "jobId" => $jobId,
            "x" => $location->getX(),
            "y" => $location->getY(),
            "z" => $location->getZ(),
            "yaw" => $location->getYaw(),
            "pitch" => $location->getPitch(),
            "world" => $location->getWorld()->getFolderName()
        ];
        $this->npcData->set("main_npcs", $mainNpcs);
        $this->npcData->save();

        $player->sendMessage("§a§l[RcJob] §eНПС '§b" . self::JOB_NAMES[$jobId] . "§e' создан!");
    }

    private function spawnWorkerNPC(Player $player, int $jobId): void {
        $location = $player->getLocation();

        $workerNpcs = $this->npcData->get("worker_npcs", []);
        $npcId = count($workerNpcs) + 1;

        $nbt = CompoundTag::create();
        $nbt->setInt("JobId", $jobId);
        $nbt->setInt("WorkerNpcId", $npcId);
        $entity = new WorkerNPC($location, WorkerNPC::createDefaultSkin(), $nbt);
        $entity->spawnToAll();

        $workerNpcs[] = [
            "jobId" => $jobId,
            "npcId" => $npcId,
            "x" => $location->getX(),
            "y" => $location->getY(),
            "z" => $location->getZ(),
            "yaw" => $location->getYaw(),
            "pitch" => $location->getPitch(),
            "world" => $location->getWorld()->getFolderName()
        ];
        $this->npcData->set("worker_npcs", $workerNpcs);
        $this->npcData->save();

        $names = [2 => "Клиент", 3 => "Скупщик", 4 => "Заказчик"];
        $player->sendMessage("§a§l[RcJob] §e" . ($names[$jobId] ?? "НПС") . " создан! ID: §b$npcId");
    }

    public function startWork(Player $player, int $jobId): bool {
        $name = $player->getName();

        if(isset($this->activeWorkers[$name])) {
            $player->sendMessage("§c§l[RcJob] §eВы уже работаете!");
            return false;
        }

        $zone = $this->getJobZone($jobId);
        if($zone === null) {
            $player->sendMessage("§c§l[RcJob] §eЗона не настроена!");
            return false;
        }

        $pData = $this->getPlayerData($name);
        $lastReset = $pData["job_{$jobId}_last_reset"] ?? 0;
        $blocksToday = $pData["job_{$jobId}_blocks_today"] ?? 0;

        if(time() - $lastReset >= 86400) {
            $blocksToday = 0;
            $pData["job_{$jobId}_last_reset"] = time();
            $pData["job_{$jobId}_blocks_today"] = 0;
            $this->savePlayerData($name, $pData);
        }

        if($blocksToday >= self::MAX_BLOCKS_PER_DAY) {
            $remaining = 86400 - (time() - $lastReset);
            $hours = intdiv($remaining, 3600);
            $minutes = intdiv($remaining % 3600, 60);
            $player->sendMessage("§c§l[RcJob] §eЛимит! Подождите: §b{$hours}ч {$minutes}мин");
            return false;
        }

        $this->activeWorkers[$name] = [
            "job" => $jobId,
            "startTime" => time(),
            "blocksBroken" => 0,
            "earned" => 0.0,
            "totalBlocksToday" => $blocksToday
        ];

        if($jobId === 2) {
            $this->giveComputerTools($player);
        }

        $jobName = self::JOB_NAMES[$jobId] ?? "Подработка";
        $player->sendMessage("§a§l[RcJob] §eВы устроились: §b$jobName");
        return true;
    }

    public function endWork(string $playerName, bool $silent = false): void {
        if(!isset($this->activeWorkers[$playerName])) return;

        $data = $this->activeWorkers[$playerName];
        $jobId = $data["job"];
        $earned = $data["earned"];
        $broken = $data["blocksBroken"];

        $pData = $this->getPlayerData($playerName);
        $pData["job_{$jobId}_total_earned"] = ($pData["job_{$jobId}_total_earned"] ?? 0) + $earned;
        $pData["job_{$jobId}_total_blocks"] = ($pData["job_{$jobId}_total_blocks"] ?? 0) + $broken;
        $pData["job_{$jobId}_xp"] = ($pData["job_{$jobId}_xp"] ?? 0) + $broken;
        $pData["job_{$jobId}_blocks_today"] = $data["totalBlocksToday"] + $broken;

        $currentXp = $pData["job_{$jobId}_xp"] ?? 0;
        $currentLevel = $pData["job_{$jobId}_level"] ?? 1;
        $oldLevel = $currentLevel;
        foreach(self::SKILL_XP as $level => $required) {
            if($currentXp >= $required && $level > $currentLevel) {
                $currentLevel = $level;
            }
        }
        $pData["job_{$jobId}_level"] = $currentLevel;
        $this->savePlayerData($playerName, $pData);

        $player = $this->getServer()->getPlayerExact($playerName);

        if($player !== null) {
            if($jobId === 2) $this->removeComputerTools($player);
            if($jobId === 3) $this->removeLogsFromInventory($player);
            if($jobId === 4) $this->removeParcel($player);
        }

        unset($this->activeWorkers[$playerName]);
        unset($this->computerNpcState[$playerName]);
        unset($this->warehouseTargets[$playerName]);
        unset($this->pendingCaptchas[$playerName]);

        if(!$silent && $player !== null) {
            $jobName = self::JOB_NAMES[$jobId] ?? "Подработка";
            $player->sendMessage("§a§l[RcJob] §eВы уволились: §b$jobName");
            $player->sendMessage("§a§l[RcJob] §eЗаработано: §a" . round($earned, 2) . " руб. §e| Действий: §b{$broken}");

            if($currentLevel > $oldLevel) {
                $this->formManager->openLevelUpForm($player, $jobId, $currentLevel);
            }
        }
    }

    private function giveComputerTools(Player $player): void {
        $items = [
            VanillaItems::STICK()->setCustomName(self::TOOL_NAMES["screwdriver"]),
            VanillaItems::BLAZE_ROD()->setCustomName(self::TOOL_NAMES["flashlight"]),
            VanillaItems::IRON_INGOT()->setCustomName(self::TOOL_NAMES["soldering"]),
            VanillaItems::STRING()->setCustomName(self::TOOL_NAMES["cable"])
        ];
        foreach($items as $item) {
            $nbt = $item->getNamedTag();
            $nbt->setString("rcjob_tool", "yes");
            $item->setNamedTag($nbt);
            $player->getInventory()->addItem($item);
        }
    }

    private function removeComputerTools(Player $player): void {
        foreach($player->getInventory()->getContents() as $slot => $item) {
            if($item->getNamedTag()->getTag("rcjob_tool") !== null) {
                $player->getInventory()->clear($slot);
            }
        }
    }

    private function removeLogsFromInventory(Player $player): void {
        foreach($player->getInventory()->getContents() as $slot => $item) {
            if($item->getNamedTag()->getTag("rcjob_log") !== null) {
                $player->getInventory()->clear($slot);
            }
        }
    }

    public function getHeldToolKey(Player $player): ?string {
        $item = $player->getInventory()->getItemInHand();
        if($item->getNamedTag()->getTag("rcjob_tool") === null) return null;
        $customName = $item->getCustomName();
        foreach(self::TOOL_NAMES as $key => $tName) {
            if($customName === $tName) return $key;
        }
        return null;
    }

    public function setComputerNpcState(string $playerName, int $npcId, array $state): void {
        $this->computerNpcState[$playerName][$npcId] = $state;
    }

    public function getComputerNpcState(string $playerName, int $npcId): ?array {
        return $this->computerNpcState[$playerName][$npcId] ?? null;
    }

    public function clearComputerNpcState(string $playerName, int $npcId): void {
        unset($this->computerNpcState[$playerName][$npcId]);
    }

    public function setWarehouseTarget(string $playerName, ?Vector3 $target): void {
        if($target === null) {
            unset($this->warehouseTargets[$playerName]);
        } else {
            $this->warehouseTargets[$playerName] = $target;
        }
    }

    public function getWarehouseTarget(string $playerName): ?Vector3 {
        return $this->warehouseTargets[$playerName] ?? null;
    }

    public function hasParcel(Player $player): bool {
        foreach($player->getInventory()->getContents() as $item) {
            if($item->getNamedTag()->getTag("rcjob_parcel") !== null) return true;
        }
        return false;
    }

    public function giveParcel(Player $player): void {
        $item = VanillaBlocks::CHEST()->asItem();
        $item->setCustomName("§l§6Посылка");
        $item->setLore(["§7Отнесите на подсвеченную бочку"]);
        $nbt = $item->getNamedTag();
        $nbt->setString("rcjob_parcel", "yes");
        $item->setNamedTag($nbt);
        $player->getInventory()->addItem($item);
    }

    public function removeParcel(Player $player): void {
        foreach($player->getInventory()->getContents() as $slot => $item) {
            if($item->getNamedTag()->getTag("rcjob_parcel") !== null) {
                $player->getInventory()->clear($slot);
                return;
            }
        }
    }

    public function addEarnings(string $playerName, int $jobId, float $amount): void {
        if(!isset($this->activeWorkers[$playerName])) return;
        $this->activeWorkers[$playerName]["earned"] += $amount;
        $this->activeWorkers[$playerName]["blocksBroken"]++;
        $this->giveMoney($playerName, $amount);
    }

    public function addLogEarnings(string $playerName, int $count, float $amount): void {
        if(!isset($this->activeWorkers[$playerName])) return;
        $this->activeWorkers[$playerName]["earned"] += $amount;
        $this->giveMoney($playerName, $amount);
    }

    public function sendJobTip(Player $player): void {
        $name = $player->getName();
        if(!isset($this->activeWorkers[$name])) return;

        $data = $this->activeWorkers[$name];
        $jobId = $data["job"];
        $earned = round($data["earned"], 2);
        $remaining = self::MAX_BLOCKS_PER_DAY - ($data["totalBlocksToday"] + $data["blocksBroken"]);
        $jobName = self::JOB_NAMES[$jobId] ?? "Подработка";

        $boostText = "";
        if($this->isBoostActive()) {
            $boostText = " §c§lx" . $this->boostMultiplier;
        }

        $player->sendTip("§l§b{$jobName} §f| §a{$earned} руб.{$boostText} §f| §eОсталось: §c{$remaining}§e/1000");
    }

    public function removePendingCaptcha(string $name): void {
        unset($this->pendingCaptchas[$name]);
    }

    private function sendCaptchaToAll(): void {
        foreach($this->activeWorkers as $name => $data) {
            if(isset($this->pendingCaptchas[$name])) continue;
            $player = $this->getServer()->getPlayerExact($name);
            if($player === null) continue;

            $type = mt_rand(0, 2);

            if($type === 0) {
                $a = mt_rand(1, 20);
                $b = mt_rand(1, 20);
                $answer = $a + $b;
                $question = "{$a} + {$b}";
            } elseif($type === 1) {
                $a = mt_rand(10, 30);
                $b = mt_rand(1, 10);
                $answer = $a - $b;
                $question = "{$a} - {$b}";
            } else {
                $a = mt_rand(2, 10);
                $b = mt_rand(2, 10);
                $answer = $a * $b;
                $question = "{$a} × {$b}";
            }

            $this->pendingCaptchas[$name] = ["time" => time(), "answer" => $answer];
            $this->formManager->openCaptchaForm($player, $question, $answer);
        }
    }

    private function checkCaptchaTimeouts(): void {
        foreach($this->pendingCaptchas as $name => $data) {
            if(time() - $data["time"] > 60) {
                $player = $this->getServer()->getPlayerExact($name);
                unset($this->pendingCaptchas[$name]);
                if($player !== null) {
                    $player->kick("§c§l[RcJob] §eВремя на проверку истекло!");
                }
            }
        }

        if($this->boostMultiplier > 1.0 && time() >= $this->boostEndTime) {
            $this->boostMultiplier = 1.0;
            $this->boostEndTime = 0;
            $this->saveBoost();
            $this->getServer()->broadcastMessage("§c§l[RcJob] §eБуст завершён!");
        }
    }

    public function isWorking(string $playerName): bool {
        return isset($this->activeWorkers[$playerName]);
    }

    public function getWorkerData(string $playerName): ?array {
        return $this->activeWorkers[$playerName] ?? null;
    }

    public function getWorkerJob(string $playerName): int {
        return $this->activeWorkers[$playerName]["job"] ?? 0;
    }

    public function canDoMore(string $playerName): bool {
        if(!isset($this->activeWorkers[$playerName])) return false;
        $data = $this->activeWorkers[$playerName];
        return ($data["totalBlocksToday"] + $data["blocksBroken"]) < self::MAX_BLOCKS_PER_DAY;
    }

    public function getPlayerData(string $name): array {
        return $this->playerData->get($name, []);
    }

    public function savePlayerData(string $name, array $data): void {
        $this->playerData->set($name, $data);
        $this->playerData->save();
    }

    public function getSkillLevel(string $name, int $jobId): int {
        $data = $this->getPlayerData($name);
        return $data["job_{$jobId}_level"] ?? 1;
    }

    public function getSkillXp(string $name, int $jobId): int {
        $data = $this->getPlayerData($name);
        return $data["job_{$jobId}_xp"] ?? 0;
    }

    public function getXpForNextLevel(int $currentLevel): int {
        $next = $currentLevel + 1;
        if($next > 5) return 0;
        return self::SKILL_XP[$next] ?? 0;
    }

    public function getTotalEarned(string $name, int $jobId): float {
        $data = $this->getPlayerData($name);
        return (float)($data["job_{$jobId}_total_earned"] ?? 0);
    }

    public function getCooldownRemaining(string $name, int $jobId): int {
        $data = $this->getPlayerData($name);
        $lastReset = $data["job_{$jobId}_last_reset"] ?? 0;
        $blocksToday = $data["job_{$jobId}_blocks_today"] ?? 0;
        if(time() - $lastReset >= 86400) return 0;
        if($blocksToday >= self::MAX_BLOCKS_PER_DAY) {
            return 86400 - (time() - $lastReset);
        }
        return 0;
    }

    public function getBlocksToday(string $name, int $jobId): int {
        $data = $this->getPlayerData($name);
        $lastReset = $data["job_{$jobId}_last_reset"] ?? 0;
        if(time() - $lastReset >= 86400) return 0;
        return $data["job_{$jobId}_blocks_today"] ?? 0;
    }

    public function getPayRange(int $jobId, int $skillLevel): array {
        if(isset(self::JOB_PAY_PER_LEVEL[$jobId][$skillLevel])) {
            return self::JOB_PAY_PER_LEVEL[$jobId][$skillLevel];
        }
        $base = self::JOB_PAY[$jobId] ?? [3, 6];
        $bonus = ($skillLevel - 1) * 1.0;
        return [$base[0] + $bonus, $base[1] + $bonus];
    }

    public function calculatePay(int $jobId, int $skillLevel): float {
        $range = $this->getPayRange($jobId, $skillLevel);
        $pay = round(mt_rand((int)($range[0] * 100), (int)($range[1] * 100)) / 100, 2);

        if($skillLevel < 5 && $this->isBoostActive()) {
            $pay = round($pay * $this->boostMultiplier, 2);
        }

        return $pay;
    }

    public function countLogsInInventory(Player $player): int {
        $count = 0;
        foreach($player->getInventory()->getContents() as $item) {
            if($item->getNamedTag()->getTag("rcjob_log") !== null) {
                $count += $item->getCount();
            }
        }
        return $count;
    }

    public function removeAllLogs(Player $player): int {
        $count = 0;
        foreach($player->getInventory()->getContents() as $slot => $item) {
            if($item->getNamedTag()->getTag("rcjob_log") !== null) {
                $count += $item->getCount();
                $player->getInventory()->clear($slot);
            }
        }
        return $count;
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        $block = $event->getBlock();
        $pos = $block->getPosition();
        $world = $pos->getWorld()->getFolderName();

        if(!isset($this->activeWorkers[$name])) return;

        $data = $this->activeWorkers[$name];
        $jobId = $data["job"];

        if(!$this->canDoMore($name)) {
            $player->sendMessage("§c§l[RcJob] §eЛимит на сегодня!");
            $this->endWork($name);
            return;
        }

        switch($jobId) {
            case 1:
                if(!($block instanceof Wheat) || $block->getAge() < 7) return;
                if(!$this->isInZone($pos, $jobId, $world)) return;

                $event->setDrops([]);
                $event->setXpDropAmount(0);

                $skillLevel = $this->getSkillLevel($name, $jobId);
                $pay = $this->calculatePay($jobId, $skillLevel);

                $this->addEarnings($name, $jobId, $pay);

                $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($pos): void {
                    $wheat = VanillaBlocks::WHEAT();
                    $wheat->setAge(7);
                    $pos->getWorld()->setBlock($pos, $wheat);
                }), 1);

                $this->sendJobTip($player);
                break;

            case 3:
                if(!($block instanceof Wood)) return;
                if(!$this->isInZone($pos, $jobId, $world)) return;

                $event->setDrops([]);
                $event->setXpDropAmount(0);

                $this->activeWorkers[$name]["blocksBroken"]++;

                $logItem = $block->asItem();
                $logItem->setCustomName("§l§6Бревно");
                $nbt = $logItem->getNamedTag();
                $nbt->setString("rcjob_log", "yes");
                $logItem->setNamedTag($nbt);
                $player->getInventory()->addItem($logItem);

                $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($pos, $block): void {
                    $pos->getWorld()->setBlock($pos, $block);
                }), 1);

                $this->sendJobTip($player);
                break;
        }
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        $block = $event->getBlock();
        $pos = $block->getPosition();

        if(!isset($this->activeWorkers[$name])) return;
        $jobId = $this->activeWorkers[$name]["job"];

        if($jobId === 4 && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if($block->getTypeId() !== VanillaBlocks::BARREL()->getTypeId()) return;

            $event->cancel();

            if(!$this->hasParcel($player)) return;

            $target = $this->getWarehouseTarget($name);
            if($target === null) return;

            if($pos->floor()->equals($target->floor())) {
                $this->removeParcel($player);

                $skillLevel = $this->getSkillLevel($name, $jobId);
                $pay = $this->calculatePay($jobId, $skillLevel);
                $this->addEarnings($name, $jobId, $pay);

                $this->setWarehouseTarget($name, null);

                $this->sendJobTip($player);
                $player->sendMessage("§a§l[RcJob] §eПосылка доставлена! Вернитесь за новой.");
            } else {
                $player->sendMessage("§c§l[RcJob] §eЭто не та бочка!");
            }
        }
    }

    public function onPlayerDropItem(PlayerDropItemEvent $event): void {
        $item = $event->getItem();
        $nbt = $item->getNamedTag();

        if($nbt->getTag("rcjob_tool") !== null || $nbt->getTag("rcjob_parcel") !== null || $nbt->getTag("rcjob_log") !== null) {
            $event->cancel();
            $event->getPlayer()->sendMessage("§c§l[RcJob] §eНельзя выбрасывать рабочие предметы!");
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $name = $event->getPlayer()->getName();
        if(isset($this->activeWorkers[$name])) {
            $this->endWork($name, true);
        }
        unset($this->selections[$name]);
        unset($this->pendingCaptchas[$name]);
    }

    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();

        if(!isset($this->activeWorkers[$name])) return;

        $jobId = $this->activeWorkers[$name]["job"];
        $pos = $player->getPosition();
        $world = $player->getWorld()->getFolderName();

        if(!$this->isNearZone($pos, $jobId, $world)) {
            $player->sendMessage("§c§l[RcJob] §eВы ушли далеко! Подработка завершена.");
            $this->endWork($name);
        }
    }

    private function tickWorkers(): void {
        foreach($this->activeWorkers as $name => $data) {
            $player = $this->getServer()->getPlayerExact($name);
            if($player === null) {
                $this->endWork($name, true);
                continue;
            }

            $this->sendJobTip($player);
        }
    }

    private function tickWarehouseParticles(): void {
        foreach($this->warehouseTargets as $name => $target) {
            $player = $this->getServer()->getPlayerExact($name);
            if($player === null) {
                unset($this->warehouseTargets[$name]);
                continue;
            }

            $world = $player->getWorld();

            for($i = 0; $i < 16; $i++) {
                $angle = ($i / 16) * 2 * M_PI;
                $px = $target->x + 0.5 + cos($angle) * 0.7;
                $pz = $target->z + 0.5 + sin($angle) * 0.7;
                $world->addParticle(new Vector3($px, $target->y + 0.2, $pz), new HappyVillagerParticle(), [$player]);
            }

            for($i = 0; $i < 8; $i++) {
                $angle = ($i / 8) * 2 * M_PI;
                $px = $target->x + 0.5 + cos($angle) * 0.4;
                $pz = $target->z + 0.5 + sin($angle) * 0.4;
                $world->addParticle(new Vector3($px, $target->y + 0.5, $pz), new HappyVillagerParticle(), [$player]);
            }
        }
    }
}