<?php

namespace InzeOwr\RcOrg\systems;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;
use InzeOwr\RcOrg\Main;
use InzeOwr\RcOrg\forms\TreasuryForms;
use InzeOwr\RcOrg\forms\Forms;

class TreasurySystem {

    private Main $plugin;
    private Config $treasury;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->treasury = new Config($plugin->getDataFolder() . "treasury.json", Config::JSON);
    }

    public function getBalance(string $orgKey): float {
        return (float)$this->treasury->getNested("$orgKey.balance", 0);
    }

    public function addBalance(string $orgKey, float $amount): void {
        $current = $this->getBalance($orgKey);
        $this->treasury->setNested("$orgKey.balance", $current + $amount);
        $this->treasury->save();
    }

    public function removeBalance(string $orgKey, float $amount): bool {
        $current = $this->getBalance($orgKey);
        if ($current < $amount) return false;
        $this->treasury->setNested("$orgKey.balance", $current - $amount);
        $this->treasury->save();
        return true;
    }

    public function getWithdrawnToday(string $playerName): float {
        $key = strtolower($playerName);
        $data = $this->treasury->getNested("withdraw_limits.$key", null);
        if ($data === null) return 0;

        $lastDate = $data['date'] ?? "";
        $today = date("d.m.Y");

        if ($lastDate !== $today) return 0;
        return (float)($data['amount'] ?? 0);
    }

    public function addWithdrawnToday(string $playerName, float $amount): void {
        $key = strtolower($playerName);
        $current = $this->getWithdrawnToday($playerName);
        $this->treasury->setNested("withdraw_limits.$key", [
            "date" => date("d.m.Y"),
            "amount" => $current + $amount
        ]);
        $this->treasury->save();
    }

    public function getRemainingWithdrawLimit(string $playerName): float {
        return max(0, 100000 - $this->getWithdrawnToday($playerName));
    }

    public function getBonusReceivedThisWeek(string $playerName): float {
        $key = strtolower($playerName);
        $data = $this->treasury->getNested("bonus_limits.$key", null);
        if ($data === null) return 0;

        $lastWeek = $data['week'] ?? "";
        $currentWeek = date("W.Y");

        if ($lastWeek !== $currentWeek) return 0;
        return (float)($data['amount'] ?? 0);
    }

    public function addBonusReceived(string $playerName, float $amount): void {
        $key = strtolower($playerName);
        $current = $this->getBonusReceivedThisWeek($playerName);
        $this->treasury->setNested("bonus_limits.$key", [
            "week" => date("W.Y"),
            "amount" => $current + $amount
        ]);
        $this->treasury->save();
    }

    public function getRemainingBonusLimit(string $playerName): float {
        return max(0, 50000 - $this->getBonusReceivedThisWeek($playerName));
    }

    public function deposit(Player $player, string $orgKey, float $amount): void {
        if ($this->plugin->getPlayerOrg($player->getName()) !== $orgKey || $this->plugin->getPlayerRank($player->getName()) < 16) {
            $player->sendMessage("§c§l[Казна] §r§l§fУ вас нет доступа к управлению казной.");
            return;
        }
        if ($amount < 100) {
            $player->sendMessage("§c§l[Казна] §6§lМинимальная сумма пополнения: §e§l100\$");
            return;
        }

        $money = EconomyAPI::getInstance()->myMoney($player);
        if ($money < $amount) {
            $player->sendMessage("§c§l[Казна] §6§lНедостаточно средств на личном счёте.");
            return;
        }

        EconomyAPI::getInstance()->reduceMoney($player, $amount);
        $this->addBalance($orgKey, $amount);

        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $newBalance = $this->getBalance($orgKey);

        $player->sendMessage("§6§l[Казна] §e§lВы пополнили казну {$coloredOrg} §e§lна §a§l" . number_format($amount) . "\$");
        $player->sendMessage("§6§l[Казна] §e§lТекущий баланс казны: §a§l" . number_format($newBalance) . "\$");

        $rankName = $this->plugin->getRealRankName($player->getName());
        $this->plugin->addLog($orgKey, "§e§l{$player->getName()} §6§l({$rankName}§6§l) пополнил казну на §a§l" . number_format($amount) . "\$§6§l. Баланс: §a§l" . number_format($newBalance) . "\$");
    }

    public function withdraw(Player $player, string $orgKey, float $amount): void {
        $rank = $this->plugin->getPlayerRank($player->getName());
        if ($this->plugin->getPlayerOrg($player->getName()) !== $orgKey || $rank < 16) {
            $player->sendMessage("§c§l[Казна] §r§l§fУ вас нет доступа к управлению казной.");
            return;
        }

        if ($amount < 100) {
            $player->sendMessage("§c§l[Казна] §6§lМинимальная сумма снятия: §e§l100\$");
            return;
        }

        if ($rank === 16) {
            $remaining = $this->getRemainingWithdrawLimit($player->getName());
            if ($amount > $remaining) {
                $player->sendMessage("§c§l[Казна] §6§lПревышен дневной лимит снятия.");
                $player->sendMessage("§6§l[Казна] §e§lДоступно к снятию сегодня: §a§l" . number_format($remaining) . "\$");
                return;
            }
        }

        $balance = $this->getBalance($orgKey);
        if ($balance < $amount) {
            $player->sendMessage("§c§l[Казна] §6§lНедостаточно средств в казне.");
            $player->sendMessage("§6§l[Казна] §e§lТекущий баланс: §a§l" . number_format($balance) . "\$");
            return;
        }

        $this->removeBalance($orgKey, $amount);
        EconomyAPI::getInstance()->addMoney($player, $amount);

        if ($rank === 16) {
            $this->addWithdrawnToday($player->getName(), $amount);
        }

        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $newBalance = $this->getBalance($orgKey);

        $player->sendMessage("§6§l[Казна] §e§lВы сняли §a§l" . number_format($amount) . "\$ §e§lиз казны {$coloredOrg}");
        $player->sendMessage("§6§l[Казна] §e§lТекущий баланс казны: §a§l" . number_format($newBalance) . "\$");

        $rankName = $this->plugin->getRealRankName($player->getName());
        $this->plugin->addLog($orgKey, "§c§l{$player->getName()} §6§l({$rankName}§6§l) снял из казны §c§l" . number_format($amount) . "\$§6§l. Баланс: §a§l" . number_format($newBalance) . "\$");
    }

    public function giveBonusToAll(Player $leader, string $orgKey, float $amount): void {
        if ($this->plugin->getPlayerOrg($leader->getName()) !== $orgKey || $this->plugin->getPlayerRank($leader->getName()) < 16) {
            $leader->sendMessage("§c§l[Казна] §r§l§fУ вас нет доступа к выдаче премий.");
            return;
        }
        $targets = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($this->plugin->getPlayerOrg($p->getName()) === $orgKey && $p->getName() !== $leader->getName()) {
                $targets[] = $p;
            }
        }

        if (empty($targets)) {
            $leader->sendMessage("§c§l[Казна] §6§lНет онлайн сотрудников для выдачи премии.");
            return;
        }

        $totalNeeded = 0;
        $canReceive = [];
        $skipped = [];

        foreach ($targets as $p) {
            $remaining = $this->getRemainingBonusLimit($p->getName());
            $give = min($amount, $remaining);
            if ($give <= 0) {
                $skipped[] = $p->getName() . " §7§l(недельный лимит исчерпан)";
            } else {
                $canReceive[] = ["player" => $p, "amount" => $give];
                $totalNeeded += $give;
            }
        }

        $balance = $this->getBalance($orgKey);

        if ($balance <= 0) {
            $leader->sendMessage("§c§l[Казна] §6§lКазна пуста. Пополните баланс.");
            return;
        }

        if ($balance < $totalNeeded) {
            $shortage = $totalNeeded - $balance;
            TreasuryForms::openInsufficientFundsMenu($leader, $orgKey, $amount, $shortage, $balance, "all");
            return;
        }

        $this->removeBalance($orgKey, $totalNeeded);
        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $rankName = $this->plugin->getRealRankName($leader->getName());

        foreach ($canReceive as $entry) {
            $p = $entry['player'];
            $give = $entry['amount'];
            EconomyAPI::getInstance()->addMoney($p, $give);
            $this->addBonusReceived($p->getName(), $give);
            $p->sendMessage("§6§l[Казна] §e§lВам выдана премия §a§l" . number_format($give) . "\$ §e§lот руководства {$coloredOrg}");
        }

        $leader->sendMessage("§6§l[Казна] §e§lПремия выдана §a§l" . count($canReceive) . " §e§lсотрудникам на сумму §a§l" . number_format($totalNeeded) . "\$");

        if (!empty($skipped)) {
            $leader->sendMessage("§c§l[Казна] §6§lПропущены (лимит): §7§l" . implode(", ", $skipped));
        }

        $newBalance = $this->getBalance($orgKey);
        $this->plugin->addLog($orgKey, "§e§l{$leader->getName()} §6§l({$rankName}§6§l) выдал премию всем онлайн сотрудникам по §a§l" . number_format($amount) . "\$§6§l. Итого: §c§l" . number_format($totalNeeded) . "\$§6§l. Баланс: §a§l" . number_format($newBalance) . "\$");
    }

    public function giveBonusToPlayer(Player $leader, string $orgKey, string $targetName, float $amount): void {
        $remaining = $this->getRemainingBonusLimit($targetName);

        if ($remaining <= 0) {
            $leader->sendMessage("§c§l[Казна] §6§lГражданин §e§l{$targetName} §6§lуже получил максимальную премию на этой неделе (§e§l50,000\$§6§l).");
            return;
        }

        $give = min($amount, $remaining);
        $balance = $this->getBalance($orgKey);

        if ($balance <= 0) {
            $leader->sendMessage("§c§l[Казна] §6§lКазна пуста. Пополните баланс.");
            return;
        }

        if ($balance < $give) {
            $shortage = $give - $balance;
            TreasuryForms::openInsufficientFundsMenu($leader, $orgKey, $amount, $shortage, $balance, $targetName);
            return;
        }

        $this->removeBalance($orgKey, $give);
        $this->addBonusReceived($targetName, $give);
        EconomyAPI::getInstance()->addMoney(Server::getInstance()->getPlayerExact($targetName) ?? $targetName, $give);

        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $rankName = $this->plugin->getRealRankName($leader->getName());
        $newBalance = $this->getBalance($orgKey);

        $leader->sendMessage("§6§l[Казна] §e§lПремия §a§l" . number_format($give) . "\$ §e§lвыдана сотруднику §e§l{$targetName}");

        if ($give < $amount) {
            $leader->sendMessage("§c§l[Казна] §6§lВыдано меньше запрошенного — у сотрудника остаток лимита: §e§l" . number_format($remaining) . "\$");
        }

        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target !== null) {
            $target->sendMessage("§6§l[Казна] §e§lВам выдана премия §a§l" . number_format($give) . "\$ §e§lот руководства {$coloredOrg}");
        }

        $this->plugin->addLog($orgKey, "§e§l{$leader->getName()} §6§l({$rankName}§6§l) выдал премию §e§l{$targetName} §6§lна сумму §a§l" . number_format($give) . "\$§6§l. Баланс: §a§l" . number_format($newBalance) . "\$");
    }

    public function govFundOrg(string $orgKey, float $amount, string $byName): string {
        $hasLeader = false;
        foreach ($this->plugin->data->getAll() as $key => $data) {
            if (isset($data['org']) && $data['org'] === $orgKey && isset($data['rank']) && $data['rank'] === 16) {
                $hasLeader = true;
                break;
            }
        }

        if (!$hasLeader) {
            return "no_leader";
        }

        $this->addBalance($orgKey, $amount);
        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $newBalance = $this->getBalance($orgKey);

        $this->plugin->addLog($orgKey, "§6§l[Правительство] §e§l{$byName} §6§lвыделил казне §a§l" . number_format($amount) . "\$§6§l. Баланс: §a§l" . number_format($newBalance) . "\$");

        return "ok";
    }

    public function govFundAll(Player $leader, float $amount): void {
        $orgs = $this->plugin->getConfig()->get("orgs", []);
        $pvOrg = "PV";
        $pvBalance = $this->getBalance($pvOrg);

        $eligibleOrgs = [];
        foreach ($orgs as $key => $name) {
            if ($key === "MF" || $key === $pvOrg) continue;
            $eligibleOrgs[] = $key;
        }

        if (empty($eligibleOrgs)) {
            $leader->sendMessage("§c§l[Казна] §6§lНет доступных организаций для финансирования.");
            return;
        }

        $perOrg = floor($amount / count($eligibleOrgs));
        $totalNeeded = $perOrg * count($eligibleOrgs);

        if ($pvBalance < $totalNeeded) {
            $leader->sendMessage("§c§l[Казна] §6§lНедостаточно средств в казне Правительства.");
            $leader->sendMessage("§6§l[Казна] §e§lТребуется: §c§l" . number_format($totalNeeded) . "\$ §e§l| Баланс: §a§l" . number_format($pvBalance) . "\$");
            return;
        }

        $this->removeBalance($pvOrg, $totalNeeded);

        $success = [];
        $noLeader = [];

        foreach ($eligibleOrgs as $orgKey) {
            $result = $this->govFundOrg($orgKey, $perOrg, $leader->getName());
            $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
            if ($result === "ok") {
                $success[] = $coloredOrg . " §e§l(+" . number_format($perOrg) . "\$§e§l)";
            } else {
                $noLeader[] = $coloredOrg;
                $this->addBalance($pvOrg, $perOrg);
            }
        }

        $rankName = $this->plugin->getRealRankName($leader->getName());
        $newPvBalance = $this->getBalance($pvOrg);

        $leader->sendMessage("§6§l[Казна] §e§lФинансирование выполнено.");

        if (!empty($success)) {
            $leader->sendMessage("§a§l[Казна] §6§lПолучили финансирование:");
            foreach ($success as $s) {
                $leader->sendMessage("  §e§l- {$s}");
            }
        }

        if (!empty($noLeader)) {
            $leader->sendMessage("§c§l[Казна] §6§lНе получили (нет руководителя):");
            foreach ($noLeader as $n) {
                $leader->sendMessage("  §7§l- {$n}");
            }
        }

        $leader->sendMessage("§6§l[Казна] §e§lБаланс казны Правительства: §a§l" . number_format($newPvBalance) . "\$");
        $this->plugin->addLog($pvOrg, "§e§l{$leader->getName()} §6§l({$rankName}§6§l) выделил всем организациям по §a§l" . number_format($perOrg) . "\$§6§l. Баланс ПВ: §a§l" . number_format($newPvBalance) . "\$");
    }

    public function govFundSingle(Player $leader, string $orgKey, float $amount): void {
        $pvOrg = "PV";
        $pvBalance = $this->getBalance($pvOrg);

        if ($pvBalance < $amount) {
            $leader->sendMessage("§c§l[Казна] §6§lНедостаточно средств в казне Правительства.");
            $leader->sendMessage("§6§l[Казна] §e§lТребуется: §c§l" . number_format($amount) . "\$ §e§l| Баланс: §a§l" . number_format($pvBalance) . "\$");
            return;
        }

        $this->removeBalance($pvOrg, $amount);
        $result = $this->govFundOrg($orgKey, $amount, $leader->getName());
        $coloredOrg = $this->plugin->getColoredOrgName($orgKey);
        $rankName = $this->plugin->getRealRankName($leader->getName());
        $newPvBalance = $this->getBalance($pvOrg);

        if ($result === "ok") {
            $leader->sendMessage("§6§l[Казна] §a§l" . number_format($amount) . "\$ §e§lуспешно переведено в казну {$coloredOrg}");
            $leader->sendMessage("§6§l[Казна] §e§lБаланс казны Правительства: §a§l" . number_format($newPvBalance) . "\$");
            $this->plugin->addLog($pvOrg, "§e§l{$leader->getName()} §6§l({$rankName}§6§l) выделил {$coloredOrg} §6§lсумму §a§l" . number_format($amount) . "\$§6§l. Баланс ПВ: §a§l" . number_format($newPvBalance) . "\$");
        } else {
            $this->addBalance($pvOrg, $amount);
            $leader->sendMessage("§c§l[Казна] §6§lОрганизация {$coloredOrg} §6§lне имеет назначенного руководителя. Перевод отменён.");
        }
    }

    public function adminFundOrg(string $orgKey, float $amount, string $adminName): string {
        $hasLeader = false;
        foreach ($this->plugin->data->getAll() as $key => $data) {
            if (isset($data['org']) && $data['org'] === $orgKey && isset($data['rank']) && $data['rank'] === 16) {
                $hasLeader = true;
                break;
            }
        }

        if (!$hasLeader) return "no_leader";

        $this->addBalance($orgKey, $amount);
        $newBalance = $this->getBalance($orgKey);
        $this->plugin->addLog($orgKey, "§b§l[Администратор] §e§l{$adminName} §6§lпополнил казну на §a§l" . number_format($amount) . "\$§6§l. Баланс: §a§l" . number_format($newBalance) . "\$");
        return "ok";
    }

    public function adminFundAll(\pocketmine\command\CommandSender $sender, float $amount): void {
        $orgs = $this->plugin->getConfig()->get("orgs", []);

        $success = [];
        $noLeader = [];

        foreach ($orgs as $key => $name) {
            if ($key === "MF") continue;
            $result = $this->adminFundOrg($key, $amount, $sender->getName());
            $coloredOrg = $this->plugin->getColoredOrgName($key);
            if ($result === "ok") {
                $success[] = $coloredOrg . " §e§l(+" . number_format($amount) . "\$§e§l)";
            } else {
                $noLeader[] = $coloredOrg;
            }
        }

        $sender->sendMessage("§6§l[Казна] §e§lАдминистративное пополнение выполнено.");

        if (!empty($success)) {
            $sender->sendMessage("§a§l[Казна] §6§lПолучили финансирование:");
            foreach ($success as $s) {
                $sender->sendMessage("  §e§l- {$s}");
            }
        }

        if (!empty($noLeader)) {
            $sender->sendMessage("§c§l[Казна] §6§lНе получили (нет руководителя):");
            foreach ($noLeader as $n) {
                $sender->sendMessage("  §7§l- {$n}");
            }
        }
    }
}