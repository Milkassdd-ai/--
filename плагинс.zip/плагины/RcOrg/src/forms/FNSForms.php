<?php

namespace InzeOwr\RcOrg\forms;

use pocketmine\player\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use InzeOwr\RcOrg\Main;

class FNSForms {

    private static function getRcTel(): ?object {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("RcTel");
        if ($plugin !== null && $plugin->isEnabled()) return $plugin;
        return null;
    }

    private static function findNameByPhone(string $phoneNumber): ?string {
        $rcTel = self::getRcTel();
        if ($rcTel === null) return null;
        $file = $rcTel->getDataFolder() . "data/phones.json";
        if (!file_exists($file)) return null;
        $allData = json_decode(file_get_contents($file), true);
        if (!is_array($allData)) return null;
        $cleanInput = preg_replace('/[^0-9+]/', '', $phoneNumber);
        foreach ($allData as $name => $data) {
            if (!isset($data['number'])) continue;
            $cleanNumber = preg_replace('/[^0-9+]/', '', $data['number']);
            if ($cleanNumber === $cleanInput) return (string)$name;
        }
        return null;
    }

    private static function resolveTarget(string $input): ?string {
        $rcTel = self::getRcTel();
        if ($rcTel === null) return null;
        if ($rcTel->hasSim($input)) return $input;
        $found = $rcTel->findPlayerByPartialName($input);
        if ($found !== null && $rcTel->hasSim($found)) return $found;
        $byPhone = self::findNameByPhone($input);
        if ($byPhone !== null) return $byPhone;
        return null;
    }

    private static function getFNSAccessLevel(Player $player): int {
        $api = Main::getInstance();
        $org = $api->getPlayerOrg($player->getName());
        $pvRank = $api->getPlayerRank($player->getName());
        $fnsRank = $api->getFNSSystem()->getFNSRank($player->getName());
        if ($org === "PV" && $pvRank >= 16 && $pvRank <= 100) return 3;
        if ($fnsRank >= 5) return 2;
        if ($fnsRank >= 4) return 1;
        if ($fnsRank >= 1) return 0;
        return -1;
    }

    private static function parseTimeString(string $input): ?int {
        $input = trim($input);
        if (preg_match('/^(\d+)\s*(s|m|h|d)$/i', $input, $m)) {
            $val = (int)$m[1];
            if ($val <= 0) return null;
            return match(strtolower($m[2])) {
                's' => $val,
                'm' => $val * 60,
                'h' => $val * 3600,
                'd' => $val * 86400,
                default => null
            };
        }
        return null;
    }

    private static function formatDuration(int $seconds): string {
        if ($seconds <= 0) return "0 сек.";
        $d = floor($seconds / 86400);
        $h = floor(($seconds % 86400) / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        $parts = [];
        if ($d > 0) $parts[] = "{$d} дн.";
        if ($h > 0) $parts[] = "{$h} ч.";
        if ($m > 0) $parts[] = "{$m} мин.";
        if ($s > 0 || empty($parts)) $parts[] = "{$s} сек.";
        return implode(" ", $parts);
    }

    public static function openFNSTabletMenu(Player $player): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $fnsRank = $fns->getFNSRank($player->getName());
        $pvRank = $api->getPlayerRank($player->getName());
        $role = "";
        if ($fnsRank > 0) {
            $role = "§e" . $fns->getFNSRankName($fnsRank);
        } elseif ($pvRank >= 16) {
            $role = "§6" . $api->getRankName("PV", $pvRank);
        }
        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) return;
            switch ($data) {
                case 0: self::openFinanceSearchForm($player); break;
                case 1: self::openDepartmentsMenu($player); break;
            }
        });
        $form->setTitle("§l§eПланшет ФНС");
        $form->setContent(
            "§l§eФЕДЕРАЛЬНАЯ НАЛОГОВАЯ СЛУЖБА\n\n" .
            "§r§l§fСотрудник: §e{$player->getName()}\n" .
            "§l§fДолжность: {$role}\n\n" .
            "§l§7Выберите раздел:"
        );
        $form->addButton("§l§6ДЕНЕЖНЫЕ СРЕДСТВА\n§r§l§7Финансовый мониторинг граждан");
        $form->addButton("§l§dМЕНЮ ОТДЕЛОВ ФНС\n§r§l§7Управление сотрудниками");
        $player->sendForm($form);
    }

    public static function openFinanceSearchForm(Player $player): void {
        $form = new CustomForm(function (Player $player, $data) {
            if ($data === null) { self::openFNSTabletMenu($player); return; }
            $input = trim($data[1] ?? "");
            if (empty($input)) {
                $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fВведите номер телефона или ник.");
                return;
            }
            $targetName = self::resolveTarget($input);
            if ($targetName === null) {
                $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fГражданин не найден в базе данных.");
                return;
            }
            self::openFinanceInfoForm($player, $targetName);
        });
        $form->setTitle("§l§6Поиск гражданина");
        $form->addLabel("§l§eФИНАНСОВЫЙ МОНИТОРИНГ\n\n§r§l§fВведите номер телефона или ник гражданина.\n\n§l§7Формат: +7 (XXX) XXX-XX-XX или ник");
        $form->addInput("§l§fНомер / Ник:", "+7 (900) 000-00-00");
        $player->sendForm($form);
    }

    public static function openFinanceInfoForm(Player $player, string $targetName): void {
        $api = Main::getInstance();
        $rcTel = self::getRcTel();
        if ($rcTel === null) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fСистема телекоммуникаций недоступна."); return; }

        $hasSim = $rcTel->hasSim($targetName);
        $hasPhone = $rcTel->hasPhone($targetName);
        $phoneNumber = $hasSim ? $rcTel->getPhoneNumber($targetName) : "Не зарегистрирован";
        $phoneBalance = $hasSim ? $rcTel->getPhoneBalance($targetName) : 0.0;
        $battery = $hasPhone ? $rcTel->getBatteryPercent($targetName) : 0;
        $cashBalance = $rcTel->getMoney($targetName);
        $fio = $api->getFio($targetName);
        $org = $api->getPlayerOrg($targetName);
        $orgStr = $org ? $api->getColoredOrgName($org) . " §f(" . $api->getRealRankName($targetName) . ")" : "§7Безработный";
        $isOnline = Server::getInstance()->getPlayerExact($targetName) !== null;
        $statusStr = $isOnline ? "§aВ сети" : "§cНе в сети";
        $accounts = $rcTel->getPlayerAccounts($targetName);
        $totalBank = 0.0;
        foreach ($accounts as $acc) $totalBank += (float)($acc['balance'] ?? 0.0);
        $batteryColor = $battery <= 20 ? "§c" : ($battery <= 50 ? "§e" : "§a");

        $content = "§l§eДОСЬЕ ФИНАНСОВОГО МОНИТОРИНГА\n";
        $content .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $content .= "§l§fФИО: §b{$fio}\n";
        $content .= "§l§fНик: §e{$targetName}\n";
        $content .= "§l§fСтатус: {$statusStr}\n";
        $content .= "§l§fОрганизация: {$orgStr}\n\n";
        $content .= "§l§6ТЕЛЕКОММУНИКАЦИИ:\n";
        $content .= "§r§l§fНомер: §b{$phoneNumber}\n";
        $content .= "§l§fSIM: " . ($hasSim ? "§aАктивна" : "§cНет") . " §f| Телефон: " . ($hasPhone ? "§aЕсть" : "§cНет") . "\n";
        $content .= "§l§fБаланс тел.: §e" . number_format($phoneBalance, 2) . " руб.\n";
        if ($hasPhone) $content .= "§l§fЗаряд: {$batteryColor}{$battery}%\n";
        $content .= "\n§l§aФИНАНСЫ:\n";
        $content .= "§r§l§fНаличные: §e" . number_format($cashBalance, 2) . "\$\n";
        $content .= "§l§fСчетов: §e" . count($accounts) . " §f| Банк. баланс: §e" . number_format($totalBank, 2) . "\$\n";
        $content .= "§l§fОбщие активы: §6" . number_format($cashBalance + $totalBank, 2) . "\$\n";
        $content .= "\n§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";

        $form = new SimpleForm(function (Player $player, $data) use ($targetName) {
            if ($data === null) return;
            switch ($data) {
                case 0: self::openFinanceTransfersView($player, $targetName); break;
                case 1: self::openFinanceBankAccountsList($player, $targetName); break;
                case 2: self::openFinanceSearchForm($player); break;
            }
        });
        $form->setTitle("§l§8ФНС | {$targetName}");
        $form->setContent($content);
        $form->addButton("§l§6ИСТОРИЯ ПЕРЕВОДОВ\n§r§l§7За последние 7 дней");
        $form->addButton("§l§3БАНКОВСКИЕ СЧЕТА\n§r§l§7Счета и депозиты");
        $form->addButton("§l§e<- НОВЫЙ ПОИСК");
        $player->sendForm($form);
    }

    public static function openFinanceTransfersView(Player $player, string $targetName): void {
        $rcTel = self::getRcTel();
        if ($rcTel === null) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fСистема недоступна."); return; }

        $history = $rcTel->getTransferHistory($targetName, 7);
        $outgoing = [];
        $incoming = [];
        $totalOut = 0.0;
        $totalIn = 0.0;

        foreach ($history as $entry) {
            if (($entry['dir'] ?? '') === 'out') {
                $outgoing[] = $entry;
                $totalOut += (float)($entry['sum'] ?? 0);
            } else {
                $incoming[] = $entry;
                $totalIn += (float)($entry['sum'] ?? 0);
            }
        }

        $outCount = count($outgoing);
        $inCount = count($incoming);

        $content = "§l§6ИСТОРИЯ ПЕРЕВОДОВ: §e{$targetName}\n";
        $content .= "§r§l§7Период: последние 7 дней\n";
        $content .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";

        $content .= "§l§cИСХОДЯЩИЕ ({$outCount}):\n";
        if (empty($outgoing)) {
            $content .= "§r§l§7  Нет исходящих переводов.\n";
        } else {
            foreach (array_slice($outgoing, 0, 15) as $i => $t) {
                $num = $i + 1;
                $to = $t['with'] ?? '???';
                $sum = number_format((float)($t['sum'] ?? 0), 2);
                $time = isset($t['t']) ? date("d.m.Y H:i:s", $t['t']) : "-";
                $type = $t['type'] ?? 'transfer';
                $content .= "§r§l§f  {$num}. §c-> §e{$to} §f| §e{$sum} руб.\n";
                $content .= "§r§l§7     {$time} [{$type}]\n";
            }
            if ($outCount > 15) {
                $content .= "§r§l§7  ... и ещё " . ($outCount - 15) . " записей\n";
            }
        }

        $content .= "\n§l§aВХОДЯЩИЕ ({$inCount}):\n";
        if (empty($incoming)) {
            $content .= "§r§l§7  Нет входящих переводов.\n";
        } else {
            foreach (array_slice($incoming, 0, 15) as $i => $t) {
                $num = $i + 1;
                $from = $t['with'] ?? '???';
                $sum = number_format((float)($t['sum'] ?? 0), 2);
                $time = isset($t['t']) ? date("d.m.Y H:i:s", $t['t']) : "-";
                $type = $t['type'] ?? 'transfer';
                $content .= "§r§l§f  {$num}. §a<- §b{$from} §f| §e{$sum} руб.\n";
                $content .= "§r§l§7     {$time} [{$type}]\n";
            }
            if ($inCount > 15) {
                $content .= "§r§l§7  ... и ещё " . ($inCount - 15) . " записей\n";
            }
        }

        $content .= "\n§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§fИсходящих: §c" . number_format($totalOut, 2) . " руб.\n";
        $content .= "§l§fВходящих: §a" . number_format($totalIn, 2) . " руб.\n";
        $content .= "§l§fОборот: §6" . number_format($totalOut + $totalIn, 2) . " руб.\n";
        $content .= "§l§fВсего операций: §e" . count($history) . "\n";
        $content .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§l§7Дата отчёта: " . date("d.m.Y H:i:s");

        $form = new SimpleForm(function (Player $player, $data) use ($targetName) {
            if ($data === null) return;
            if ($data === 0) self::openFinanceInfoForm($player, $targetName);
        });
        $form->setTitle("§l§6Переводы | {$targetName}");
        $form->setContent($content);
        $form->addButton("§l§e<- НАЗАД К ДОСЬЕ");
        $player->sendForm($form);
    }

    public static function openFinanceBankAccountsList(Player $player, string $targetName): void {
        $rcTel = self::getRcTel();
        if ($rcTel === null) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fСистема недоступна."); return; }
        $accounts = $rcTel->getPlayerAccounts($targetName);

        $form = new SimpleForm(function (Player $player, $data) use ($targetName, $accounts) {
            if ($data === null) return;
            if ($data === 0) { self::openFinanceInfoForm($player, $targetName); return; }
            $keys = array_keys($accounts);
            $index = $data - 1;
            if (isset($keys[$index])) self::openFinanceBankAccountDetail($player, $targetName, $keys[$index]);
        });

        $form->setTitle("§l§3Счета | {$targetName}");
        $content = "§l§3БАНКОВСКИЕ СЧЕТА: §e{$targetName}\n";
        $content .= "§r§l§fВсего счетов: §e" . count($accounts) . "\n\n";
        $content .= empty($accounts) ? "§l§7Нет открытых счетов." : "§l§7Выберите счёт:";
        $form->setContent($content);
        $form->addButton("§l§e<- НАЗАД К ДОСЬЕ");

        foreach ($accounts as $accId => $accData) {
            $accName = $accData['name'] ?? "Без названия";
            $accBalance = (float)($accData['balance'] ?? 0.0);
            $status = "";
            if ($accData['frozen'] ?? false) $status = " §c[ЗАМОРОЖЕН]";
            if ($accData['blocked'] ?? false) $status = " §4[ЗАБЛОКИРОВАН]";
            $form->addButton("§l§3{$accName}{$status}\n§r§l§7{$accId} | §e" . number_format($accBalance, 2) . "\$");
        }
        $player->sendForm($form);
    }

    public static function openFinanceBankAccountDetail(Player $player, string $targetName, string $accountId): void {
        $rcTel = self::getRcTel();
        if ($rcTel === null) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fСистема недоступна."); return; }
        $accounts = $rcTel->getPlayerAccounts($targetName);
        if (!isset($accounts[$accountId])) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fСчёт не найден."); return; }

        $acc = $accounts[$accountId];
        $deposits = $rcTel->getDeposits($targetName, $accountId);
        $isFrozen = $rcTel->isAccountFrozen($targetName, $accountId);
        $isBlocked = $rcTel->isAccountBlocked($targetName, $accountId);
        $accessLevel = self::getFNSAccessLevel($player);

        $content = "§l§3ДЕТАЛИ БАНКОВСКОГО СЧЁТА\n";
        $content .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $content .= "§l§fВладелец: §e{$targetName}\n";
        $content .= "§l§fНазвание: §3{$acc['name']}\n";
        $content .= "§l§fНомер: §7{$accountId}\n";
        $content .= "§l§fБаланс: §e" . number_format((float)($acc['balance'] ?? 0), 2) . "\$\n";
        $content .= "§l§fОткрыт: §7" . (isset($acc['created']) ? date("d.m.Y H:i", $acc['created']) : "-") . "\n";

        if ($isFrozen) {
            $freezeInfo = $rcTel->getFreezeInfo($targetName, $accountId);
            $content .= "\n§l§c[ЗАМОРОЖЕН]\n";
            $content .= "§r§l§fЗаморозил: §c" . ($freezeInfo['by'] ?? '?') . "\n";
            if (($freezeInfo['at'] ?? 0) > 0) $content .= "§l§fДата: §7" . date("d.m.Y H:i", $freezeInfo['at']) . "\n";
        }

        if ($isBlocked) {
            $blockInfo = $rcTel->getBlockInfo($targetName, $accountId);
            $content .= "\n§l§4[ЗАБЛОКИРОВАН]\n";
            $content .= "§r§l§fЗаблокировал: §4" . ($blockInfo['by'] ?? '?') . "\n";
            if (($blockInfo['at'] ?? 0) > 0) $content .= "§l§fДата: §7" . date("d.m.Y H:i", $blockInfo['at']) . "\n";
            $until = $blockInfo['until'] ?? 0;
            if ($until === -1) {
                $content .= "§l§fСрок: §4НАВСЕГДА\n";
            } elseif ($until > time()) {
                $remaining = $until - time();
                $content .= "§l§fИстекает: §e" . date("d.m.Y H:i", $until) . "\n";
                $content .= "§l§fОсталось: §e" . self::formatDuration($remaining) . "\n";
            }
        }

        $content .= "\n§l§6ДЕПОЗИТЫ:\n";
        $content .= "§r§8━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        if (empty($deposits)) {
            $content .= "§l§7Активных депозитов нет.\n";
        } else {
            $totalDep = 0.0;
            $num = 1;
            foreach ($deposits as $depId => $dep) {
                $amount = (float)($dep['amount'] ?? 0);
                $original = (float)($dep['original_amount'] ?? 0);
                $percent = (float)($dep['percent'] ?? 0);
                $days = (int)($dep['days'] ?? 0);
                $profit = $amount - $original;
                $remainDays = isset($dep['expires']) ? max(0, (int)ceil(($dep['expires'] - time()) / 86400)) : 0;
                $content .= "\n§l§e> #{$num} §7({$depId})\n";
                $content .= "§r§l§f  Сумма: §e" . number_format($amount, 2) . "\$ §7(нач. " . number_format($original, 2) . "\$)\n";
                $content .= "§l§f  Прибыль: §a+" . number_format($profit, 2) . "\$ §7| {$percent}% за {$days} дн.\n";
                $content .= "§l§f  Осталось: §e{$remainDays} дн.\n";
                $totalDep += $amount;
                $num++;
            }
            $content .= "\n§l§fИтого в депозитах: §6" . number_format($totalDep, 2) . "\$\n";
        }

        $buttons = [];
        $buttons[] = ["text" => "§l§3<- НАЗАД К СЧЕТАМ", "action" => "back"];

        if ($accessLevel >= 1 || $accessLevel === 3) {
            if ($isFrozen) {
                $buttons[] = ["text" => "§l§aРАЗМОРОЗИТЬ СЧЁТ\n§r§l§7Снять ограничения", "action" => "unfreeze"];
            } else {
                $buttons[] = ["text" => "§l§cЗАМОРОЗИТЬ СЧЁТ\n§r§l§7Запретить операции", "action" => "freeze"];
            }
        }

        if ($accessLevel >= 2 || $accessLevel === 3) {
            if ($isBlocked) {
                $buttons[] = ["text" => "§l§aРАЗБЛОКИРОВАТЬ СЧЁТ\n§r§l§7Восстановить доступ", "action" => "unblock"];
            } else {
                $buttons[] = ["text" => "§l§4ЗАБЛОКИРОВАТЬ СЧЁТ\n§r§l§7Ограничить доступ", "action" => "block"];
            }
        }

        $form = new SimpleForm(function (Player $player, $data) use ($targetName, $accountId, $buttons) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;
            $action = $buttons[$data]['action'];
            switch ($action) {
                case 'back': self::openFinanceBankAccountsList($player, $targetName); break;
                case 'freeze': self::openFreezeConfirm($player, $targetName, $accountId); break;
                case 'unfreeze': self::openUnfreezeConfirm($player, $targetName, $accountId); break;
                case 'block': self::openBlockMenu($player, $targetName, $accountId); break;
                case 'unblock': self::openUnblockConfirm($player, $targetName, $accountId); break;
            }
        });
        $form->setTitle("§l§3Счёт | {$accountId}");
        $form->setContent($content);
        foreach ($buttons as $btn) $form->addButton($btn['text']);
        $player->sendForm($form);
    }

    public static function openFreezeConfirm(Player $player, string $targetName, string $accountId): void {
        $form = new ModalForm(function (Player $player, ?bool $data) use ($targetName, $accountId) {
            if ($data === null || $data === false) { self::openFinanceBankAccountDetail($player, $targetName, $accountId); return; }
            $rcTel = self::getRcTel();
            if ($rcTel === null) return;
            $rcTel->freezeAccount($targetName, $accountId, $player->getName());
            $player->sendMessage("§a§l[§eФНС§a§l] §r§l§fСчёт §3{$accountId} §fгражданина §e{$targetName} §fзаморожен.");
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target) $target->sendMessage("§c§l[§eФНС§c§l] §r§l§fВаш банковский счёт §3{$accountId} §fзаморожен решением ФНС. Операции запрещены.");
            self::openFinanceBankAccountDetail($player, $targetName, $accountId);
        });
        $form->setTitle("§l§cЗаморозка счёта");
        $form->setContent(
            "§l§fВы собираетесь заморозить счёт:\n\n" .
            "§l§fВладелец: §e{$targetName}\n" .
            "§l§fСчёт: §3{$accountId}\n\n" .
            "§l§cПосле заморозки владелец не сможет:\n" .
            "§r§l§7- Пополнять счёт\n" .
            "§l§7- Снимать средства\n" .
            "§l§7- Совершать переводы\n" .
            "§l§7- Управлять депозитами\n\n" .
            "§l§fПодтвердить заморозку?"
        );
        $form->setButton1("§l§cДА, ЗАМОРОЗИТЬ");
        $form->setButton2("§l§aОТМЕНА");
        $player->sendForm($form);
    }

    public static function openUnfreezeConfirm(Player $player, string $targetName, string $accountId): void {
        $form = new ModalForm(function (Player $player, ?bool $data) use ($targetName, $accountId) {
            if ($data === null || $data === false) { self::openFinanceBankAccountDetail($player, $targetName, $accountId); return; }
            $rcTel = self::getRcTel();
            if ($rcTel === null) return;
            $rcTel->unfreezeAccount($targetName, $accountId);
            $player->sendMessage("§a§l[§eФНС§a§l] §r§l§fСчёт §3{$accountId} §fгражданина §e{$targetName} §fразморожен.");
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target) $target->sendMessage("§a§l[§eФНС§a§l] §r§l§fВаш банковский счёт §3{$accountId} §fразморожен. Операции доступны.");
            self::openFinanceBankAccountDetail($player, $targetName, $accountId);
        });
        $form->setTitle("§l§aРазморозка счёта");
        $form->setContent("§l§fРазморозить счёт §3{$accountId} §fгражданина §e{$targetName}§f?\n\n§l§7Все операции станут доступны владельцу.");
        $form->setButton1("§l§aДА, РАЗМОРОЗИТЬ");
        $form->setButton2("§l§cОТМЕНА");
        $player->sendForm($form);
    }

    public static function openBlockMenu(Player $player, string $targetName, string $accountId): void {
        $rcTel = self::getRcTel();
        if ($rcTel === null) return;
        $acc = $rcTel->getPlayerAccounts($targetName)[$accountId] ?? null;
        if ($acc === null) return;
        $balance = number_format((float)($acc['balance'] ?? 0), 2);

        $form = new SimpleForm(function (Player $player, $data) use ($targetName, $accountId) {
            if ($data === null) return;
            switch ($data) {
                case 0: self::openBlockPermanentConfirm($player, $targetName, $accountId); break;
                case 1: self::openBlockTemporaryForm($player, $targetName, $accountId); break;
                case 2: self::openFinanceBankAccountDetail($player, $targetName, $accountId); break;
            }
        });
        $form->setTitle("§l§4Блокировка счёта");
        $form->setContent(
            "§l§fВладелец: §e{$targetName}\n" .
            "§l§fСчёт: §3{$accountId}\n" .
            "§l§fБаланс: §e{$balance}\$\n\n" .
            "§l§cВыберите тип блокировки:"
        );
        $form->addButton("§l§4НАВСЕГДА\n§r§l§7Счёт удаляется из системы");
        $form->addButton("§l§eВРЕМЕННО\n§r§l§7Блокировка на указанный срок");
        $form->addButton("§l§a<- НАЗАД");
        $player->sendForm($form);
    }

    public static function openBlockPermanentConfirm(Player $player, string $targetName, string $accountId): void {
        $rcTel = self::getRcTel();
        if ($rcTel === null) return;
        $acc = $rcTel->getPlayerAccounts($targetName)[$accountId] ?? null;
        if ($acc === null) return;
        $deposits = $rcTel->getDeposits($targetName, $accountId);
        $totalBalance = (float)($acc['balance'] ?? 0);
        $totalDep = 0.0;
        foreach ($deposits as $dep) $totalDep += (float)($dep['amount'] ?? 0);
        $totalConfiscated = $totalBalance + $totalDep;

        $form = new ModalForm(function (Player $player, ?bool $data) use ($targetName, $accountId) {
            if ($data === null || $data === false) { self::openBlockMenu($player, $targetName, $accountId); return; }
            $rcTel = self::getRcTel();
            if ($rcTel === null) return;
            $confiscated = $rcTel->deleteAccountByFNS($targetName, $accountId);
            $player->sendMessage("§4§l[§eФНС§4§l] §r§l§fСчёт §3{$accountId} §fгражданина §e{$targetName} §fЗАБЛОКИРОВАН НАВСЕГДА.");
            $player->sendMessage("§l§7Конфисковано: §e" . number_format($confiscated, 2) . "\$");
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target) {
                $target->sendMessage("§4§l[§eФНС§4§l] §r§l§fВаш банковский счёт §3{$accountId} §fзаблокирован навсегда решением ФНС.");
                $target->sendMessage("§l§7Средства конфискованы. Счёт удалён из банковской системы.");
            }
            self::openFinanceBankAccountsList($player, $targetName);
        });
        $form->setTitle("§l§4ПЕРМАНЕНТНАЯ БЛОКИРОВКА");
        $form->setContent(
            "§l§4ВНИМАНИЕ! НЕОБРАТИМОЕ ДЕЙСТВИЕ!\n\n" .
            "§r§l§fВладелец: §e{$targetName}\n" .
            "§l§fСчёт: §3{$accountId}\n\n" .
            "§l§fБаланс счёта: §e" . number_format($totalBalance, 2) . "\$\n" .
            "§l§fДепозиты: §e" . number_format($totalDep, 2) . "\$\n" .
            "§l§fК конфискации: §c" . number_format($totalConfiscated, 2) . "\$\n\n" .
            "§l§4Счёт будет УДАЛЁН из банковской системы.\n" .
            "§l§4Все средства и депозиты будут конфискованы.\n" .
            "§l§4Это действие НЕЛЬЗЯ отменить!\n\n" .
            "§l§fВы уверены?"
        );
        $form->setButton1("§l§4ДА, ЗАБЛОКИРОВАТЬ НАВСЕГДА");
        $form->setButton2("§l§aОТМЕНА");
        $player->sendForm($form);
    }

    public static function openBlockTemporaryForm(Player $player, string $targetName, string $accountId): void {
        $form = new CustomForm(function (Player $player, $data) use ($targetName, $accountId) {
            if ($data === null) { self::openBlockMenu($player, $targetName, $accountId); return; }
            $timeStr = trim($data[1] ?? "");
            if (empty($timeStr)) {
                $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fВведите время блокировки.");
                return;
            }
            $seconds = self::parseTimeString($timeStr);
            if ($seconds === null || $seconds < 60) {
                $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fНекорректный формат. Используйте: 30m, 2h, 1d (мин. 60 сек.)");
                return;
            }
            if ($seconds > 30 * 86400) {
                $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fМаксимальный срок - 30 дней.");
                return;
            }
            $rcTel = self::getRcTel();
            if ($rcTel === null) return;
            $rcTel->blockAccount($targetName, $accountId, $player->getName(), $seconds);
            $durationStr = self::formatDuration($seconds);
            $player->sendMessage("§e§l[§eФНС§e§l] §r§l§fСчёт §3{$accountId} §fгражданина §e{$targetName} §fзаблокирован на §e{$durationStr}§f.");
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target) {
                $target->sendMessage("§c§l[§eФНС§c§l] §r§l§fВаш банковский счёт §3{$accountId} §fзаблокирован на §e{$durationStr}§f.");
                $target->sendMessage("§l§7Доступ к счёту временно ограничен решением ФНС.");
            }
            self::openFinanceBankAccountDetail($player, $targetName, $accountId);
        });
        $form->setTitle("§l§eВременная блокировка");
        $form->addLabel(
            "§l§fВладелец: §e{$targetName}\n" .
            "§l§fСчёт: §3{$accountId}\n\n" .
            "§l§7Введите срок блокировки.\n" .
            "§l§7Формат: число + единица\n\n" .
            "§l§e30s §7= 30 секунд\n" .
            "§l§e10m §7= 10 минут\n" .
            "§l§e2h §7= 2 часа\n" .
            "§l§e1d §7= 1 день\n\n" .
            "§l§7Мин: 60 сек. | Макс: 30 дней"
        );
        $form->addInput("§l§fСрок блокировки:", "2h");
        $player->sendForm($form);
    }

    public static function openUnblockConfirm(Player $player, string $targetName, string $accountId): void {
        $rcTel = self::getRcTel();
        if ($rcTel === null) return;
        $blockInfo = $rcTel->getBlockInfo($targetName, $accountId);
        $blockedBy = $blockInfo['by'] ?? '?';
        $blockedAt = ($blockInfo['at'] ?? 0) > 0 ? date("d.m.Y H:i", $blockInfo['at']) : "-";
        $until = $blockInfo['until'] ?? 0;
        $untilStr = ($until === -1) ? "Бессрочно" : (($until > 0) ? date("d.m.Y H:i", $until) : "-");

        $form = new ModalForm(function (Player $player, ?bool $data) use ($targetName, $accountId) {
            if ($data === null || $data === false) { self::openFinanceBankAccountDetail($player, $targetName, $accountId); return; }
            $rcTel = self::getRcTel();
            if ($rcTel === null) return;
            $rcTel->unblockAccount($targetName, $accountId);
            $player->sendMessage("§a§l[§eФНС§a§l] §r§l§fСчёт §3{$accountId} §fгражданина §e{$targetName} §fразблокирован.");
            $target = Server::getInstance()->getPlayerExact($targetName);
            if ($target) $target->sendMessage("§a§l[§eФНС§a§l] §r§l§fВаш банковский счёт §3{$accountId} §fразблокирован. Доступ восстановлен.");
            self::openFinanceBankAccountDetail($player, $targetName, $accountId);
        });
        $form->setTitle("§l§aРазблокировка счёта");
        $form->setContent(
            "§l§fРазблокировать счёт §3{$accountId}§f?\n\n" .
            "§l§fВладелец: §e{$targetName}\n" .
            "§l§fЗаблокировал: §7{$blockedBy}\n" .
            "§l§fДата блокировки: §7{$blockedAt}\n" .
            "§l§fСрок: §7{$untilStr}\n\n" .
            "§l§7Доступ владельца к счёту будет восстановлен."
        );
        $form->setButton1("§l§aДА, РАЗБЛОКИРОВАТЬ");
        $form->setButton2("§l§cОТМЕНА");
        $player->sendForm($form);
    }

    public static function openDepartmentsMenu(Player $player): void {
        $api = Main::getInstance();
        $coloredPV = $api->getColoredOrgName("PV");
        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) return;
            if ($data === 0) self::openFNSMenu($player);
            if ($data === 1) self::openFNSTabletMenu($player);
        });
        $fnsCount = $api->getFNSSystem()->getFNSMemberCount();
        $form->setTitle("§l§6ОТДЕЛЫ | {$coloredPV}");
        $form->setContent("§l§fВыберите отдел:");
        $form->addButton("§l§eФедеральная Налоговая Служба\n§r§l§7Сотрудников: {$fnsCount}");
        $form->addButton("§l§6<- НАЗАД К ПЛАНШЕТУ");
        $player->sendForm($form);
    }

    public static function openFNSMenu(Player $player): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $coloredPV = $api->getColoredOrgName("PV");
        $leader = $fns->getFNSLeader();
        $leaderStr = $leader
            ? "§l§fРуководитель: §e{$leader['fio']} §7({$leader['nick']})\n§l§fДата назначения: §7{$leader['date']}"
            : "§l§fРуководитель: §7Должность вакантна";
        $memberCount = $fns->getFNSMemberCount();
        $playerFnsRank = $fns->getFNSRank($player->getName());
        $playerFnsRankName = $playerFnsRank > 0 ? $fns->getFNSRankName($playerFnsRank) : null;
        $content = "§l§eФЕДЕРАЛЬНАЯ НАЛОГОВАЯ СЛУЖБА\n§r§l§7Подразделение {$coloredPV}\n\n";
        $content .= "§8==============================\n{$leaderStr}\n§8==============================\n\n";
        $content .= "§l§fВсего сотрудников: §e{$memberCount}\n";
        if ($playerFnsRankName) $content .= "\n§l§aВаша должность: §e{$playerFnsRankName} ({$playerFnsRank})\n";
        $buttons = [];
        if ($playerFnsRank > 0) $buttons[] = ["text" => "§l§bЛИЧНОЕ ДЕЛО ФНС\n§r§l§7Досье, ЗП, Увольнение", "action" => "personal"];
        $buttons[] = ["text" => "§l§dБАЗА СОТРУДНИКОВ ФНС\n§r§l§7Список и управление", "action" => "staff"];
        $buttons[] = ["text" => "§l§6<- НАЗАД К ОТДЕЛАМ", "action" => "back"];
        $form = new SimpleForm(function (Player $player, $data) use ($buttons) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;
            switch ($buttons[$data]['action']) {
                case 'personal': self::openFNSPersonalFile($player); break;
                case 'staff': self::openFNSStaffList($player); break;
                case 'back': self::openDepartmentsMenu($player); break;
            }
        });
        $form->setTitle("§l§eФедеральная Налоговая Служба");
        $form->setContent($content);
        foreach ($buttons as $btn) $form->addButton($btn['text']);
        $player->sendForm($form);
    }

    public static function openFNSPersonalFile(Player $player): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $coloredPV = $api->getColoredOrgName("PV");
        if (!$fns->isInFNS($player->getName())) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fВы не состоите в ФНС."); return; }
        $fnsRank = $fns->getFNSRank($player->getName());
        $fnsRankName = $fns->getFNSRankName($fnsRank);
        $fnsJoinDate = $fns->getFNSJoinDate($player->getName());
        $savedPVRank = $fns->getSavedPVRank($player->getName());
        $savedPVRankName = $api->getRankName("PV", $savedPVRank);
        $fio = $api->getFio($player->getName());
        $lastSalary = $fns->getLastFNSSalary($player->getName());
        $diff = 1200 - (time() - $lastSalary);
        $salaryTime = ($diff > 0) ? "§c" . floor($diff / 60) . " мин. " . ($diff % 60) . " сек." : "§aГотова к выдаче";
        $salary = $fns->getFNSSalary($fnsRank);
        $content = "§l§eЛИЧНОЕ ДЕЛО СОТРУДНИКА ФНС:\n\n";
        $content .= "§r§l§fФИО: §b{$fio}\n§l§fПозывной: §7{$player->getName()}\n\n";
        $content .= "§l§eДОЛЖНОСТЬ:\n§r§l§f>> §e{$fnsRankName} ({$fnsRank})\n§l§fДата вступления: §7{$fnsJoinDate}\n\n";
        $content .= "§l§7СОХРАНЁННЫЙ РАНГ {$coloredPV}§l§7:\n§r§l§f>> §6{$savedPVRankName} ({$savedPVRank})\n\n";
        $content .= "§l§aБУХГАЛТЕРИЯ:\n§r§l§fЗарплата: §e" . number_format($salary) . "\$\n§l§fСтатус: {$salaryTime}\n";
        $form = new SimpleForm(function (Player $player, $data) use ($fns) {
            if ($data === null) return;
            switch ($data) {
                case 0: $fns->collectFNSSalary($player); break;
                case 1: self::openFNSLeaveConfirm($player); break;
                case 2: self::openFNSMenu($player); break;
            }
        });
        $form->setTitle("§l§eЛичное дело ФНС");
        $form->setContent($content);
        $form->addButton("§l§aПОЛУЧИТЬ ЗАРПЛАТУ\n§r§l§7Забрать жалование");
        $form->addButton("§l§cУВОЛИТЬСЯ ИЗ ФНС\n§r§l§4По собственному желанию");
        $form->addButton("§l§6<- НАЗАД");
        $player->sendForm($form);
    }

    public static function openFNSLeaveConfirm(Player $player): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $coloredPV = $api->getColoredOrgName("PV");
        $fnsRank = $fns->getFNSRank($player->getName());
        $fnsRankName = $fns->getFNSRankName($fnsRank);
        $savedPVRank = $fns->getSavedPVRank($player->getName());
        $savedPVRankName = $api->getRankName("PV", $savedPVRank);
        $form = new ModalForm(function (Player $player, ?bool $data) use ($api) {
            if ($data === null) return;
            if ($data === true) $api->getFNSSystem()->selfLeave($player);
            else $player->sendMessage("§a§l[§eФНС§a§l] §r§l§fУвольнение отменено.");
        });
        $form->setTitle("§l§cУВОЛЬНЕНИЕ ИЗ ФНС");
        $form->setContent(
            "§l§cВНИМАНИЕ!\n\n§r§l§fВаша должность: §e{$fnsRankName} ({$fnsRank})\n\n" .
            "§l§7> Должность в ФНС аннулируется.\n§l§7> Ранг в {$coloredPV} §7восстановится:\n§l§a> {$savedPVRankName} ({$savedPVRank})\n\n" .
            "§l§fВы уверены?"
        );
        $form->setButton1("§l§cДА, УВОЛИТЬСЯ");
        $form->setButton2("§l§aНЕТ, ОСТАТЬСЯ");
        $player->sendForm($form);
    }

    public static function openFNSStaffList(Player $player): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $members = $fns->getAllFNSMembers();
        $form = new SimpleForm(function (Player $player, $data) use ($members) {
            if ($data === null) return;
            if ($data === 0) { self::openFNSMenu($player); return; }
            $index = $data - 1;
            if (isset($members[$index])) self::openFNSDossier($player, $members[$index]['name']);
        });
        $form->setTitle("§l§eБАЗА СОТРУДНИКОВ ФНС");
        $form->setContent("§l§fВсего: §e" . count($members));
        $form->addButton("§l§6<- НАЗАД");
        foreach ($members as $member) {
            $rankName = $fns->getFNSRankName($member['rank']);
            $isOnline = Server::getInstance()->getPlayerExact($member['name']) !== null;
            $status = $isOnline ? "§a[На службе]" : "§c[Не в сети]";
            $form->addButton("§l{$member['name']}\n§r§l§7{$rankName} ({$member['rank']}) {$status}");
        }
        $player->sendForm($form);
    }

    public static function openFNSDossier(Player $player, string $targetName): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $coloredPV = $api->getColoredOrgName("PV");
        if (!$fns->isInFNS($targetName)) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§fСотрудник не найден."); return; }
        $fnsRank = $fns->getFNSRank($targetName);
        $fnsRankName = $fns->getFNSRankName($fnsRank);
        $fnsJoinDate = $fns->getFNSJoinDate($targetName);
        $savedPVRank = $fns->getSavedPVRank($targetName);
        $savedPVRankName = $api->getRankName("PV", $savedPVRank);
        $fio = $api->getFio($targetName);
        $isOnline = Server::getInstance()->getPlayerExact($targetName) ? "§aВ сети" : "§cНе в сети";
        $content = "§l§eДОСЬЕ СОТРУДНИКА ФНС:\n\n";
        $content .= "§r§l§fФИО: §b{$fio}\n§l§fПозывной: §7{$targetName}\n§l§fСтатус: {$isOnline}\n\n";
        $content .= "§l§eДОЛЖНОСТЬ:\n§r§l§f>> §e{$fnsRankName} ({$fnsRank})\n§l§fДата вступления: §7{$fnsJoinDate}\n\n";
        $content .= "§l§7СОХРАНЁННЫЙ РАНГ {$coloredPV}§l§7:\n§r§l§f>> §6{$savedPVRankName} ({$savedPVRank})\n";
        if ($api->getCourtSystem()->hasCriminalRecord($targetName)) $content .= "\n§l§cВНИМАНИЕ: Имеется судимость!\n";
        $buttons = [];
        $buttons[] = ["text" => "§l§6<- НАЗАД", "action" => "back"];
        $canManage = $fns->canManageFNS($player);
        $isSelf = strtolower($player->getName()) === strtolower($targetName);
        if ($canManage && !$isSelf) {
            $adminFnsRank = $fns->getFNSRank($player->getName());
            $adminPvRank = $api->getPlayerRank($player->getName());
            $adminOrg = $api->getPlayerOrg($player->getName());
            $canManageThis = false;
            if ($adminOrg === "PV" && $adminPvRank >= 16) $canManageThis = true;
            elseif ($adminFnsRank >= 5 && $fnsRank < $adminFnsRank) $canManageThis = true;
            if ($canManageThis) {
                if ($fnsRank < 6) $buttons[] = ["text" => "§l§aПОВЫСИТЬ\n§r§l§7Повышение ранга", "action" => "promote"];
                if ($fnsRank > 1) $buttons[] = ["text" => "§l§eПОНИЗИТЬ\n§r§l§7Понижение ранга", "action" => "demote"];
                $buttons[] = ["text" => "§l§cУВОЛИТЬ\n§r§l§7Снятие с должности", "action" => "fire"];
                if ($adminOrg === "PV" && $adminPvRank >= 16)
                    $buttons[] = ["text" => "§l§bСПЕЦ. НАЗНАЧЕНИЕ\n§r§l§7Выдать ранг", "action" => "setrank"];
            }
        }
        $form = new SimpleForm(function (Player $player, $data) use ($fns, $targetName, $buttons) {
            if ($data === null) return;
            if (!isset($buttons[$data])) return;
            switch ($buttons[$data]['action']) {
                case 'back': self::openFNSStaffList($player); break;
                case 'promote': $fns->promoteFNS($player, $targetName); break;
                case 'demote': $fns->demoteFNS($player, $targetName); break;
                case 'fire': self::openFNSFireConfirm($player, $targetName); break;
                case 'setrank': self::openFNSSetRankForm($player, $targetName); break;
            }
        });
        $form->setTitle("§l§8ФНС | {$targetName}");
        $form->setContent($content);
        foreach ($buttons as $btn) $form->addButton($btn['text']);
        $player->sendForm($form);
    }

    public static function openFNSFireConfirm(Player $player, string $targetName): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $rankName = $fns->getFNSRankName($fns->getFNSRank($targetName));
        $coloredPV = $api->getColoredOrgName("PV");
        $savedPVRank = $fns->getSavedPVRank($targetName);
        $savedPVRankName = $api->getRankName("PV", $savedPVRank);
        $form = new CustomForm(function (Player $player, $data) use ($api, $targetName) {
            if ($data === null) return;
            $reason = trim($data[1] ?? "");
            $api->getFNSSystem()->removeFromFNS($player, $targetName, $reason);
        });
        $form->setTitle("§l§cУВОЛЬНЕНИЕ ИЗ ФНС");
        $form->addLabel("§l§fСотрудник: §e{$targetName}\n§l§fДолжность: §e{$rankName}\n\n§l§7Ранг {$coloredPV} §7восстановится:\n§l§a>> {$savedPVRankName} ({$savedPVRank})");
        $form->addInput("§l§fПричина (необязательно):", "По решению руководства");
        $player->sendForm($form);
    }

    public static function openFNSSetRankForm(Player $player, string $targetName): void {
        $form = new CustomForm(function (Player $player, $data) use ($targetName) {
            if ($data === null) return;
            Main::getInstance()->getFNSSystem()->setFNSRank($player, $targetName, (int)$data[0]);
        });
        $form->setTitle("§l§bСПЕЦ. НАЗНАЧЕНИЕ ФНС");
        $form->addSlider("§l§fРанг для §e{$targetName}§f:", 1, 6, 1, 1);
        $player->sendForm($form);
    }

    public static function openInviteToFNSConfirm(Player $player, string $targetName): void {
        $api = Main::getInstance();
        $fns = $api->getFNSSystem();
        $coloredPV = $api->getColoredOrgName("PV");
        $check = $fns->canJoinFNS($targetName);
        if (!$check['success']) { $player->sendMessage("§c§l[§eФНС§c§l] §r§l§f" . $check['error']); return; }
        $fio = $api->getFio($targetName);
        $pvRank = $api->getPlayerRank($targetName);
        $pvRankName = $api->getRankName("PV", $pvRank);
        $firstRankName = $fns->getFNSRankName(1);
        $form = new ModalForm(function (Player $player, ?bool $data) use ($api, $targetName) {
            if ($data === null) return;
            if ($data === true) $api->getFNSSystem()->addToFNS($player, $targetName);
            else $player->sendMessage("§7§l[§eФНС§7§l] §r§l§fОтменено.");
        });
        $form->setTitle("§l§ePРИНЯТИЕ В ФНС");
        $form->setContent(
            "§l§fПринять в §eФНС§f:\n\n§l§fФИО: §b{$fio}\n§l§fНик: §e{$targetName}\n" .
            "§l§fДолжность в {$coloredPV}§f: §6{$pvRankName} ({$pvRank})\n\n" .
            "§l§7Будет принят на 1 ранг: §e{$firstRankName}\n§l§7Ранг {$coloredPV} §7сохранится.\n\n§l§fПодтвердить?"
        );
        $form->setButton1("§l§aДА, ПРИНЯТЬ");
        $form->setButton2("§l§cОТМЕНА");
        $player->sendForm($form);
    }
}